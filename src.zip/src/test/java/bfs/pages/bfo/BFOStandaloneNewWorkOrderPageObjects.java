package bfs.pages.bfo;
import com.codeborne.selenide.*;
import org.openqa.selenium.By;

import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.*;
import static bfs.pages.BasePage.highLightElement;

public class BFOStandaloneNewWorkOrderPageObjects {

    private final static By SEARCH_ACCOUNT_TETBOX = By.xpath("//label[contains(text(),'Installed At Account *')]/following-sibling::div//input[@placeholder='Search Accounts...']");
    private final static By SHOWALL_RESULTS_LIST = By.xpath("//ul[@role='group']//li");
//    private final static By WORKORDER_TYPE_BUTTON = By.xpath("//label[contains(text(),'Work Order Type *')]/following-sibling::div//button");
    private final static By WORKORDER_TYPE_BUTTON = By.xpath("//label[contains(text(),'Work Order Type *')]/parent::span/following-sibling::div//button");
//    private final static By WORKORDER_SUB_TYPE_BUTTON = By.xpath("//label[contains(text(),'Work Order Sub-Type *')]/following-sibling::div//button");
    private final static By WORKORDER_SUB_TYPE_BUTTON = By.xpath("//label[contains(text(),'Work Order Sub-Type *')]/parent::span/following-sibling::div//button");
    private final static By LOCATION_TEXTBOX= By.xpath("//label[contains(text(),'Location *')]/following-sibling::div//input[@placeholder='Search Locations...']");
    private final static By CONTACT_TEXTBOX= By.xpath("//label[contains(text(),'Contact')]/following-sibling::div//input[starts-with(@placeholder,'Search Contacts')]");
    private final static By CUSTOMER_REQUESTED_DATE_TEXTBOX= By.xpath("//label[contains(text(),'Customer Requested Date')]/following-sibling::div//input[@name='CustomerRequestedDate__c']");
//    private final static By COUNTRY_OF_BACK_OFFICE_BUTTON= By.xpath("//label[contains(text(),'Country of Back Office')]/following-sibling::div/*//button");
    private final static By COUNTRY_OF_BACK_OFFICE_BUTTON= By.xpath("//label[contains(text(),'Country of Back Office')]/parent::span/following-sibling::div/*//button");
//    private final static By BACK_OFFICE_SYSTEM_BUTTON= By.xpath("//label[contains(text(),'Back Office System')]/following-sibling::div/*//button");
    private final static By BACK_OFFICE_SYSTEM_BUTTON= By.xpath("//label[contains(text(),'Back Office System')]/parent::span/following-sibling::div/*//button");
//    private final static By WORK_ORDER_CATEGORY_BUTTTON= By.xpath("//label[contains(text(),'Work Order Category')]/following-sibling::div/*//button");
    private final static By WORK_ORDER_CATEGORY_BUTTTON= By.xpath("//label[contains(text(),'Work Order Category')]/parent::span/following-sibling::div/*//button");
//    private final static By SERVICE_BUSINESS_UNIT_BUTTON= By.xpath("//div//label[contains(text(),'Services Business Unit')]/following-sibling::div/*//button");
    private final static By SERVICE_BUSINESS_UNIT_BUTTON= By.xpath("//label[contains(text(),'Services Business Unit')]/parent::span/following-sibling::div/*//button");
//    private final static By IS_BILLABLE_BUTTON= By.xpath("//label[contains(text(),'Is Billable')]/following-sibling::div/*//button");
    private final static By IS_BILLABLE_BUTTON= By.xpath("//label[contains(text(),'Is Billable')]/parent::span/following-sibling::div/*//button");
//    private final static By NON_BILLING_REASON_BUTTON= By.xpath("//label[contains(text(),'Non Billing Reason')]/following-sibling::div/*//button");
private final static By CUSTOMER_REFERENCE_NUMBER_TEXTBOX= By.xpath("//label[contains(text(),'Customer Reference Number ')]/following-sibling::div//input[@name='Customer_Reference_Number__c']");
    private final static By NON_BILLING_REASON_BUTTON= By.xpath("//label[contains(text(),'Non Billing Reason')]/parent::span/following-sibling::div/*//button");
//    private final static By PRIORITY_BUTTON= By.xpath("//label[contains(text(),'Priority')]/following-sibling::div/*//button");
    private final static By PRIORITY_BUTTON= By.xpath("//label[contains(text(),'Priority')]/parent::span/following-sibling::div/*//button");
    private final static By SKILL_CATEGORY_BUTTON= By.xpath("//label[contains(text(),'Skill Category')]/following-sibling::div/*//button");
    private final static By WORKORDER_REASON_TEXTBOX= By.xpath("//label[contains(text(),'Work Order Reason')]/following-sibling::div/textarea");
    private final static By WORKORDER_NAME_TEXTBOX= By.xpath("//label[contains(text(),'Work Order Name')]/following-sibling::div/textarea");
    private final static By SOLD_TO_ACCOUNT_TEXTBOX= By.xpath("//label[contains(text(),'Sold To Account')]/following-sibling::div//input[@placeholder='Search Accounts...']");
    private final static By SAVE_BUTTON= By.xpath("//button[contains(text(),'Save')]");
    private final static By Service_Commercial_Ref= By.xpath("//label[contains(text(),'Service Commercial Ref')]/following-sibling::div//input[starts-with(@placeholder,'Search Products')]");
    private final static By TOTAL_QUOTED_HRS = By.xpath("//label[text()='Total Quoted Hrs']//following-sibling::div//textarea");

    public BFOStandaloneNewWorkOrderPageObjects waitForNewStandAloneWorkOrderPageLoaded(){
        $(SEARCH_ACCOUNT_TETBOX).shouldBe(visible,enabled);
        return this;
    }

    public BFOStandaloneNewWorkOrderPageObjects enterAccountName(String accountName){
        $(SEARCH_ACCOUNT_TETBOX).setValue(accountName);
        return this;
    }

    public BFOStandaloneNewWorkOrderPageObjects waitForListOfAccounts(){
        $$(SHOWALL_RESULTS_LIST).shouldHave(CollectionCondition.sizeGreaterThan(0));
        return this;
    }

    public BFOStandaloneNewWorkOrderPageObjects selectAccountName(String accountname){
        By SELECT_ACCOUNT = By.xpath("//*[@title='" + accountname + "']");
        $(SELECT_ACCOUNT).shouldBe(visible,enabled).click();
        return this;
    }

    public BFOStandaloneNewWorkOrderPageObjects selectAccountNameUsingGoldenID(String goldenID,String accountname){
        enterGoldenID(goldenID);
        By SELECT_ACCOUNT = By.xpath("//*[contains(@title,'"+goldenID+"')]");
        highLightElement($(SELECT_ACCOUNT).shouldBe(visible,enabled));
        $(SELECT_ACCOUNT).shouldBe(visible,enabled).click();
        By ACCOUNT_NAME =By.xpath("//a[@data-refid='recordId'][contains(text(),'"+accountname+"')]");
       // $$().shouldBe(Duration.ofSeconds(120));
                //.shouldBe(visible, Duration.ofSeconds(120));
        Selenide.sleep(6000);
        if($$(ACCOUNT_NAME).size() == 0){
            throw new RuntimeException("Account Name is not available");
        }
        $$(ACCOUNT_NAME).iterator().forEachRemaining(element -> {

            if(element.isDisplayed()){
                highLightElement(element.shouldBe(visible,Duration.ofSeconds(120)));
                element.click(ClickOptions.withTimeout(Duration.ofSeconds(120)));
            }
        });

        return this;
    }

    public BFOStandaloneNewWorkOrderPageObjects selectWorkOrderType(String workOdrerType){
        highLightElement($(WORKORDER_TYPE_BUTTON).shouldBe(visible,enabled));
        $(WORKORDER_TYPE_BUTTON).shouldBe(visible,enabled).click();
         By WORKORDER_TYPE_LIST = By.xpath("//*[@title='" + workOdrerType + "']");

         $(WORKORDER_TYPE_LIST).scrollIntoView(true).shouldBe(visible,enabled);
        $(WORKORDER_TYPE_LIST).shouldBe(visible,enabled).click();
//         if($$(WORKORDER_TYPE_LIST).size() == 0){
//             throw new RuntimeException("Work Order Type is not available");
//         }
//                 $$(WORKORDER_TYPE_LIST).iterator().forEachRemaining(element -> {
//                     if (element.isDisplayed()) {
//                         highLightElement(element);
//                         element.click();
//                     }
//                 });
         return this;
    }
    public BFOStandaloneNewWorkOrderPageObjects enterGoldenID(String goldenID) {
        highLightElement($(SEARCH_ACCOUNT_TETBOX).shouldBe(visible,enabled));
        $(SEARCH_ACCOUNT_TETBOX).setValue(goldenID);
        return this;
    }

    public BFOStandaloneNewWorkOrderPageObjects enterLocalGoldenID(String goldenID) {
        highLightElement($(LOCATION_TEXTBOX).shouldBe(visible,enabled));
        Selenide.sleep(500);
        $(LOCATION_TEXTBOX).setValue(goldenID);
        return this;
    }

    public BFOStandaloneNewWorkOrderPageObjects enterContact(String contactName) {
        $$(CONTACT_TEXTBOX).iterator().forEachRemaining(element ->{
            if(element.isDisplayed()){
                highLightElement(element);
                element.setValue(contactName);
            }
        });
//                .shouldBe(visible,enabled));
//        $(CONTACT_TEXTBOX).setValue(contactName);
        return this;
    }
    public BFOStandaloneNewWorkOrderPageObjects searchSelectContact(String contactName){
        $$(CONTACT_TEXTBOX).iterator().forEachRemaining(element ->{
            if(element.isDisplayed()){
                highLightElement(element);
                element.setValue(contactName);
            }
        });
                //.shouldBe(visible,editable));
//        $(CONTACT_TEXTBOX).setValue(contactName);
        Selenide.sleep(3000);
        $x("//lightning-base-combobox-formatted-text[@title='"+contactName+"']").shouldBe(visible).click();
        return this;
    }
    public BFOStandaloneNewWorkOrderPageObjects selectContactName(String contactName){
        By SELECT_CONTACT = By.xpath("//*[contains(@title,'"+contactName+"')]");
        $(SELECT_CONTACT).shouldBe(visible,enabled).click();
        return this;
    }

    public BFOStandaloneNewWorkOrderPageObjects selectLocationNameUsingGoldenID(String goldenID,String locationName){
        enterLocalGoldenID(goldenID);
        By SELECT_ACCOUNT = By.xpath("//*[contains(@title,'"+goldenID+"')]");
        highLightElement($(SELECT_ACCOUNT).shouldBe(visible,enabled));
        $(SELECT_ACCOUNT).shouldBe(visible,enabled).click();
        By LOCATION_NAME =By.xpath("//a[@data-refid='recordId'][contains(text(),'"+locationName+"')]");
        highLightElement($(LOCATION_NAME).shouldBe(visible,enabled));
        $(LOCATION_NAME).shouldBe(visible,enabled).click();
        return this;
    }

    public BFOStandaloneNewWorkOrderPageObjects selectWorkOrderSubType(String workOrderSubType) {
        if(workOrderSubType.isEmpty() || workOrderSubType != null) {
            highLightElement($(WORKORDER_SUB_TYPE_BUTTON).shouldBe(visible, enabled));
            $(WORKORDER_SUB_TYPE_BUTTON).shouldBe(visible, enabled).click();
            By WORKORDER_TYPE_LIST = By.xpath("//*[@title='" + workOrderSubType + "']");
            highLightElement($(WORKORDER_TYPE_LIST).shouldBe(visible, enabled));
            $(WORKORDER_TYPE_LIST).shouldBe(visible, enabled).click();
        }
        else {
            System.out.println("Work Order Sub type is empty");
        }
        return this;
    }

    public BFOStandaloneNewWorkOrderPageObjects selectCountryOfBackOffice(String country) {
        highLightElement($(COUNTRY_OF_BACK_OFFICE_BUTTON).shouldBe(visible,enabled));
        $(COUNTRY_OF_BACK_OFFICE_BUTTON).shouldBe(visible,enabled).click();
        By WORKORDER_TYPE_LIST = By.xpath("//*[@title='" + country + "']");
        actions().moveToElement($(WORKORDER_TYPE_LIST)).build().perform();
        highLightElement($(WORKORDER_TYPE_LIST).shouldBe(visible,enabled));
        $(WORKORDER_TYPE_LIST).shouldBe(visible,enabled).click();
        return this;
    }

    public BFOStandaloneNewWorkOrderPageObjects selectBackOfficeSystem(String backOfficeSystem) {
        highLightElement($(BACK_OFFICE_SYSTEM_BUTTON).shouldBe(visible,enabled));
        $(BACK_OFFICE_SYSTEM_BUTTON).shouldBe(visible,enabled).click();
        By WORKORDER_TYPE_LIST = By.xpath("//div[@aria-label='Back Office System']//*[@title='" + backOfficeSystem + "']");
        highLightElement($(WORKORDER_TYPE_LIST).shouldBe(visible,enabled));
        $(WORKORDER_TYPE_LIST).shouldBe(visible,enabled).click();
        return this;
    }

    public BFOStandaloneNewWorkOrderPageObjects selectWorkOrderCategory(String workOrdercategory) {
        highLightElement($(WORK_ORDER_CATEGORY_BUTTTON).shouldBe(visible,enabled));
        $(WORK_ORDER_CATEGORY_BUTTTON).shouldBe(visible,enabled).click();
        By WORKORDER_TYPE_LIST = By.xpath("//*[@title='" + workOrdercategory + "']");
        highLightElement($(WORKORDER_TYPE_LIST).shouldBe(visible,enabled));
        $(WORKORDER_TYPE_LIST).shouldBe(visible,enabled).click();
        return this;
    }

    public BFOStandaloneNewWorkOrderPageObjects selectServicesBusinessUnit(String serviceBusinessUnit) {
        highLightElement($(SERVICE_BUSINESS_UNIT_BUTTON).shouldBe(visible,enabled));
        $(SERVICE_BUSINESS_UNIT_BUTTON).shouldBe(visible,enabled).click();
        Selenide.sleep(3000);
        By WORKORDER_TYPE_LIST = By.xpath("//span[contains(text(),'"+serviceBusinessUnit.toUpperCase()+"')]");
        actions().moveToElement($(WORKORDER_TYPE_LIST).shouldBe(visible,enabled)).click().build().perform();
        return this;
    }

    public BFOStandaloneNewWorkOrderPageObjects selectIsBillable(String value) {
        highLightElement($(IS_BILLABLE_BUTTON).shouldBe(visible,enabled));
        $(IS_BILLABLE_BUTTON).shouldBe(visible,enabled).click();
        By WORKORDER_TYPE_LIST = By.xpath("//*[@title='" + value + "']");
        highLightElement($(WORKORDER_TYPE_LIST).shouldBe(visible,enabled));
        $(WORKORDER_TYPE_LIST).shouldBe(visible,enabled).click();
        return this;
    }

    public BFOStandaloneNewWorkOrderPageObjects selectNonBillingReason(String reason) {
        if(reason.isEmpty() || reason !=null) {
            highLightElement($(NON_BILLING_REASON_BUTTON).shouldBe(visible, enabled));
            $(NON_BILLING_REASON_BUTTON).shouldBe(visible, enabled).click();
            By WORKORDER_TYPE_LIST = By.xpath("//*[@title='" + reason + "']");
            highLightElement($(WORKORDER_TYPE_LIST).shouldBe(visible, enabled));
            $(WORKORDER_TYPE_LIST).shouldBe(visible, enabled).click();
        }
        else {
            System.out.println("Non Billing Reason is empty");
        }
        return this;
    }

    public BFOStandaloneNewWorkOrderPageObjects selectPriority(String priority) {
        highLightElement($(PRIORITY_BUTTON).shouldBe(visible,enabled));
        $(PRIORITY_BUTTON).shouldBe(visible,enabled).click();
        By WORKORDER_TYPE_LIST = By.xpath("//*[@title='" + priority + "']");
        highLightElement($(WORKORDER_TYPE_LIST).shouldBe(visible,enabled));
        $(WORKORDER_TYPE_LIST).shouldBe(visible,enabled).click();
        return this;
    }

    public BFOStandaloneNewWorkOrderPageObjects selectSkillCategory(String skillCategroy) {
        highLightElement($(SKILL_CATEGORY_BUTTON).shouldBe(visible,enabled));
        $(SKILL_CATEGORY_BUTTON).shouldBe(visible,enabled).click();
        By WORKORDER_TYPE_LIST = By.xpath("//*[@title='" + skillCategroy + "']");
        highLightElement($(WORKORDER_TYPE_LIST).shouldBe(visible,enabled));
        $(WORKORDER_TYPE_LIST).shouldBe(visible,enabled).click();
        return this;
    }

    public BFOStandaloneNewWorkOrderPageObjects enterWorkOrderReason(String reason) {
        highLightElement($(WORKORDER_REASON_TEXTBOX).shouldBe(visible,enabled));
        $(WORKORDER_REASON_TEXTBOX).shouldBe(visible,enabled).setValue(reason);
        return this;
    }
    public BFOStandaloneNewWorkOrderPageObjects enterCustomerReferenceNumber (String value) {
        highLightElement($(CUSTOMER_REFERENCE_NUMBER_TEXTBOX).shouldBe(visible,enabled));
        $(CUSTOMER_REFERENCE_NUMBER_TEXTBOX).shouldBe(visible,enabled).setValue(value);
        return this;
    }


    public BFOStandaloneNewWorkOrderPageObjects enterCustomerRequestedDate(String date){
        if(date.isEmpty() || date.equalsIgnoreCase("today")){
            LocalDate today = LocalDate.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd MMM yyyy");
            date = today.format(formatter);
        }
        highLightElement($(CUSTOMER_REQUESTED_DATE_TEXTBOX).shouldBe(visible,enabled));
        $(CUSTOMER_REQUESTED_DATE_TEXTBOX).shouldBe(visible,enabled).setValue(date);
        return this;
    }

    public BFOStandaloneNewWorkOrderPageObjects enterServiceCommercialRef(String ServiceCommercialRef) {
        highLightElement($(Service_Commercial_Ref).shouldBe(visible,enabled));
        $(Service_Commercial_Ref).setValue(ServiceCommercialRef);
        Selenide.sleep(3000);
        $x("//lightning-base-combobox-formatted-text[@title='"+ServiceCommercialRef+"']").shouldBe(visible).click();
        return this;
    }

    public BFOStandaloneNewWorkOrderPageObjects enterWorkOrderName(String value) {
        highLightElement($(WORKORDER_NAME_TEXTBOX).shouldBe(visible,enabled));
        $(WORKORDER_NAME_TEXTBOX).shouldBe(visible,enabled).setValue(value);
        return this;
    }

    public BFOStandaloneNewWorkOrderPageObjects enterTotalQuotedHrs(String hrs) {
        if (!hrs.isEmpty() || hrs != null) {
            highLightElement($(TOTAL_QUOTED_HRS).shouldBe(visible, enabled));
            $(TOTAL_QUOTED_HRS).shouldBe(visible, enabled).setValue(hrs);
        } else {
            System.out.println("Total Quoted Hrs is not empty");
        }
        return this;
    }

    public BFOStandaloneNewWorkOrderPageObjects selectSoldToAccount(String soldToAccount,String accountName){
        highLightElement($(SOLD_TO_ACCOUNT_TEXTBOX).shouldBe(visible,enabled));
        $(SOLD_TO_ACCOUNT_TEXTBOX).shouldBe(visible,enabled).setValue(soldToAccount);
        By SELECT_ACCOUNT = By.xpath("//label[text()='Sold To Account *']//parent::*//*[contains(@title,'"+soldToAccount+"')]");
        highLightElement($(SELECT_ACCOUNT).shouldBe(visible,enabled));
        $(SELECT_ACCOUNT).shouldBe(visible,enabled).click();

        By SOLD_TO_ACCOUNT_NUMBER =By.xpath("//h1[text()='Sold To Account *']//parent::div//following-sibling::div//a[@data-refid='recordId'][contains(text(),'"+accountName+"')]");
       highLightElement($(SOLD_TO_ACCOUNT_NUMBER).shouldBe(visible,enabled));
        $(SOLD_TO_ACCOUNT_NUMBER).shouldBe(visible,enabled).click();
        return this;
    }

    public BFOStandaloneNewWorkOrderPageObjects clickOnSaveButton(){
        //highLightElement($(SAVE_BUTTON).shouldBe(visible,enabled));
        $$(SAVE_BUTTON).iterator().forEachRemaining(element ->{
            if(element.isDisplayed()){
                highLightElement(element);
                element.click();
            }
        });
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        return this;
    }
}
