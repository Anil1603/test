package bfs.pages.bfo.Pages;

import bfs.pages.bfo.PageObjects.BFOLoginPageObjects;
import org.openqa.selenium.By;

public class BFOLoginPage {
    /*
    private BFOLoginPageObjects loginPageObjects;

    public BFOLoginPage() {
        this.loginPageObjects = new BFOLoginPageObjects();
    }
    */
   public BFOLoginPage loginToApplication(String username, String password) {
       BFOLoginPageObjects loginPageObjects = new BFOLoginPageObjects();
        loginPageObjects.setUsername(username)
                        .setPassword(password)
                        .clickLoginButton();
        return this;
    }
}
