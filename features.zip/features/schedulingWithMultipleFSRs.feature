Feature: scheduling with multiple FSRs for a new Work Order.
  As a user
  I want to navigate to the application and create Work Order and schedule with multiple FSRs

  Scenario Outline: scheduling with multiple FSRs for a specific Work Order
    Given I work in application "BFO" and environment "UAT"
    And I login to "BFO" as user "coordinator-1550@bridge-fo.com.uatbfo26"
    When I navigate to "SE - Services Lightning" from app launcher
    And I wait for "10" seconds
    And I navigate to "Work Orders" from app launcher
    And I click on bfo button "New"
    And I fill work order details for creating new work order from Work Order Page:
      | Field Name                | Field Value                         |
      | Select Record Type        | Standalone Work Order               |
      | Installed At Account      | 0001340233:Ampcontrol (QLD) Pty Ltd |
      | Location                  | 0045144542:Ampcontrol QLD Pty Ltd   |
      | Work Order Type           | Repair                              |
      | Contact                   | chandra.vamsi kumar                 |
      | Customer Requested Date   | today                               |
      | Country of Back Office    | Australia                           |
      | Back Office System        | SAP Bridge AP                       |
      | Work Order Category       | Onsite                              |
      | Services Business Unit    | POWER SYSTEMS                       |
      | Is Billable               | Yes                                 |
      | Customer Reference Number | 1234                                |
      | Priority                  | Normal-Medium                       |
      | Service Commercial Ref    | QWPFSRVPLNNSGEN                     |
      | Work Order Reason         | Testing                             |
      | Work Order Name           | Testing                             |
      | Sold To Account           | 0001340233:Ampcontrol (QLD) Pty Ltd |
    Then user should be able to see the work order number and memorize work order number
    And I should see the work order status as "New" in work order page
    And I click on "Create/Update Work Order" button from SFM Tab
    And I check the message "SUCCESS : INITIATED SYNC" on sync window
    And I click on "Ok" button on sync window
    Then I should see the work order status as "Unscheduled" in work order page
    And I wait for back Office reference number
    And I check the "First Synchronization date" and "Last Synchronization date" in work order page
    And I check the "Synchronization Log" as "Work Order CREATED in Back Office" in work order page
    And I add work order to multiple FSRs in Service Board
      | Field Name | Field Value  1 | Field Value 2 |
      | FSR        | FSR-1660       | FSR-1550      |
    Then I should see the work order status as "Scheduled" in work order page
    And I should see the primary FSR as "FSR 1660"
    When I change the the primary FSR to "FSR 1550"
    Then I should see the primary FSR as "FSR 1550"
    Then Change work order status to customer confirmed
    Then I should see the work order status as "Customer Confirmed" in work order page
    And I logout from bfo application

    Examples:
      | Tab Name    | Work Details Tab |
      | Parts Order | Work Details     |