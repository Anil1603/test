package bfs.pages.bfo.Pages;



import bfs.pages.bfo.PageObjects.BFOWorkOrderPageObject;

public class BFOWorkOrderPage {

    public void clickOnNewAndContinue(String buttonName) {
        switch (buttonName.toLowerCase()){
            case "new" ->
                    new BFOWorkOrderPageObject().clickOnNewButton().waitForRecordTypePopUp();
            case "continue" ->
                    new BFOWorkOrderPageObject().clickOnContinueButton();
            default ->
                    System.out.println("Not Implemented for "+ buttonName);
        }

    }
    public void selectRecordType(String value) {
        new BFOWorkOrderPageObject().selectRecordType(value);
    }

    public void clickOnNewToCreateWorkOrder( String recordType) {
        BFOWorkOrderPageObject workOrderPageObject = new BFOWorkOrderPageObject();
        workOrderPageObject.clickOnNewButton()
                .waitForRecordTypePopUp()
                .selectRecordType(recordType)
                .clickOnContinueButton();
    }

        }


