Feature: Service Contract Creation and Validation.
  As a user
  I want to create and validate a service contract in the BFO application
  So that I can ensure accurate contract management

  Scenario: Create and Validate Service Contract
		#Coordinator
    Given I work in application "BFO" and environment "UAT"
    When I login to "bfo" as user "coordinator-1660@bridge-fo.com.uatbfo26"
    And I search for contract "IT-1333926-Services suspended, pls don't support"
    And I selects the "IT-1333926-Services suspended, pls don't support" section from "Service/Maintenance Contracts"
    And I navigate to bfo tab "Service Lines"
    And I memorize Product from Service lines as "SKU/COMS REF"
    Then the following Service Line details should not be empty:
      | Included Services | not empty |
      | Covered Products  | not empty |
    And  I memorize field sold to account as "Sold To Account"
    Then Check bfo Service Maintenance Contracts Details Fields:
      | Status                        | Pending Commercial Validation |
      | Active                        | False                       	|
    And I navigate to Disposable Email in New window
    And I memorized Disposable Email as "Disposable_Email"
    And I create new contact from "Sold To Account" with following values:
      | Field Name                    | Value                       |
      | Select Record Type            | Customer                    |
      | First Name                    | ANIL                		  |
      | Last Name                     | TestAutomation              |
      | Email                         | Disposable_Email            |
    And i updated the "Disposable_Email" in Email Section
      | Email 	|	Disposable_Email	|
    And I memorize contact as "Contact"
    And I navigate to "Service/Maintenance Contracts" from app launcher
    And I search for contract "IT-1333926-Services suspended, pls don't support"
    And I selects the "IT-1333926-Services suspended, pls don't support" section from "Service/Maintenance Contracts"
    And I update contact fields in the contract:
      | Field Name                    | Field Value  |
      | Main Installed at Contact     | Contact      |
      | Sold to Contact               | Contact      |
      | Remote Service Contact        | Contact      |
    And I Validate bfo Contract
    Then Check bfo Service Maintenance Contracts Details Fields:
      | Field Name                    | Field Value                |
      | Status                        | Validated                  |
#		| Active                        | True                       |
#		| Synchronization Log           | VAL-Sync event => BO Service Contract Updated   |
#		| Last Synchronization          | Current Date and Time      |
    And I create bfo new Contract Value Chain Player to Service Contract with following details:
      | Field Name                    |    Field Value                  |
      | Account Role                  |    Consultant                   |
      | Contact Role                  |    Admin                        |
      | Contact                       |    Contact                      |
      | Portal Access                 |    true                         |
      | Case Access                   |    All Contract Cases           |
      | Document Vault Access         |    Owner                        |

