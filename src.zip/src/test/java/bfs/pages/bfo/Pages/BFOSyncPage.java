package bfs.pages.bfo.Pages;

import bfs.pages.bfo.PageObjects.BFOSyncPageObjetcs;
import com.codeborne.selenide.Selenide;
import static com.codeborne.selenide.Selenide.*;

public class BFOSyncPage {
  //  private String parentWindow;
 //   private String childWindow;
    BFOSyncPageObjetcs bfoSyncPageObjetcs = new BFOSyncPageObjetcs();
    /*
    public void switchToChildWindow() {
        /*
        Set<String> windowHandles = WebDriverRunner.getWebDriver().getWindowHandles();
        if (windowHandles.size() < 2) {
            throw new RuntimeException("Child window not found");
        }
        Iterator<String> iterator = windowHandles.iterator();
        parentWindow = iterator.next();
        childWindow = iterator.next();
        if (childWindow == null) {
            throw new RuntimeException("Child window handle is null");
        }
        switchTo().window(childWindow);
        Selenide.sleep(8000);

        switchTo().window(1);
    }
    public void switchToParentWindow() {
        if (parentWindow == null) {
            throw new RuntimeException("Parent window handle is null");
        }
        try {
            switchTo().window(parentWindow);
        } catch (org.openqa.selenium.NoSuchWindowException e) {
            throw new RuntimeException("Parent window already closed", e);
        }
    }
*/

    public void performSyncActions() {
        switchTo().window(1);
        bfoSyncPageObjetcs.selectSecondLegacyIdRadioButtonFromSoldToAccount()
                .selectSecondLegacyIdRadioButtonFromInstalledAt()
                .clickOnSyncButton();
        Selenide.sleep(5000);
    }


    public void performSyncActionsForCostCenter(String costCenter) {
        switchTo().window(1);
        bfoSyncPageObjetcs.selectFirstCosrCenterRadioButton(costCenter);
        bfoSyncPageObjetcs.clickOnSyncButton();
        Selenide.sleep(5000);
    }

    public void clickOnSyncPageOkButton() {
        new BFOSyncPageObjetcs().clickOnSyncPageOkButton();
      //  Selenide.sleep(5000);
        switchTo().window(0);
        Selenide.sleep(30000);
        Selenide.refresh();
    //    Selenide.sleep(10000);
    //    Selenide.refresh();
      //  refresh();
    }


}
