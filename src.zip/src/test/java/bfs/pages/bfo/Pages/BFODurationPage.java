package bfs.pages.bfo.Pages;

import bfs.pages.bfo.PageObjects.BFODurationPageObjects;

public class BFODurationPage {

    BFODurationPageObjects bfoDurationPageObjects = new BFODurationPageObjects();

    public void updateTotalQuotedHrs(String hrs) {
        bfoDurationPageObjects.clickTotalQuotedHrsEditButton();
        bfoDurationPageObjects.setTotalQuotedHrs(hrs);
        bfoDurationPageObjects.clickSaveButton();

    }
}
