package rough;

import java.io.IOException;

public class LaunchDebugger {

    public static void main(String[] args) {
        LaunchDebugger.launchChromeInDebugMode();
    }
//
    public static Process launchChromeInDebugMode(){
        Process process = null;
        try {
            final String USER_DIR ="C:\\Users\\";
            final String  USERNAME = System.getProperty("user.name");
            final String CHROME_EXE_DIR="\\AppData\\Local\\Google\\Chrome\\Application\\chrome.exe";
            final String USER_DATA_DIR ="C:\\Users\\"+USERNAME+"\\AppData\\Local\\Google\\Chrome\\Application";
            String PORT ="9222";
            String chromePath = USER_DIR+USERNAME+CHROME_EXE_DIR;
            String[] command = { chromePath, "--remote-debugging-port="+PORT, "--no-first-run","--no-default-browser-check", "--user-data-dir="+USER_DATA_DIR };
            process = Runtime.getRuntime().exec(command);
            System.out.println("Chrome browser launched in debugger mode.");
            return process;
        } catch (IOException e) {
            process.destroy();
            e.printStackTrace();

        }
        return process;
    }

}
