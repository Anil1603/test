package bfs.pages.bfo.PageObjects;

import bfs.CONSTANTS;
import bfs.pages.BasePage;
import com.codeborne.selenide.*;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import static bfs.pages.bfo.ApplicationCommonMethods.waitForGivenTime;
import static com.codeborne.selenide.Condition.enabled;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.*;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.ElementClickInterceptedException;

public class BFOFlowOfWorkOrderPageObjects {
    private static final String SHOW_MORE_BUTTON = "//button[@title='Show More']";
//    private static final String SYNCHRONIZATION_LOG_STATUS = "//span[contains(text(),'Synchronization Log')]/ancestor::dt/following-sibling::dd//lightning-formatted-text";
    private static final String SYNCHRONIZATION_LOG_STATUS = "//span[contains(text(),'Synchronization Log')]/parent::div/following-sibling::div//lightning-formatted-text";

//    private static final String FIRST_SYNCHRONIZATION_DATE = "//span[contains(text(),'First Synchronization Date')]/ancestor::dt/following-sibling::dd//lightning-formatted-text";
    private static final String FIRST_SYNCHRONIZATION_DATE = "//span[contains(text(),'First Synchronization Date')]/parent::div/following-sibling::div//lightning-formatted-text";

//    private static final String LAST_SYNCHRONIZATION_DATE = "//span[contains(text(),'Last Synchronization Date')]/ancestor::dt/following-sibling::dd//lightning-formatted-text";
    private static final String LAST_SYNCHRONIZATION_DATE = "//span[contains(text(),'Last Synchronization Date')]/parent::div/following-sibling::div//lightning-formatted-text";

    private static final String SERVICE_VALIDATED_STEP_BUTTON = "//li[@data-name='Service Validated']";

//    private static final String MARK_AS_CURRENT_WORK_ORDER_STATUS = "//span[text()='Mark as Current Work Order Status *']";
private static final String MARK_AS_CURRENT_WORK_ORDER_STATUS = "//div//button//span[contains(text(),'Mark')]";
    public BFOFlowOfWorkOrderPageObjects clickOnShowMoreButton(){
        $x(SHOW_MORE_BUTTON).shouldBe(visible,enabled).click();
        return this;
    }
    public void checkSynchronizationLogStatus(String status){
//        refresh();
//        Selenide.sleep(10000);
//        $x(SYNCHRONIZATION_LOG_STATUS).shouldBe(visible).scrollIntoView(false);
//        System.out.println("Synchronization Log Status: " + $x(SYNCHRONIZATION_LOG_STATUS).shouldBe(visible).getText());
//        Assert.assertTrue($x(SYNCHRONIZATION_LOG_STATUS).shouldBe(visible).getText().contains(status));
//        CONSTANTS.captureScreen=true;
        $x(SYNCHRONIZATION_LOG_STATUS).shouldBe(visible).scrollIntoView(false);
        int maxAttempts = 10;
        int attempts = 0;
        boolean statusFound = false;
        do {
            if ($x(SYNCHRONIZATION_LOG_STATUS).shouldBe(visible).getText().contains(status)) {
                statusFound = true;
                Assert.assertTrue($x(SYNCHRONIZATION_LOG_STATUS).shouldBe(visible).getText().contains(status));
            } else {
                refresh();
                Selenide.sleep(10000); // Wait for 10 seconds before the next attempt
                $x(SYNCHRONIZATION_LOG_STATUS).shouldBe(visible).scrollIntoView(true);
                attempts++;
            }
        } while (attempts < maxAttempts && !statusFound);
        if (!statusFound) {
            Assert.fail("Expected Synchronization log message not found after " + maxAttempts + " attempts");
        }
        CONSTANTS.captureScreen=true;


    }

//    public String getWorkOrderType() {
//        waitForGivenTime(15000);
//        if (WorkOrderType == null) {
//            WorkOrderType = $x(SPLIT_WO_TEXT).shouldBe(visible).getText();
//        }
//        return splitWorkOrderNumber;
//    }
public String getWorkOrderType() {
    // Locate the element
    SelenideElement referenceElement = $x("//span[contains(text(), 'Work Order Type')]/parent::div/../parent::div/dd/div/span/slot/lightning-formatted-text");

    // Scroll to the element before interacting
    referenceElement.scrollIntoView(true);

    // Get the text from the element
    String type = referenceElement.getText();
    System.out.println("get work order type : " + type);

    return type;
}
    public String getWorkOrderOwner() {
        // Locate the element
        SelenideElement referenceElement = $x("//span[text()='Owner']/parent::div/parent::dt/following-sibling::dd/div/span/slot/force-owner-lookup/div/span/force-lookup/div/span/slot/span");

        // Scroll to the element before interacting
        referenceElement.scrollIntoView(true);

        // Get the text from the element
        String type = referenceElement.getText();
        System.out.println("get work order owner is : " + type);

        return type;
    }
    public String getWorkOrderSubType() {
        // Locate the element
        SelenideElement referenceElement = $x("//span[contains(text(), 'Work Order Sub-Type')]/parent::div/../parent::div/dd/div/span/slot/lightning-formatted-text");

        // Scroll to the element before interacting
        referenceElement.scrollIntoView(true);

        // Get the text from the element
        String type = referenceElement.getText();
        System.out.println("get work order sub type : " + type);

        return type;
    }
    public String getWorkOrderName() {
        // Locate the element
        SelenideElement referenceElement = $x("//span[contains(text(), 'Work Order Name')]/parent::div/../parent::div/dd/div/span/slot/lightning-formatted-text");

        // Scroll to the element before interacting
        referenceElement.scrollIntoView(true);

        // Get the text from the element
        String name = referenceElement.getText();
        System.out.println("get work order type : " + name);

        return name;
    }
    public String getWorkOrderReason() {
        // Locate the element
        SelenideElement referenceElement = $x("//span[contains(text(), 'Work Order Reason')]/parent::div/../parent::div/dd/div/span/slot/lightning-formatted-text");

        // Scroll to the element before interacting
        referenceElement.scrollIntoView(true);

        // Get the text from the element
        String reason = referenceElement.getText();
        System.out.println("get work order type : " + reason);

        return reason;
    }
    // Method to click on the account link with exception handling
    public void clickOnAccount() {
        try {
            Thread.sleep(8000);
            // Locate the link using the XPath
            SelenideElement accountLink = $x("//span[contains(text(),'Installed At Account')]/parent::div/parent::dt/following-sibling::dd/div/span/slot/force-lookup/div/records-hoverable-link/div/a");
            // Click the link
//            accountLink.click();
            executeJavaScript("arguments[0].click();", accountLink);
            System.out.println("Account link clicked successfully.");
        } catch (NoSuchElementException e) {
            System.err.println("Error: Account link not found.");
            e.printStackTrace();
        } catch (ElementClickInterceptedException e) {
            System.err.println("Error: Unable to click on the account link, element might be covered by another element.");
            e.printStackTrace();
        } catch (Exception e) {
            System.err.println("Unexpected error while clicking on the account link.");
            e.printStackTrace();
        }
    }
    // Method to get the Account ID text with scrolling into view
    public String getAccountIdText() {
        try {
            // Locate the "Account ID" element using XPath
            SelenideElement accountIdElement = $x("//span[text()='SE Account ID']/parent::div/parent::dt/following-sibling::dd/div/span/slot/lightning-formatted-text");

            // Scroll the element into view before extracting text
            accountIdElement.scrollIntoView(true);

            // Get the text from the element
            String accountIdText = accountIdElement.getText();
            // Return the Account ID text
            return accountIdText;
        } catch (Exception e) {
            System.err.println("Error: Unable to get the Account ID text.");
            e.printStackTrace();
            return null;
        }
    }

    public String getBackOfficeReferenceNumber() {
        // Locate the element
        SelenideElement referenceElement = $x("//span[contains(text(), 'Back Office Reference')]/parent::div/../parent::div/dd/div/span/slot/lightning-formatted-text");

        // Scroll to the element before interacting
        referenceElement.scrollIntoView(true);

        // Get the text from the element
        String fullText = referenceElement.getText();
        System.out.println("Full Back Office Reference: " + fullText);

        // Extract the number after the hyphen "-"
        String[] parts = fullText.split("-");
        String extractedNumber = parts.length > 1 ? parts[1] : ""; // Get the part after the hyphen

        System.out.println("Extracted Number: " + extractedNumber);
        return extractedNumber;
    }
    public void fetchBackOfficeReferencenumber() throws InterruptedException {

        By textBoxLocator = By.xpath("//span[text()='Assignment']");
        $(textBoxLocator).shouldBe(visible);
        ((JavascriptExecutor) WebDriverRunner.getWebDriver()).executeScript("arguments[0].scrollIntoView(true);", WebDriverRunner.getWebDriver().findElement(textBoxLocator));
        int maximum_try = 0;
        while ($(By.xpath("//span[text()='Back Office Reference #']/../following-sibling::*//span//lightning-formatted-text")).getText().equalsIgnoreCase("")) {
            Selenide.refresh();
            Thread.sleep(60000);
            ((JavascriptExecutor) WebDriverRunner.getWebDriver()).executeScript("arguments[0].scrollIntoView(true);", WebDriverRunner.getWebDriver().findElement(textBoxLocator));
            maximum_try++;
            System.out.println(maximum_try);
            if (maximum_try == 5) {
                break;
            }
        }

    }
    public String fetchBackOfficeReferenceNumber() throws InterruptedException {
        By textBoxLocator = By.xpath("//span[text()='Assignment']");
        $(textBoxLocator).shouldBe(visible);
        ((JavascriptExecutor) WebDriverRunner.getWebDriver()).executeScript("arguments[0].scrollIntoView(true);", WebDriverRunner.getWebDriver().findElement(textBoxLocator));

        String backOfficeReferenceNumber = "";
        int maximum_try = 0;

        while ($(By.xpath("//span[text()='Back Office Reference #']/../../following-sibling::*//span//lightning-formatted-text")).getText().equalsIgnoreCase("")) {
            Selenide.refresh();
            Thread.sleep(60000);
            ((JavascriptExecutor) WebDriverRunner.getWebDriver()).executeScript("arguments[0].scrollIntoView(true);", WebDriverRunner.getWebDriver().findElement(textBoxLocator));
            maximum_try++;
            System.out.println(maximum_try);
            if (maximum_try == 5) {
                break;
            }
        }

        backOfficeReferenceNumber = $(By.xpath("//span[text()='Back Office Reference #']/../../following-sibling::*//span//lightning-formatted-text")).getText();
        System.out.println("Back Office Reference Number: " + backOfficeReferenceNumber);
        return backOfficeReferenceNumber;
    }

    public void verifyFirstSynchronizationDate(String format) {
        String currentDate = BasePage.getTodayDate(format);
        SelenideElement dateElement = $x(FIRST_SYNCHRONIZATION_DATE).shouldBe(visible);
        String dateText = dateElement.getText().split(" ")[0];
        System.out.println("The first synchronization date is: " + dateText);
        Assert.assertEquals("The first synchronization date match the current date.", currentDate, dateText);
        CONSTANTS.captureScreen=true;
    }
    public void verifyLastSynchronizationDate(String format) {
        String currentDate = BasePage.getTodayDate(format);
        SelenideElement dateElement = $x(LAST_SYNCHRONIZATION_DATE).shouldBe(visible);
        String dateText = dateElement.getText().split(" ")[0];
        System.out.println("The last synchronization date is: " + dateText);
        Assert.assertEquals("The last synchronization date match the current date.", currentDate, dateText);
        CONSTANTS.captureScreen=true;
    }

    public BFOFlowOfWorkOrderPageObjects clickOnServiceValidatedStepButton(){
        $x(SERVICE_VALIDATED_STEP_BUTTON).shouldBe(visible,Duration.ofSeconds(180)).click(ClickOptions.usingJavaScript());
        return this;
    }
    public BFOFlowOfWorkOrderPageObjects clickOnMarkAsCurrentWorkOrderStatus(){
        $x(MARK_AS_CURRENT_WORK_ORDER_STATUS).shouldBe(visible,enabled).click(ClickOptions.usingJavaScript());
        return this;
    }

}
