package bfs.pages.bfo.PageObjects;

import org.openqa.selenium.By;
import com.codeborne.selenide.*;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.*;

public class BFOStandaloneNewWorkOrderPageObjects {
    private final static By SEARCH_ACCOUNT_TETBOX = By.xpath("//label[contains(text(),'Installed At Account *')]/following-sibling::div//input[@placeholder='Search Accounts...']");
    private final static By SHOWALL_RESULTS_LIST = By.xpath("//ul[@role='group']//li");
    private final static By WORKORDER_TYPE_BUTTON = By.xpath("//label[contains(text(),'Work Order Type *')]/following-sibling::div//button");
    private final static By WORKORDER_SUB_TYPE_BUTTON = By.xpath("//label[contains(text(),'Work Order Sub-Type *')]/following-sibling::div//button");
    private final static By LOCATION_TEXTBOX= By.xpath("//label[contains(text(),'Location *')]/following-sibling::div//input[@placeholder='Search Locations...']");
    private final static By CONTACT_TEXTBOX= By.xpath("//label[contains(text(),'Contact')]/following-sibling::div//input[@placeholder='Search Contacts...']");
    private final static By CUSTOMER_REQUESTED_DATE_TEXTBOX= By.xpath("//label[contains(text(),'Customer Requested Date')]/following-sibling::div//input[@name='CustomerRequestedDate__c']");
    private static final By CUSTOMER_REQUESTED_TIME_TEXTBOX = By.xpath("//label[contains(text(),'Customer Requested Time')]/following-sibling::div//button");
    private final static By COUNTRY_OF_BACK_OFFICE_BUTTON= By.xpath("//label[contains(text(),'Country of Back Office')]/following-sibling::div/*//button");
    private final static By BACK_OFFICE_SYSTEM_BUTTON= By.xpath("//label[contains(text(),'Back Office System')]/following-sibling::div/*//button");
    private final static By WORK_ORDER_CATEGORY_BUTTTON= By.xpath("//label[contains(text(),'Work Order Category')]/following-sibling::div/*//button");
    private final static By SERVICE_BUSINESS_UNIT_BUTTON= By.xpath("//div//label[contains(text(),'Services Business Unit')]/following-sibling::div/*//button");
    private final static By IS_BILLABLE_BUTTON= By.xpath("//label[contains(text(),'Is Billable')]/following-sibling::div/*//button");
    private final static By NON_BILLING_REASON_BUTTON= By.xpath("//label[contains(text(),'Non Billing Reason')]/following-sibling::div/*//button");
    private final static By PRIORITY_BUTTON= By.xpath("//label[contains(text(),'Priority')]/following-sibling::div/*//button");
    private final static By SKILL_CATEGORY_BUTTON= By.xpath("//label[contains(text(),'Skill Category')]/following-sibling::div/*//button");
    private final static By WORKORDER_REASON_TEXTBOX= By.xpath("//label[contains(text(),'Work Order Reason')]/following-sibling::div/textarea");
    private final static By WORKORDER_NAME_TEXTBOX= By.xpath("//label[contains(text(),'Work Order Name')]/following-sibling::div/textarea");
    private final static By SOLD_TO_ACCOUNT_TEXTBOX= By.xpath("//label[contains(text(),'Sold To Account')]/following-sibling::div//input[@placeholder='Search Accounts...']");
    private final static By SAVE_BUTTON= By.xpath("//button[contains(text(),'Save')]");

    public BFOStandaloneNewWorkOrderPageObjects waitForNewStandaloneWorkOrderPageToLoad() {
        $(SEARCH_ACCOUNT_TETBOX).shouldBe(visible,enabled);
        return this;
    }
    public BFOStandaloneNewWorkOrderPageObjects enterInstalledAtAccount(String accountName) {
        $(SEARCH_ACCOUNT_TETBOX).setValue(accountName);
        return this;
    }

}
