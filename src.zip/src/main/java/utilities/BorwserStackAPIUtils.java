package utilities;

import com.google.gson.Gson;
import io.restassured.RestAssured;
import io.restassured.authentication.PreemptiveBasicAuthScheme;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import requestPojo.BrowserStackStatusPojo;

public class BorwserStackAPIUtils {

    public static void setExecutionResult(String sessionid,String status,String reason){

     /*   String reason = getSessionDetails(sessionid).body().jsonPath().get("automation_session.reason");
        System.out.println("Reason :" +reason);*/
        //Set authentication credentials
        String username = "anilkumarbhusara_g9mtCX";
        String password = "iSSA1BJmCJ3qQUYYJ1qr";
        //Set base URL and path
        String baseURL = "https://api.browserstack.com/automate";

        //Set authentication
        PreemptiveBasicAuthScheme authScheme = new PreemptiveBasicAuthScheme();
        authScheme.setUserName(username);
        authScheme.setPassword(password);
        RestAssured.authentication = authScheme;
        BrowserStackStatusPojo requestbody = new BrowserStackStatusPojo(status,reason);

        //Send PUT request using Rest Assured
        RestAssured.given()
                .contentType(ContentType.JSON)
                .body(requestbody)
                .put(baseURL + "/sessions/" + sessionid + ".json")
                .then()
                .statusCode(200); //Assuming 200 is the expected status code
    }


    private static Response getSessionDetails(String sessionid){
        //Set authentication credentials
        String username = "anilkumarbhusara_g9mtCX";
        String password = "iSSA1BJmCJ3qQUYYJ1qr";
        //Set base URL and path
        String baseURL = "https://api.browserstack.com/automate/";

        //Set authentication
        PreemptiveBasicAuthScheme authScheme = new PreemptiveBasicAuthScheme();
        authScheme.setUserName(username);
        authScheme.setPassword(password);
        RestAssured.authentication = authScheme;

        //Send PUT request using Rest Assured
       return RestAssured.given()
                .contentType(ContentType.JSON)
                .get(baseURL + "/sessions/" + sessionid + ".json");
    }
}
