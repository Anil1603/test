package bfs.pages.workbench;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import static com.codeborne.selenide.Selenide.$;

public class login_work_benck_page {

    private static final By Environment_dropdown_locator= By.id("oauth_env");
    private static final By termsandCondistions_checkbox_locator= By.id("termsAccepted");
    private static final By login_button_locator= By.id("loginBtn");

    public static void select_Environment_dropdown__value(String value) {
        // select Environment dropdown value
        Select Environment_dropdown = new Select($(Environment_dropdown_locator));
        Environment_dropdown.selectByVisibleText(value);
    }

    public static void click_termsandCondistions_checkbox() {
        // click terms and conditions checkbox
        $(termsandCondistions_checkbox_locator).click();
    }

    public static void click_login_button() {
        // click login button
        $(login_button_locator).click();
    }

    public void login(String value) {
        select_Environment_dropdown__value(value);
        click_termsandCondistions_checkbox();
        click_login_button();
    }
}
