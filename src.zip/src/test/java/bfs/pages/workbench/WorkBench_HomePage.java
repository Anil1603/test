package bfs.pages.workbench;

import com.codeborne.selenide.ClickOptions;
import com.codeborne.selenide.Selenide;
import configuration.ConfigManager;
import org.openqa.selenium.By;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import com.codeborne.selenide.Configuration;
import java.util.stream.Collectors;

import java.time.Duration;
import java.nio.file.StandardCopyOption;
import java.util.Properties;

import static com.codeborne.selenide.Selenide.$;

public class WorkBench_HomePage {
    private static final String tabs_in_header = "//*[@id='navMenu']//li//*[text()='Tab_Name']";
    private static final String pageName="//*[@id='navMenu']//li//*[text()='Tab_Name']//parent::*//following-sibling::ul//a[text()='page_name']";
    private static final By Query_text_area= By.xpath("//textarea[@id='soql_query_textarea']");
    private static final By Query_button= By.xpath("//input[@name='querySubmit']");
    private static final By View_as_type_List_button= By.xpath("//input[@id='export_action_screen']");
    private static final By View_as_type_Matrix_button= By.xpath("//input[@id='export_action_matrix']");
    private static final By View_as_type_BulkCSV_button= By.xpath("//input[@id='export_action_async_csv']");
    private static final By View_as_type_BulkXML_button= By.xpath("//input[@id='export_action_async_xml']");
    private static final By download_icon = By.xpath("//h3[text()='Batches']//following::td[@class='dataValue']//a//img");


    public void navigatetospacificpage(String tabName, String pagename) {
        String tab = tabs_in_header.replace("Tab_Name", tabName);
        String page = pageName.replace("Tab_Name", tabName).replace("page_name", pagename);
        $(By.xpath(tab)).click(ClickOptions.withTimeout(Duration.ofSeconds(160)));
        $(By.xpath(page)).click(ClickOptions.withTimeout(Duration.ofSeconds(160)));
    }

    public void select_view_as_type_Radio_button(String view_as_type) {
        switch (view_as_type.toLowerCase()) {
            case "list":
                $(View_as_type_List_button).click(ClickOptions.withTimeout(Duration.ofSeconds(160)));
                break;
            case "matrix":
                $(View_as_type_Matrix_button).click(ClickOptions.withTimeout(Duration.ofSeconds(160)));
                break;
            case "bulkcsv":
                $(View_as_type_BulkCSV_button).click(ClickOptions.withTimeout(Duration.ofSeconds(160)));
                break;
            case "bulkxml":
                $(View_as_type_BulkXML_button).click(ClickOptions.withTimeout(Duration.ofSeconds(160)));
                break;
        }
    }

    public void enter_query(String query) {
        $(Query_text_area).sendKeys(query);
    }

    public void click_query_button() {
        $(Query_button).click(ClickOptions.withTimeout(Duration.ofSeconds(160)));
    }

    public void click_download_icon() {
        $(download_icon).click(ClickOptions.withTimeout(Duration.ofSeconds(160)));
    }


//    public void executeQueryAndDownloadResults(String queryName, String recordCount, String format) {
//
//        String query=ConfigManager.getProperty(queryName,"SOQLQUERIES").replaceAll("RECORDCOUNT",recordCount);
//        select_view_as_type_Radio_button(format);
//        enter_query(query);
//        click_query_button();
//        click_download_icon();
//
//        Selenide.sleep(5000);
//        String location = System.getProperty("user.dir") + "\\Downloads";
//        System.out.println("Downloaded file location: " + location);
//    }

    private final String projectRoot = System.getProperty("user.dir");
    private final String projectDownloadPath = projectRoot + File.separator + "downloads";
    private final String userDownloadPath = System.getProperty("user.home") + File.separator + "Downloads";


    /**
     * Ensures the project download directory exists.
     */
    private void ensureDownloadDirectory() {
        File directory = new File(projectDownloadPath);
        if (!directory.exists() && directory.mkdirs()) {
            System.out.println("Download directory created: " + projectDownloadPath);
        }
    }

    /**
     * Deletes all bulkQuery CSV files from the user's Downloads folder.
     */
    private void deleteOldUserDownloads() {
        File dir = new File(userDownloadPath);
        if (dir.exists() && dir.isDirectory()) {
            File[] files = dir.listFiles((d, name) -> name.matches("bulkQuery_result_\\d+\\.csv"));
            if (files != null) {
                for (File file : files) {
                    if (file.delete()) {
                        System.out.println("Deleted old file: " + file.getName());
                    } else {
                        System.out.println("Failed to delete: " + file.getName());
                    }
                }
            }
        }
    }

    /**
     * Deletes all CSV files from the project downloads folder.
     */
    private void deleteOldProjectDownloads() {
        File dir = new File(projectDownloadPath);
        if (dir.exists() && dir.isDirectory()) {
            File[] existingFiles = dir.listFiles((d, name) -> name.endsWith(".csv"));
            if (existingFiles != null) {
                for (File file : existingFiles) {
                    if (file.delete()) {
                        System.out.println("Deleted from project folder: " + file.getName());
                    }
                }
            }
        }
    }

    /**
     * Waits for the CSV file to be downloaded.
     */
    private File waitForDownload(int timeout) {
        File dir = new File(userDownloadPath);
        long startTime = System.currentTimeMillis();
        File downloadedFile = null;

        while ((System.currentTimeMillis() - startTime) < (timeout * 1000)) {
            File[] files = dir.listFiles((d, name) -> name.startsWith("bulkQuery_result_") && name.endsWith(".csv"));
            if (files != null && files.length > 0) {
                downloadedFile = files[0];
                break;
            }
            try {
                Thread.sleep(1000);
            } catch (InterruptedException ignored) {}
        }

        if (downloadedFile == null) {
            throw new RuntimeException("Download timed out! No file found.");
        }

        System.out.println("Download complete: " + downloadedFile.getName());
        return downloadedFile;
    }

    /**
     * Moves the downloaded file from the user's Downloads folder to the project downloads folder.
     */
    private File moveFileToProjectDownloads(File file) {
        File destination = new File(projectDownloadPath, file.getName());
        try {
            Files.move(file.toPath(), destination.toPath(), StandardCopyOption.REPLACE_EXISTING);
            System.out.println("File moved to project folder: " + destination.getAbsolutePath());
        } catch (IOException e) {
            throw new RuntimeException("Failed to move file: " + e.getMessage());
        }
        return destination;
    }

    /**
     * Reads and prints the CSV file content.
     */
    private void readAndPrintCSV(File file) {
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            List<String> lines = br.lines().collect(Collectors.toList());
            System.out.println("CSV Content:");
            lines.forEach(System.out::println);
        } catch (IOException e) {
            System.out.println("Error reading CSV file: " + e.getMessage());
        }
    }

    /**
     * Executes a query, downloads the result, moves the file, and prints the CSV content.
     */
    public void executeQueryAndDownloadResults(String queryName, String recordCount, String format) {
        ensureDownloadDirectory();
        deleteOldUserDownloads();
        deleteOldProjectDownloads();

        // Execute query and trigger download
        String query = ConfigManager.getProperty(queryName, "SOQLQUERIES").replaceAll("RECORDCOUNT", recordCount);
        select_view_as_type_Radio_button(format);
        enter_query(query);
        click_query_button();
        click_download_icon();

        // Wait for the download and move the file
        File downloadedFile = waitForDownload(60);
        File movedFile = moveFileToProjectDownloads(downloadedFile);

        // Print CSV content
        readAndPrintCSV(movedFile);
    }


}
