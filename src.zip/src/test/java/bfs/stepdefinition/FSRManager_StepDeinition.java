package bfs.stepdefinition;

import bfs.pages.bfo.BFOVerifyCreatedWorkOrderPageObjects;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import org.junit.Assert;

import static bfs.CONSTANTS.captureScreen;

public class FSRManager_StepDeinition {

    @And("Validate all following fields:")
    public void validateAllFollowingFields(DataTable table) {


    }
}
