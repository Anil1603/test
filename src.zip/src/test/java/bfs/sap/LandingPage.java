package bfs.sap;

import com.jacob.activeX.ActiveXComponent;
import org.junit.Assert;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import static bfs.sap.SAPLogin.Session;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.awt.*;
import java.awt.datatransfer.*;
import com.jacob.com.Variant;

//import static ecocare.sap.test.LoginTest.Session;

public class LandingPage {

    public static ActiveXComponent enterTransactionCode(String code) throws InterruptedException, IOException {

        Thread.sleep(8000);

        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        wnd.invoke("maximize");

        // Enter transaction code VA03
        ActiveXComponent okcd = new ActiveXComponent(Session.invoke("findById", "wnd[0]/tbar[0]/okcd").toDispatch());
        okcd.setProperty("text", code);

        ActiveXComponent wn = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        wn.invoke("sendVKey", 0);

        return wnd;
    }

    public static ActiveXComponent enterOrderNumber(String code) throws InterruptedException, IOException {

        Thread.sleep(10000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent orderNumber = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/ctxtCAUFVD-AUFNR").toDispatch());
        orderNumber.setProperty("text", code);

        ActiveXComponent wn = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        wn.invoke("sendVKey", 0);

        return wnd;
    }

public static String getOrderNumber() throws InterruptedException, IOException {

    Thread.sleep(10000);
    ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
    // Enter transaction code VA03
    ActiveXComponent workOrderId = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/ctxtCAUFVD-AUFNR").toDispatch());
    String workOrderValue = workOrderId.getProperty("text").getString();
    System.out.println("Work Order ID: " + workOrderValue);
    Thread.sleep(5000);

    return workOrderValue;
}

    public static ActiveXComponent selectEnhancement() throws InterruptedException, IOException {

        Thread.sleep(8000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent tab = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/subSUB_ALL:SAPLCOIH:3001/ssubSUB_LEVEL:SAPLCOIH:1100/tabsTS_1100/tabp+CUK").toDispatch());
        tab.invoke("select");
        Thread.sleep(5000);

        return wnd;
    }
    public static ActiveXComponent selectOperations() throws InterruptedException, IOException {

        Thread.sleep(8000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent tab = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/subSUB_ALL:SAPLCOIH:3001/ssubSUB_LEVEL:SAPLCOIH:1100/tabsTS_1100/tabpVGUE").toDispatch());
        tab.invoke("select");
        Thread.sleep(5000);

        return wnd;
    }
    public static ActiveXComponent selectPartner() throws InterruptedException, IOException {

        Thread.sleep(8000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent tab = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/subSUB_ALL:SAPLCOIH:3001/ssubSUB_LEVEL:SAPLCOIH:1100/tabsTS_1100/tabpPARU").toDispatch());
        tab.invoke("select");
        Thread.sleep(5000);

        return wnd;
    }

    // Method to compare the beginning of two strings without using explicit indices
    public static void assertPartialMatch(String actual, String expected) {
        // Check if the 'actual' string contains the beginning part of 'expected'
        boolean isMatch = actual.toLowerCase().startsWith(expected.toLowerCase());

        // If there's no match, throw an assertion error
        assert isMatch : "Partial match failed: Actual string does not start with expected string.";
    }
    // Method to assert if 'actual' matches the beginning of 'expected'
    public static void assertPartialMatchs(String actual, String expected) {
        boolean isPartialMatch = expected.toLowerCase().startsWith(actual.toLowerCase());

        assert isPartialMatch : "Assertion Failed: '" + actual + "' is not a partial match of '" + expected + "'";
    }
    // Dynamically splits actual and finds max matching prefix with expected
    public static void assertDynamicPartialMatch(String actual, String expected) {
        String[] actualWords = actual.split(" ");
        StringBuilder prefixBuilder = new StringBuilder();
        String bestMatch = "";

        for (String word : actualWords) {
            if (prefixBuilder.length() > 0) {
                prefixBuilder.append(" ");
            }
            prefixBuilder.append(word);

            String currentPrefix = prefixBuilder.toString();
            if (expected.toLowerCase().startsWith(currentPrefix.toLowerCase())) {
                bestMatch = currentPrefix;
            } else {
                break;
            }
        }

        // Assert using the best match found
        assert !bestMatch.isEmpty() : "No matching prefix found between actual and expected.";
        System.out.println("Best matching prefix: '" + bestMatch + "'");
    }
    public static void assertPartialRefNumberMatch(String actual, String expected) {
        if (actual == null || expected == null) {
            throw new IllegalArgumentException("Actual and Expected cannot be null");
        }

        if (!actual.toLowerCase().contains(expected.toLowerCase())) {
            throw new AssertionError("Expected partial match not found.\nActual: " + actual + "\nExpected to contain: " + expected);
        }

        System.out.println("✅ Partial match successful: '" + expected + "' found in actual text.");
    }


    public static void compareText(String expected, String actual) {
//        Assert.assertEquals(actual, expected, "The text is not matching");
//        Assert.assertTrue(actual.contains(expected)"Text mismatch: " + actual);
        if (actual != null && expected != null && expected.contains(actual)) {
            System.out.println("Text match successful");
        } else {
            System.out.println("Text mismatch! Expected: [" + expected + "], but found: [" + actual + "]");
            Assert.fail("Text mismatch! Expected: [" + expected + "], but found: [" + actual+ "]");
        }
        System.out.println("Text Matched" + actual);
    }

    public static String getWorkOrderId() throws InterruptedException, IOException {

        Thread.sleep(10000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent workOrderId = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/subSUB_ALL:SAPLCOIH:3001/ssubSUB_LEVEL:SAPLCOIH:1100/tabsTS_1100/tabp+CUK/ssubSUB_AUFTRAG:SAPLCOIH:1180/subCUSTSCR1:SAPLXWOC:0900/txtCAUFVD-YYWRKID").toDispatch());
        String workOrderIdValue = workOrderId.getProperty("text").getString();
        System.out.println("Work Order ID: " + workOrderIdValue);
        Thread.sleep(5000);

        return workOrderIdValue;
    }

    public static String getContractId() throws InterruptedException, IOException {

        Thread.sleep(10000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent contractId = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/ctxtVBAK-VBELN").toDispatch());
        String contractIdValue = contractId.getProperty("text").getString();
        System.out.println("contractIdValue: " + contractIdValue);
        Thread.sleep(5000);

        return contractIdValue;
    }

    public static String getBfoNumber() throws InterruptedException, IOException {

        Thread.sleep(10000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent bfoNumber = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/subSUB_ALL:SAPLCOIH:3001/ssubSUB_LEVEL:SAPLCOIH:1100/tabsTS_1100/tabp+CUK/ssubSUB_AUFTRAG:SAPLCOIH:1180/subCUSTSCR1:SAPLXWOC:0900/txtCAUFVD-YYWRKNO").toDispatch());
        String bfoNumberValue = bfoNumber.getProperty("text").getString();
        System.out.println("BFO Number: " + bfoNumberValue);
        Thread.sleep(5000);

        return bfoNumberValue;
    }

    public static String getWorkOrderType() throws InterruptedException, IOException {

        Thread.sleep(10000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent workOrderType = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/subSUB_ALL:SAPLCOIH:3001/ssubSUB_LEVEL:SAPLCOIH:1100/tabsTS_1100/tabp+CUK/ssubSUB_AUFTRAG:SAPLCOIH:1180/subCUSTSCR1:SAPLXWOC:0900/txtCAUFVD-YYWRKTYP").toDispatch());
        String workOrderTypeValue = workOrderType.getProperty("text").getString();
        System.out.println("Work Order Type: " + workOrderTypeValue);
        Thread.sleep(5000);

        return workOrderTypeValue;
    }
    public static String getWorkOrderSubType() throws InterruptedException, IOException {

        Thread.sleep(8000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent workOrderSubType = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/subSUB_ALL:SAPLCOIH:3001/ssubSUB_LEVEL:SAPLCOIH:1100/tabsTS_1100/tabp+CUK/ssubSUB_AUFTRAG:SAPLCOIH:1180/subCUSTSCR1:SAPLXWOC:0900/txtCAUFVD-YYWRKSUBTYP").toDispatch());
        String workOrderSubTypeValue = workOrderSubType.getProperty("text").getString();
        System.out.println("Work Order Type: " + workOrderSubTypeValue);
        Thread.sleep(5000);

        return workOrderSubTypeValue;
    }


    public static ActiveXComponent selectComponent() throws InterruptedException, IOException {

        Thread.sleep(5000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent tab = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/subSUB_ALL:SAPLCOIH:3001/ssubSUB_LEVEL:SAPLCOIH:1100/tabsTS_1100/tabpMUEB").toDispatch());
        tab.invoke("select");
        Thread.sleep(5000);

        return wnd;
    }

    public static String getPartsOrder() throws InterruptedException, IOException {

        Thread.sleep(4000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent partsOrder = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/subSUB_ALL:SAPLCOIH:3001/ssubSUB_LEVEL:SAPLCOIH:1101/tabsTS_1100/tabpMUEB/ssubSUB_AUFTRAG:SAPLCOMK:3020/tblSAPLCOMKTCTRL_3020/ctxtRESBD-MATNR[1,0]").toDispatch());
        String partsOrderValue = partsOrder.getProperty("text").getString();
        System.out.println("Parts order is: " + partsOrderValue);
        Thread.sleep(5000);

        return partsOrderValue;
    }

    public static String getWorkOrderNameReason() throws InterruptedException, IOException {

        Thread.sleep(5000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent workOrderNameReason = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/subSUB_ALL:SAPLCOIH:3001/ssubSUB_LEVEL:SAPLCOIH:1100/subSUB_KOPF:SAPLCOIH:1102/subSUB_TEXT:SAPLCOIH:1103/cntlLTEXT/shell").toDispatch());
        String workOrderNameReasonValue = workOrderNameReason.getProperty("text").getString();
        System.out.println("Work Order ID: " + workOrderNameReasonValue);
        Thread.sleep(5000);

        return workOrderNameReasonValue;
    }

    public static String getStatus() throws InterruptedException, IOException {

        Thread.sleep(5000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent relStatus = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/subSUB_ALL:SAPLCOIH:3001/ssubSUB_LEVEL:SAPLCOIH:1100/subSUB_KOPF:SAPLCOIH:1102/txtCAUFVD-STTXT").toDispatch());
        String workOrderStatus = relStatus.getProperty("text").getString();
        System.out.println("Work Order status is: " + workOrderStatus);
        Thread.sleep(5000);

        return workOrderStatus;
    }

    public static ActiveXComponent entercontractOrderNumber(String code) throws InterruptedException, IOException {

        Thread.sleep(10000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent contractNumber = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/ctxtVBAK-VBELN").toDispatch());
        contractNumber.setProperty("text", code);

        ActiveXComponent wn = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        wn.invoke("sendVKey", 0);

        return wnd;

    }
    public static ActiveXComponent click() throws InterruptedException {

        Thread.sleep(10000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent popUp = new ActiveXComponent(Session.invoke("findById", "wnd[1]/tbar[0]/btn[0]").toDispatch());
//        contractNumber.setProperty("text", code);
        popUp.invoke("press");

        ActiveXComponent wn = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        wn.invoke("sendVKey", 0);

        return wnd;

    }
    //
    public static ActiveXComponent clickDisplayHeaderdetails() throws InterruptedException {
//
        Thread.sleep(10000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent popUp = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/subSUBSCREEN_HEADER:SAPMV45A:4021/btnBT_HEAD").toDispatch());
//        contractNumber.setProperty("text", code);
        popUp.invoke("press");

//        ActiveXComponent wn = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
//        wn.invoke("sendVKey", 0);
//
        return wnd;

    }
    public static ActiveXComponent clickStatusTab() throws InterruptedException, IOException {

        Thread.sleep(10000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent tab = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/tabsTAXI_TABSTRIP_HEAD/tabpT\\12").toDispatch());
        tab.invoke("select");
        Thread.sleep(5000);

        return wnd;
    }
    public static String contractUserStatus() throws InterruptedException, IOException {

        Thread.sleep(10000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent userStatus = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/tabsTAXI_TABSTRIP_HEAD/tabpT\\12/ssubSUBSCREEN_BODY:SAPMV45A:4305/txtRV45A-ASTTX").toDispatch());
        String userStatusValue = userStatus.getProperty("text").getString();
        System.out.println("User Status is : " + userStatusValue);
        Thread.sleep(5000);

        return userStatusValue;
    }
    public static ActiveXComponent enterContractType(String code) throws InterruptedException, IOException {

        Thread.sleep(6000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent contractType = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/ctxtVBAK-AUART").toDispatch());
        contractType.setProperty("text", code);
        return wnd;

    }
    public static ActiveXComponent enterOrderType(String code) throws InterruptedException, IOException {

        Thread.sleep(6000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent wkOrderType = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/ctxtAUFPAR-PM_AUFART").toDispatch());
        wkOrderType.setProperty("text", code);
        return wnd;

    }
    public static ActiveXComponent enterSalesOrganization(String code) throws InterruptedException, IOException {

        Thread.sleep(4000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent salesOrganization = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/ctxtVBAK-VKORG").toDispatch());
        salesOrganization.setProperty("text", code);

        return wnd;

    }
    public static ActiveXComponent enterPriority(String code) throws InterruptedException, IOException {

        Thread.sleep(4000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent salesOrganization = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/cmbCAUFVD-PRIOK").toDispatch());
        salesOrganization.setProperty("key", code);

        return wnd;

    }
    public static ActiveXComponent enterDistributionChannel(String code) throws InterruptedException, IOException {

        Thread.sleep(4000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent distributionChannel = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/ctxtVBAK-VTWEG").toDispatch());
        distributionChannel.setProperty("text", code);

//        ActiveXComponent wn = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
//        wn.invoke("sendVKey", 0);

        return wnd;

    }
    public static ActiveXComponent enterDivision(String code) throws InterruptedException, IOException {

        Thread.sleep(4000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent division = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/ctxtVBAK-SPART").toDispatch());
        division.setProperty("text", code);

        ActiveXComponent wn = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        wn.invoke("sendVKey", 0);

        return wnd;

    }
    public static ActiveXComponent enterPingPlant(String code) throws InterruptedException, IOException {

        Thread.sleep(4000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent division = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/ctxtCAUFVD-IWERK").toDispatch());
        division.setProperty("text", code);

        ActiveXComponent wn = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        wn.invoke("sendVKey", 0);

        return wnd;

    }
    public static ActiveXComponent enterSoldtoParty(String code) throws InterruptedException, IOException {

        Thread.sleep(10000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent soldParty = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/subSUBSCREEN_HEADER:SAPMV45A:4021/subPART-SUB:SAPMV45A:4701/ctxtKUAGV-KUNNR").toDispatch());
        soldParty.setProperty("text", code);

        return wnd;

    }
    public static ActiveXComponent enterWorkOrderSoldToParty(String code) throws InterruptedException, IOException {

        Thread.sleep(8000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent soldParty = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/subSUB_ALL:SAPLCOIH:3001/ssubSUB_LEVEL:SAPLCOIH:1100/tabsTS_1100/tabpIHKZ/ssubSUB_AUFTRAG:SAPLCOIH:1120/subSUB_ADRESSE:SAPLIPAR:0704/tabsTSTRIP_700/tabpKUND/ssubTSTRIP_SCREEN:SAPLIPAR:0130/subADRESSE:SAPLIPAR:0150/ctxtVIQMEL-KUNUM").toDispatch());
        soldParty.setProperty("text", code);

        return wnd;

    }
    public static ActiveXComponent enterServiceProduct(String code) throws InterruptedException, IOException {

        Thread.sleep(8000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent serviceProduct = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/subSUB_ALL:SAPLCOIH:3001/ssubSUB_LEVEL:SAPLCOIH:1100/tabsTS_1100/tabpIHKZ/ssubSUB_AUFTRAG:SAPLCOIH:1120/subSUB_SERVICE:SAPLCOI3:0300/ctxtPMSDO-MATNR").toDispatch());
        serviceProduct.setProperty("text", code);

        return wnd;

    }
    public static ActiveXComponent enterWorkOrderQuantity(String code) throws InterruptedException, IOException {

        Thread.sleep(8000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent workOrderQuantity = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/subSUB_ALL:SAPLCOIH:3001/ssubSUB_LEVEL:SAPLCOIH:1100/tabsTS_1100/tabpIHKZ/ssubSUB_AUFTRAG:SAPLCOIH:1120/subSUB_SERVICE:SAPLCOI3:0300/txtPMSDO-MENGE").toDispatch());
        workOrderQuantity.setProperty("text", code);

        return wnd;

    }
    public static ActiveXComponent enterWorkOrderAccountIndicator(String code) throws InterruptedException, IOException {

        Thread.sleep(8000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent WorkOrderAccountIndicator = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/subSUB_ALL:SAPLCOIH:3001/ssubSUB_LEVEL:SAPLCOIH:1100/tabsTS_1100/tabpIHKZ/ssubSUB_AUFTRAG:SAPLCOIH:1120/subSUB_SERVICE:SAPLCOI3:0300/ctxtCAUFVD-BEMOT").toDispatch());
        WorkOrderAccountIndicator.setProperty("text", code);

        return wnd;

    }
    public static ActiveXComponent enterWorkOrderMnWkCtrFirst(String code) throws InterruptedException, IOException {

        Thread.sleep(8000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent WorkOrderMnWkCtrFirst = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/subSUB_ALL:SAPLCOIH:3001/ssubSUB_LEVEL:SAPLCOIH:1100/tabsTS_1100/tabpIHKZ/ssubSUB_AUFTRAG:SAPLCOIH:1120/subHEADER:SAPLCOIH:0154/ctxtCAUFVD-VAPLZ").toDispatch());
        WorkOrderMnWkCtrFirst.setProperty("text", code);

        return wnd;

    }
    public static ActiveXComponent enterWorkOrderMnWkCtrSecond(String code) throws InterruptedException, IOException {

        Thread.sleep(8000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent WorkOrderMnWkCtrSecond = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/subSUB_ALL:SAPLCOIH:3001/ssubSUB_LEVEL:SAPLCOIH:1100/tabsTS_1100/tabpIHKZ/ssubSUB_AUFTRAG:SAPLCOIH:1120/subHEADER:SAPLCOIH:0154/ctxtCAUFVD-VAWRK").toDispatch());
        WorkOrderMnWkCtrSecond.setProperty("text", code);

        return wnd;

    }
    public static ActiveXComponent enterWorkOrderOperationValue(String code) throws InterruptedException, IOException {

        Thread.sleep(8000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent WorkOrderOperationValue = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/subSUB_ALL:SAPLCOIH:3001/ssubSUB_LEVEL:SAPLCOIH:1100/tabsTS_1100/tabpIHKZ/ssubSUB_AUFTRAG:SAPLCOIH:1120/subAVO:SAPLCOI0:0310/txtAFVGD-LTXA1").toDispatch());
        WorkOrderOperationValue.setProperty("text", code);

        return wnd;

    }
    public static ActiveXComponent enterWorkOrderWkCtrPlnt(String code) throws InterruptedException, IOException {

        Thread.sleep(8000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent WorkOrderWkCtrPlnt = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/subSUB_ALL:SAPLCOIH:3001/ssubSUB_LEVEL:SAPLCOIH:1100/tabsTS_1100/tabpIHKZ/ssubSUB_AUFTRAG:SAPLCOIH:1120/subAVO:SAPLCOI0:0310/ctxtAFVGD-ARBPL").toDispatch());
        WorkOrderWkCtrPlnt.setProperty("text", code);

        return wnd;

    }
    public static ActiveXComponent enterWorkOrderCrlkey(String code) throws InterruptedException, IOException {

        Thread.sleep(8000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent WorkOrderCrlkey = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/subSUB_ALL:SAPLCOIH:3001/ssubSUB_LEVEL:SAPLCOIH:1100/tabsTS_1100/tabpIHKZ/ssubSUB_AUFTRAG:SAPLCOIH:1120/subAVO:SAPLCOI0:0310/ctxtAFVGD-STEUS").toDispatch());
        WorkOrderCrlkey.setProperty("text", code);

        return wnd;

    }
    public static ActiveXComponent enterWorkOrderShipToParty(String code) throws InterruptedException, IOException {

        Thread.sleep(8000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent WorkOrderShipToParty = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/subSUB_ALL:SAPLCOIH:3001/ssubSUB_LEVEL:SAPLCOIH:1101/tabsTS_1100/tabpPARU/ssubSUB_AUFTRAG:SAPLIPAR:0201/tblSAPLIPARTCTRL_0200/cmbIHPA-PARVW[0,1]").toDispatch());
        WorkOrderShipToParty.setProperty("key", code);

        return wnd;

    }
    public static ActiveXComponent enterWorkOrderPartnerValue(String code) throws InterruptedException, IOException {

        Thread.sleep(8000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent workOrderPartnerValue = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/subSUB_ALL:SAPLCOIH:3001/ssubSUB_LEVEL:SAPLCOIH:1101/tabsTS_1100/tabpPARU/ssubSUB_AUFTRAG:SAPLIPAR:0201/tblSAPLIPARTCTRL_0200/ctxtIHPA-PARNR[1,1]").toDispatch());
        workOrderPartnerValue.setProperty("text", code);

        return wnd;

    }
    public static ActiveXComponent enterShiptoParty(String code) throws InterruptedException, IOException {

        Thread.sleep(5000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent shipParty = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/subSUBSCREEN_HEADER:SAPMV45A:4021/subPART-SUB:SAPMV45A:4701/ctxtKUWEV-KUNNR").toDispatch());
        shipParty.setProperty("text", code);

//        ActiveXComponent wn = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
//        wn.invoke("sendVKey", 0);

        return wnd;

    }
    public static ActiveXComponent enterPurchOrderNumber(String code) throws InterruptedException, IOException {

        Thread.sleep(5000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent purchOrderNumber = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/subSUBSCREEN_HEADER:SAPMV45A:4021/txtVBKD-BSTKD").toDispatch());
        purchOrderNumber.setProperty("text", code);

        return wnd;


    }
    public static String getCurrentDateInDotFormat() {
        LocalDate today = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy");
        return today.format(formatter); // <- returns the formatted string
    }
    public static String getEndDateOneYearFromTodayInDotFormat() {
        LocalDate today = LocalDate.now();
        LocalDate endDate = today.plusYears(1); // Adds 1 year dynamically
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy");
        return endDate.format(formatter);
    }
    // Returns tomorrow's date in "dd.MM.yyyy" format
    public static String getTomorrowDateInDotFormat() {
        LocalDate tomorrow = LocalDate.now().plusDays(1);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy");
        return tomorrow.format(formatter);
    }

    // Returns the date one year after tomorrow in "dd.MM.yyyy" format
    public static String getOneYearAfterTomorrowDateInDotFormat() {
        LocalDate endDate = LocalDate.now().plusDays(1).plusYears(1);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy");
        return endDate.format(formatter);
    }
    public static String enterContractStartDate() throws InterruptedException, IOException {

        Thread.sleep(5000);
        String dateValue = getCurrentDateInDotFormat();
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent contractStartDate = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/tabsTAXI_TABSTRIP_OVERVIEW/tabpT\\01/ssubSUBSCREEN_BODY:SAPMV45A:4426/ssubHEADER_FRAME:SAPMV45A:4440/subSUBSCREEN_VERTRAG:SAPLV45W:0400/ctxtVEDA-VBEGDAT").toDispatch());
        contractStartDate.setProperty("text", dateValue);

        return dateValue;

    }
    public static String enterContractEndDate() throws InterruptedException, IOException {

        Thread.sleep(5000);
        String contractEndDateValue = getEndDateOneYearFromTodayInDotFormat();
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent contractEndDate = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/tabsTAXI_TABSTRIP_OVERVIEW/tabpT\\01/ssubSUBSCREEN_BODY:SAPMV45A:4426/ssubHEADER_FRAME:SAPMV45A:4440/subSUBSCREEN_VERTRAG:SAPLV45W:0400/ctxtVEDA-VENDDAT").toDispatch());
        contractEndDate.setProperty("text", contractEndDateValue);

        return contractEndDateValue;

    }
    // Enters contract start date (tomorrow) into SAP and returns the value
    public static String enterContractTomorrowStartDateInSAP() throws InterruptedException, IOException {
        Thread.sleep(5000);
        String startDate = getTomorrowDateInDotFormat();
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());

        ActiveXComponent startDateField = new ActiveXComponent(
                Session.invoke("findById",
                        "wnd[0]/usr/tabsTAXI_TABSTRIP_OVERVIEW/tabpT\\01/ssubSUBSCREEN_BODY:SAPMV45A:4426/ssubHEADER_FRAME:SAPMV45A:4440/subSUBSCREEN_VERTRAG:SAPLV45W:0400/ctxtVEDA-VBEGDAT"
                ).toDispatch()
        );
        startDateField.setProperty("text", startDate);
        return startDate;
    }

    // Enters contract end date (tomorrow + 1 year) into SAP and returns the value
    public static String enterContractTomorrowYearEndDateInSAP() throws InterruptedException, IOException {
        Thread.sleep(5000);
        String endDate = getOneYearAfterTomorrowDateInDotFormat();
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());

        ActiveXComponent endDateField = new ActiveXComponent(
                Session.invoke("findById",
                        "wnd[0]/usr/tabsTAXI_TABSTRIP_OVERVIEW/tabpT\\01/ssubSUBSCREEN_BODY:SAPMV45A:4426/ssubHEADER_FRAME:SAPMV45A:4440/subSUBSCREEN_VERTRAG:SAPLV45W:0400/ctxtVEDA-VENDDAT"
                ).toDispatch()
        );
        endDateField.setProperty("text", endDate);
        return endDate;
    }
    public static ActiveXComponent enterMaterial(String code) throws InterruptedException, IOException {

        Thread.sleep(5000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent material = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/tabsTAXI_TABSTRIP_OVERVIEW/tabpT\\01/ssubSUBSCREEN_BODY:SAPMV45A:4426/subSUBSCREEN_TC:SAPMV45A:4908/tblSAPMV45ATCTRL_U_ERF_KONTRAKT/ctxtRV45A-MABNR[1,0]").toDispatch());
        material.setProperty("text", code);

//        ActiveXComponent wn = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
//        wn.invoke("sendVKey", 0);

        return wnd;

    }
    public static ActiveXComponent enterSecondMaterial(String code) throws InterruptedException, IOException {

        Thread.sleep(5000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent material = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/tabsTAXI_TABSTRIP_OVERVIEW/tabpT\\01/ssubSUBSCREEN_BODY:SAPMV45A:4426/subSUBSCREEN_TC:SAPMV45A:4908/tblSAPMV45ATCTRL_U_ERF_KONTRAKT/ctxtRV45A-MABNR[1,1]").toDispatch());
        material.setProperty("text", code);

//        ActiveXComponent wn = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
//        wn.invoke("sendVKey", 0);

        return wnd;

    }
    public static ActiveXComponent enterTargetQuantity(String code) throws InterruptedException, IOException {

        Thread.sleep(5000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent targetQuantity = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/tabsTAXI_TABSTRIP_OVERVIEW/tabpT\\01/ssubSUBSCREEN_BODY:SAPMV45A:4426/subSUBSCREEN_TC:SAPMV45A:4908/tblSAPMV45ATCTRL_U_ERF_KONTRAKT/txtVBAP-ZMENG[2,0]").toDispatch());
        targetQuantity.setProperty("text", code);

        return wnd;

    }

    public static ActiveXComponent enterOrderQuantity(String code) throws InterruptedException, IOException {

        Thread.sleep(5000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent orderQuantity = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/tabsTAXI_TABSTRIP_OVERVIEW/tabpT\\01/ssubSUBSCREEN_BODY:SAPMV45A:4426/subSUBSCREEN_TC:SAPMV45A:4908/tblSAPMV45ATCTRL_U_ERF_KONTRAKT/txtRV45A-KWMENG[8,0]").toDispatch());
        orderQuantity.setProperty("text", code);
        return wnd;

    }

    public static ActiveXComponent enterSecondTargetQuantity(String code) throws InterruptedException, IOException {

        Thread.sleep(5000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent targetQuantity = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/tabsTAXI_TABSTRIP_OVERVIEW/tabpT\\01/ssubSUBSCREEN_BODY:SAPMV45A:4426/subSUBSCREEN_TC:SAPMV45A:4908/tblSAPMV45ATCTRL_U_ERF_KONTRAKT/txtVBAP-ZMENG[2,1]").toDispatch());
        targetQuantity.setProperty("text", code);

        return wnd;

    }

    public static ActiveXComponent enterSecondOrderQuantity(String code) throws InterruptedException, IOException {

        Thread.sleep(5000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent orderQuantity = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/tabsTAXI_TABSTRIP_OVERVIEW/tabpT\\01/ssubSUBSCREEN_BODY:SAPMV45A:4426/subSUBSCREEN_TC:SAPMV45A:4908/tblSAPMV45ATCTRL_U_ERF_KONTRAKT/txtRV45A-KWMENG[8,1]").toDispatch());
        orderQuantity.setProperty("text", code);
        return wnd;

    }

    public static String getFirstMaterialItem() throws InterruptedException, IOException {

        Thread.sleep(6000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent userStatus = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/tabsTAXI_TABSTRIP_OVERVIEW/tabpT\\01/ssubSUBSCREEN_BODY:SAPMV45A:4426/subSUBSCREEN_TC:SAPMV45A:4908/tblSAPMV45ATCTRL_U_ERF_KONTRAKT/txtVBAP-POSNR[0,0]").toDispatch());
        String firstMaterialItem = userStatus.getProperty("text").getString();
        System.out.println("First Material item number : " + firstMaterialItem);
        Thread.sleep(5000);

        return firstMaterialItem;
    }

    public static String getSecondMaterialItem() throws InterruptedException, IOException {

        Thread.sleep(6000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent userStatus = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/tabsTAXI_TABSTRIP_OVERVIEW/tabpT\\01/ssubSUBSCREEN_BODY:SAPMV45A:4426/subSUBSCREEN_TC:SAPMV45A:4908/tblSAPMV45ATCTRL_U_ERF_KONTRAKT/txtVBAP-POSNR[0,1]").toDispatch());
        String secondMaterialItem = userStatus.getProperty("text").getString();
        System.out.println("Second Material item number : " + secondMaterialItem);
        Thread.sleep(5000);

        return secondMaterialItem;
    }

    public static String getFirstMaterial() throws InterruptedException, IOException {

        Thread.sleep(6000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent userStatus = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/tabsTAXI_TABSTRIP_OVERVIEW/tabpT\\01/ssubSUBSCREEN_BODY:SAPMV45A:4426/subSUBSCREEN_TC:SAPMV45A:4908/tblSAPMV45ATCTRL_U_ERF_KONTRAKT/ctxtRV45A-MABNR[1,0]").toDispatch());
        String firstMaterial = userStatus.getProperty("text").getString();
        System.out.println("First Material is : " + firstMaterial);
        Thread.sleep(5000);

        return firstMaterial;
    }
    public static String getSecondMaterial() throws InterruptedException, IOException {

        Thread.sleep(6000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent userStatus = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/tabsTAXI_TABSTRIP_OVERVIEW/tabpT\\01/ssubSUBSCREEN_BODY:SAPMV45A:4426/subSUBSCREEN_TC:SAPMV45A:4908/tblSAPMV45ATCTRL_U_ERF_KONTRAKT/ctxtRV45A-MABNR[1,1]").toDispatch());
        String secondMaterial = userStatus.getProperty("text").getString();
        System.out.println("Second Material is : " + secondMaterial);
        Thread.sleep(5000);

        return secondMaterial;
    }
    public static ActiveXComponent clickSaveButton() throws InterruptedException, IOException {

        Thread.sleep(5000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent saveButton = new ActiveXComponent(Session.invoke("findById", "wnd[0]/tbar[0]/btn[11]").toDispatch());
        saveButton.invoke("press");
        Thread.sleep(5000);

        return wnd;
    }
    public static ActiveXComponent clickDocumentFlowButton() throws InterruptedException, IOException {

        Thread.sleep(5000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent saveButton = new ActiveXComponent(Session.invoke("findById", "wnd[0]/tbar[1]/btn[35]").toDispatch());
        saveButton.invoke("press");
        Thread.sleep(5000);

        return wnd;
    }
//    public static ActiveXComponent enterTable(String code) throws InterruptedException, IOException {
//
//        Thread.sleep(10000);
//        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
//        // Enter transaction code VA03
//        ActiveXComponent tableNumber = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/ctxtGD-TAB").toDispatch());
//        tableNumber.setProperty("text", code);
//
//        ActiveXComponent wn = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
//        wn.invoke("sendVKey", 0);
//
//        return wnd;
//    }
public static String enterTableName(String code, String goldenId) {
    try {

        Robot robot = new Robot();
        Thread.sleep(8000); // Small delay to ensure the textbox is focused

        typeText(robot, code);
        Thread.sleep(3000); // Optional pause before Enter
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);
        Thread.sleep(6000);
        robot.keyPress(KeyEvent.VK_CONTROL);
        robot.keyPress(KeyEvent.VK_F);
        robot.keyRelease(KeyEvent.VK_F);
        robot.keyRelease(KeyEvent.VK_CONTROL);
        Thread.sleep(6000);
        typeText(robot, "golden id");
        Thread.sleep(3000);
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);
        Thread.sleep(5000);
        // Press Tab 6 times
        for (int i = 0; i < 6; i++) {
            robot.keyPress(KeyEvent.VK_TAB);
            robot.keyRelease(KeyEvent.VK_TAB);
            Thread.sleep(2000);

        }

// Type 1234
        typeText(robot, goldenId);
        Thread.sleep(4000);
        robot.keyPress(KeyEvent.VK_F8);
        robot.keyRelease(KeyEvent.VK_F8);
        Thread.sleep(8000);
        // Hit TAB key to focus the active field

        robot.keyPress(KeyEvent.VK_TAB);

        robot.keyRelease(KeyEvent.VK_TAB);

        // Wait a bit for the focus to shift

        Thread.sleep(2000);

        // Press CTRL + C to copy the value

        robot.keyPress(KeyEvent.VK_CONTROL);

        robot.keyPress(KeyEvent.VK_C);

        robot.keyRelease(KeyEvent.VK_C);

        robot.keyRelease(KeyEvent.VK_CONTROL);

        // Wait for the clipboard to be updated

        Thread.sleep(500);

        // Read from the clipboard

        String clipboardContent = getClipboardContent();

        // Print the clipboard content

        System.out.println("Clipboard content: " + clipboardContent);
        return clipboardContent;

    } catch (Exception e) {
        e.printStackTrace();
    }
    return code;
}

    // Method to retrieve clipboard content
    private static String getClipboardContent() {
        try {
            Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
            Transferable content = clipboard.getContents(null);
            if (content != null && content.isDataFlavorSupported(DataFlavor.stringFlavor)) {
                return (String) content.getTransferData(DataFlavor.stringFlavor);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }
    private static void typeText(Robot robot, String text) throws InterruptedException {
        for (char ch : text.toCharArray()) {
            typeChar(robot, ch);
            Thread.sleep(100); // Delay between keystrokes
        }
    }

    private static void typeChar(Robot robot, char ch) {
        boolean isUpperCase = Character.isUpperCase(ch);
        int keyCode = KeyEvent.getExtendedKeyCodeForChar(ch);

        if (isUpperCase) {
            robot.keyPress(KeyEvent.VK_SHIFT);
        }

        robot.keyPress(keyCode);
        robot.keyRelease(keyCode);

        if (isUpperCase) {
            robot.keyRelease(KeyEvent.VK_SHIFT);
        }
    }



//    public static String getRefPartOrderInDocument() throws InterruptedException, IOException {
//
//        Thread.sleep(8000);
//        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
//        // Enter transaction code VA03
//        ActiveXComponent refPartOrder = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/shell/shellcont[1]/shell[1]").toDispatch());
//        String workOrderRefPartsOrder = refPartOrder.getProperty("text").getString();
//        System.out.println("Ref Parts Order is: " + workOrderRefPartsOrder);
//        Thread.sleep(5000);
//
//        return workOrderRefPartsOrder;
//    }

    public static void doubleClickPartOrderInDocument(String row, String column) throws InterruptedException, IOException {
        Thread.sleep(8000);

        // Maximize the window (optional but safer)
//        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
//        wnd.invoke("maximize");

        // Access the SAP grid
//        ActiveXComponent grid = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/shell/shellcont[1]/shell[1]").toDispatch());
//
//        // Get the value from row and column
//        Variant cellValue = grid.invoke("GetCellValue", new Variant("          3"), new Variant("&Hierarchy"));
//        String workOrderRefPartsOrder = cellValue.getString();
//
//        System.out.println("Ref Parts Order is: " + workOrderRefPartsOrder);
//
//        Thread.sleep(5000);
//        return workOrderRefPartsOrder;

        Thread.sleep(3000);
        String workOrderRefPartsOrder = "";
        // Maximize the window

        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());

        wnd.invoke("maximize");

        // Access the grid shell

        ActiveXComponent grid = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/shell/shellcont[1]/shell[1]").toDispatch());

        // Double click item in the grid

        grid.invoke("doubleClickItem", new Variant(row), new Variant(column));

        System.out.println("Double clicked on row " + row + " column " + column);

    }

    public static String pressDownTabAndCopy() throws Exception {
        Robot robot = new Robot();
        robot.setAutoDelay(5000); // Small delay between actions

        // Press DOWN arrow 2 times
        robot.keyPress(KeyEvent.VK_DOWN);
        robot.keyRelease(KeyEvent.VK_DOWN);
        Thread.sleep(2000);

        robot.keyPress(KeyEvent.VK_DOWN);
        robot.keyRelease(KeyEvent.VK_DOWN);
        Thread.sleep(2000);

        // Press TAB
        robot.keyPress(KeyEvent.VK_TAB);
        robot.keyRelease(KeyEvent.VK_TAB);
        Thread.sleep(2000);

        // Press CTRL+C to copy
        robot.keyPress(KeyEvent.VK_CONTROL);
        robot.keyPress(KeyEvent.VK_C);
        Thread.sleep(2000);
        robot.keyRelease(KeyEvent.VK_C);
        robot.keyRelease(KeyEvent.VK_CONTROL);

        // Read from clipboard
        Thread.sleep(2000); // wait for clipboard to update
        Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
        Transferable contents = clipboard.getContents(null);

        if (contents != null && contents.isDataFlavorSupported(DataFlavor.stringFlavor)) {
            String copiedText = (String) contents.getTransferData(DataFlavor.stringFlavor);
            System.out.println("Copied Text: " + copiedText);
            return copiedText;
        } else {
            System.out.println("No text data found in clipboard!");
            return "";
        }
    }

    public static String getMnWkCtr() throws InterruptedException, IOException {

        Thread.sleep(5000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent mnWkCtr = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/subSUB_ALL:SAPLCOIH:3001/ssubSUB_LEVEL:SAPLCOIH:1100/tabsTS_1100/tabpIHKZ/ssubSUB_AUFTRAG:SAPLCOIH:1120/subHEADER:SAPLCOIH:0154/txtCAUFVD-VATXT").toDispatch());
        String workOrderMnWkCtr = mnWkCtr.getProperty("text").getString();
        System.out.println("Work Order MnWkCtr is: " + workOrderMnWkCtr);
        Thread.sleep(5000);

        return workOrderMnWkCtr;
    }
    public static String getOperationFirstActValue() throws InterruptedException, IOException {

        Thread.sleep(4000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent firstActValue = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/subSUB_ALL:SAPLCOIH:3001/ssubSUB_LEVEL:SAPLCOIH:1101/tabsTS_1100/tabpVGUE/ssubSUB_AUFTRAG:SAPLCOVG:3010/tblSAPLCOVGTCTRL_3010/txtAFVGD-VORNR[0,0]").toDispatch());
        String workOrderFirstActValue = firstActValue.getProperty("text").getString();
        System.out.println("First Act value is: " + workOrderFirstActValue);
        Thread.sleep(5000);

        return workOrderFirstActValue;
    }
    public static String getOperationSecondActValue() throws InterruptedException, IOException {

        Thread.sleep(4000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent secondActValue = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/subSUB_ALL:SAPLCOIH:3001/ssubSUB_LEVEL:SAPLCOIH:1101/tabsTS_1100/tabpVGUE/ssubSUB_AUFTRAG:SAPLCOVG:3010/tblSAPLCOVGTCTRL_3010/txtAFVGD-VORNR[0,1]").toDispatch());
        String workOrderSecondActValue = secondActValue.getProperty("text").getString();
        System.out.println("First Act value is: " + workOrderSecondActValue);
        Thread.sleep(5000);

        return workOrderSecondActValue;
    }

    public static String getPartnerShipToParty() throws InterruptedException, IOException {

        Thread.sleep(4000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent shipToParty = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/subSUB_ALL:SAPLCOIH:3001/ssubSUB_LEVEL:SAPLCOIH:1101/tabsTS_1100/tabpPARU/ssubSUB_AUFTRAG:SAPLIPAR:0201/tblSAPLIPARTCTRL_0200/ctxtIHPA-PARNR[1,0]").toDispatch());
        String workOrderPartnerShipToParty = shipToParty.getProperty("text").getString();
        System.out.println("Partner Ship To Party is: " + workOrderPartnerShipToParty);
        Thread.sleep(5000);

        return workOrderPartnerShipToParty;
    }
    public static String getPartnerSoldToParty() throws InterruptedException, IOException {

        Thread.sleep(4000);
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        // Enter transaction code VA03
        ActiveXComponent soldToParty = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/subSUB_ALL:SAPLCOIH:3001/ssubSUB_LEVEL:SAPLCOIH:1101/tabsTS_1100/tabpPARU/ssubSUB_AUFTRAG:SAPLIPAR:0201/tblSAPLIPARTCTRL_0200/ctxtIHPA-PARNR[1,1]").toDispatch());
        String workOrderPartnerSoldToParty = soldToParty.getProperty("text").getString();
        System.out.println("Partner Sold To Party is: " + workOrderPartnerSoldToParty);
        Thread.sleep(5000);

        return workOrderPartnerSoldToParty;
    }

}