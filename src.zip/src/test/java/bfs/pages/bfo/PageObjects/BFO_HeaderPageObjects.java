package bfs.pages.bfo.PageObjects;

import com.codeborne.selenide.ClickOptions;
import com.codeborne.selenide.SelenideElement;

import static com.codeborne.selenide.Condition.enabled;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selectors.byTagAndText;
import static com.codeborne.selenide.Selenide.$;

public class BFO_HeaderPageObjects {

    private static final String USER_PROFILE = "div.slds-global-header__item>ul>li>span>div>button>div>[data-aura-class='forceSocialPhoto']";
    private static final SelenideElement LOGOUT_LINK =   $(byTagAndText("a","Log Out"));

    public BFO_HeaderPageObjects clickOnUserProfile(){
        $(USER_PROFILE).shouldBe(enabled).click(ClickOptions.usingJavaScript());
        return this;
    }

    public BFO_HeaderPageObjects clickOnLogout(){
        LOGOUT_LINK.shouldBe(visible,enabled).click();
        return this;
    }

}
