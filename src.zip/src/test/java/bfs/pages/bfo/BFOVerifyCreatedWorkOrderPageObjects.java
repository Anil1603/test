package bfs.pages.bfo;

import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.WebDriverRunner;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import bfs.CONSTANTS;
import bfs.pages.BasePage;

import java.time.Duration;
import java.util.NoSuchElementException;

import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;
import static org.openqa.selenium.support.ui.ExpectedConditions.numberOfWindowsToBe;
import static org.openqa.selenium.support.ui.ExpectedConditions.titleContains;
import static bfs.pages.BasePage.highLightElement;

public class BFOVerifyCreatedWorkOrderPageObjects {

    private static final By WorkOrderText = By.xpath("//span[text()='Work Order Number *']/../../following-sibling::*//span//lightning-formatted-text");
    public String getWorkOrderNumber(){
        highLightElement($(WorkOrderText).shouldBe(visible));
        return $(WorkOrderText).shouldBe(visible).getText();
    }

    public void openWorkOrder(String url) throws InterruptedException {
        WebDriverRunner.getWebDriver().navigate().to(url);
        By textBoxLocator = By.xpath("//span[text()='Assignment']");
        $(textBoxLocator).shouldBe(visible);
        ((JavascriptExecutor) WebDriverRunner.getWebDriver()).executeScript("arguments[0].scrollIntoView(true);", WebDriverRunner.getWebDriver().findElement(textBoxLocator));
        int maximum_try =0;
        while( $(By.xpath("//span[text()='Back Office Reference #']/../../following-sibling::*//span//lightning-formatted-text")).getText().equalsIgnoreCase("")){
            Selenide.refresh();
            Thread.sleep(60000);
            ((JavascriptExecutor) WebDriverRunner.getWebDriver()).executeScript("arguments[0].scrollIntoView(true);", WebDriverRunner.getWebDriver().findElement(textBoxLocator));
            maximum_try++;
            System.out.println(maximum_try);
            if(maximum_try==5){break;}
        }


    }

    public String verifyFields(String locator) {

        try {
            By textBoxLocator = By.xpath("//slot[@name='outputField']/lightning-formatted-text[text()='"+locator+"']");
            WebDriverWait wait = new WebDriverWait(WebDriverRunner.getWebDriver(), Duration.ofSeconds(120));
            WebElement textBox =wait.until(ExpectedConditions.visibilityOfElementLocated(textBoxLocator));
            //WebElement textBox = driver.findElement(textBoxLocator);
            ((JavascriptExecutor) WebDriverRunner.getWebDriver()).executeScript("arguments[0].scrollIntoView(true);", textBox);
            return textBox.getText();
        }
        catch (NoSuchElementException e) {
            System.out.println(locator +"is not present. " + e.fillInStackTrace());
            return "";
        }

        catch (Exception e) {
            System.out.println("An error occurred while verifying "+  locator + e.fillInStackTrace());
            return "";
        }

    }

    public Boolean verifyFields(String Fieldname, String text) {
        By textBoxLocator = null;
        boolean result = false;
        try {
            BasePage.highLightElement($(By.xpath("//span[text()='" + Fieldname + "']")));
            textBoxLocator = By.xpath("//span[text()='" + Fieldname + "']/../../following-sibling::*//span[text()='" + text + "']");
            WebDriverWait wait = new WebDriverWait(WebDriverRunner.getWebDriver(), Duration.ofSeconds(120));
            WebElement textBox = wait.until(ExpectedConditions.visibilityOfElementLocated(textBoxLocator));
           // WebElement textBox = WebDriverRunner.getWebDriver().findElement(textBoxLocator);
            result =textBox.getText().equalsIgnoreCase(text);
            ((JavascriptExecutor) WebDriverRunner.getWebDriver()).executeScript("arguments[0].scrollIntoView(true);", textBox);
            Actions act = new Actions(WebDriverRunner.getWebDriver()).scrollToElement(textBox);
        } catch (NoSuchElementException e) {
            System.out.println(Fieldname + "is not present. " + e.fillInStackTrace());
        } catch (Exception e) {
            System.out.println("An error occurred while verifying " + text + e.fillInStackTrace());
        }
        return result;
    }


    public void clickCreate_UpdateWorkOrderLink() throws InterruptedException {
        String originalWindow = WebDriverRunner.getWebDriver().getWindowHandle();
        Actions actions = new Actions(WebDriverRunner.getWebDriver());
        actions.moveToElement(WebDriverRunner.getWebDriver().findElement(By.xpath("//a[@title='Create/Update Work Order']"))).click().build().perform();
        new WebDriverWait(WebDriverRunner.getWebDriver(), Duration.ofSeconds(60))
                .until(numberOfWindowsToBe(2));

        //Loop through until we find a new window handle
        for (String windowHandle : WebDriverRunner.getWebDriver().getWindowHandles()) {
            if(!originalWindow.contentEquals(windowHandle)) {
                WebDriverRunner.getWebDriver().switchTo().window(windowHandle);
                break;
            }
        }
        $(By.xpath("//button[text()='OK']")).shouldBe(visible).click();
        WebDriverRunner.getWebDriver().switchTo().window(WebDriverRunner.getWebDriver().getWindowHandles().iterator().next());
        new WebDriverWait(WebDriverRunner.getWebDriver(), Duration.ofSeconds(60))
                .until(titleContains("Work Order"));
        Thread.sleep(20000);

    }

    public void fetchBackOfficeReferencenumber() throws InterruptedException {

        By textBoxLocator = By.xpath("//span[text()='Assignment']");
        $(textBoxLocator).shouldBe(visible);
        ((JavascriptExecutor) WebDriverRunner.getWebDriver()).executeScript("arguments[0].scrollIntoView(true);", WebDriverRunner.getWebDriver().findElement(textBoxLocator));
        int maximum_try = 0;
        while ($(By.xpath("//span[text()='Back Office Reference #']/../../following-sibling::*//span//lightning-formatted-text")).getText().equalsIgnoreCase("")) {
            Selenide.refresh();
            Thread.sleep(60000);
            ((JavascriptExecutor) WebDriverRunner.getWebDriver()).executeScript("arguments[0].scrollIntoView(true);", WebDriverRunner.getWebDriver().findElement(textBoxLocator));
            maximum_try++;
            System.out.println(maximum_try);
            if (maximum_try == 5) {
                break;
            }
        }

    }

    public void checkOrderStatus(String status) {
        $(By.cssSelector("body")).sendKeys(Keys.HOME);
        By WorkOrderstatus = By.xpath("//li//a[@role='option'][@aria-selected='true']//span[contains(@class,'title')]");
        Assert.assertTrue($(WorkOrderstatus).shouldBe(visible).getText().contains(status));
        CONSTANTS.captureScreen=true;
    }
}
