package bfs.pages.servicemax.PageObjects;

import bfs.CONSTANTS;
import com.codeborne.selenide.*;
import bfs.pages.BasePage;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import java.time.LocalDate;
import java.util.List;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import static bfs.pages.bfo.ApplicationCommonMethods.*;
import static com.codeborne.selenide.Condition.enabled;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.*;
import static com.codeborne.selenide.Selenide.executeJavaScript;

public class ServiceBoardPageObjects {
    public static final String SEARCH_ALL_RESOURCES_TEXTBOX = "//input[@placeholder='Search All Resources']";
    public static final String WARNING_MESSAGE = "//div[@class='FormField form-field FormField--warning']/div";
    public static final String TIME_TEXTBOX = "(\"px-datetime-picker#svmx_start_datetime\").getShadowRoot().findElement(By.cssSelector(\"px-datetime-field\")).getShadowRoot()\n" +
            "                    .findElement(By.cssSelector(\"div>div>div#fieldWrapper>#time\")).getShadowRoot().findElement(By.cssSelector(\"div>px-datetime-entry-cell\")).getShadowRoot().findElement(By.cssSelector(\"input\"))";

    public static final String JOB_VALUE="//label[contains(text(),'Job')]/following-sibling::div/span";
    public static final String PRIMARY_FSR="//span[@class='test-id__field-value slds-form-element__static slds-grow word-break-ie11 is-read-only']//records-hoverable-link/div/a/span/slot/span/slot";
    public static final String SAVE_BUTTON="//button[contains(text(),'Save')]";
    public static final String HOVER_WO = "//div[@class='Disclosure card__container']";
    public static final String MENU_WORKORDER_BUTTON = "//div[@class='card-action__dropdown-container']//px-dropdown";
    public static final String MANAGE_MULTIPLE_RESOURCES_OPTION = "div.dropdown-option[title='Manage Multiple Resources']";
    public static final String ALIGN_APPOINTMENT_BUTTON = "//px-toggle[@id='alignAppt']";
    public static final String PLUS_ICON_FSR = "//div[text()='%s']//parent::div//preceding-sibling::px-icon";
    public static final String SAVE_AND_EXIT_BUTTON = "//a[contains(@class,'save-and-exit')]";
    public static final String EXIT_BUTTON = "//span[text()='Exit']";
    //public static final String FIRST_FSR_APPOINTMENT = "(//span[contains(text(),'%s')]//ancestor::div[contains(@id,'ganttEventDescriptionID')])[1]";
    public static final String FIRST_FSR_APPOINTMENT1 = "(//span[contains(text(),'New Appointment')]//ancestor::div[contains(@id,'ganttEventDescriptionID')])[1]";
    public static final String FIRST_FSR_APPOINTMENT = "(//span[contains(text(),'New Appointment')]//ancestor::div[contains(@id,'dcGanttGrid') and contains(@class,'sch-event')])[1]";
    public static final String EDIT_APPOINTMENT = "//span[text()='Edit Appointment']";
    public static final String EDIT_APPOINTMENT_HEADER = "//div[text()='Edit Appointment']";
    public static final String PRIMARY_FSR_TEXTBOX1 = "(//span[contains(text(),'Primary FSR')]//ancestor::dt//following-sibling::dd//span)[4]";
    public static final String PRIMARY_FSR_TEXTBOX = "(//span[contains(text(),'Primary FSR')]//parent::div//following-sibling::div//span)[4]";
    public static final String HOVER_ON_FSR = "//div[text()='%s']//ancestor::table";
    public static final String MENU_FSR_BUTTON = "//div[text()='%s']//following-sibling::div[@class='dc-resource-menu']";
    public static final String SET_AS_PRIMARY_RESOURCE = "//span[text()='Set as Primary Resource']";
    public static final String YES_BUTTON = "//button[text()='Yes']";
    public static final String FSR_SEARCH_RESULT = "//div[@id='dcGantt-1017-body']//div[@id='dc-resource__info-name-id' and text()='%s']";
    public static final String WORK_ORDER_SERVCIE_BOARD = "//div[@class='Disclosure__trigger card__trigger']//div[@class='card-line__content' and contains(@id,'name')]";
    public static final String FREQUENCY_UNIT_OPTIONS = "iron-selector//div[@title='%s']";
    public static final String SKIP_WEEKENDS_CHECKBOX = "//div[@fid='bfs_skip_weekends']//input";
    public static  List<WebElement> childElements1;
    public static final String COUNT_OF_SLOTS_FOR_WORKORDER = "//span[contains(text(),'%s')]//ancestor::div[@unselectable='on' and contains(@id,'timelineview')]";

    public ServiceBoardPageObjects setResourceNameOnSearchBoxAndClickEnter(String resourceName) {
        $x(SEARCH_ALL_RESOURCES_TEXTBOX).shouldBe(visible, enabled).setValue(resourceName);
        actions().sendKeys(Keys.ENTER).perform();
        return this;
    }

    public ServiceBoardPageObjects setResourceNameOnSearchBoxAfterClearingAndClickEnter(String resourceName) {
        waitForElementToBeVisibleAndClickable($x(SEARCH_ALL_RESOURCES_TEXTBOX));
        //waitForGivenTime(4000);
        $x(SEARCH_ALL_RESOURCES_TEXTBOX).shouldBe(visible, enabled).click();
        copyAndBackspace($x(SEARCH_ALL_RESOURCES_TEXTBOX));
        $x(SEARCH_ALL_RESOURCES_TEXTBOX).shouldBe(visible, enabled).setValue(resourceName);
        actions().sendKeys(Keys.ENTER).perform();
        return this;
    }

    public void dragAndDropWorkOrderToFSR() {
        String WORK_ORDER_COMPONENTS = "//div[@class='card__container card__main-part']/ancestor::div[@class='card-action__container card__action card__drag-zone']";
        //String FSR_COMPONENTS = "//div[contains(text(),'FSR_1532')]/ancestor::div[@class='x-grid-scrollbar-clipper x-grid-scrollbar-clipper-locked ']/following-sibling::div//table//tr[@class='dc-gantt-row--child  x-grid-row']//div[@id='sch-timespangroup-ext-76-DC.model.Event-2']/div";
        String FSR_COMPONENTS = "//table[contains(@id,'timelineview-record')]//tbody//tr//td//div//div[contains(@style,'background: rgba(136')]";

       SelenideElement WORK_ORDER = $x(WORK_ORDER_COMPONENTS);
        ElementsCollection WORK_ORDER_ = $$x(WORK_ORDER_COMPONENTS);

        int width = WORK_ORDER.getSize().getWidth();
        System.out.println(width);
       int height = WORK_ORDER.getSize().getHeight();
        System.out.println(height);
        SelenideElement FSR = $x(FSR_COMPONENTS);
        Selenide.sleep(7000);
       actions().moveToElement((WORK_ORDER_).get(0)).moveByOffset(15,7).clickAndHold().dragAndDropBy($$x(FSR_COMPONENTS).get(0), 0, 30).release().perform();
        Selenide.sleep(5000);
      //  actions().dragAndDrop(WORK_ORDER, FSR).perform();
      //  actions().moveToElement(WORK_ORDER).dragAndDrop(WORK_ORDER, FSR).build().perform();
      //  actions().moveToElement(WORK_ORDER).clickAndHold().moveToElement(FSR).release().perform();
        //actions().doubleClick(WORK_ORDER).clickAndHold().moveToElement(FSR).release().perform();
    }
/*
        public void setStartTimeIfWorngingMessageAppear() {
            // Fetch the initial time value from the TIME_TEXTBOX and convert it to an integer
            int initialTime = Integer.parseInt(executeJavaScript("return " + TIME_TEXTBOX + ".value").toString());

            // Loop until the warning message is no longer displayed
            while ($x(WARNING_MESSAGE).isDisplayed()) {
                executeJavaScript("arguments[0].click();", $(TIME_TEXTBOX));
                $(TIME_TEXTBOX).setValue(String.valueOf(initialTime)).pressEnter().pressTab();

                // Increment the time by 1
                initialTime++;
            }
        }
*/

    public void dragAndDropWorkOrderAndAssignRecurringAppointmentToFSR() {
        String WORK_ORDER_COMPONENTS = "//div[@class='card__container card__main-part']/ancestor::div[@class='card-action__container card__action card__drag-zone']";
        //String FSR_COMPONENTS = "//div[contains(text(),'FSR_1532')]/ancestor::div[@class='x-grid-scrollbar-clipper x-grid-scrollbar-clipper-locked ']/following-sibling::div//table//tr[@class='dc-gantt-row--child  x-grid-row']//div[@id='sch-timespangroup-ext-76-DC.model.Event-2']/div";
        String FSR_COMPONENTS = "//table[contains(@id,'timelineview-record')]//tbody//tr//td//div//div[contains(@style,'background: rgba(136')]";

        SelenideElement WORK_ORDER = $x(WORK_ORDER_COMPONENTS);
        ElementsCollection WORK_ORDER_ = $$x(WORK_ORDER_COMPONENTS);

        int width = WORK_ORDER.getSize().getWidth();
        System.out.println(width);
        int height = WORK_ORDER.getSize().getHeight();
        System.out.println(height);
        SelenideElement FSR = $x(FSR_COMPONENTS);
        Selenide.sleep(7000);
        actions().moveToElement((WORK_ORDER_).get(0)).moveByOffset(15,7).clickAndHold().dragAndDropBy($$x(FSR_COMPONENTS).get(0), 0, 30).release().perform();
        Selenide.sleep(5000);
        //  actions().dragAndDrop(WORK_ORDER, FSR).perform();
        //  actions().moveToElement(WORK_ORDER).dragAndDrop(WORK_ORDER, FSR).build().perform();
        //  actions().moveToElement(WORK_ORDER).clickAndHold().moveToElement(FSR).release().perform();
        //actions().doubleClick(WORK_ORDER).clickAndHold().moveToElement(FSR).release().perform();
    }

    public ServiceBoardPageObjects getChildElementForRecurrentFields() {
        WebElement slot1 = $("px-accordion[header-value='Schedule']").getShadowRoot().findElement(By.cssSelector("iron-collapse>div>slot"));
        childElements1 = executeJavaScript(
                "return arguments[0].assignedNodes().filter(node => node.nodeType === Node.ELEMENT_NODE);", slot1
        );
        return this;
    }

    public ServiceBoardPageObjects enterFrequency(String frequency) {
        WebElement frequencyTextBox = childElements1.get(0).findElement(By.xpath("//input[@id='bfs_frequency']"));
        frequencyTextBox.click();
        frequencyTextBox.sendKeys(frequency);
        return this;
    }

    public ServiceBoardPageObjects selectFrequencyUnit(String frequencyUnit) {
        WebElement frequencyUnit_Dropdown_arrow = (WebElement) childElements1.get(0).findElement(By.cssSelector("div[fid='bfs_frequency_unit']"))
                .findElement(By.cssSelector("px-dropdown")).getShadowRoot().
                findElement(By.cssSelector("px-dropdown-trigger")).getShadowRoot().
                findElement(By.cssSelector("px-icon")).getShadowRoot().
                findElement(By.cssSelector("iron-icon"));
        ((JavascriptExecutor) WebDriverRunner.getWebDriver()).executeScript("arguments[0].scrollIntoView(true);", frequencyUnit_Dropdown_arrow);
        frequencyUnit_Dropdown_arrow.click();

        WebElement frequencyUnit_Dropdown_slot1 = childElements1.get(0)
                .findElement(By.cssSelector("div[fid='bfs_frequency_unit']"))
                .findElement(By.cssSelector("px-dropdown")).getShadowRoot()
                .findElement(By.cssSelector("px-overlay-content")).getShadowRoot()
                .findElement(By.cssSelector("slot"));
        List<WebElement> frequencyUnit_Dropdown_options_slot1_Nodes = executeJavaScript(
                "return arguments[0].assignedNodes().filter(node => node.nodeType === Node.ELEMENT_NODE);", frequencyUnit_Dropdown_slot1
        );

        WebElement slot2 = frequencyUnit_Dropdown_options_slot1_Nodes.get(0).getShadowRoot()
                .findElement(By.cssSelector("iron-dropdown")).getShadowRoot()
                .findElement(By.cssSelector("slot"));
        List<WebElement> dropdown_options_slot2_nodes = executeJavaScript(
                "return arguments[0].assignedNodes().filter(node => node.nodeType === Node.ELEMENT_NODE);", slot2
        );
        WebElement dropdown_option = dropdown_options_slot2_nodes.get(0).findElement(By.xpath(String.format(FREQUENCY_UNIT_OPTIONS, frequencyUnit)));
        dropdown_option.click();
        return this;
    }

    public ServiceBoardPageObjects enterRecurrenceEndDate(String numberOfDays) {
        try {
            LocalDate endDate = LocalDate.now().plusDays(Integer.parseInt(numberOfDays));
            String day = String.valueOf(endDate.getDayOfMonth());
            String month = String.valueOf(endDate.getMonthValue());
            String year = String.valueOf(endDate.getYear());

            WebElement recurrenceEndDate_textField_Date = findElementByOrder("1");
            WebElement recurrenceEndDate_textField_Month = findElementByOrder("0");
            WebElement recurrenceEndDate_textField_Year = findElementByOrder("2");

            recurrenceEndDate_textField_Date.click();
            recurrenceEndDate_textField_Date.sendKeys(day);
            recurrenceEndDate_textField_Month.sendKeys(month);
            recurrenceEndDate_textField_Year.sendKeys(year);
        } catch (Exception e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
        return this;
    }

    private WebElement findElementByOrder(String order) {
        return childElements1.get(0).findElement(By.xpath("//div[@fid='bfs_recurrence_end_date']"))
                .findElement(By.cssSelector("px-datetime-picker")).getShadowRoot()
                .findElement(By.cssSelector("px-datetime-field")).getShadowRoot()
                .findElement(By.cssSelector("px-datetime-entry")).getShadowRoot()
                .findElement(By.cssSelector("px-datetime-entry-cell[order='" + order + "']")).getShadowRoot()
                .findElement(By.cssSelector("input"));
    }

    public ServiceBoardPageObjects selectSkipWeekendCheckBox(boolean skipWeekend) {
        WebElement skipWeekendCheckbox = childElements1.get(0).findElement(By.xpath(SKIP_WEEKENDS_CHECKBOX));
        if (skipWeekendCheckbox.isSelected() != skipWeekend) {
            skipWeekendCheckbox.click();
        }
        CONSTANTS.captureScreen = true;
        return this;
    }



    public int getCountofRecurringSlots_CurrentWorkOrder(String workOrderNumber) {
        return $$x(String.format(COUNT_OF_SLOTS_FOR_WORKORDER, workOrderNumber)).size();
    }

    public void setStartTimeIfWorngingMessageAppear(String time) {
        int timeValue = Integer.parseInt(time);

        while ($x(WARNING_MESSAGE).isDisplayed()) {
            // Locate the input field and click it
            WebElement setValue = $("px-datetime-picker#svmx_start_datetime").getShadowRoot().findElement(By.cssSelector("px-datetime-field")).getShadowRoot()
                    .findElement(By.cssSelector("div>div>div#fieldWrapper>#time")).getShadowRoot().findElement(By.cssSelector("div>px-datetime-entry-cell")).getShadowRoot().findElement(By.cssSelector("input"));
            setValue.click();

            // Set the value and press Tab
            setValue.clear();
            setValue.sendKeys(String.valueOf(timeValue));
            setValue.sendKeys(Keys.TAB);

            // Increment the time value by 1
            timeValue++;
        }
    }


    public void setRecurringTime(String frequency, String frequencyUnit, String recurrenceEndDate, boolean skipWeekend) {

    }

/*
    public void setStartTimeIfWorngingMessageAppear(String time) {
        if ($x(WARNING_MESSAGE).isDisplayed()) {
            $("px-datetime-picker#svmx_start_datetime").getShadowRoot().findElement(By.cssSelector("px-datetime-field")).getShadowRoot()
                    .findElement(By.cssSelector("div>div>div#fieldWrapper>#time")).getShadowRoot().findElement(By.cssSelector("div>px-datetime-entry-cell")).getShadowRoot().findElement(By.cssSelector("input")).click();
            WebElement setValue = $("px-datetime-picker#svmx_start_datetime").getShadowRoot().findElement(By.cssSelector("px-datetime-field")).getShadowRoot()
                    .findElement(By.cssSelector("div>div>div#fieldWrapper>#time")).getShadowRoot().findElement(By.cssSelector("div>px-datetime-entry-cell")).getShadowRoot().findElement(By.cssSelector("input"));
            //set the value using and pass time
            setValue.sendKeys(time);
            setValue.sendKeys(Keys.TAB);

        }
    }
*/
    public void checkTheJobValue(String jobValue) {
        Assert.assertTrue($x(JOB_VALUE).shouldBe(visible).getText().contains(jobValue));
    }
    public ServiceBoardPageObjects clickOnSaveButton(){
        $x(SAVE_BUTTON).shouldBe(visible,enabled).click();
        return this;}

    public void checkPrimaryFSR(String fsrName){
        $$x(PRIMARY_FSR).get(18).shouldBe(visible).scrollIntoView(false);
        Selenide.sleep(2000);
        Assert.assertTrue($$x(PRIMARY_FSR).get(18).shouldBe(visible).getText().contains(fsrName));
    }


    public ServiceBoardPageObjects hoverOnWorkOrder() {
        highlightElement($x(HOVER_WO).shouldBe(visible, enabled));
        actions().moveToElement($x(HOVER_WO)).build().perform();
        return this;
    }

    public ServiceBoardPageObjects clickWorkOrderMenu() {
        highlightElement($x(MENU_WORKORDER_BUTTON).shouldBe(visible, enabled));
        $x(MENU_WORKORDER_BUTTON).shouldBe(visible, enabled).click();
        return this;
    }

    public ServiceBoardPageObjects selectManageMultipleReourcesOptions() {
        WebElement slot = $("px-dropdown").getShadowRoot().findElement(By.cssSelector("px-dropdown-content")).getShadowRoot().findElement(By.cssSelector("iron-dropdown")).getShadowRoot().findElement(By.cssSelector("div>slot"));
        List<WebElement> childElements = executeJavaScript(
                "return arguments[0].assignedNodes().filter(node => node.nodeType === Node.ELEMENT_NODE);", slot
        ); // this returns div iron-selector
        childElements.get(0).findElement(By.cssSelector(MANAGE_MULTIPLE_RESOURCES_OPTION)).click();
        return this;
    }



    public ServiceBoardPageObjects enableAlignAppointmentButton() {
        highlightElement($x(ALIGN_APPOINTMENT_BUTTON).shouldBe(visible, enabled));
        if ($x(ALIGN_APPOINTMENT_BUTTON).getAttribute("checked") == null) {
            $x(ALIGN_APPOINTMENT_BUTTON).click();
        }
        return this;
    }

    public ServiceBoardPageObjects clickPlusIconForFSR(String fsr) {
        //waitForGivenTime(6000);
        waitForElementToBeVisibleAndClickable($x(String.format(FSR_SEARCH_RESULT, fsr.replace("-", " "))));
        WebElement plusIcon = $("px-icon.dc-resource__add").getShadowRoot().findElement(By.cssSelector("iron-icon"));
        executeJavaScript("arguments[0].click();", plusIcon);
        return this;
    }

    public ServiceBoardPageObjects clickFirstFsrSlot() {
        SelenideElement timeSlot = $x(FIRST_FSR_APPOINTMENT);
        timeSlot.click();
        return this;
    }

    public ServiceBoardPageObjects clickEditAppointment() {
        highlightElement($x(EDIT_APPOINTMENT).shouldBe(visible, enabled));
        $x(EDIT_APPOINTMENT).shouldBe(visible, enabled).click();
        $x(EDIT_APPOINTMENT_HEADER).shouldBe(visible);
        return this;
    }

    public ServiceBoardPageObjects clickSaveAndExit() {
        highlightElement($x(SAVE_AND_EXIT_BUTTON).shouldBe(visible, enabled));
        $x(SAVE_AND_EXIT_BUTTON).shouldBe(visible, enabled).click();
        return this;
    }

    public String getPrimaryFSR() {
        return $x(PRIMARY_FSR_TEXTBOX).getText();
    }

    public ServiceBoardPageObjects hoverOnFSR(String fsr) {
        Selenide.sleep(2000);
        highlightElement($x(String.format(HOVER_ON_FSR, fsr)).shouldBe(visible, enabled));
        actions().moveToElement($x(String.format(HOVER_ON_FSR, fsr))).build().perform();
        return this;
    }

    public ServiceBoardPageObjects clickFSRMenu(String fsr) {
        hoverOnFSR(fsr);
        highlightElement($x(String.format(MENU_FSR_BUTTON, fsr)).shouldBe(visible, enabled));
        $x(String.format(MENU_FSR_BUTTON, fsr)).shouldBe(visible, enabled).click();
        return this;
    }

    public ServiceBoardPageObjects clickSetAsPrimaryResource() {
        highlightElement($x(SET_AS_PRIMARY_RESOURCE).shouldBe(visible, enabled));
        $x(SET_AS_PRIMARY_RESOURCE).shouldBe(visible, enabled).click();
        return this;
    }

    public ServiceBoardPageObjects clickOnYesButton() {
        highlightElement($x(YES_BUTTON).shouldBe(visible, enabled));
        $x(YES_BUTTON).shouldBe(visible, enabled).click();
        return this;
    }

    public ServiceBoardPageObjects clickOnExitButton() {
        highlightElement($x(EXIT_BUTTON).shouldBe(visible, enabled));
        $x(EXIT_BUTTON).shouldBe(visible, enabled).click();
        return this;
    }

    public WebElement spinnerInServiceBoard(){
       return  $("px-spinner").getShadowRoot().findElement(By.cssSelector("div.spinner-container"));
    }

    }




