package bfs.sap;

import com.jacob.activeX.ActiveXComponent;
import com.jacob.com.ComThread;
import com.jacob.com.Dispatch;
import com.jacob.com.Variant;

import java.io.IOException;

public class LoginTest extends SAPGuiClassName{


    /*
     * Declaring the ActiveXComponent Objects
     */
    static ActiveXComponent SAPROTWr;
    static ActiveXComponent GUIApp;
    static ActiveXComponent Connection;
    static ActiveXComponent Session;
    static ActiveXComponent Obj;
    ActiveXComponent SAPGIRD;
    static Dispatch ROTEntry;
    Variant Value;
    static Variant ScriptEngine;
    private static Process p;
    static SAPGeneric sapGenric;
    /*
     * Opens the SAP Session and returns the Active Session Object
     */

    public static void getSapSessionObject() throws InterruptedException{
        String cnt = "0";
        ComThread.InitSTA();

        //Opening the SAP Logon
        try {
            p = Runtime.getRuntime().exec("C:\\Program Files (x86)\\SAP\\FrontEnd\\SAPgui\\saplogon.exe");
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        Thread.sleep(5000);
        //-Set SapGuiAuto = GetObject("SAPGUI")---------------------------
        SAPROTWr = new ActiveXComponent("SapROTWr.SapROTWrapper");

        ROTEntry = SAPROTWr.invoke("GetROTEntry", "SAPGUI").toDispatch();
        //-Set application = SapGuiAuto.GetScriptingEngine------------
        ScriptEngine = Dispatch.call(ROTEntry, "GetScriptingEngine");
        GUIApp = new ActiveXComponent(ScriptEngine.toDispatch());
/*
        SAPROTWr = new ActiveXComponent("SapROTWr.SapROTWrapper");
        //SAP Connection Name
        Connection = new ActiveXComponent(
                GUIApp.invoke("OpenConnection","(Bridge) ECC 6.0 SSO - TRA - QAW Quality EMEA").toDispatch());

        //-Set session = connection.Children(0)-----------------------

        //Initialization for the SAPGeneric
        sapGenric  = new SAPGeneric(Connection);
        sapGenric.setSession(new ActiveXComponent(sapGenric.getSession().invoke("FindById", "wnd[0]").toDispatch()));
        Session=sapGenric.getSession();
        */
    }
 public static void loginToTRASystem() throws InterruptedException {

     SAPROTWr = new ActiveXComponent("SapROTWr.SapROTWrapper");
     //SAP Connection Name
     Connection = new ActiveXComponent(
             GUIApp.invoke("OpenConnection","(Bridge) ECC 6.0 SSO - TRA - QAW Quality EMEA").toDispatch());

     //-Set session = connection.Children(0)-----------------------

     //Initialization for the SAPGeneric
     //Thread.sleep(10000);
     sapGenric  = new SAPGeneric(Connection);
     sapGenric.setSession(new ActiveXComponent(sapGenric.getSession().invoke("FindById", "wnd[0]").toDispatch()));
     Session=sapGenric.getSession();
     //   return this;


     /*
     SAPROTWr = new ActiveXComponent("SapROTWr.SapROTWrapper");
     // SAP Connection Name
     Connection = new ActiveXComponent(
             GUIApp.invoke("OpenConnection", "(Bridge) ECC 6.0 SSO - TRA - QAW Quality EMEA").toDispatch());

     // Check if the connection has children
     //Variant childrenCount = Connection.getProperty("Children").toDispatch().invoke("Count");
     Variant childrenCount = Dispatch.call(Connection.getProperty("Children").toDispatch(), "Count");
     if (childrenCount.getInt() > 0) {
         // Initialization for the SAPGeneric
         sapGenric = new SAPGeneric(Connection);
         sapGenric.setSession(new ActiveXComponent(sapGenric.getSession().invoke("FindById", "wnd[0]").toDispatch()));
         Session = sapGenric.getSession();
     } else {
         System.err.println("No children found in the connection.");
     }
     */
 }

    /*
     * Logging to SAP GUI
     */

    public static void  LoginSAPGUI() throws InterruptedException
    {/*

       // Session = sapGenric.getSession();
        Thread.sleep(10000);
        sapGenric.SAPGUIOKCodeFiled("okcd", "VA01");
        sapGenric.SAPGUIEnter();
        Thread.sleep(2000L);
        sapGenric.setTextByName("VBAK-AUART",SAPGuiClassName.GuiCTextClassName ,"ZOR");
        setTextByName("VBAK-VKORG",SAPGuiClassName.GuiCTextClassName,"0001");
        Thread.sleep(2000L);
        Obj = new ActiveXComponent(Session.invoke("findById","wnd[0]").toDispatch());
        Obj.invoke("sendVKey", 0);
        Thread.sleep(10000);
        Obj = new ActiveXComponent(Session.invoke("findById","wnd[0]/usr/subSUBSCREEN_HEADER:SAPMV45A:4021/subPART-SUB:SAPMV45A:4701/ctxtKUAGV-KUNNR").toDispatch());
        Obj.setProperty("text", "0001");
        // Create a Variant array with the name and type of the GUI element
        //setTextByName("VBAK-AUART",SAPGuiClassName.GuiCTextClassName,"ZOR");
     /*   Obj = new ActiveXComponent(sapGenric.getSession().invoke("findById","wnd[0]/usr/ctxtVBAK-AUART").toDispatch());
        Obj.setProperty("text", "VA01");
        Obj = new ActiveXComponent(sapGenric.getSession().invoke("findById","wnd[0]").toDispatch());
        Obj.invoke("sendVKey", 0);
        Thread.sleep(5000);*/
/*
        Thread.sleep(10000);
        sapGenric.SAPGUIOKCodeFiled("okcd", "VA03");
        sapGenric.SAPGUIEnter();
        Thread.sleep(2000L);     //VBAK-VBELN
    //    sapGenric.setTextByName("VBAK-VBELN",SAPGuiClassName.GuiCTextClassName , CONSTANTS.data.get("SalesOrderNumber"));
        sapGenric.setTextByName("VBAK-VBELN",SAPGuiClassName.GuiCTextClassName , "0222603534");
     //   setTextByName("VBAK-VKORG",SAPGuiClassName.GuiCTextClassName,"0001");
        Thread.sleep(2000L);
        //table name - SAPMV45ATCTRL_U_ERF_AUFTRAG

        Thread.sleep(10000);
*/
        // Maximize the window
     //   Session.invoke("findById", "wnd[0]").invoke("maximize");
        ActiveXComponent wnd = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        wnd.invoke("maximize");

        // Enter transaction code VA03
        ActiveXComponent okcd = new ActiveXComponent(Session.invoke("findById", "wnd[0]/tbar[0]/okcd").toDispatch());
        okcd.setProperty("text", "VA03");
     //   Session.invoke("findById", "wnd[0]").invoke("sendVKey", 0);
        ActiveXComponent wn = new ActiveXComponent(Session.invoke("findById", "wnd[0]").toDispatch());
        wn.invoke("sendVKey", 0);
        Thread.sleep(2000);

        // Set sales order number
        ActiveXComponent vbeln = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/ctxtVBAK-VBELN").toDispatch());
        vbeln.setProperty("text", "0222602564");
       vbeln.setProperty("caretPosition", 10);

        // Press search button
      //  Session.invoke("findById", "wnd[0]/usr/btnBT_SUCH").invoke("press");
        ActiveXComponent btnSearch = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/btnBT_SUCH").toDispatch());
        btnSearch.invoke("press");
        // Adjust column width
        Thread.sleep(10000);
        ActiveXComponent table = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/tabsTAXI_TABSTRIP_OVERVIEW/tabpT\\01/ssubSUBSCREEN_BODY:SAPMV45A:4400/subSUBSCREEN_TC:SAPMV45A:4900/tblSAPMV45ATCTRL_U_ERF_AUFTRAG").toDispatch());
     //   table.invoke("columns").invoke("elementAt", 26).setProperty("width", 20);
     //   ActiveXComponent table1 = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/tabsTAXI_TABSTRIP_OVERVIEW/tabpT\\01/ssubSUBSCREEN_BODY:SAPMV45A:4400/subSUBSCREEN_TC:SAPMV45A:4900/tblSAPMV45ATCTRL_U_ERF_AUFTRAG").toDispatch());
        ActiveXComponent columns = new ActiveXComponent(table.invoke("columns").toDispatch());
        ActiveXComponent column = new ActiveXComponent(columns.invoke("elementAt", 26).toDispatch());
        column.setProperty("width", 20);
        // Set focus on dropdown
        ActiveXComponent dropdown_0 = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/tabsTAXI_TABSTRIP_OVERVIEW/tabpT\\01/ssubSUBSCREEN_BODY:SAPMV45A:4400/subSUBSCREEN_TC:SAPMV45A:4900/tblSAPMV45ATCTRL_U_ERF_AUFTRAG/cmbVBAP-ABGRU[26,0]").toDispatch());
        dropdown_0.invoke("setFocus");
       String test_0 = dropdown_0.getPropertyAsString("text");
        System.out.println(test_0.isBlank());
        ActiveXComponent dropdown_1 = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/tabsTAXI_TABSTRIP_OVERVIEW/tabpT\\01/ssubSUBSCREEN_BODY:SAPMV45A:4400/subSUBSCREEN_TC:SAPMV45A:4900/tblSAPMV45ATCTRL_U_ERF_AUFTRAG/cmbVBAP-ABGRU[26,1]").toDispatch());
        dropdown_1.invoke("setFocus");
        String test_1 = dropdown_1.getPropertyAsString("text");
        System.out.println(test_1);
        ActiveXComponent dropdown_2 = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/tabsTAXI_TABSTRIP_OVERVIEW/tabpT\\01/ssubSUBSCREEN_BODY:SAPMV45A:4400/subSUBSCREEN_TC:SAPMV45A:4900/tblSAPMV45ATCTRL_U_ERF_AUFTRAG/cmbVBAP-ABGRU[26,2]").toDispatch());
        dropdown_2.invoke("setFocus");
        String test_2 = dropdown_2.getPropertyAsString("text");
        System.out.println(test_2);
        wnd.invoke("close");
        Thread.sleep(6000);
        ActiveXComponent btnClose = new ActiveXComponent(Session.invoke("findById", "wnd[1]/usr/btnSPOP-OPTION1").toDispatch());
        Thread.sleep(6000);
        btnClose.invoke("press");
    }

    public static void invokePress(ActiveXComponent session, String locatorType, String locatorValue){
        session = new ActiveXComponent(session.invoke(locatorType,locatorValue).toDispatch());
        session.invoke("press");
    }
    private static void setTextByName(String elementName, String sapGuiClassName, String value) throws InterruptedException {
        Variant[] arg = new Variant[2];
        arg[0] = new Variant(elementName); // Name of the element
        arg[1] = new Variant(sapGuiClassName); // Type of the element
        // Use findByName with the Variant array
        Obj = new ActiveXComponent(Session.invoke("findByName", arg).toDispatch());
        Obj.setProperty("text", value);
        Thread.sleep(2000L);
    }


    public static void main(String[] args) throws InterruptedException {
        getSapSessionObject();
        loginToTRASystem();
        LoginSAPGUI();

    }

}
