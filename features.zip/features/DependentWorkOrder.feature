Feature: Dependent Work Order Creation.
  As a user
  I want to navigate to the application and create two Work Orders for a specific Dependent Scenario
  So that I can manage both work orders from specific Dependent Scenario efficiently

	#@BFSTST-2032 @BFSTST-2033
  Scenario: Create a Dependent Work Order for a specific Dependent Scenario Finish to Start
		#Coordinator
    Given I work in application "BFO" and environment "UAT"
    And I login to "BFO" as user "coordinator-1660@bridge-fo.com.uatbfo26"
    When I navigate to "SE - Services Lightning" from app launcher
    And I wait for "10" seconds
    And I navigate to "Work Orders" from app launcher
    And I click on bfo button "New"
    And I fill work order details for creating new work order from Work Order Page:
      |Field Name                            | Field Value                               |
      |Select Record Type                    | Standalone Work Order                     |
      |Installed At Account                  | 0001340233:Ampcontrol (QLD) Pty Ltd       |
      |Location                              | 0045144542:Ampcontrol QLD Pty Ltd         |
      |Work Order Type                       | Repair                                    |
#    |Work Order Sub-Type                   |                                           |
      |Contact                               |   chandra.vamsi kumar                     |
      |Customer Requested Date               | today                                     |
      |Country of Back Office                | Australia                                 |
      | Back Office System                   |SAP Bridge AP                              |
      |Work Order Category                   |Onsite                                     |
      |Services Business Unit                |POWER SYSTEMS                              |
      |Is Billable                           | Yes                                       |
      |Customer Reference Number             |1234                                       |
      |Priority                              | Normal-Medium                             |
#    |Non Billing Reason                    |                                           |
      |Service Commercial Ref                |QWPFSRVPLNNSGEN                            |
#    |Skill Category                        |                                           |
      |Work Order Reason                     | Testing                                   |
      |Work Order Name                       | Testing                                   |
      |Sold To Account                       |0001340233:Ampcontrol (QLD) Pty Ltd        |
    Then I should see the work order status as "New" in work order page
    And I memorize work Order as "Work Order1"
    And I navigate to "Work Orders" from app launcher
    And I click on bfo button "New"
    And I fill work order details for creating new work order from Work Order Page:
      |Field Name                            | Field Value                               |
      |Select Record Type                    | Standalone Work Order                     |
      |Installed At Account                  | 0001340233:Ampcontrol (QLD) Pty Ltd       |
      |Location                              | 0045144542:Ampcontrol QLD Pty Ltd         |
      |Work Order Type                       | Repair                                    |
#    |Work Order Sub-Type                   |                                           |
      |Contact                               |   chandra.vamsi kumar                     |
      |Customer Requested Date               | today                                     |
      |Country of Back Office                | Australia                                 |
      | Back Office System                   |SAP Bridge AP                              |
      |Work Order Category                   |Onsite                                     |
      |Services Business Unit                |POWER SYSTEMS                              |
      |Is Billable                           | Yes                                       |
      |Priority                              | Normal-Medium                             |
#    |Non Billing Reason                    |                                           |
      |Service Commercial Ref                |QWPFSRVPLNNSGEN                            |
#    |Skill Category                        |                                           |
      |Work Order Reason                     | Testing                                   |
      |Work Order Name                       | Testing                                   |
      |Sold To Account                       |0001340233:Ampcontrol (QLD) Pty Ltd        |
    Then I should see the work order status as "New" in work order page
    And I memorize work Order as "Work Order2"
    And I click on Create Dependency Group button from work order page
    And I created dependent work order with following details
      |PrimaryWO                             | SecondryWO                                |      Dependency Group Name    |    Description         |     Time Dependency                                                                         |
      |Work Order1                           | Work Order2                               |      Automation Test Group    |    Automation Test     |  Finish to Start: Primary work order must finish before secondary work order can start      |
#      |Work Order1                           | Work Order2                               |      Automation Test Group    |    Automation Test     |  Start to Start: Primary work order must start before secondary work order can start      |
#      |Work Order1                           | Work Order2                               |      Automation Test Group    |    Automation Test     |  Finish to Finish: Primary work order must finish before secondary work order can finish      |
#      |Work Order1                           | Work Order2                               |      Automation Test Group    |    Automation Test     |  Start to Finish: Primary work order must start before secondary work order can finish      |
#      |Work Order1                           | Work Order2                               |      Automation Test Group    |    Automation Test     |  Start in Unison: Both work orders must start simultaneously                           |
#      |Work Order1                           | Work Order2                               |      Automation Test Group    |    Automation Test     |  Finish in Unison: Both work orders must finish simultaneously                           |
    And I memorize Dependency Group Number as "Dependency_Group_Number"
    And I memorize Work Order Dependency Number as "Work_Order_Dependency_Number"
    And I search for WONumber "Work Order2"
    And I selects the "Work Orders" section from "Work Order2"
    And I click on "Create/Update Work Order" button from SFM Tab
#    And I click on "Sync" button from Sync page
    And I check the message "SUCCESS : INITIATED SYNC" on sync window
    And I click on "Ok" button on sync window
    Then I should see the work order status as "Unscheduled" in work order page
    And I wait for back Office reference number
    And I check the "First Synchronization date" and "Last Synchronization date" in work order page
    And I check the "Synchronization Log" as "Work Order CREATED in Back Office" in work order page
    And I add work order to "FSR-1660" in Service Board
    Then I should see the work order status as "Scheduled" in work order page
    And I wait for "160" seconds


