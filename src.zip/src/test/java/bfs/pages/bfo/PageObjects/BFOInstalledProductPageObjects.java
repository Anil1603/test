package bfs.pages.bfo.PageObjects;
import com.codeborne.selenide.ElementsCollection;
import org.openqa.selenium.By;
import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.*;

public class BFOInstalledProductPageObjects {
    private static final String INSTALLED_PRODUCT_SEARCH_TEXTBOX = "//input[@name='enter-search']";
    private static final String GO_BUTTON = "//button[contains(text(),'Go')]";
    private static final String INSTALLED_PRODUCT_NAME_CHECKBOX = "//div[@title='%s']/../following-sibling::td/div[@class='slds-truncate slds-text-align_center']/img/ancestor::td//preceding-sibling::td//input[@type='checkbox']";
    private static final String ATTACH_IP_BUTTON = "//button[contains(text(),'Attach IP')]";

    public BFOInstalledProductPageObjects setInstalledProductSearchTextBox(String productName){
        $x(INSTALLED_PRODUCT_SEARCH_TEXTBOX).shouldBe(visible,enabled).setValue(productName);
        return this;
    }
    public BFOInstalledProductPageObjects clickOnGoButton(){
        $x(GO_BUTTON).shouldBe(visible,enabled).click();
        return this;
    }
    public BFOInstalledProductPageObjects clickOnInstalledProductCheckBox(String productName){
        ElementsCollection INSTALLED_PRODUCT_CHECKBOX = $$x(String.format(INSTALLED_PRODUCT_NAME_CHECKBOX,productName));
        INSTALLED_PRODUCT_CHECKBOX.get(0).shouldBe(visible,enabled).click();
        return this;
    }
    public BFOInstalledProductPageObjects clickOnAttachIPButton(){
        $x(ATTACH_IP_BUTTON).shouldBe(visible,enabled).click();
        return this;
    }
}
