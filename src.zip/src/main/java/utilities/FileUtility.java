package utilities;

import java.io.File;

public class FileUtility {
	
	public static String getFileAbsolutePath(String folderlocation){
		String filepath="";
		try{
			File file=getLastModified(folderlocation);
			filepath=file.getAbsolutePath();
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}
		return filepath;
	}
	
	public static File getLastModified(String directoryFilePath)
	{ 
		File chosenFile = null;
		try{
		File directory = new File(directoryFilePath);
	    File[] files = directory.listFiles(File::isFile);
	    long lastModifiedTime = Long.MIN_VALUE;
	    

	    if (files != null)
	    {
	        for (File file : files)
	        {
	            if (file.lastModified() > lastModifiedTime)
	            {
	                chosenFile = file;
	                lastModifiedTime = file.lastModified();
	            }
	        }
	    }
	    
	}catch(Exception ex){
		System.out.println(ex.getMessage());
	}
	return chosenFile;
	}

	
	public static String getLastModifiedFileName(String directoryFilePath)
	{ 
		File chosenFile = null;
		try{
		File directory = new File(directoryFilePath);
	    File[] files = directory.listFiles(File::isFile);
	    long lastModifiedTime = Long.MIN_VALUE;
	    

	    if (files != null)
	    {
	        for (File file : files)
	        {
	            if (file.lastModified() > lastModifiedTime)
	            {
	                chosenFile = file;
	                lastModifiedTime = file.lastModified();
	            }
	        }
	    }
	    
	}catch(Exception ex){
		System.out.println(ex.getMessage());
	}
	return chosenFile.getAbsolutePath();
	}
	
	public static String getAbsoluteFilePath(String...parameters){
		File filePath =null;
		try{
			filePath = new File(System.getProperty("user.dir") + "/"+parameters[0]+"/"+parameters[1]+parameters[2]);
			
		}catch(Exception ex){
			System.out.println("File is not present or corrupted "+ ex.fillInStackTrace());
		}
		return filePath.getAbsolutePath();
	}
	
	
	public static boolean isFolderEmpty(String path) {
		File file = new File(path);
		boolean isEmpty = false;
		if (file.isDirectory()) {

			if (file.list().length > 0) {

				System.out.println("Directory is not empty!");

			} else {

				System.out.println("Directory is empty!");
				isEmpty = true;
			}

		} else {

			System.out.println("This is not a directory");

		}
		return isEmpty;
	}

	public static void deleteAllFilesFromFolder(String path) {
        try{
			if(!isFolderEmpty(path)){
				File file = new File(path);
				File[] files = file.listFiles();
				for (File f : files) {
					if (f.isFile() && f.exists()) {
						f.delete();
						System.out.println("successfully deleted");
					} else {
						System.out.println("cant delete a file due to open or error");
					}
				}
			}

        }catch(Exception ex){
        	System.out.println(ex.getMessage());
        }
		
	}
	
	public static void deleteAllFilesFromFolderWithExtension(String path,String extension) {

		File file = new File(path);
		File[] files = file.listFiles();
		for (File f : files) {
			System.out.println(f.getName());
			if (f.isFile() && f.exists()&&f.getName().contains(extension)) {
				f.delete();
				System.out.println("successfully deleted");
				break;
			}
		}
	}
	
	
	public static void main(String[] args) {
		String path = System.getProperty("user.dir")+"/features/";
		System.out.println(isFolderEmpty(path));
		File file = new File(path);
		File[] files = file.listFiles();
		for (File f : files) {
			System.out.println(f.getName());
			f.delete();
		}
		
	}
	
	
}
