package bfs.pages.bfo;
import bfs.pages.BasePage;
import com.codeborne.selenide.CollectionCondition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.Selenide;
import org.openqa.selenium.By;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.*;


public class BFONewServiceContractBasicInfoPageObjects {
    private static final By CONTRACT_RECORD_NAME_TEXTBOX = By.xpath("//label[contains(text(),'Contract Record Name/Number')]/following-sibling::div//input");
    private static final By SOLD_TO_ACCOUNT_TEXT_BOX = By.xpath("//label[contains(text(),'Sold To Account')]/following-sibling::div//input[@placeholder='Select an Account']");
    private static final By MAIN_INSTALLED_AT_ACCOUNT_TEXT_BOX = By.xpath("//label[contains(text(),'Main Installed At Account')]/following-sibling::div//input[@placeholder='Select an Account']");
    private static final By MAIN_INSTALLED_AT_CONTACT_TEXT_BOX = By.xpath("//label[contains(text(),'Main Installed at Contact')]/following-sibling::div//input[@placeholder='Select a Contact']");
    private static final By BILL_TO_ACCOUNT_TEXT_BOX = By.xpath("//label[contains(text(),'Bill To Account')]/following-sibling::div//input[@placeholder='Select an Account']");
    private static final By REMOTE_SERVICE_CONTACT_TEXT_BOX = By.xpath("//label[contains(text(),'Remote Service Contact')]/following-sibling::div//input[@placeholder='Select a Contact']");
    private static final By START_DATE_TEXT_BOX = By.xpath("//label[contains(text(),'Start Date')]/following-sibling::div//input");
    private static final By END_DATE_TEXT_BOX = By.xpath("//label[contains(text(),'End Date')]/following-sibling::div//input");
    private static final By Description_TEXT_BOX = By.xpath("//input[@name='Description']");
    private static final By SERVICE_MAINTENANCE_CONTRACT_NEW_BUTTON = By.xpath("//a[@title='New']");

    public BFONewServiceContractBasicInfoPageObjects setServiceContractName(String name) {
        $(CONTRACT_RECORD_NAME_TEXTBOX).shouldBe(visible, enabled).setValue(name);
        Selenide.sleep(4000);
        return this;
    }
    public BFONewServiceContractBasicInfoPageObjects setSoldToAccount(String account) {
        /*
        $(SOLD_TO_ACCOUNT_TEXT_BOX).shouldBe(visible, enabled).setValue(account.split(":")[0]);
        $x("//ul[@role='listbox']//li[@role='presentation']//span[@role='option']//div[text()='"+account.split(":")[1]+"']")
                .should(visible,interactable,enabled).click();
        return this;

         */
        Selenide.sleep(3000);
        $(SOLD_TO_ACCOUNT_TEXT_BOX).shouldBe(visible,enabled).setValue(account.split(":")[0]);
        $x("//li[@role='presentation']//div[contains(text(),'"+account.split(":")[1]+"')]").shouldBe(visible,enabled).click();
        Selenide.sleep(3000);
        return this;
    }

    public BFONewServiceContractBasicInfoPageObjects setMainInstalledAtAccount(String account) {

        //if account name has firsname and lastname
        if(account.contains(":") && account.split(":")[0].contains(" ")){
            String accountName = account.split(":")[0].split(" ")[0];
            $(MAIN_INSTALLED_AT_ACCOUNT_TEXT_BOX).shouldBe(visible, enabled).setValue(accountName);
            BasePage.highLightElement($x("//div[contains(@class,'slds-lookup__menu')]//*[text()='"+account.split(":")[1]+"']"));
            $x("//div[contains(@class,'slds-lookup__menu')]//*[text()='"+account.split(":")[1]+"']").click();
        }else{
            $(MAIN_INSTALLED_AT_ACCOUNT_TEXT_BOX).shouldBe(visible, enabled).setValue(account.split(":")[0]);
            BasePage.highLightElement($x("//div[contains(@class,'slds-lookup__menu')]//*[text()='"+account.split(":")[1]+"']"));
            $x("//div[contains(@class,'slds-lookup__menu')]//*[text()='"+account.split(":")[1]+"']").click();
        }

        /*if(!$$x("//div[contains(@class,'slds-lookup__menu')]//*[contains(text(),'"+account.split(":")[1]+"')]/following-sibling::*").isEmpty()){
          //  BasePage.highLightElement($x("//div[contains(@class,'slds-lookup__menu')]//*[contains(text(),'Sharma Electric works(1003)')]/following-sibling::span[not(normalize-space())]//div[contains(@class,'slds-lookup__menu')]//*[contains(text(),'Sharma Electric works(1003)')]/following-sibling::span[not(normalize-space())]"));
            Selenide.sleep(10);
            BasePage.highLightElement($x("//div[contains(@class,'slds-lookup__menu')]//*[contains(text(),'"+account.split(":")[1]+"')]/following-sibling::*[normalize-space()]"));
            $x("//div[contains(@class,'slds-lookup__menu')]//*[contains(text(),'"+account.split(":")[1]+"')]/following-sibling::*[normalize-space()]").click();
        }else{
            BasePage.highLightElement($x("//div[contains(@class,'slds-lookup__menu')]//*[contains(text(),'"+account.split(":")[1]+"')]/following-sibling::*"));
            $$x("//div[contains(@class,'slds-lookup__menu')]//*[contains(text(),'"+account.split(":")[1]+"')]/following-sibling::*").get(0).click();
        }*/
        return this;
    }

    public BFONewServiceContractBasicInfoPageObjects setMainInstalledAtContact(String contact) {
        //if account name has firsname and lastname
       /* if(contact.contains(":") && contact.split(":")[0].contains(" ")){
            String accountName = contact.split(":")[0].split(" ")[0];
            $(MAIN_INSTALLED_AT_CONTACT_TEXT_BOX).shouldBe(visible, enabled).setValue(accountName);
            BasePage.highLightElement($x("//div[contains(@class,'slds-lookup__menu')]//*[text()='"+contact.split(":")[1]+"']"));
            $x("//div[contains(@class,'slds-lookup__menu')]//*[text()='"+contact.split(":")[1]+"']").click();
        }else{
            $(MAIN_INSTALLED_AT_CONTACT_TEXT_BOX).shouldBe(visible, enabled).setValue(contact.split(":")[0]);
            BasePage.highLightElement($x("//div[contains(@class,'slds-lookup__menu')]//*[text()='"+contact.split(":")[1]+"']"));
            $x("//div[contains(@class,'slds-lookup__menu')]//*[text()='"+contact.split(":")[1]+"']").click();
        }*/

        String accountName = contact.split(":")[0].split(" ")[0];
        $(MAIN_INSTALLED_AT_CONTACT_TEXT_BOX).shouldBe(visible, enabled).setValue(accountName);
       /* Selenide.sleep(10000);
        ElementsCollection lists = $$(".slds-lookup__result-text").shouldHave(CollectionCondition.sizeGreaterThan(0));
        for (int i = 0; i < lists.size(); i++) {
           if(lists.get(i).getText().equalsIgnoreCase(contact.split(":")[1])){
               lists.get(i).click();
               break;
           }
        }*/
        ElementsCollection collections = $$(".slds-lookup__result-text").shouldHave(CollectionCondition.sizeGreaterThan(0));
        collections.filterBy(text(contact.split(":")[1])).first().click();

        //select the contact from ist
        return this;
    }

    public BFONewServiceContractBasicInfoPageObjects setBillToAccount(String account) {
        $(BILL_TO_ACCOUNT_TEXT_BOX).shouldBe(visible, enabled).setValue(account);
        //select the account from ist
        //if account name has firsname and lastname
        if(account.contains(":") && account.split(":")[0].contains(" ")){
            String accountName = account.split(":")[0].split(" ")[0];
            $(BILL_TO_ACCOUNT_TEXT_BOX).shouldBe(visible, enabled).setValue(accountName);
            BasePage.highLightElement($x("//div[contains(@class,'slds-lookup__menu')]//*[text()='"+account.split(":")[1]+"']"));
            $x("//div[contains(@class,'slds-lookup__menu')]//*[text()='"+account.split(":")[1]+"']").click();
        }else{
            $(BILL_TO_ACCOUNT_TEXT_BOX).shouldBe(visible, enabled).setValue(account.split(":")[0]);
            BasePage.highLightElement($x("//div[contains(@class,'slds-lookup__menu')]//*[text()='"+account.split(":")[1]+"']"));
            $x("//div[contains(@class,'slds-lookup__menu')]//*[text()='"+account.split(":")[1]+"']").click();
        }
        return this;
    }

    public BFONewServiceContractBasicInfoPageObjects setRemoteServiceContact(String contact) {
        String contactName = contact.split(":")[0].split(" ")[0];
        $(REMOTE_SERVICE_CONTACT_TEXT_BOX).shouldBe(visible, enabled).setValue(contactName);
        //select the contact from ist
       /* Selenide.sleep(10000);
        ElementsCollection lists = $$(".slds-lookup__result-text").shouldHave(CollectionCondition.sizeGreaterThan(0));
        for (int i = 0; i < lists.size(); i++) {
            if(lists.get(i).getText().equalsIgnoreCase(contact.split(":")[1])){
                lists.get(i).click();
                break;
            }
        }*/
        ElementsCollection collections = $$(".slds-lookup__result-text").shouldHave(CollectionCondition.sizeGreaterThan(0));
        collections.filterBy(text(contact.split(":")[1])).first().click();

        return this;
    }

    public BFONewServiceContractBasicInfoPageObjects setStartDate(String startDate) {
      String currentDate =  BasePage.getTodayDate("MM/dd/yyyy");
        $(START_DATE_TEXT_BOX).shouldBe(visible, enabled).setValue(currentDate);
        return this;
    }

    public BFONewServiceContractBasicInfoPageObjects setEndDate(String endDate) {
        String nextYearDate = BasePage.getNextYearDate("MM/dd/yyyy");
        $(END_DATE_TEXT_BOX).shouldBe(visible, enabled).setValue(nextYearDate);
        return this;
    }

    public BFONewServiceContractBasicInfoPageObjects setDescription(String description) {
        $(Description_TEXT_BOX).shouldBe(visible, enabled).setValue(description);
        return this;
    }

    public BFONewServiceContractBasicInfoPageObjects clickOnNewButton() {
        $(SERVICE_MAINTENANCE_CONTRACT_NEW_BUTTON).shouldBe(visible, enabled).click();
        return this;
    }

    public void setBasicInfoForServiceContract(String fieldName,String value){
        switch (fieldName.toLowerCase()){
            case "contract name" ->setServiceContractName(value).setDescription("Testing");
            case "sold to account"-> setSoldToAccount(value);
            case "main installed at account"->setMainInstalledAtAccount(value);
            case "bill to account"->setBillToAccount(value);
            case "main installed at contact"->setMainInstalledAtContact(value);
            case "remote service contact"->setRemoteServiceContact(value);
            case "start date"->setStartDate(value);
            case "end date"->setEndDate(value);
            case "description"->setDescription(value);
            default -> throw new RuntimeException("Not implemented for " + fieldName);
        }
    }
}
