Feature: work Order Creation.
	#@BFSTST-2032 @BFSTST-2033
  Scenario: Work Order Creation for system SAP BBO AP
		#Coordinator
    Given I work in application "BFO" and environment "UAT"
    And I login to "BFO" as user "coordinator-1660@bridge-fo.com.uatbfo26"
    When I navigate to "SE - Services Lightning" from app launcher
    And I wait for "10" seconds
    And I navigate to "Work Orders" from app launcher
    And I click on bfo button "New"
    And I fill work order details for creating new work order from Work Order Page:
    |Field Name                            | Field Value                               |
    |Select Record Type                    | Standalone Work Order                     |
    |Installed At Account                  | 0001340233:Ampcontrol (QLD) Pty Ltd       |
    |Location                              | 0045144542:Ampcontrol QLD Pty Ltd         |
    |Work Order Type                       | Repair                                    |
#    |Work Order Sub-Type                   |                                           |
    |Contact                               |   chandra.vamsi kumar                     |
    |Customer Requested Date               | today                                     |
    |Country of Back Office                | Australia                                 |
    | Back Office System                   |SAP Bridge AP                              |
    |Work Order Category                   |Onsite                                     |
    |Services Business Unit                |POWER SYSTEMS                              |
    |Is Billable                           | Yes                                       |
    |Priority                              | Normal-Medium                             |
#    |Non Billing Reason                    |                                           |
    |Service Commercial Ref                |QWPFSRVPLNNSGEN                            |
#    |Skill Category                        |                                           |
    |Work Order Reason                     | Testing                                   |
    |Work Order Name                       | Testing                                   |
    |Sold To Account                       |0001340233:Ampcontrol (QLD) Pty Ltd        |
    Then I should see the work order status as "New" in work order page
    And I memorize work Order as "Work Order"
#    And I add Service Maintenance Contract to Work Order:
#      |Field Name                                      | Field Value                           |
#      |Service/Maintenance Contract                    | PRH200-0040160770                     |
    And I click on "Create/Update Work Order" button from SFM Tab
#   And I click on "Sync" button from Sync page
    And I check the message "SUCCESS : INITIATED SYNC" on sync window
    And I click on "Ok" button on sync window
    Then I should see the work order status as "Unscheduled" in work order page
    And I wait for back Office reference number
    And I check the "First Synchronization date" and "Last Synchronization date" in work order page
    And I check the "Synchronization Log" as "Work Order CREATED in Back Office" in work order page
    And I add work order to "John Jeziorski" in Service Board
    Then I should see the work order status as "Scheduled" in work order page
    And I memorized current work order number as "current_work_order_number_Url" and "current_work_order_number"
    Then Change work order status to customer confirmed
    Then I should see the work order status as "Customer Confirmed" in work order page
    And I logout from bfo application
	#FSR User
    Given I work in application "BFO" and environment "UAT"
    And I login to "BFO" as user "ccc-1660@bridge-fo.com.uatbfo26"
    And I navigate to "Setup" Page by using URL
    And I login as Proxy User "John Jeziorski"
    And FSR accepts the work order "current_work_order_number_Url"
    Then check fsr response is "Acknowledge FSR"
    And I click on "Update WO" button from SFM Tab
    And I select the fsr response as "Acknowledge FSR" from update wo page in servicemax
    And I click on "Save" button in update wo page in servicemax
    And I click on "Update WO" button from SFM Tab
    And I select the fsr response as "Under Preparation" from update wo page in servicemax
    And I click on "Save" button in update wo page in servicemax
    Then I should see the work order status as "WIP" in work order page
    And I click on "Update WO" button from SFM Tab
    And I select the fsr response as "On-Site" from update wo page in servicemax
    And I click on "Save" button in update wo page in servicemax
    And I click on "Update WO" button from SFM Tab
    And I select the fsr response as "WIP" from update wo page in servicemax
    And I fill the Risk Assessment details in WIP FSR response:
      |Field Name 		                |Field Value |
      |Is Risk Assessment Attached        |No|
      |NO Risk Assessment Reason          |Other|
      |No Risk Assessment Details         |Testing|
    And I click on "Save" button in update wo page in servicemax
    And I click on "Update WO" button from SFM Tab
    And I select the fsr response as "Delivered" from update wo page in servicemax
    And I fill the service details in delivered fsr response:
      |Field Name 		                |Field Value |
      |Work Performed                     |Testing|
      |Opportunity Detected               |No|
    And I click on add my time  and select the activity as "Service" in delivered fsr response
    And I update the time and click on "Save" button in update wo page in servicemax
    Then I should see the work order status as "Service Delivered" in work order page
    When I click on "Complete WO Tasks" button from SFM Tab
    And I click on "Save" button two times in Complete WO Task page
    Then I should see the work order status as "Service Completed" in work order page
    And I logout from bfo application
	#FSR Manager
#    Given I work in application "BFO" and environment "UAT"
#		#And I navigate to url "https://test.salesforce.com"
##    James WILSON
#    And I login to "BFO" as user "fsrmanager-1660@bridge-fo.com.uat24"
##    When
##    When I click on "My Team Assigned FSR" from home page
##    And I look for the service completed work order "current_work_order_number" and open it
##    And the user selects "Work Orders" from the Search menu
#    And I search for WONumber "Work Order"
#    And I selects the "Work Order" section from "Work Orders"
    Given I work in application "BFO" and environment "UAT"
    And I login to "BFO" as user "ccc-1660@bridge-fo.com.uatbfo26"
    And I navigate to "Setup" Page by using URL
#    And I login as Proxy User "James WILSON"
    And I login as Proxy User SESA "sesa450121" with userName "James WILSON"
    And I search for WONumber "Work Order"
    And I selects the "Work Order" section from "Work Orders"
    And I click on "Review Time And Expense Lightning" button from SFM Tab
    Then I verify the all details and click button two times:
      |Field Name 		                |Field Value |
      |Opportunity Detected               |No|
      |Work Order                         |current_work_order_number|
      |Work Performed                     |Testing|
      |Completed By                       |John Jeziorski |
#      |Completed On                       |today|
      |Installed At Account               |Ampcontrol (QLD) Pty Ltd|
    And I changed the work order status to service validated
    Then I should see the work order status as "Service Validated" in work order page
#    And I check the "First Synchronization date" and "Last Synchronization date" in work order page in FSR Manager
#    And I check the "First Synchronization date" and "Last Synchronization date" in work order page
    And I check the "Synchronization Log" as "Work Order TECHNICALLY CLOSED in Back Office" in work order page
