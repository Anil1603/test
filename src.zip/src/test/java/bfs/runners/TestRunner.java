package bfs.runners;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

@CucumberOptions(
        features = {
//                "features/attach_ip_workorder.feature"
//                "features/clone_work_order.feature",
//                "features/release_bo_parts_order.feature",
//               "features/parts_order.feature",
//                "features/workordercreation_techclose.feature",
                // "features/parts_order_germany.feature"
//               "features/clone_work_order.feature",
//                "features/followup_workorder.feature",
//                "features/work_order_creation_location.feature"
//                "features/split_workorder.feature.feature"
//                "features/workordercreation_prod.feature"
//                "features/work_order_creation_case.feature"
//               "features/work_Order_Creation_from_Work_bench.feature",
//                "features/attach_ip_workorder.feature",
//                "features/update_work_order_bfs_to_sap.feature",
//                "features/create_parts_order_bfs_to_sap.feature",
//                "features/create_work_order_bfs_to_sap.feature",
//                "features/multipleLines_Reference_parts_order.feature"
//                 "features/create contract and update_contract_bfs_to_sap.feature"
//                "features/update_contract_sap_to_bfs.feature"
//                "features/create _work _order_sap_bfs.feature"
//                "features/create_ip_WorkOrder.feature"
//                "features/release_bo_parts_order.feature"
                "features/parts_order.feature"
//                "features/release_bo_parts_order.feature"

//                "features/AddPartsOrderAndSave.feature",
//                "features/Message_Validation_For_ATP_Check.feature",
//                "features/SyncInERP.feature",
//                "features/atp_ErrorCheckForAddedPart.feature",
//                "features/atp_WarningCheckForAddedPart.feature",
//                "features/create_ip_WorkOrder.feature",
//                "features/emergency_work_order_creation_location.feature",
//                "features/differentTypesOfActivitiesCombinationInTimeEntities_CustomerDelay.feature",
//                "features/differentTypesOfActivitiesCombinationInTimeEntities_Delete_Time.feature",
//                "features/differentTypesOfActivitiesCombinationInTimeEntities_JobPrepAndReport.feature",
//                "features/differentTypesOfActivitiesCombinationInTimeEntities_Miscellaneous.feature",
//                "features/differentTypesOfActivitiesCombinationInTimeEntities_ProjectManagement.feature",
//                "features/differentTypesOfActivitiesCombinationInTimeEntities_Remote Expertise.feature",
//                "features/differentTypesOfActivitiesCombinationInTimeEntities_Rest.feature",
//                "features/differentTypesOfActivitiesCombinationInTimeEntities_service.feature",
//                "features/differentTypesOfActivitiesCombinationInTimeEntities_Travel.feature",
//                "features/differentTypesOfActivitiesCombinationInTimeEntities_Update_Time.feature",
//                "features/multipleLines_NonRereference_PartsOrder.feature",
//                "features/multipleLines_Reference_parts_order.feature",
//                "features/multiple_ReferenceAndNonRereference_PartsOrders.feature",
//                "features/multiple_NonRereference_PartsOrder.feature",
//                "features/recurringAssignmentToFSR.feature",
//                "features/schedulingWithMultipleFSRs.feature",
//                "features/clone_WorkOrder_In_New_Stage.feature",
//                "features/clone_WorkOrder_In_unscheduled_Stage.feature",
//                "features/clone_WorkOrder_In_unscheduled_Stage_QuoteHrsGreaterThanOriginalWO.feature",
//                "features/clone_WorkOrder_In_unscheduled_Stage_QuoteHrsLessThanOriginalWO.feature",
//                "features/Work_Order_CountryOfBackOffice_UNIFY.feature"
        },
        glue = {"bfs"},
        plugin = {
                "pretty",
                "html:Reports/Html/report.html",
                "html:target/cucumber-reports.html",
                "json:target/cucumber.json",
                "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
        },
        monochrome = true
)

//"pretty",
//        "html:Reports/Html/report.html", "json:target/cucumber-reports/reports.json","com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"


public class TestRunner extends AbstractTestNGCucumberTests {

    @BeforeClass
    @Parameters({"EXECUTION_TYPE", "MAX_THREADS"})
    public static void setupThreadPool(String executionType, String maxThreads) {
        System.setProperty("EXECUTION_TYPE", executionType);
        System.setProperty("MAX_THREADS", maxThreads);

        System.setProperty("dataproviderthreadcount", maxThreads);
        System.setProperty("cucumber.execution.parallel.enabled", "true");
        System.setProperty("cucumber.execution.parallel.config.strategy", "fixed");
        System.setProperty("cucumber.execution.parallel.config.fixed.parallelism", maxThreads);

        System.out.println("Execution Mode: " + executionType);
        System.out.println("Running tests with max " + maxThreads + " browser instances.");
    }

    @Override
    @DataProvider(parallel = true)
    public Object[][] scenarios() {
        return super.scenarios();
    }
}