package bfs.B2F;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;

import java.util.HashMap;
import java.util.Map;

public class getAccessToken {

    public static String accessToken;

@BeforeTest
    public String servicecontract(){

    RestAssured.baseURI = "https://test.salesforce.com/services/oauth2/token";

    Map<String, String> formParams = new HashMap<>();
    formParams.put("grant_type", "password");
    formParams.put("client_id", "oQGIXMBsZgvOKMfybhrAbZdBjSibxUmMghLprbOegqVFJV.TartJWKJfgcbfCYDYHrIhwdelHDGOLHznygChR");
    formParams.put("client_secret", "WgBZsozvFTIcXLTLaseSlTkOrSCigpxVQdcSyS");
    formParams.put("username", "coordinator-1660@bridge-fo.com.uat24");
    formParams.put("password", "Test@#1234567");

    Response response = RestAssured
            .given()
            .header("Cookie", "BrowserId=1R_sTu-2Ee-Rdk8NyMH9Jg; CookieConsentPolicy=0:0; LSKey-c$CookieConsentPolicy=0:0")
            .formParams(formParams)
            .post();

    System.out.println(response.jsonPath().prettify());
    Assert.assertEquals(response.getStatusCode(), 200);
    accessToken = response.jsonPath().getString("access_token");
    return accessToken;
}
}
