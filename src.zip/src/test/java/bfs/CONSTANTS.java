package bfs;

import com.aventstack.extentreports.ExtentReports;
import io.cucumber.java.Scenario;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CONSTANTS {
    public static boolean captureScreen = false;
    public static String ERROR_REASON="";
    public static String APPLICATION_NAME;

    //Scenario ID or Name
    public static String SCENARIO_ID="";
    public static String  EXECUTION_ID="";
    public static String SCENARIO_LOG="";
    public static Scenario scenario;
    public static Map<String, String> memorizedData = new HashMap<>();
    public static Map<String, List> memorizedDatalist = new HashMap<>();
 //   public static ExtentReports extent;
 //   public static String backOfficeReferenceNumber;
//    public static Map<String, String> memorizedData = new HashMap<>();
//    public static Map<String, List> memorizedDatalist = new HashMap<>();
}
