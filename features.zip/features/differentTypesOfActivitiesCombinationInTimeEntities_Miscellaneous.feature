Feature: FSR updates Work order as Service Delivered with various Activity type  as Miscellaneous.
  As a user
  I want to navigate to the application and create Work Order
  So that FSR can complete Work order and update Time Entity for Service delivered status

  Scenario Outline: FSR updates Work order as Service Delivered with various Activity type  as Miscellaneous
    Given I work in application "BFO" and environment "UAT"
    And I login to "BFO" as user "coordinator-1660@bridge-fo.com.uatbfo26"
    When I navigate to "SE - Services Lightning" from app launcher
    And I wait for "10" seconds
    And I navigate to "Work Orders" from app launcher
    And I click on bfo button "New"
    And I fill work order details for creating new work order from Work Order Page:
      | Field Name                | Field Value                         |
      | Select Record Type        | Standalone Work Order               |
      | Installed At Account      | 0001340233:Ampcontrol (QLD) Pty Ltd |
      | Location                  | 0045144542:Ampcontrol QLD Pty Ltd   |
      | Work Order Type           | Repair                              |
#    |Work Order Sub-Type                   |                                           |
      | Contact                   | chandra.vamsi kumar                 |
      | Customer Requested Date   | today                               |
      | Country of Back Office    | Australia                           |
      | Back Office System        | SAP Bridge AP                       |
      | Work Order Category       | Onsite                              |
      | Services Business Unit    | POWER SYSTEMS                       |
      | Is Billable               | Yes                                 |
      | Customer Reference Number | 1234                                |
      | Priority                  | Normal-Medium                       |
#    |Non Billing Reason                    |                                           |
      | Service Commercial Ref    | QWPFSRVPLNNSGEN                     |
#    |Skill Category                        |                                           |
      | Work Order Reason         | Testing                             |
      | Work Order Name           | Testing                             |
      | Sold To Account           | 0001340233:Ampcontrol (QLD) Pty Ltd |
    Then user should be able to see the work order number and memorize work order number
    And I should see the work order status as "New" in work order page
    And I click on "Create/Update Work Order" button from SFM Tab
    And I check the message "SUCCESS : INITIATED SYNC" on sync window
    And I click on "Ok" button on sync window
    Then I should see the work order status as "Unscheduled" in work order page
    And I wait for back Office reference number
    And I check the "First Synchronization date" and "Last Synchronization date" in work order page
    And I check the "Synchronization Log" as "Work Order CREATED in Back Office" in work order page
    And I add work order to "FSR-1660" in Service Board
    Then I should see the work order status as "Scheduled" in work order page
    And the user selects the "<Tab Name>" tab in Work Order Details
    And the user creates multiple Parts Orders
      | Parts Order Type | Requested Ship Date | Ship From Plant | Product Name | Tab         |
      | Ship only        | dd MMM yyyy         | AU10            | PAS600       | Parts Order |

    And the user selects the "<Tab Name>" tab in Work Order Details
    Then the parts order status should be "Released" in "<Tab Name>"
    And the Part Reference value should be displayed on expanding Parts Order Lines
    And the parts order should be memorized
    And the user selects the "<Work Details Tab>" tab in Work Order Details
    And the work detail line number should be displayed and memorize work detail
    And I navigate to bfo tab "Details"
    And I check the "Synchronization Log" as "Work Order RELEASED Successfully in Back Office" in work order page
    And I memorized current work order number as "current_work_order_number_Url" and "current_work_order_number"
    Then Change work order status to customer confirmed
    Then I should see the work order status as "Customer Confirmed" in work order page
    And I logout from bfo application
    #Admin User
    Given I work in application "BFO" and environment "UAT"
    And I login to "BFO" as user "sesa811424@bridge-fo.com.uatbfo26"
    And the user selects "<Menu Item>" from the Search menu
    When the user search and selects the "<Menu Item>"
    And the user selects the "<Tab Name>" tab in Work Order Details
    When the user updates the Line Details
      | Line Status | Shipped Qty |
      | Received    | 1           |
    And I logout from bfo application
    #FSR User
    Given I work in application "BFO" and environment "UAT"
    And I login to "BFO" as user "fsr-1660@bridge-fo.com.uatbfo26"
    And FSR accepts the work order "current_work_order_number_Url"
    Then check fsr response is "Acknowledge FSR"
    And I click on "Update WO" button from SFM Tab
    And I select the fsr response as "Acknowledge FSR" from update wo page in servicemax
    And I click on "Save" button in update wo page in servicemax
    And I click on "Update WO" button from SFM Tab
    And I select the fsr response as "Under Preparation" from update wo page in servicemax
    And I click on "Save" button in update wo page in servicemax
    Then I should see the work order status as "WIP" in work order page
    And I click on "Update WO" button from SFM Tab
    And I select the fsr response as "On-Site" from update wo page in servicemax
    And I click on "Save" button in update wo page in servicemax
    And I click on "Update WO" button from SFM Tab
    And I select the fsr response as "WIP" from update wo page in servicemax
    And I fill the Risk Assessment details in WIP FSR response:
      | Field Name                  | Field Value |
      | Is Risk Assessment Attached | No          |
      | NO Risk Assessment Reason   | Other       |
      | No Risk Assessment Details  | Testing     |
    And I click on "Save" button in update wo page in servicemax
    And I click on "Update WO" button from SFM Tab
    And the user selects the "PLANNED PARTS" tab in "Update WO"
    And the user update the "Line Number" and enters the "Installed Quantity" as "<Installed Quantity>" in Planned Parts
    And the user selects Save Work Order Line
    And I click on "Update WO" button from SFM Tab
    And I select the fsr response as "Delivered" from update wo page in servicemax
    And I fill the service details in delivered fsr response:
      | Field Name           | Field Value |
      | Work Performed       | Testing     |
      | Opportunity Detected | No          |
    And I click on add my time  and select the activity as "<Activity Type>" in delivered fsr response

    And I update Customer Hour Type and time and click on "Save" button in update wo page in servicemax
    Then I should see the work order status as "Service Delivered" in work order page
    When I click on "Complete WO Tasks" button from SFM Tab
    And I click on "Save" button in Complete WO Task page
    Then I should see the work order status as "Service Completed" in work order page
    And I logout from bfo application
	#FSR Manager
    Given I work in application "BFO" and environment "UAT"
    And I login to "BFO" as user "fsrmanager-1660@bridge-fo.com.uatbfo26"
    And the user selects "<Menu Item>" from the Search menu
    When the user search and selects the "<Menu Item>"
    And I click on "Review Time And Expense Lightning" button from SFM Tab
    Then I verify the all details and click Save button:
      | Field Name           | Field Value               |
      | Opportunity Detected | No                        |
      | Work Order           | current_work_order_number |
      | Work Performed       | Testing                   |
      | Completed By         | FSR 1660                  |
      | Completed On         | today                     |
      | Installed At Account | Ampcontrol (QLD) Pty Ltd  |
    And I changed the work order status to service validated
    Then I should see the work order status as "Service Validated" in work order page
    And I check the "Synchronization Log" as "Work Order TECHNICALLY CLOSED in Back Office" in work order page

    Examples:
      | Menu Item   | Tab Name    | Work Details Tab | Installed Quantity | Activity Type |
      | Work Orders | Parts Order | Work Details     | 1                  | Miscellaneous |