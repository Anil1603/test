Feature: Parts order creation.
  As a user
  I want to navigate to the application and create parts order for Work Order
  So that I can create parts order efficiently

Scenario Outline: followup Work Order for a specific Work Order
    Given I work in application "BFO" and environment "UAT"
    When I login to "bfo" as user "coordinator-1660@bridge-fo.com.uatbfo26"
    And the user selects "<Menu Item>" from the Search menu
    And the user enters "<Work Order>" in Global Search
    And the user selects the "<Work Order>" from search results
     And the user selects the "<Tab Name>" tab in Work Order Details

######################################## ACTUAL TEST SCRIPT #################


  And the user selects the "<Tab Name>" tab in Work Order Details

  And the user creates multiple Non Reference Parts Orders
    | Parts Order Type | Requested Ship Date | Ship From Plant  | Product Name | Tab          | Text Reference | Unit Of Measure | Order Type | Committed Ship date |
    | Ship only        | dd MMM yyyy         | AU27             | 47849        | Parts Order  | 565656         | AU              | Ship only  | today                |
    | Ship only        | dd MMM yyyy         | AU27             | 47849        | Parts Order  | 676767         | AU              | Ship only  | today                |
  And the user selects the "<Tab Name>" tab in Work Order Details
  Then the parts order status should be "Released" in "<Tab Name>"
  And the Part Reference value should be displayed on expanding Parts Order Lines

  And the parts order should be memorized
  And the user selects the "<Work Details Tab>" tab in Work Order Details
  And the work detail line number should be displayed and memorize work detail




  And I memorized current work order number as "current_work_order_number_Url" and "current_work_order_number"
  Then Change work order status to customer confirmed
  Then I should see the work order status as "Customer Confirmed" in work order page
  And I logout from bfo application
    #Admin User
  Given I work in application "BFO" and environment "UAT"
  And I login to "BFO" as user "sesa766015@bridge-fo.com.uatbfo26"
  And the user selects "<Menu Item>" from the Search menu
  When the user search and selects the "<Menu Item>"
  And the user selects the "<Tab Name>" tab in Work Order Details
  When the user updates the Line Details
    | Line Status | Shipped Qty |
    | Received     | 1           |
  And I logout from bfo application
    #FSR User
  Given I work in application "BFO" and environment "UAT"
  And I login to "BFO" as user "fsr-1660@bridge-fo.com.uatbfo26"
  And FSR accepts the work order "current_work_order_number_Url"
  Then check fsr response is "Acknowledge FSR"
  And I click on "Update WO" button from SFM Tab
  And I select the fsr response as "Acknowledge FSR" from update wo page in servicemax
  And I click on "Save" button in update wo page in servicemax
  And I click on "Update WO" button from SFM Tab
  And I select the fsr response as "Under Preparation" from update wo page in servicemax
  And I click on "Save" button in update wo page in servicemax
  Then I should see the work order status as "WIP" in work order page
  And I click on "Update WO" button from SFM Tab
  And I select the fsr response as "On-Site" from update wo page in servicemax
  And I click on "Save" button in update wo page in servicemax
  And I click on "Update WO" button from SFM Tab
  And I select the fsr response as "WIP" from update wo page in servicemax
  And I fill the Risk Assessment details in WIP FSR response:
    |Field Name 		                |Field Value |
    |Is Risk Assessment Attached        |No|
    |NO Risk Assessment Reason          |Other|
    |No Risk Assessment Details         |Testing|
  And I click on "Save" button in update wo page in servicemax
  And I click on "Update WO" button from SFM Tab

  And the user selects the "PLANNED PARTS" tab in "Update WO"
  And the user update the "Line Number" and enters the "Installed Quantity" as "<Installed Quantity>" in Planned Parts


  And the user selects Save Work Order Line
  And I click on "Update WO" button from SFM Tab

  And I select the fsr response as "Delivered" from update wo page in servicemax
  And I fill the service details in delivered fsr response:
    |Field Name 		                |Field Value |
    |Work Performed                     |Testing|
    |Opportunity Detected               |No|
  And I click on add my time  and select the activity as "Service" in delivered fsr response
  And I update the time and click on "Save" button in update wo page in servicemax
  Then I should see the work order status as "Service Delivered" in work order page
  When I click on "Complete WO Tasks" button from SFM Tab
  And I click on "Save" button two times in Complete WO Task page
  Then I should see the work order status as "Service Completed" in work order page
  And I logout from bfo application
	#FSR Manager
  Given I work in application "BFO" and environment "UAT"
  And I login to "BFO" as user "fsrmanager-1660@bridge-fo.com.uatbfo26"
  And the user selects "<Menu Item>" from the Search menu
  When the user search and selects the "<Menu Item>"

  And I click on "Review Time And Expense Lightning" button from SFM Tab
  Then I verify the all details and click button two times:
    |Field Name 		                |Field Value |
    |Opportunity Detected               |No|
    |Work Order                         |current_work_order_number|
    |Work Performed                     |Testing|
    |Completed By                       |FSR 1660|
    |Completed On                       |10/01/2025|
    |Installed At Account               |Sharma Electric works(1003)|
  And I changed the work order status to service validated
  Then I should see the work order status as "Service Validated" in work order page
  And I check the "First Synchronization date" and "Last Synchronization date" in work order page
  And I check the "Synchronization Log" as "Work Order RELEASED Successfully in Back Office" in work order page

#  And the user selects "<Menu Item>" from the Search menu
#  When the user search and selects the "<Menu Item>"


  Examples:
    | Menu Item      | Work Order       | Tab Name      | Parts Order Type | Ship From Plant | Product Name | Line Status | Shipped Qty | Work Details Tab     | Installed Quantity |
    | Work Orders    | WO-12266013      | Parts Order   | Ship only        | AU10            | 47053       | Received     | 1           |   Work Details       |  1                 |



