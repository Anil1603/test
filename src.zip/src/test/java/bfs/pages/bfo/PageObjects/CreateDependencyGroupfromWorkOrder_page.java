package bfs.pages.bfo.PageObjects;

import com.codeborne.selenide.ClickOptions;
import com.codeborne.selenide.Selenide;
import org.openqa.selenium.By;
import org.openqa.selenium.devtools.v85.indexeddb.model.Key;

import java.time.Duration;

import static bfs.pages.BasePage.highLightElement;
import static bfs.pages.BasePage.switchToFrame;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$x;

public class CreateDependencyGroupfromWorkOrder_page {

    private static final By Iframe = By.xpath("//iframe[@title='Service Delivery']");
    private static final By dependencyGroupName = By.xpath("//input[@name='SVMXC__Dependency_Group_Name__c']");
    private static final By Description = By.xpath("//input[@name='SVMXC__Description__c']");
    private static final By addWODependencyButton = By.xpath("//button[text()='Add Work Order Dependency (Dependency Group)']");
    private static final By dropdown_wo_dependency_line=By.xpath("//div[@aria-readonly='true']/button[contains(@class, 'Button Dropdown__button DetailsDataGrid_MenuButton slds-button Button--type-icon-border slds-button--icon')]");
    private static final By dropdown_Edit_value=By.xpath("//span[text()='Edit']");
    private static final By primaryWO_search_Box= By.xpath("//input[@name='SVMXC__Primary_Work_Order__c']");
    private static final By secondaryWO_SearchBox= By.xpath("//input[@name='SVMXC__Secondary_Work_Order__c']");
    private static final By timeDependency_dropdwon=By.xpath("//input[@name='SVMXC__Time_Dependency__c']");
    private static final By Update_button=By.xpath("//button//*[text()='Update']");
//    private static final By primaryWO_SearchBox= By.xpath("//input[contains(@id, 'form-element-')]");
//    private static final By secondaryWO_tableCalum= By.xpath("//div[contains(@class,'SVMXC__Secondary_Work_Order__c')]//div[@class='CellEditPopover__cellcontent']");
//    private static final By secondaryWO_SearchBox= By.xpath("//input[@name='SVMXC__Secondary_Work_Order__c'][contains(@id, 'form-element-')]");
//    private static final By timeDependency= By.xpath("//div[contains(@class,'SVMXC__Time_Dependency__c')]//div[@class='CellEditPopover__cellcontent']");
//    private static final By timeDependency_input_box= By.xpath("//input[@name='SVMXC__Time_Dependency__c']");
//    private static final By workOrderDetails = By.xpath("//div[contains(@class,'inline-edit--Name')]");
    private static final By saveButton= By.xpath("//div[@class='PageHeader__container']//button//*[text()='Save']");

    private static String primaryWO_Search_Result = "//span[@class='Menu__item-content slds-truncate']//*[text()='WO_Number']";



//    public void CreateDependencyGroupfromWorkOrder(String DependencyGroupName, String Descriptiontext, String primaryWO, String secondaryWO, String timeDependencytext) {
//        switchToFrame(Iframe);
//        $(addWODependencyButton).click();
//        $(primaryWO_SearchBox).setValue(primaryWO);
//        $(By.xpath(primaryWO_Search_Result.replace("WO_Number", primaryWO))).click(ClickOptions.withTimeout(Duration.ofSeconds(120)));
//        highLightElement($(secondaryWO_tableCalum));
//        $(secondaryWO_tableCalum).click(ClickOptions.usingJavaScript())
//                .click(ClickOptions.usingJavaScript());
//        highLightElement($(secondaryWO_SearchBox));
//        $(secondaryWO_SearchBox).setValue(secondaryWO);
//        $(By.xpath(primaryWO_Search_Result.replace("WO_Number", secondaryWO))).click(ClickOptions.withTimeout(Duration.ofSeconds(120)));
//        $(timeDependency).click(ClickOptions.usingJavaScript())
//                .click(ClickOptions.usingJavaScript());
//        $(timeDependency_input_box).click(ClickOptions.usingJavaScript());
//
//                $x("//*[text()='"+timeDependencytext+"']").click(ClickOptions.usingJavaScript());
//                $(dependencyGroupName).click(ClickOptions.usingJavaScript());
//        $(dependencyGroupName).setValue(DependencyGroupName);
//        $(Description).setValue(Descriptiontext);
//        $(saveButton).click(ClickOptions.usingJavaScript());
//        Selenide.switchTo().defaultContent();
//
//    }

    public void CreateDependencyGroupfromWorkOrder(String DependencyGroupName, String Descriptiontext, String primaryWO, String secondaryWO, String timeDependencytext) {
        switchToFrame(Iframe);
        highLightElement($(dependencyGroupName));
        $(dependencyGroupName).click();
        $(dependencyGroupName).setValue(DependencyGroupName);
        highLightElement($(Description));
        $(Description).setValue(Descriptiontext);
        highLightElement($(addWODependencyButton));
        $(addWODependencyButton).click();
        highLightElement($(primaryWO_search_Box));
        $(primaryWO_search_Box).click(ClickOptions.usingJavaScript())
                .click(ClickOptions.usingJavaScript()).setValue(primaryWO);
        $x("//span[contains(text(), '"+primaryWO+"')]").click(ClickOptions.withTimeout(Duration.ofSeconds(120)));
        //$(By.xpath(primaryWO_Search_Result.replace("WO_Number", primaryWO))).click(ClickOptions.withTimeout(Duration.ofSeconds(120)));
        //$(secondaryWO_SearchBox).click(ClickOptions.usingJavaScript());
        highLightElement($(dropdown_wo_dependency_line));
        $(dropdown_wo_dependency_line).click(ClickOptions.usingJavaScript());
        highLightElement($(dropdown_Edit_value));
        $(dropdown_Edit_value).click(ClickOptions.usingJavaScript());
        highLightElement($(timeDependency_dropdwon));
        $(timeDependency_dropdwon).click(ClickOptions.usingJavaScript());
        $x("//*[text()='"+timeDependencytext+"']").click(ClickOptions.usingJavaScript());
        highLightElement($(secondaryWO_SearchBox));
        $(secondaryWO_SearchBox).click(ClickOptions.usingJavaScript()).setValue(secondaryWO);
        $x("//span[contains(text(), '"+secondaryWO+"')]").click(ClickOptions.withTimeout(Duration.ofSeconds(120)));
        //$(By.xpath(primaryWO_Search_Result.replace("WO_Number", secondaryWO))).click(ClickOptions.withTimeout(Duration.ofSeconds(120)));
        highLightElement($(Update_button));
        $(Update_button).click();
        highLightElement($(saveButton));
        $(saveButton).click(ClickOptions.usingJavaScript()).click(ClickOptions.usingJavaScript());
        Selenide.switchTo().defaultContent();

    }





}
