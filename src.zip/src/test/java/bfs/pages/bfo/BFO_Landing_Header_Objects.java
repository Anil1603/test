package bfs.pages.bfo;

import com.codeborne.selenide.*;
import org.openqa.selenium.By;

import static com.codeborne.selenide.Condition.*;
import static bfs.pages.BasePage.highLightElement;
import static com.codeborne.selenide.Selenide.*;

public class BFO_Landing_Header_Objects {

    // private static final By APP_MENU_ICON =By.xpath("//div[@role='navigation'][@aria-label='App']");
    private static final String APP_MENU_ICON ="//div[@role='navigation'][@aria-label='App']";
    private static final By APP_SEARCH_TEXTBOX =By.xpath("//input[@part='input'][@type='search'][contains(@placeholder,'Search apps')]");
    private static final By LIST_OF_MENU = By.xpath("//div[@class='al-menu-dropdown-list']/*/a/div/*/span/p/b");
    private static final String Search_Service_Contract = "//div[@aria-label='Service/Maintenance Contracts||List View']//th//a[@data-refid='recordId']";
    private static final String Search_cvcp ="//div[@aria-label='Contract Value Chain Players||List View']//th//a[@data-refid='recordId']";
    private static final String Search_cases="//div[@aria-label='Cases||List View']//th//a[@data-refid='recordId']";
    private  static final String Search_WorkOrder="//div[@aria-label='Work Orders||List View']//th//a[@data-refid='recordId']";
    //Search Contract
    private static final String APP_SEARCH_BUTTON ="//button[@aria-label='Search']";
    private static  final  By APP_CONTRACT_SEARCH= By.xpath("//input[contains(@title, 'Search')]");

    public BFO_Landing_Header_Objects clickOnAPPMenuIcon(){
        highLightElement($(By.xpath(APP_MENU_ICON)).shouldBe(visible,enabled));
        $x((APP_MENU_ICON)).shouldBe(visible,enabled).click();
        return this;
    }

    public BFO_Landing_Header_Objects enterAppsToSearch(String appname){
        highLightElement($(APP_SEARCH_TEXTBOX).shouldBe(visible,enabled));
        $(APP_SEARCH_TEXTBOX).shouldBe(visible,enabled).setValue(appname);
        return this;
    }

    public BFO_Landing_Header_Objects waitForListOfMenu(){
        $$(LIST_OF_MENU).shouldHave(CollectionCondition.sizeGreaterThan(0));
        return this;
    }

    public void clickOnWorkOrder(String appName) {
     /*   List<WebElement> elements = WebDriverRunner.getWebDriver().findElements(LIST_OF_MENU);
        System.out.println(elements.size());
        for(WebElement element: elements){
            if(element.getText().equalsIgnoreCase(appName))
            {
             element.click();
             break;
            }
        }*/
        ElementsCollection menuItems = $$(LIST_OF_MENU);
        System.out.println(menuItems.size());
        for (SelenideElement menuItem : menuItems) {
            System.out.println(menuItem.getText());
            if(menuItem.getText().equalsIgnoreCase(appName)){
                highLightElement(menuItem);
                menuItem.click();
                break;
            }
        }
    }

    // Search & Select Contracts

    // Utility method to highlight and ensure element visibility
    private SelenideElement getElementWithHighlight(SelenideElement element) {
        highLightElement(element.shouldBe(visible, enabled));
        return element;
    }

    public void searchContract(String contractNumber) {
        Selenide.sleep(5000);
        SelenideElement searchField = getElementWithHighlight($(APP_CONTRACT_SEARCH));
        searchField.setValue(contractNumber).pressEnter();
    }

//    public void navigateToContract() {
//        // Build the dynamic XPath using the contractNumber and title
//        String xpath = String.format(
//                "//a[text()='%s']/../../../parent::div/following-sibling::div/div//table/tbody/tr/th/span/a[@title=\"%s\"]",
//                appName, contractNumber);
//
//        // Locate and interact with the element
//        SelenideElement contractLink = getElementWithHighlight($(By.xpath(xpath)));
//        contractLink.click();
//    }
public void navigateToContract() {

    SelenideElement contractLink = getElementWithHighlight($x(Search_Service_Contract));
    contractLink.click();
}

    public void navigateToCVCP() {
        Selenide.sleep(5000);
        if ($x(Search_cvcp).isDisplayed()) {
            SelenideElement CVCPLink = getElementWithHighlight($x(Search_cvcp));
            CVCPLink.click();
            Selenide.sleep(8000);
        }
    }

    public void navigateToCases() {
        Selenide.sleep(5000);
        if ($x(Search_cases).isDisplayed()) {
            SelenideElement casesLink = getElementWithHighlight($x(Search_cases));
            casesLink.click();
            Selenide.sleep(8000);
        }
    }
    public void navigateToWorkOrders() {
        Selenide.sleep(5000);
        if ($x(Search_WorkOrder).isDisplayed()) {
            SelenideElement casesLink = getElementWithHighlight($x(Search_WorkOrder));
            casesLink.click();
            Selenide.sleep(8000);
        }
    }

}
