package bfs.Pojo;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;
import java.util.List;

public class WorkOrderData {
    public List<WorkOrder> workOrders;

    public static class WorkOrder {
        public String SelectRecordType;
        public String InstalledAtAccount;
        public String Location;
        public String WorkOrderType;
        public String Contact;
        public String CustomerRequestedDate;
        public String CountryOfBackOffice;
        public String BackOfficeSystem;
        public String WorkOrderCategory;
        public String ServicesBusinessUnit;
        public String IsBillable;
        public String Priority;
        public String ServiceCommercialRef;
        public String WorkOrderReason;
        public String WorkOrderName;
        public String SoldToAccount;
        public String NonBillingReason;
        public String SkillCategory;
        public String WorkOrderSubType;
    }

    public static WorkOrderData load(String filePath) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.readValue(new File(filePath), WorkOrderData.class);
    }

}