package bfs.hooks;

import org.apache.commons.mail.DefaultAuthenticator;

import org.apache.commons.mail.EmailAttachment;

import org.apache.commons.mail.EmailException;

import org.apache.commons.mail.MultiPartEmail;

import java.io.File;

public class ReportEmailSender {

    public static void sendReportEmail() {

        try {

            String basePath = System.getProperty("user.dir") + File.separator + "Reports" + File.separator + "ExtentReports";
            System.out.println("Base Path" + basePath);
            File latestReport = getLatestReport(basePath);
            System.out.println("Latest Report" + latestReport);
            if (latestReport == null) {

                System.out.println("❌ No report.html found in latest timestamped folder.");

                return;

            }

            // 1. Prepare attachment

            EmailAttachment attachment = new EmailAttachment();

            attachment.setPath(latestReport.getAbsolutePath());

            attachment.setDisposition(EmailAttachment.ATTACHMENT);

            attachment.setDescription("Automation Test Report");

            attachment.setName("AutomationTestReport.html");

            // 2. Prepare email

            MultiPartEmail email = new MultiPartEmail();

            email.setHostName("smtp.se.com");

            email.setSmtpPort(587);

            email.setStartTLSEnabled(true);

            email.setAuthenticator(new DefaultAuthenticator(

                    "anilkumar.bhusarapalli@se.com",    // replace with your email

                    "Dady"     // plain password (no 2FA)

            ));

            email.setFrom("anilkumar.bhusarapalli@se.com", "Automation Bot");

            email.addTo("anilkumar.bhusarapalli@se.com", "QA Team");

            email.setSubject("Automation Test Execution Report");

            email.setMsg("Hi Team,\n\nPlease find attached the automation test execution report.\n\nRegards,\nAutomation Framework");

            // 3. Attach and send

            email.attach(attachment);

            email.send();

            System.out.println("✅ Email sent with report: " + latestReport.getAbsolutePath());

        } catch (EmailException e) {

            e.printStackTrace();

        }

    }

    private static File getLatestReport(String extentReportsPath) {

        File baseDir = new File(extentReportsPath);

        if (!baseDir.exists() || !baseDir.isDirectory()) return null;

        File[] timestampedDirs = baseDir.listFiles(File::isDirectory);

        if (timestampedDirs == null || timestampedDirs.length == 0) return null;

        // Find the latest timestamped folder

        File latestDir = timestampedDirs[0];

        for (File dir : timestampedDirs) {

            if (dir.lastModified() > latestDir.lastModified()) {

                latestDir = dir;

            }

        }

        // Go to test-output/report.html

        File report = new File(latestDir, "test-output" + File.separator + "report.html");

        return report.exists() ? report : null;

    }

}

