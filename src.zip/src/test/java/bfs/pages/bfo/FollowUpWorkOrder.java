package bfs.pages.bfo;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import com.codeborne.selenide.WebDriverRunner;
import org.openqa.selenium.interactions.Actions;

import java.util.List;

import static bfs.pages.bfo.ApplicationCommonMethods.*;
import static com.codeborne.selenide.Condition.enabled;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.*;

public class FollowUpWorkOrder {

    // XPaths for elements
    private static final String FOLLOW_UP_WORK_ORDER = "//span[text()='Follow Up Work Order']/parent::a";
    private static final String DROPDOWN_XPATH_TEMPLATE = "//label[contains(text(), '%s')]/parent::div/div/div/div/div/div/input";
    private static final String DROPDOWN_ITEM_XPATH_TEMPLATE = "//span[text()='%s']/parent::span/parent::a/parent::li";
    private static final String CUSTOMER_REQUESTED_DATE = "//label[contains(text(), '%s')]/parent::div/div/div/div/div/input";
    private static final String FOLLOW_UP_WO_FRAME = "//iframe[@title='Service Delivery']";
    private static final String SAVE_FOLLOW_UP_WO = "//span[text()='Save']/parent::button";


//    public FollowUpWorkOrder clickFollowUpWorkOrder() {
//        try {
//            waitForGivenTime(5000);
//            SelenideElement newWorkOrder = $x(FOLLOW_UP_WORK_ORDER);
//            waitForElementToBeVisibleAndClickable(newWorkOrder);
//            newWorkOrder.scrollIntoView("{block: \"center\"}");
//            Actions actions = new Actions(WebDriverRunner.getWebDriver());
//            actions.moveToElement(newWorkOrder, 0, 0).click().perform();
//
//            waitForGivenTime(8000);
//        } catch (Exception e) {
//            ApplicationCommonMethods.handleException("Error clicking on Follow Up Work Order", e);
//        }
//        return this;
//
//    }

    public FollowUpWorkOrder selectRevisitReason(String labelText, String value) {
        waitForGivenTime(5000);
        ApplicationCommonMethods.switchToFrame(FOLLOW_UP_WO_FRAME);
        selectDropdownValueSafely(labelText, value, "Error selecting on Country Of Back Office");
        return this;
    }


    private void selectDropdownValueSafely(String labelText, String value, String errorMessage) {
        try {
            selectDropdownValue(labelText, DROPDOWN_XPATH_TEMPLATE, DROPDOWN_ITEM_XPATH_TEMPLATE, value);
        } catch (Exception e) {
            handleException(errorMessage, e);
        }
    }

    public FollowUpWorkOrder selectCustomerRequestDate(String labelText, String dateFormat) {
        ApplicationCommonMethods.clickAndEnterDynamicDate(labelText, CUSTOMER_REQUESTED_DATE, dateFormat);
        return this;
    }

    public FollowUpWorkOrder clickSaveFollowUpWorkOrder() {
        try {
            SelenideElement saveWorkOrder = $x(SAVE_FOLLOW_UP_WO);
            waitForElementToBeVisibleAndClickable(saveWorkOrder);
            saveWorkOrder.click();
            switchTo().defaultContent();
            waitForGivenTime(15000);
        } catch (Exception e) {
            handleException("Error clicking on Continue Work Order", e);
        }
        return this;
    }

}
