Feature: Doing Proxy Login.
  As a user
  I want to navigate to the application and do Proxy Login
  So that I can check Proxy Login functionality

	#@BFSTST-2032 @BFSTST-2033
  Scenario: Checking Proxy Login
		#Coordinator
    Given I work in application "BFO" and environment "UAT"
    And I login to "BFO" as user "ccc-1660@bridge-fo.com.uatbfo26"
    And I navigate to "Setup" Page by using URL
    And I login as Proxy User "FSR 1660"