package bfs.pages.bfo.Pages;

import bfs.pages.bfo.PageObjects.BFOFlowOfWorkOrderPageObjects;

public class BFOFlowOfWorkOrderPage {
    BFOFlowOfWorkOrderPageObjects bfoFlowOfWorkOrderPageObjects = new BFOFlowOfWorkOrderPageObjects();


}
