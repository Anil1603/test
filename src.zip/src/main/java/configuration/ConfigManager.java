package configuration;

import java.util.Properties;

public final class ConfigManager {

	private static Properties appConfig = null;

	public static String getProperty(String propertyName, String folderName, String propertiesFilePath) {
		// First, check if the system property is set
		String systemValue = System.getProperty(propertyName);
		if (systemValue != null && !systemValue.isEmpty()) {
			return systemValue;
		}

		// If system property is not found, load from properties file
		appConfig = FileUtility.loadProperties(folderName, propertiesFilePath);
		return appConfig.getProperty(propertyName);
	}

	public static String getProperty(String propertyName, String propertiesFileName) {
		String systemValue = System.getProperty(propertyName);
		if (systemValue != null && !systemValue.isEmpty()) {
			return systemValue;
		}

		String root = "Configuration";
		appConfig = FileUtility.loadProperties(root, propertiesFileName);
		return appConfig.getProperty(propertyName);
	}
}