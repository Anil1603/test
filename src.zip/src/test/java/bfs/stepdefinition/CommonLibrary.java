package bfs.stepdefinition;
import bfs.CONSTANTS;
import bfs.pages.BasePage;
import bfs.pages.bfo.BFOLoginPageObjects;
import bfs.pages.bfo.BFOStandaloneNewWorkOrderPageObjects;
import bfs.pages.bfo.PageObjects.*;
import bfs.pages.bfo.Pages.*;
import bfs.pages.servicemax.PageObjects.ServiceBoardPageObjects;
import bfs.pages.servicemax.Pages.ServiceBoardPage;
import bfs.pages.workbench.login_work_benck_page;
import com.aventstack.extentreports.ExtentTest;
import com.codeborne.selenide.*;
import configuration.ConfigManager;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import bfs.pages.bfo.*;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.interactions.Actions;
import utilities.JSONUtils;

import java.io.File;
import java.time.Duration;
import java.util.*;

import static bfs.CONSTANTS.*;
import static com.codeborne.selenide.Condition.enabled;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selectors.*;
import static com.codeborne.selenide.Selenide.*;
import static org.junit.Assert.assertEquals;

public class CommonLibrary {
Map<String,String> data = new HashMap<>();
Map<String,String> workordernumbers = new HashMap<>();
    List<String> fsrNames = new ArrayList<>();

    @Given("I work in application {string} and environment {string}")
    public void launchApplicationURLUsingAppNameAndEnvironment(String applicationName,String environmentName){
        String environmentFromPropertyFile =ConfigManager.getProperty("ENVIRONMENT","application");
        if(environmentFromPropertyFile.isEmpty()){
            System.out.println("Set Environment from Scenario");
            open(ConfigManager.getProperty(applicationName+"_"+environmentName+"_URL","application"));
        }else {
            System.out.println("Set Environment from application property file");
            open(ConfigManager.getProperty(applicationName+"_"+environmentFromPropertyFile+"_URL","application"));
        }
        WebDriverRunner.getWebDriver().manage().window().maximize();
    }

    @Then("I navigate to tab {string}")
    public void iNavigateToTab(String tabName) {

    }

    @And("I open New tab in Browser")
    public void iOpenNewTabInBrowser() {
        executeJavaScript("window.open('about:blank', '_blank');");
        switchTo().window("");
    }


    @And("I logout from application")
    public void iLogoutFromApplication() {
    }

    @And("I login to {string} as user {string}")
    public void iLoginToAsUser(String appName,String username) {
        System.out.println("Username "+username);
        System.out.println("App Name "+appName);
        String password = null;
        if(!username.equalsIgnoreCase("sandbox")) {
            password = JSONUtils.getPassword(username, "users.json");
        }
        switch (appName.toLowerCase()) {
            case "bfo" ->
                new BFOLoginPageObjects().setUsername(username).setPassword(password).clickLoginButton();
            case "workbench" -> new login_work_benck_page().login(username);

            default ->
                System.out.println("Not Implemented for "+ appName);
        }
    }

    @And("I Search for app {string}")
    public void iSearchForApp(String appName) {
        new BFO_Landing_Header_Objects()
                .clickOnAPPMenuIcon()
                .enterAppsToSearch(appName)
                .waitForListOfMenu().clickOnWorkOrder(appName);
    }

    @And("I click on bfo button {string}")
    public void iClickOnBfoButton(String buttonName) {

        switch (buttonName.toLowerCase()) {
            case "new" ->
                    new BFOWorkOrderPageObjects().clickOnNewButton().waitForRecordTypePopUp();
            case "continue" ->
                    new BFOWorkOrderPageObjects().clickOnContinueButton();
            case "save"-> new BFOStandaloneNewWorkOrderPageObjects().clickOnSaveButton();
            default ->
                    System.out.println("Not Implemented for "+ buttonName);
        }


    }

    @And("I select record type {string}")
    public void iSelectRecordType(String value) {
        new BFOWorkOrderPageObjects().selectRecordType(value);
    }

    @And("I set bfo field {string} to value {string}")
    public void iSetBfoFieldToValue(String fieldName, String value) {
        switch (fieldName.toLowerCase()){
        case "installed at account"-> {new BFOStandaloneNewWorkOrderPageObjects().waitForNewStandAloneWorkOrderPageLoaded()
                .selectAccountNameUsingGoldenID(value.split(":")[0], value.split(":")[1]);}
        case "location" -> new BFOStandaloneNewWorkOrderPageObjects()
                    .selectLocationNameUsingGoldenID(value.split(":")[0], value.split(":")[1]);
        case "customer requested date"->
            new BFOStandaloneNewWorkOrderPageObjects().enterCustomerRequestedDate(value);
        case "work order category"->
                    new BFOStandaloneNewWorkOrderPageObjects().selectWorkOrderCategory(value);
        case "services business unit"->
                    new BFOStandaloneNewWorkOrderPageObjects().selectServicesBusinessUnit(value.toUpperCase());
        case "is billable"->
                new BFOStandaloneNewWorkOrderPageObjects().selectIsBillable(value);
        case "non billing reason"->
                new BFOStandaloneNewWorkOrderPageObjects().selectNonBillingReason(value);
        case "priority"->
                new BFOStandaloneNewWorkOrderPageObjects().selectPriority(value);
        case "skill category"->
                new BFOStandaloneNewWorkOrderPageObjects().selectSkillCategory(value);
        case "work order reason"->
                new BFOStandaloneNewWorkOrderPageObjects().enterWorkOrderReason(value);
        case "work order name"->
                new BFOStandaloneNewWorkOrderPageObjects().enterWorkOrderName(value);
        case "sold to account"->
                new BFOStandaloneNewWorkOrderPageObjects().selectSoldToAccount(value.split(":")[0], value.split(":")[1]);
        default ->
                System.out.println("Not Implemented for "+ fieldName);
        }
    }

    @And("I select workorder type {string}")
    public void iSelectWorkorderType(String workOrderType) {
        new BFOStandaloneNewWorkOrderPageObjects().selectWorkOrderType(workOrderType);
    }

    @And("I select workorder subtype {string}")
    public void iSelectWorkorderSubtype(String workOrderSubType) {
        new BFOStandaloneNewWorkOrderPageObjects().selectWorkOrderSubType(workOrderSubType);
    }

    @And("I select contact {string}")
    public void iSelectContact(String contactName) {
        new BFOStandaloneNewWorkOrderPageObjects().enterContact(contactName.split(" ")[0]).selectContactName(contactName);
    }

    @And("I select country of back office {string}")
    public void iSelectCountryOfBackOffice(String country) {
        new BFOStandaloneNewWorkOrderPageObjects().selectCountryOfBackOffice(country);
    }

    @And("I select back office system {string}")
    public void iSelectBackOfficeSystem(String backOfficeSystem) {
        new BFOStandaloneNewWorkOrderPageObjects().selectBackOfficeSystem(backOfficeSystem);
    }

    @Given("I navigate to url {string}")
    public void iNavigateToUrl(String url) {
      //new BFOVerifyCreatedWorkOrderPageObjects().openWorkOrder(url);
      // WebDriverRunner.getWebDriver().navigate().to(url);
      open(url);
     //   executeJavaScript("window.open('" + url + "');");
    }

    @And("I capture workOrder number as {string}")
    public void iCaptureWorkOrderNumberAs(String arg0) {
        String workOrderNumber = new BFOVerifyCreatedWorkOrderPageObjects().getWorkOrderNumber();
        data.put("WorkOrderNumber",workOrderNumber);
    }




    @And("I verify workorder fields")
    public void iVerifyWorkorderFields(DataTable dataTable) {
        BFOVerifyCreatedWorkOrderPageObjects bfoVerifyCreatedWorkOrderPageObjects = new BFOVerifyCreatedWorkOrderPageObjects();
        List<Map<String, String>> workorderData = dataTable.asMaps(String.class, String.class);
        Assert.assertTrue(bfoVerifyCreatedWorkOrderPageObjects.verifyFields("Installed At Account *",workorderData.get(0).get("Installed At Account")));
        captureScreenshot();
        Assert.assertTrue(bfoVerifyCreatedWorkOrderPageObjects.verifyFields("Location *",workorderData.get(0).get("Location")));
        captureScreenshot();
        Assert.assertTrue(bfoVerifyCreatedWorkOrderPageObjects.verifyFields("Contact",workorderData.get(0).get("Contact")));
        captureScreenshot();
        Assert.assertTrue(bfoVerifyCreatedWorkOrderPageObjects.verifyFields("Sold To Account *",workorderData.get(0).get("Sold To Account")));
        captureScreenshot();
        captureScreen=false;

    }

    @And("I Create/Update Work Order")
    public void iCreateUpdateWorkOrder() {

    }


    @And("capture screenshot")
    public void captureScreenshot() {
        captureScreen=true;
    }

    @And("I verify workorders fields")
    public void verifyWorkOrderFields(DataTable dataTable) {
        List<Map<String, String>> rows = dataTable.asMaps(String.class, String.class);
        for (Map<String, String> row : rows) {
            for (Map.Entry<String, String> entry : row.entrySet()) {
                String field = entry.getKey();
                String value = entry.getValue();
                System.out.println("Verifying " + field + ": " + value);
            }
        }
    }

    @And("Check {string} has value {string}")
    public void checkHasValue(String FieldName, String Value) {
        BFOVerifyCreatedWorkOrderPageObjects bfoVerifyCreatedWorkOrderPageObjects = new BFOVerifyCreatedWorkOrderPageObjects();
        switch (FieldName.toLowerCase()){
            case "installed at account"->{ Assert.assertTrue(bfoVerifyCreatedWorkOrderPageObjects.verifyFields("Installed At Account *",Value)); captureScreen=true; }
            case "location" -> {Assert.assertTrue(bfoVerifyCreatedWorkOrderPageObjects.verifyFields("Location *",Value)); captureScreen=true;}
            case "contact"->{Assert.assertTrue(bfoVerifyCreatedWorkOrderPageObjects.verifyFields("Contact",Value)); captureScreen=true;}
            case "work order category"-> {Assert.assertTrue(bfoVerifyCreatedWorkOrderPageObjects.verifyFields("Onsite").equalsIgnoreCase(Value)); captureScreen=true;}
            case "service business unit"->{Assert.assertTrue(bfoVerifyCreatedWorkOrderPageObjects.verifyFields("SECURE POWER").equalsIgnoreCase(Value)); captureScreen=true;}
            case "priority"-> {Assert.assertTrue(bfoVerifyCreatedWorkOrderPageObjects.verifyFields("Normal-Medium").equalsIgnoreCase(Value));captureScreen=true;}
            case "work order reason"-> {Assert.assertTrue(bfoVerifyCreatedWorkOrderPageObjects.verifyFields("Testing").equalsIgnoreCase(Value)); captureScreen=true;}
            case "sold to account"->{ Assert.assertTrue(bfoVerifyCreatedWorkOrderPageObjects.verifyFields("Sold To Account *",Value)); captureScreen=true;}
            case "non billing reason"->{ Assert.assertTrue(bfoVerifyCreatedWorkOrderPageObjects.verifyFields("Contract").equalsIgnoreCase(Value)); captureScreen=true;}
            case "is billable"->{ Assert.assertTrue(bfoVerifyCreatedWorkOrderPageObjects.verifyFields(Value).equalsIgnoreCase(Value)); captureScreen=true;}
            case "work order subtype"->{ Assert.assertTrue(bfoVerifyCreatedWorkOrderPageObjects.verifyFields("Basic Operator Training").equalsIgnoreCase(Value)); captureScreen=true;}
            default -> System.out.println("Not Implemented for "+ FieldName);
    }
 }

    @And("I click on link {string} Work Order")
    public void iClickOnCreateUpdateWorkOrder(String linkName) throws InterruptedException {
        BFOVerifyCreatedWorkOrderPageObjects bfoVerifyCreatedWorkOrderPageObjects = new BFOVerifyCreatedWorkOrderPageObjects();
        bfoVerifyCreatedWorkOrderPageObjects.clickCreate_UpdateWorkOrderLink();
    }

    @And("Wait for back office reference number")
    public void waitForBackOfficeRefrenceNumber() throws InterruptedException {
        BFOVerifyCreatedWorkOrderPageObjects bfoVerifyCreatedWorkOrderPageObjects = new BFOVerifyCreatedWorkOrderPageObjects();
        bfoVerifyCreatedWorkOrderPageObjects.fetchBackOfficeReferencenumber();
    }

    @And("Check Work Order Status contains {string}")
    public void checkContains(String status) {
        BFOVerifyCreatedWorkOrderPageObjects bfoVerifyCreatedWorkOrderPageObjects = new BFOVerifyCreatedWorkOrderPageObjects();
        bfoVerifyCreatedWorkOrderPageObjects.checkOrderStatus(status);
    }

    @And("I UploadFile {string};")
    public void iUploadFile(String fileName) {
        final String s = System.getProperty("user.dir") + "/TestData/" + fileName;
        $(By.xpath("//input[@type='file'][@id='fileinput']"))
                .uploadFile(new File(s));
        sleep(5000);
    }

    @And("develop new step")
    public void developNewStep() {

        //shadow dom handling
        /*$(By.tagName("hgf-c360nav")).shouldBe(visible);
        WebElement c = element(By.xpath("//hgf-c360nav")).shouldBe(visible).getShadowRoot()
                .findElement(By.cssSelector("header>div>div>nav[role='navigation']>div>hgf-button")).getShadowRoot().findElement(By.cssSelector("a"));
        *//*JavascriptExecutor js = (JavascriptExecutor) WebDriverRunner.getWebDriver();
        js.executeScript("arguments[0].click();", c);*//*
        new Actions(WebDriverRunner.getWebDriver()).moveToElement(c).click().perform();
        switchTo().window(1);
        System.out.println(title());
    */

       // $(byXpath("//div[@class='zw-product-header ']//div[@class='zmenu-cta-cont']//a[text()='Get Started']")).shouldBe(visible).click();
       //$(byXpath("//*[@name='order_preview']")).click();
        /*$(byLinkText("About Us")).click();
        switchTo().window(1);
        System.out.println(title());
        $(byXpath("//*[contains(text(),'My Products')]")).click();
        $(byAttribute("aria-label","Login/Register")).click();
        $(byLinkText("Create account")).click();
        switchTo().window(2);
        System.out.println(title());
        $(byTagName("qds-input")).shouldBe(visible).getShadowRoot().findElement(By.cssSelector("div>input")).sendKeys("Azhar");
        $(By.cssSelector("select[name='country']")).selectOption("India");*/

        $(byName("onboardingRadio")).shouldBe(enabled).click();
        $(By.tagName("qds-checkbox")).shouldBe(enabled).getShadowRoot().findElement(By.cssSelector("label>div>input")).click();
    }

    @When("I navigate to {string} from app launcher")
    public void iNavigateToFromAppLauncher(String appName) {
        new BFO_Landing_Header_Objects()
                .clickOnAPPMenuIcon()
                .enterAppsToSearch(appName)
                .waitForListOfMenu().clickOnWorkOrder(appName);
    }


    @And("I fill basic info details for creating new service contract:")
    public void iCreateANewServiceMaintenanceContractWithFollowingDetails(DataTable table) {
        Map<String, String> fields = new BasePage().storeFieldsIn(table.asMap());
        for (Map.Entry<String, String> entry : fields.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();
            new BFONewServiceContractBasicInfoPageObjects().setBasicInfoForServiceContract(key,value);
        }
        captureScreen=true;
    }


    @And("I fill contract details for creating new service contract:")
    public void iFillContractDetailsForCreatingNewServiceContract(DataTable table) {
        Map<String, String> fields = new BasePage().storeFieldsIn(table.asMap());
        for (Map.Entry<String, String> entry : fields.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();
            new BFONewServiceContractDetailsPageObjects().setContractDetailsForServiceContract(key,value);
        }
        captureScreen=true;
    }

    @And("I click on button {string}")
    public void iClickOnButton(String arg0) {
                 new BFONewServiceContractBasicInfoPageObjects().clickOnNewButton();
                 sleep(8000);

    }

    @And("I click on button {string} on service contract creation page")
    public void i_click_on_button_on_service_contract_creation_page(String arg0 ) {
        new BFONewServiceContractDetailsPageObjects().clickSaveAndNextButton();
    }

    @And("I search and select the product {string} from service line")
    public void i_search_and_select_the_product_from_service_line(String productName) {
        new BFOServiceLinePage().searchAndSelectTheProduct(productName);
    }

    @And("I fill the service line details for product :")
    public void iFillTheServiceLineDetailsForProduct(DataTable table) {
        Map<String, String> fields = new BasePage().storeFieldsIn(table.asMap());
        for (Map.Entry<String, String> entry : fields.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();
            new BFOServiceLinePageObjects().setProuctDeatilsOnServiceLine(key,value);
        }
        captureScreen=true;

    }
    /*
    @And("I search and select the product {string} and installed product {string}from cover products")
    public void iSearchAndSelectTheProductAndInstalledProductFromCoverProducts(String productname) {
        new BFOCoverProductPage().addCoverProduct(productname);

    }
*/

    @And("I search and select the product {string} from new service and maintenance contract")
    public void iSearchAndSelectTheProductFromNewServiceAndMaintenanceContract(String productname) {
        new BFOCoverProductPage().addCoverProduct(productname);
    }

    @And("I Search  and select installed product {string} from service and maintenence")
    public void iSearchAndSelectInstalledProductFromServiceAndMaintenence(String installedProduct) {
        new BFOInstalledProductPage().addInstalledProduct(installedProduct);

    }

    @And("I click on button {string} in new service maintenance contract page")
    public void iClickOnButtonInNewServiceMaintenanceContractPage(String arg0) {
        new BFOCoverProductPageObjetcs().clickOnSaveButton();
    }

    @And("I click on validate Contract button and enter validation note{string}to validate the contract")
    public void iClickOnValidateContractButtonAndEnterValidationNoteToValidateTheContract(String notes) {
        new BFOValidateContract().validateContract(notes);
    }

    @Then("I should see the contract status as {string}  and status is {string} in service contract page")
    public void iShouldSeeTheContractStatusAsAndStatusIsInServiceContractPage(String arg0, String status) {
        new BFOVerifyServiceContractBasicInfoPageObjects().checkContractStatus(status);
    }

    @And("I click on create pm plan button from contract name {string}")
    public void iClickOnCreatePmPlanButtonFromContractName(String contractName) {
        new BFOPMPlan().clickOnRelatedTab(contractName);
    }

    @And("I fill Pm plan details for creating new pm plan:")
    public void iFillPmPlanDetailsForCreatingNewPmPlan(DataTable table) {
        Map<String, String> fields = new BasePage().storeFieldsIn(table.asMap());
        for (Map.Entry<String, String> entry : fields.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();
            new BFOCreatePmPlanObjects().setPmPlanDetails(key,value);
        }
        captureScreen=true;

    }

    @And("click on button {string}")
    public void clickOnButton(String arg0) {
        new BFOCreatePmPlanObjects().clickOnCreateButton();
        sleep(5000);
        new BFOCreatePmPlanObjects().clickOnCloseThisWindow();
    }

    @When("I click on {string} button to create work order")
    public void iClickOnButtonToCreateWorkOrder(String arg0) {
        new BFO_SFMTabObjects().clickOnCreateWorkOrderButton();
    }

    @And("I fill work order details for creating new work order from service maintenance contract:")
    public void iFillWorkOrderDetailsForCreatingNewWorkOrderFromServiceMaintenanceContract(DataTable table) {
        Map<String, String> fields = new BasePage().storeFieldsIn(table.asMap());
        for (Map.Entry<String, String> entry : fields.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();
            new BFOServiceMaintenanceWorkOderPage().setMandatoryDetailsForWorkOrder(key,value);
        }
        captureScreen=true;

    }

    @And("I click on {string} button in work order page")
    public void iClickOnButtonInWorkOrderPage(String arg0) {
        new BFOValidateContractPageObjects().clickOnSaveButton();
    }

    @Then("I should see the work order status as {string} in work order page")
    public void iShouldSeeTheWorkOrderStatusAsInWorkOrderPage(String workOrderStatus) {
        sleep(10000);
        new BFOVerifyWorkOrderStatus().checkWorkOrderStatus(workOrderStatus);
    }




    @And("I click on {string} button from SFM Tab")
    public void iClickOnButtonFromSFMTab(String buttonName) {
        new BFO_SFMTabObjects().clickOnSFMTabButtons(buttonName);
     //   new BFO_SFMTabObjects().clickOnCreateUpdateWorkOrderButton();
    }

    @And("I check the message {string} on sync window")
    public void iCheckTheMessageOnSyncWindow(String msg) {

        new BFOSyncPageObjetcs().checkSyncPageMessage(msg);
        captureScreen=true;
    }

    @And("I click on {string} button on sync window")
    public void iClickOnButtonOnSyncWindow(String arg0) {
        new BFOSyncPage().clickOnSyncPageOkButton();
    }

    @And("I wait for back Office reference number")
    public void iWaitForBackOfficeReferenceNumber() throws InterruptedException {
        new BFOFlowOfWorkOrderPageObjects().fetchBackOfficeReferencenumber();
    //    ExtentTest extentLogger = CONSTANTS.extent.createTest("Wait for back Office reference number");
    //    extentLogger.info("Back Office Reference Number is fetched"+CONSTANTS.backOfficeReferenceNumber);
    }

    @And("I check the {string} and {string} in work order page")
    public void iCheckTheAndInWorkOrderPage(String arg0, String arg1) {
        new BFOFlowOfWorkOrderPageObjects().verifyFirstSynchronizationDate("dd/MM/yyyy");
        new BFOFlowOfWorkOrderPageObjects().verifyLastSynchronizationDate("dd/MM/yyyy");
    }

    @And("I check the {string} and {string} in work order page in FSR Manager")
    public void iCheckTheSynchronizationDatesInWorkOrderPageInFSRManager(String firstSyncDate, String lastSyncDate) {
        new BFOFlowOfWorkOrderPageObjects().verifyFirstSynchronizationDate("d/M/yyyy");
        new BFOFlowOfWorkOrderPageObjects().verifyLastSynchronizationDate("d/M/yyyy");
    }

    @And("I check the {string} as {string} in work order page")
    public void iCheckTheAsInWorkOrderPage(String arg0, String value) {
        new BFOFlowOfWorkOrderPageObjects().checkSynchronizationLogStatus(value);

    }



    @And("I click on {string} button from Sync page")
    public void iClickOnButtonFromSyncPage(String arg0) {
        new BFOSyncPage().performSyncActions();
    }

    @And("I switch to {string} window for work order to add into {string}")
    public void iSwitchToWindowForWorkOrderToAddInto(String arg0, String fsrName) {
        new ServiceBoardPage().searchAndAddFSRToWorkOrder(fsrName);
    }

    @And("I drag and drop the work order into {string}")
    public void iDragAndDropTheWorkOrderInto(String arg0) {
        new ServiceBoardPageObjects().dragAndDropWorkOrderToFSR();
    }

    @And("I click on {string} button in service board page")
    public void iClickOnButtonInServiceBoardPage(String arg0) {
        new ServiceBoardPage().clickOnSaveAndReturnTomainWindow();

    }

    @And("I check the Primary FSR as {string} in work order page")
    public void iCheckThePrimaryFSRAsInWorkOrderPage(String fsrName) {
        new ServiceBoardPageObjects().checkPrimaryFSR(fsrName);
    }

    @And("Change work order status to customer confirmed")
    public void changeWorkOrderStatusManually() {
        BFO_CustomerConfirmedPageObjects bfo_customerConfirmedPageObjects = new BFO_CustomerConfirmedPageObjects();
        bfo_customerConfirmedPageObjects.clickOnCustomerConfirmedTab()
                .clickOnMarkAsCurrentWorkOrderStatus()
                .clickOnDoneButton();
        sleep(3000);


/*
        String status = bfo_customerConfirmedPageObjects.clickOnCustomerConfirmedTab().clickOnMarkAsCurrentWorkOrderStatus().clickOnDoneButton().getWorkOrderStatus();
        Assert.assertTrue(status.equalsIgnoreCase("Customer Confirmed"));
        */
        captureScreen=true;
    }

    @And("I develop new steps")
    public void developNewSteps(){

    }



    @And("I add work order to {string} in Service Board")
    public void iAddWorkOrderToInServiceBoard(String fsrName) {
        sleep(4000);
        new BFO_SFMTabObjects().clickOnSFMTabButtons("Service Board");
        new ServiceBoardPage().searchAndAddFSRToWorkOrder(fsrName);
        new ServiceBoardPageObjects().dragAndDropWorkOrderToFSR();
        new ServiceBoardPage().clickOnSaveAndReturnTomainWindow();
    }

    @And("I add work order in Service Board as Recurring assignment")
    public void iAddWorkOrderToInServiceBoardToFSRAsRecurringAssignment(DataTable table) {
        String fsrName = null;
        String frequency = null;
        String frequencyUnit = null;
        String numOfDays = null;
        String skipweekends = null;
        List<String> additionalNonReferenceProductName = new ArrayList<>();
        List<Map<String, String>> orders = table.asMaps(String.class, String.class);
        for (Map<String, String> entry : orders) {
            fsrName = entry.get("FSR Name");
            frequency = entry.get("Frequency");
            frequencyUnit = entry.get("Frequency Unit");
            numOfDays = entry.get("Number of Days From today for end date");
            skipweekends = entry.get("Skip Weekend");
        }
        sleep(4000);
        new BFO_SFMTabObjects().clickOnSFMTabButtons("Service Board");
        new ServiceBoardPage().searchAndAddFSRToWorkOrder(fsrName);
        new ServiceBoardPage().enterRecurringWorkOrderData(frequency, frequencyUnit, numOfDays, Boolean.valueOf(skipweekends));
        new ServiceBoardPage().clickOnSave();
        String workOrder = new Work_Order_StepDefinition().fetchWorkOrderNumber();
        new ServiceBoardPage().verifyRecurringAssignment(workOrder, frequency, frequencyUnit, numOfDays, Boolean.valueOf(skipweekends));
        new ServiceBoardPage().returnToMainWindow();
    }

    @And("I add work order to multiple FSRs in Service Board")
    public void iAddWorkOrderToMultipleFSRsInServiceBoard(DataTable table) {
        sleep(4000);
        new BFO_SFMTabObjects().clickOnSFMTabButtons("Service Board");
        new ServiceBoardPage().switchToWindowAndCloseAnnouncementPopUP();
        new ServiceBoardPageObjects().hoverOnWorkOrder().clickWorkOrderMenu().selectManageMultipleReourcesOptions().enableAlignAppointmentButton();
        List<Map<String, String>> rows = table.asMaps(String.class, String.class);
        for (Map<String, String> row : rows) {
            String fieldName = row.get("Field Name");
            for (Map.Entry<String, String> entry : row.entrySet()) {
                if (!entry.getKey().equals("Field Name")) {
                    String fieldValue = entry.getValue();
                    System.out.println("Field Name: " + fieldName);
                    System.out.println("Field Value: " + fieldValue);
                    fsrNames.add(fieldValue);
                    new ServiceBoardPage().addFSR_ToGroupAppointment(fieldValue);
                }
            }
        }
        new ServiceBoardPage().setTimeWithMultipleFSR();
    }

    @When("I change the the primary FSR to {string}")
    public void iChangeThePrimaryFSRTo(String newFSR) {
        new BFO_SFMTabObjects().clickOnSFMTabButtons("Service Board");
        new ServiceBoardPage().changePrimaryFSR(newFSR);
    }

    @Then("I should see the primary FSR as {string}")
    public void iShouldSeeThePrimaryFSRAs(String expectedFSR) {
        new ServiceBoardPage().verifyPrimaryFSR(expectedFSR);
    }

    @Then("validate contract and check contract status as {string} and work order status as {string}")
    public void validateContractAndCheckContractStatusAsAndWorkOrderStatusAs(String contractStatus, String workOrderStatus) {
        new BFOValidateContract().validateContract("Testing");
        new BFOVerifyServiceContractBasicInfoPageObjects().checkContractStatus(workOrderStatus);
    }



    @And("I logout from bfo application")
    public void iLogoutFromBfoApplication() {
      new BFOHeaderPage().logoutFromBFO();
        executeJavaScript("location.reload();");
//      closeWebDriver();

    }

    @And("I memorized current work order number as {string}")
    public void iMemorizedCurrentWorkOrderNumberAs(String key) {
        String workOrderNumberWithUrl = BasePage.getWorkOrderNumberWithUrl();
        System.out.println(workOrderNumberWithUrl);
        BasePage.storeData(key,workOrderNumberWithUrl);
    }
    @And("I memorized current work order number as {string} and {string}")
    public void iMemorizedCurrentWorkOrderNumberAsAnd(String key1, String key2) {
        String workOrderNumberWithUrl = BasePage.getWorkOrderNumberWithUrl();
        String workOrderNumber = BasePage.getWorkOrderNumber();
        System.out.println(workOrderNumberWithUrl + " and " + workOrderNumber);
        BasePage.storeData(key1,workOrderNumberWithUrl);
        BasePage.storeData(key2,workOrderNumber);
    }

    @And("I wait for {string} seconds")
    public void iWaitForSeconds(String miliseconds) {

        sleep(Integer.parseInt(miliseconds)* 1000L);
    }

    @And("I selects the {string} section from {string}")
    public void iSelectedSpecificObject(String quote_number,  String appName) {
        sleep(5000);
        switch (appName.toLowerCase()){
            case "service/maintenance contracts":
                new BFO_Landing_Header_Objects().navigateToContract();
                break;

            case "contract value chain players":
                //Selenide.sleep(5000);
                new BFO_Landing_Header_Objects().navigateToCVCP();
                break;

            case "cases":
                new BFO_Landing_Header_Objects().navigateToCases();

            case "work orders":
                new BFO_Landing_Header_Objects().navigateToWorkOrders();
                break;

            default:
                System.out.println("Not Implemented for "+ appName);
        }
    }
    @And("I select the sap contract {string} section from {string}")
    public void iSelectedSpecificSap(String quote_number,  String appName) {
        sleep(5000);
        switch (appName.toLowerCase()){
            case "service/maintenance contracts":
                new BFO_Landing_Header_Objects().navigateToContract();
                break;

            case "contract value chain players":
                //Selenide.sleep(5000);
                new BFO_Landing_Header_Objects().navigateToCVCP();
                break;

            case "cases":
                new BFO_Landing_Header_Objects().navigateToCases();

            case "work orders":
                new BFO_Landing_Header_Objects().navigateToWorkOrders();
                break;

            default:
                System.out.println("Not Implemented for "+ appName);
        }
    }

    @And("I navigate to {string} Page by using URL")
    public void iNavigateToPageByUsingURL(String pageName) {

        new SalesforceUserHome_page().navigateToPage(pageName);
    }

    @And("I login as Proxy User {string}")
    public void iLoginAsProxyUser(String proxyUser) throws InterruptedException {
        new SalesforceSetup_page().loginAsProxyUser(proxyUser);
    }

    @And("I login as Proxy User SESA {string} with userName {string}")
    public void iLoginAsProxyUserSESAWithUserName(String sesa, String userName) throws InterruptedException {
        new SalesforceSetup_page().loginAsProxyUser(sesa, userName);
    }

    @And("I update the Total Quoted Hrs to {string} and save")
    public void updateTotalQuoteHrsInDurationPage(String hrs) {
        new BFODurationPage().updateTotalQuotedHrs(hrs);
    }

    /*
    @And("I navigate to url {string}")
    public void iNavigateToUrl(String url) throws InterruptedException {
        //new BFOVerifyCreatedWorkOrderPageObjects().openWorkOrder(url);
        // WebDriverRunner.getWebDriver().navigate().to(url);
        // executeJavaScript("return document.readyState").equals("complete");
         executeJavaScript("location.reload();");
         open(url);}
    }

*/




/*
    @When("I search and select the product {string} from service line")
    public void iSearchAndSelectTheProductFromServiceLine(String productName) {
        new BFOServiceLinePage().searchAndSelectTheProduct(productName);
    }

    @When("I click on button {string} on service contract creation page")
    public void iClickOnButtonOnServiceContractCreationPage(String arg0) {
        new BFONewServiceContractDetailsPageObjects().clickSaveAndNextButton();
    }

 */
}