package bfs.pages;

import com.codeborne.selenide.*;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.time.Duration;

import java.util.List;
import com.codeborne.selenide.*;
import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.$;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import com.codeborne.selenide.WebDriverRunner;




import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.*;

public class BasePage {
     Map<String,String> fieldsMap = new LinkedHashMap<>();
     public static HashMap<String,String> data = new LinkedHashMap<>();
    private static String getElementValueUsingJSByID(String id) {
        return executeJavaScript("return document.getElementById('" + id + "').value");
    }

    public static void highLightElement(SelenideElement element) {
        JavascriptExecutor js = (JavascriptExecutor) WebDriverRunner.getWebDriver();
        //use executeScript() method and pass the arguments
        //Here i pass values based on css style. Yellow background color with solid red color border.
        js.executeScript("arguments[0].setAttribute('style', 'border-width: 3px; border-style: solid; border-color: red');", element);
    }


    public static void  storeData(String key, String workOrderNumber) {
        data.put(key,workOrderNumber);
    }

    public  String getWorkOrderNumberURL(String workorder) {
        Selenide.sleep(3000);
        System.out.println(data.get(workorder));
        String[] workOrder = data.get(workorder).split("::");
        return workOrder[1];
    }
    public  String getWorkOrderNumber(String workorder) {
        System.out.println(data.get(workorder));
        String[] workOrder = data.get(workorder).split("::");
        return workOrder[0];
    }

    public  Map<String,String> storeFieldsIn(Map<String, String> data) {
        for (Map.Entry<String, String> entry : data.entrySet()) {
            String key = entry.getKey().toLowerCase();
            System.out.println("key "+key);
            String value = entry.getValue();
            System.out.println("value "+value);
            if(!key.equalsIgnoreCase("field name")) {
                fieldsMap.put(key,value);
            }
        }
        return fieldsMap;
    }
    public static void switchFrame(By locator){
        locator=By.cssSelector("iframe[name*='vfFrameId_']");
        Selenide.switchTo().frame($(locator));

    }
    static By childFrame = By.cssSelector("iframe[name*='vfFrameId_']");
    public static void switchToChildFrame(){
       Selenide.switchTo().frame($(childFrame));

    }
    public static String getTodayDate(String format) {
        LocalDate today = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
        return today.format(formatter);
    }

    public static String getNextYearDate(String format) {
        LocalDate today = LocalDate.now();
        LocalDate nextYearDate = today.plusYears(1);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
        return nextYearDate.format(formatter);
    }

    public static String getWorkOrderNumber() {
        ElementsCollection workOrderNumber = $$x("//*[contains(text(),'Work Order')]/../../parent::h1/*/*[@slot='primaryField']");
        String wo = workOrderNumber.get(0).getText();
        System.out.println("Work Order Number is: "+wo);
        return wo;

    }

    public static String getWorkOrderNumberWithUrl(){
        String wo = $$x("//*[contains(text(),'Work Order')]/../../parent::h1/*/*[@slot='primaryField']").get(0).shouldBe(visible).getText();
        if(wo.isBlank()){
            wo= WebDriverRunner.getWebDriver().getTitle().split(" ")[0];
            System.out.println(wo);
            String currentUrl =WebDriverRunner.getWebDriver().getCurrentUrl();
            wo = wo+"::"+currentUrl;
        }else{
            String currentUrl =WebDriverRunner.getWebDriver().getCurrentUrl();
            wo = wo+"::"+currentUrl;
        }
        return wo;
    }

    // Wait for an element to be visible
    public static SelenideElement waitForVisibility(By locator, int timeoutInSeconds) {
        return $(locator).shouldBe(visible, Duration.ofSeconds(timeoutInSeconds));
    }

    // Wait for an element to be clickable
    public static SelenideElement waitForClickability(By locator, int timeoutInSeconds) {
        return $(locator).shouldBe(enabled, Duration.ofSeconds(timeoutInSeconds));
    }

    // Click an element
    public static void clickElement(By locator) {
        $(locator).click();
    }

    // Enter text into an input field
    public static void enterText(By locator, String text) {
        $(locator).setValue(text);
    }

    // Get text of an element
    public static String getElementText(By locator) {
        return $(locator).getText();
    }

    // Verify if an element contains a specific text
    public static void verifyElementText(By locator, String expectedText) {
        $(locator).shouldHave(text(expectedText));
    }

    // Verify if an element exists
    public static boolean isElementPresent(By locator) {
        return $(locator).exists();
    }

//    // Get all elements matching a locator
//    public static List<SelenideElement> getAllElements(By locator) {
//        return $$(locator);
//    }

    // Scroll to an element
    public static void scrollToElement(By locator) {
        $(locator).scrollTo();
    }

    // Hover over an element
    public static void hoverOverElement(By locator) {
        $(locator).hover();
    }

    // Select a value from a dropdown by visible text
    public static void selectDropdownByVisibleText(By locator, String visibleText) {
        $(locator).selectOption(visibleText);
    }

    // Select a value from a dropdown by value
    public static void selectDropdownByValue(By locator, String value) {
        $(locator).selectOptionByValue(value);
    }

    // Get attribute value of an element
    public static String getElementAttribute(By locator, String attribute) {
        return $(locator).getAttribute(attribute);
    }

    // Wait for a page to load completely
    public static void waitForPageLoad() {
        Selenide.executeJavaScript("return document.readyState").equals("complete");
    }

    // Switch to a specific frame by index
    public static void switchToFrame(int index) {
        WebDriverRunner.getWebDriver().switchTo().frame(index);
    }

    // Switch to a specific frame by locator
    public static void switchToFrame(By locator) {
        WebDriverRunner.getWebDriver().switchTo().frame($(locator));
    }

    // Switch to the default content
    public static void switchToDefaultContent() {
        WebDriverRunner.getWebDriver().switchTo().defaultContent();
    }

    // Accept an alert
    public static void acceptAlert() {
        Selenide.switchTo().alert().accept();
    }

    // Dismiss an alert
    public static void dismissAlert() {
        Selenide.switchTo().alert().dismiss();
    }

    // Get alert text
    public static String getAlertText() {
        return Selenide.switchTo().alert().getText();
    }

    // Clear an input field
    public static void clearField(By locator) {
        $(locator).clear();
    }
    // Switch to a specific window by title
    public static void switchToWindowByTitle(String title) {
        for (String handle : WebDriverRunner.getWebDriver().getWindowHandles()) {
            WebDriverRunner.getWebDriver().switchTo().window(handle);
            if (WebDriverRunner.getWebDriver().getTitle().equals(title)) {
                break;
            }
        }
    }

    // Switch to a window by index
    public static void switchToWindowByIndex(int index) {
        String[] handles = WebDriverRunner.getWebDriver().getWindowHandles().toArray(new String[0]);
        WebDriverRunner.getWebDriver().switchTo().window(handles[index]);
    }

    // Close all windows except the main one
    public static void closeAllExceptMainWindow() {
        String mainHandle = WebDriverRunner.getWebDriver().getWindowHandles().iterator().next();
        for (String handle : WebDriverRunner.getWebDriver().getWindowHandles()) {
            if (!handle.equals(mainHandle)) {
                WebDriverRunner.getWebDriver().switchTo().window(handle).close();
            }
        }
        WebDriverRunner.getWebDriver().switchTo().window(mainHandle);
    }
    // Click an element using JavaScript
    public static void jsClick(By locator) {
        Selenide.executeJavaScript("arguments[0].click();", $(locator));
    }

    // Scroll into view using JavaScript
    public static void scrollIntoView(By locator) {
        Selenide.executeJavaScript("arguments[0].scrollIntoView(true);", $(locator));
    }

    // Get inner text of an element
    public static String getInnerText(By locator) {
        return Selenide.executeJavaScript("return arguments[0].innerText;", $(locator));
    }
    // Switch to a window that is not the current one
    public static void switchToOtherWindow() {
        WebDriver driver = WebDriverRunner.getWebDriver();
        String currentWindowHandle = driver.getWindowHandle();

        for (String windowHandle : driver.getWindowHandles()) {
            if (!windowHandle.equals(currentWindowHandle)) {
                driver.switchTo().window(windowHandle);
                break;
            }
        }
    }

    // Switch to a window containing specific text
    public static void switchToWindowContainingText(String text) {
        WebDriver driver = WebDriverRunner.getWebDriver();

        for (String windowHandle : driver.getWindowHandles()) {
            driver.switchTo().window(windowHandle);
            if (driver.getPageSource().contains(text)) {
                break;
            }
        }
    }

    // Switch back to the main window
    public static void switchToMainWindow() {
        WebDriver driver = WebDriverRunner.getWebDriver();
        String mainWindowHandle = driver.getWindowHandles().iterator().next();
        driver.switchTo().window(mainWindowHandle);
    }
    public static int countWeekendDays(LocalDate startDate, LocalDate endDate) {
        int weekendCount = 0;

        // Iterate through the date range
        LocalDate currentDate = startDate;
        while (!currentDate.isAfter(endDate)) {
            DayOfWeek dayOfWeek = currentDate.getDayOfWeek();
            if (dayOfWeek == DayOfWeek.SATURDAY || dayOfWeek == DayOfWeek.SUNDAY) {
                weekendCount++;
            }
            currentDate = currentDate.plusDays(1);
        }

        return weekendCount;
    }

    public static long calculateDaysBetween(LocalDate startDate, LocalDate endDate) {
        // Calculate the number of days between the start and end dates
        return ChronoUnit.DAYS.between(startDate, endDate);
    }

    public static void switchToChildWindow(String parentWindow) {
        Set<String> windowHandles = WebDriverRunner.getWebDriver().getWindowHandles();
        if (windowHandles.size() > 1) {
            for (String handle : windowHandles) {
                if (!handle.equals(parentWindow)) {
                    WebDriverRunner.getWebDriver().switchTo().window(handle);
                    break;
                }
            }
        }
    }
}



