package bfs.pages.bfo;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import com.codeborne.selenide.WebDriverRunner;
import bfs.CONSTANTS;
import com.codeborne.selenide.*;
import com.codeborne.selenide.ex.ElementNotFound;
import org.junit.Assert;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;

import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.*;

import static bfs.pages.BasePage.waitForPageLoad;
import static bfs.pages.bfo.ApplicationCommonMethods.*;
import static com.codeborne.selenide.Condition.enabled;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.*;

public class WorkOrdersIpAndSkills {

    // XPaths for elements
    private static final String NEW_INSTALLED_PRODUCTS = "(//h2[text()='Installed products']/../parent::div/../following-sibling::div/following-sibling::div/div/button[text()='New'])[last()]";
    private static final String INSTALLED_PRODUCTS_HEADER_TEXT = "//h1[@title='New Service / Maintenance Contract']";
    private static final String INSTALLED_PRODUCTS_CHECKBOX = "//table[@aria-describedby='Search and Create Installed Product']/tbody/tr/td/div/input";
    private static final String INSTALLED_ACCOUNT_TITLE = "//table[@aria-describedby='Search and Create Installed Product']/tbody/tr/td[3]/div";
    private static final String INSTALLED_PRODUCTS_RADIO = "//tr[contains(@class, 'cLCMP_FSSearchJobBasket')]/td//div/span/input[@type='radio']";
    private static final String ATTACH_IP_BUTTON = "//button[text()='Attach IP']";
    private static final String CREATE_NEW_BUTTON = "//button[text()='Create New']";
    private static final String SEARCH_FROM_PRODUCT_CATALOG_TEXT = "//div[text()='SEARCH FROM PRODUCT CATALOG']";
    private static final String BRAND_DROPDOWN_BUTTON = "//div[contains(@class,'NewInstalledProduct')]//button[@aria-label='BRAND']";
    private static final String DEVICE_TYPE_DROPDOWN_BUTTON = "//div[contains(@class,'NewInstalledProduct')]//button[@aria-label='DEVICE TYPE']";
    private static final String RANGE_DROPDOWN_BUTTON = "//div[contains(@class,'NewInstalledProduct')]//button[@aria-label='RANGE']";
    private static final String SUB_RANGE_DROPDOWN_BUTTON = "//div[contains(@class,'NewInstalledProduct')]//button[@aria-label='SUB RANGE']";

    private static final String BRAND_DROPDOWN_OPTION = "//label[text()='BRAND']//following::lightning-base-combobox-item[@data-value='%s']";
    private static final String DEVICE_TYPE_DROPDOWN_OPTION = "//label[text()='DEVICE TYPE']//following::lightning-base-combobox-item[@data-value='%s']";
    private static final String RANGE_DROPDOWN_OPTION = "//label[text()='RANGE']//following::lightning-base-combobox-item[@data-value='%s']";
    private static final String SUB_RANGE_DROPDOWN_OPTION = "//label[text()='SUB RANGE']//following::lightning-base-combobox-item[@data-value='%s']";

    private static final String NO_RECORDS_TEXT = "//div[text()='No Records']";
    private static final String UNABLE_TO_FIND_PRODUCT_CHECKBOX = "//span[text()='Unable to find the product']//preceding-sibling::span[@part='indicator']";
    private static final String NEXT_BUTTON = "//div[contains(@class,'NewInstalledProduct')]//button[text()='Next' and contains(@class,'button_brand')]";
    private static final String SEARCH_TEXTBOX = "//input[@name='enter-search']";
    private static final String GO_BUTTON_IN_CREATE_IP = "//div[contains(@class,'NewInstalledProduct')]//button[text()='Go']";
    private static final String GO_BUTTON = "//button[text()='Go']";
    private static final String SERIAL_NUMBER_TEXTBOX = "//input[@name='Serial Number']";
    private static final String INSTALLED_PRODUCT_NAME_TEXTBOX = "//input[@name='Installed Product Name']";
    private static final String CUSTOMER_INSTALLED_PRODUCT_REFERENCE = "//input[@name='Reference']";
    private static final String DATE_SHIPPED = "//label[text()='Date Shipped']//following-sibling::div//input";
    private static final String MANUFACTURING_DATE = "//label[text()='Manufacturing Date']//following-sibling::div//input";
    private static final String COMMISSIONING_DATE_INSTALL_DATE = "//label[text()='Commissioning Date Install Date']//following-sibling::div//input";
    private static final String LIFECYCLE_STATUS_BUTTON = "//button[contains(@name,'LifeCycleStatusOfTheInstalledProduct')]";
    private static final String LIFECYCLE_STATUS_DROPDOWN_OPTIONS = "//span[text()='%s']//ancestor::lightning-base-combobox-item";
    private static final String SAVE_BUTTON = "//div[contains(@class,'slds-grid slds-gutters cLCMP_FSCloneIP')]//button[text()='Save' and @class='slds-button slds-button_brand']";
    private static final String SUCCESS_MESSAGE = "//span[@class='toastMessage forceActionsText']"; // IP is created Successfully.
    private static final String SUCCESS_TITLE = "//div[contains(@class,'toastTitle')]";
    private static final String CLOSE_BUTTON = "//footer//button[@title='Close']";
    private static String INSTALLED_PRODUCT_NAME = null;
    private static String TABLE_HEADERS = "//table[@aria-describedby='Search and Create Installed Product']//th";
    private static String TABLE_ROWS = "//table[@aria-describedby='Search and Create Installed Product']//tbody/tr";


    public WorkOrdersIpAndSkills clickNewInstalledProducts() {
        try {
            waitForGivenTime(8000);
            SelenideElement newButton = $x(NEW_INSTALLED_PRODUCTS);

            // Scroll into view before clicking
            newButton.scrollIntoView("{block: \"center\"}");

            // Use JavaScript to click
            executeJavaScript("arguments[0].click();", newButton);
            waitForGivenTime(10000);
            waitForPageLoad();
            return this;
        } catch (Exception e) {
            ApplicationCommonMethods.handleException("Error clicking on New Installed Products", e);
            throw e;
        }
    }



    // Handle exceptions
    public static void handleException(String message, Exception exception) {
        System.err.println(message + ": " + exception.getMessage());
        exception.printStackTrace();
        throw new RuntimeException(message, exception);
    }

    private static void performAction(Runnable action, String errorMessage) {
        try {
            action.run();
        } catch (Exception e) {
            ApplicationCommonMethods.handleException(errorMessage, e);
        }
    }

    // Helper method to get elements with highlight
    private static SelenideElement highlightElement(SelenideElement element) {
        element.shouldBe(visible, Duration.ofSeconds(10));
        return element;
    }

    public WorkOrdersIpAndSkills validateInstalledProductText(String expectedText) {
        ApplicationCommonMethods.performAction(() -> {
            SelenideElement element = highlightElement($x(INSTALLED_PRODUCTS_HEADER_TEXT));
            waitForElementToBeVisibleAndClickable(element);
            if (!element.getText().contains(expectedText)) {
                throw new AssertionError("Expected text: " + expectedText + " not found in element.");
            }
        }, "Error validating text in element");
        return this;
    }

    public List<String> selectInstalledProductCheckboxes() {
        List<String> selectedTitles = new ArrayList<>();

        try {
            ElementsCollection checkboxes = $$x(INSTALLED_PRODUCTS_CHECKBOX);
            ElementsCollection titleElements = $$x(INSTALLED_ACCOUNT_TITLE);

            int totalCheckboxes = checkboxes.size();

            if (totalCheckboxes == 0) {
                throw new IllegalStateException("No checkboxes found in the table.");
            }

            if (totalCheckboxes >= 3) {
                // Select random 3 checkboxes and get corresponding titles
                List<Integer> randomIndices = getRandomIndices(totalCheckboxes, 3);
                for (int index : randomIndices) {
                    toggleCheckboxUsingJS(checkboxes.get(index));
                    selectedTitles.add(getTitle(titleElements, index));
                }
            } else {
                // Select all available checkboxes and get corresponding titles
                for (int i = 0; i < totalCheckboxes; i++) {
                    toggleCheckboxUsingJS(checkboxes.get(i));
                    selectedTitles.add(getTitle(titleElements, i));
                }
            }

        } catch (Exception e) {
            ApplicationCommonMethods.handleException("Error selecting checkboxes and retrieving titles", e);
        }

        System.out.println("Selected Titles: " + selectedTitles);
        return selectedTitles;
    }

    // ✅ Toggle checkbox: If selected, unselect it first, then select it again
    private void toggleCheckboxUsingJS(SelenideElement checkbox) {
        checkbox.shouldBe(visible, enabled).scrollIntoView("{block: \"center\"}");

        boolean isAlreadySelected = checkbox.isSelected();

        if (isAlreadySelected) {
            System.out.println("Checkbox is already selected, unselecting...");
            executeJavaScript("arguments[0].click();", checkbox);
            sleep(500);  // Small wait before re-selecting
        }

        System.out.println("Selecting checkbox...");
        executeJavaScript("arguments[0].click();", checkbox);
    }

    // ✅ Retrieve the title attribute safely
    private String getTitle(ElementsCollection titleElements, int index) {
        if (index < titleElements.size()) {
            return titleElements.get(index).getAttribute("title");
        }
        return "N/A";
    }

    // ✅ Generate random indices
    private List<Integer> getRandomIndices(int total, int count) {
        List<Integer> indices = new ArrayList<>();
        while (indices.size() < count) {
            int randomIndex = (int) (Math.random() * total);
            if (!indices.contains(randomIndex)) {
                indices.add(randomIndex);
            }
        }
        return indices;
    }


    public void selectInstalledProductsRadio() {
        ElementsCollection radioButtons = $$x(INSTALLED_PRODUCTS_RADIO);

        int totalRadioButtons = radioButtons.size();

        if (totalRadioButtons == 0) {
            throw new IllegalStateException("No radio buttons found.");
        }

        List<Integer> indices = getRandomIndices(totalRadioButtons, 1); // Get one random index
        SelenideElement selectedRadioButton = radioButtons.get(indices.get(0));

        if (selectedRadioButton.isSelected()) {
            System.out.println("Randomly selected radio button is already selected. Selecting another one...");

            for (int i = 0; i < totalRadioButtons; i++) {
                if (!radioButtons.get(i).isSelected()) {
                    selectedRadioButton = radioButtons.get(i);
                    break;
                }
            }
        }

        // Select the chosen radio button using JavaScript click
        selectRadioUsingJS(selectedRadioButton);
    }

    // ✅ JavaScript click helper method for radio buttons
    private void selectRadioUsingJS(SelenideElement radioButton) {
        radioButton.shouldBe(visible, enabled).scrollIntoView("{block: \"center\"}");
        executeJavaScript("arguments[0].click();", radioButton);
    }

    public WorkOrdersIpAndSkills clickAttachIP() {
        try {
            waitForGivenTime(8000);
            SelenideElement newButton = $x(ATTACH_IP_BUTTON);

            // Scroll into view before clicking
            newButton.scrollIntoView("{block: \"center\"}");

            // Use JavaScript to click
            executeJavaScript("arguments[0].click();", newButton);
            waitForGivenTime(10000);
            waitForPageLoad();
            return this;
        } catch (Exception e) {
            ApplicationCommonMethods.handleException("Error clicking on Attach IP", e);
            throw e;
        }
    }

    public List<String> getInstalledProductTitles() {
        waitForPageLoad();
        waitForGivenTime(15000);
        List<String> installedProductTitles = new ArrayList<>();

        try {
            ElementsCollection installedProducts = $$x("(//flexipage-component2[@data-component-id='LCMP_FSInstalledProductSmartList'])[last()]//table/tbody/tr/td/a[@data-label='Installed Product']");

            if (installedProducts.isEmpty()) {
                throw new IllegalStateException("No installed products found.");
            }

            for (SelenideElement product : installedProducts) {
                String title = product.getAttribute("title");
                if (title != null && !title.isEmpty()) {
                    installedProductTitles.add(title);
                }
            }

        } catch (Exception e) {
            ApplicationCommonMethods.handleException("Error retrieving installed product titles", e);
        }

        System.out.println("Installed Product Titles: " + installedProductTitles);
        return installedProductTitles;
    }


    public void compareSelectedAndInstalledProducts(List<String> selectedTitles, List<String> installedProducts) {
        if (selectedTitles == null || installedProducts == null) {
            throw new IllegalStateException("One or both lists are not initialized.");
        }

        // Convert lists to sets for easy comparison
        Set<String> selectedSet = new HashSet<>(selectedTitles);
        Set<String> installedSet = new HashSet<>(installedProducts);

        // Find common elements
        Set<String> commonElements = new HashSet<>(selectedSet);
        commonElements.retainAll(installedSet);

        // Find differences
        Set<String> selectedOnly = new HashSet<>(selectedSet);
        selectedOnly.removeAll(installedSet);

        Set<String> installedOnly = new HashSet<>(installedSet);
        installedOnly.removeAll(selectedSet);

        // Log results
        System.out.println("✅ Matching Elements: " + commonElements);
        System.out.println("❌ Selected but not in Installed: " + selectedOnly);
        System.out.println("❌ Installed but not in Selected: " + installedOnly);

        // Assert both lists are identical
        Assert.assertEquals("❌ Lists do not match!", selectedSet, installedSet);

        System.out.println("🎯 Both lists match exactly!");
    }
    public List<String> getSerialNumbers() {
        waitForPageLoad();
        waitForGivenTime(15000);
        List<String> serialNumbers = new ArrayList<>();

        try {
            ElementsCollection serialNumbersLocator = $$x("(//flexipage-component2[@data-component-id='LCMP_FSInstalledProductSmartList'])[last()]//table/tbody/tr/td[@data-label='Serial/Lot Number']/div/lightning-formatted-rich-text/span  ");

            if (serialNumbersLocator.isEmpty()) {
                throw new IllegalStateException("No installed products found.");
            }

            for (SelenideElement product : serialNumbersLocator) {
                String title = product.getText();
                if (!title.isEmpty()) {
                    serialNumbers.add(title);
                }
            }

        } catch (Exception e) {
            ApplicationCommonMethods.handleException("Error retrieving Serial Numbers", e);
        }

        System.out.println("Serial Numbers: " + serialNumbers);
        return serialNumbers;
    }

    public void clickOnCreateNewbutton() {
        highlightElement($x(CREATE_NEW_BUTTON).shouldBe(visible, enabled));
        $x(CREATE_NEW_BUTTON).shouldBe(visible, enabled).click(ClickOptions.usingJavaScript());
    }

    public void selectBrand(String value) {
        $x(BRAND_DROPDOWN_BUTTON).shouldBe(visible).click();
        $x(String.format(BRAND_DROPDOWN_OPTION, value)).shouldBe(visible).click(ClickOptions.usingJavaScript());
    }

    public void selectDeviceType(String value) {
        $x(DEVICE_TYPE_DROPDOWN_BUTTON).shouldBe(visible).click();
        $x(String.format(DEVICE_TYPE_DROPDOWN_OPTION, value)).shouldBe(visible).click(ClickOptions.usingJavaScript());
    }

    public void selectRange(String value) {
        $x(RANGE_DROPDOWN_BUTTON).shouldBe(visible).click();
        $x(String.format(RANGE_DROPDOWN_OPTION, value)).shouldBe(visible).click(ClickOptions.usingJavaScript());
    }

    public void selectSubRange(String value) {
        $x(SUB_RANGE_DROPDOWN_BUTTON).shouldBe(visible).click();
        $x(String.format(SUB_RANGE_DROPDOWN_OPTION, value)).shouldBe(visible).click(ClickOptions.usingJavaScript());
    }

    public boolean isNoRecordsTextDisplayed() {
        boolean isVisible;
        try {
            $x(NO_RECORDS_TEXT).shouldBe(visible, Duration.ofSeconds(5));
            isVisible = true;
        } catch (ElementNotFound e) {
            isVisible = false;
        }
        return isVisible;
    }

    public void selectUnabletoFindProductCheckbox() {
        $x(UNABLE_TO_FIND_PRODUCT_CHECKBOX).scrollIntoView("{block: \"center\"}").click();
    }

    public void clickOnNextbuttonInNewIPCreationPopUp() {
        $x(NEXT_BUTTON).scrollIntoView("{block: \"center\"}").click(ClickOptions.usingJavaScript());
    }

    public void clickOnGOButtonInCreateNewIPPopUp() {
        highlightElement($x(GO_BUTTON_IN_CREATE_IP).scrollIntoView("{block: \"center\"}").shouldBe(visible, enabled));
        $x(GO_BUTTON_IN_CREATE_IP).shouldBe(visible, enabled).click(ClickOptions.usingJavaScript());
    }

    public void ClickOnGoButton() {
        highlightElement($x(GO_BUTTON).scrollIntoView("{block: \"center\"}").shouldBe(visible, enabled));
        $x(GO_BUTTON).shouldBe(visible, enabled).click(ClickOptions.usingJavaScript());
    }

    public void enterSerialNumber(String serialNumber) {
        highlightElement($x(SERIAL_NUMBER_TEXTBOX).shouldBe(visible, enabled)).setValue(serialNumber);
    }

    public void enterInstalledProductName(String installedProductName) {
        highlightElement($x(INSTALLED_PRODUCT_NAME_TEXTBOX).shouldBe(visible, enabled)).setValue(installedProductName);
    }

    public void enterCustomerInstalledProductReference(String customerInstalledProductReference) {
        highlightElement($x(CUSTOMER_INSTALLED_PRODUCT_REFERENCE).shouldBe(visible, enabled)).setValue(customerInstalledProductReference);
    }


    public void enterDateShipped(String date) {
        if (date.isEmpty() || date.equalsIgnoreCase("today")) {
            LocalDate today = LocalDate.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd MMM yyyy");
            date = today.format(formatter);
        }
        highlightElement($x(DATE_SHIPPED).shouldBe(visible, enabled)).setValue(date);
    }

    public void enterManufacturingDate(String date) {
        if (date.isEmpty() || date.equalsIgnoreCase("today")) {
            LocalDate today = LocalDate.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd MMM yyyy");
            date = today.format(formatter);
        }
        highlightElement($x(MANUFACTURING_DATE).shouldBe(visible, enabled)).setValue(date);
    }

    public void enterCommissioningDateInstallDate(String date) {
        if (date.isEmpty() || date.equalsIgnoreCase("today")) {
            LocalDate today = LocalDate.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd MMM yyyy");
            date = today.format(formatter);
        }
        highlightElement($x(COMMISSIONING_DATE_INSTALL_DATE).shouldBe(visible, enabled)).setValue(date);
    }

    public void enterLifecycleStatus(String dropdownValue) {
        highlightElement($x(LIFECYCLE_STATUS_BUTTON).shouldBe(visible, enabled)).click();
        $x(String.format(LIFECYCLE_STATUS_DROPDOWN_OPTIONS, dropdownValue)).shouldBe(visible, enabled).click();
    }

    public void clickOnSave() {
        highlightElement($x(SAVE_BUTTON).shouldBe(Condition.visible, enabled));
        $x(SAVE_BUTTON).shouldBe(Condition.visible, enabled).click(ClickOptions.usingJavaScript());
    }

    public void clickOnCloseButton() {
        highlightElement($x(CLOSE_BUTTON).shouldBe(visible, enabled)).click(ClickOptions.usingJavaScript());
    }

    public void enterCreateInstalledProductDetails(Map<String, String> searchFields) {
        String serialNumber = searchFields.get("SERIAL NUMBER");
        String customerInstalledProductReference = searchFields.get("CUSTOMER INSTALLED PRODUCT REFERENCE");
        String dateShipped = searchFields.get("DATE SHIPPED");
        String manufacturingDate = searchFields.get("MANUFACTURING DATE");
        String commissioningDateInstallDate = searchFields.get("COMMISSIONING DATE INSTALL DATE");
        String lifecycleStatus_dropdownValue = searchFields.get("LIFECYCLE STATUS");

        if (serialNumber != null && !serialNumber.isEmpty()) {
            enterSerialNumber(serialNumber);
        }

        INSTALLED_PRODUCT_NAME = UUID.randomUUID().toString();
        enterInstalledProductName(INSTALLED_PRODUCT_NAME);
        System.out.println("INSTALLED_PRODUCT_NAME -> " + INSTALLED_PRODUCT_NAME);

        if (customerInstalledProductReference != null && !customerInstalledProductReference.isEmpty()) {
            enterCustomerInstalledProductReference(customerInstalledProductReference);
        }
        if (dateShipped != null && !dateShipped.isEmpty()) {
            enterDateShipped(dateShipped);
        }
        if (manufacturingDate != null && !manufacturingDate.isEmpty()) {
            enterManufacturingDate(manufacturingDate);
        }
        if (commissioningDateInstallDate != null && !commissioningDateInstallDate.isEmpty()) {
            enterCommissioningDateInstallDate(commissioningDateInstallDate);
        }
        if (lifecycleStatus_dropdownValue != null && !lifecycleStatus_dropdownValue.isEmpty()) {
            enterLifecycleStatus(lifecycleStatus_dropdownValue);
        }
        CONSTANTS.captureScreen = true;
        clickOnSave();
    }

    public void setSearchFromProductCatalogText() {
        highlightElement($x(SEARCH_TEXTBOX).shouldBe(visible, enabled).setValue(INSTALLED_PRODUCT_NAME));
    }

    public void verifySuccessToastMessgaeOnSavingCreateInstalledProduct(String expectedTitle, String expectedText) {      //IP is created Successfully.
        String actualTitle = $x(SUCCESS_TITLE).shouldBe(visible, enabled).getText();
        String actualText = $x(SUCCESS_MESSAGE).shouldBe(visible, enabled).getText();
        CONSTANTS.captureScreen = true;
        Assert.assertEquals("Expected Toast Title not found : " + expectedTitle, expectedTitle, actualTitle);
        Assert.assertEquals("Expected Toast message not found : " + expectedText, expectedText, actualText);
    }

    public void verifyProductDetailsAfterCreation(Map<String, String> searchFields) {
        waitForGivenTime(3000);
        HashMap<String, String> expectedProductDetails = new HashMap<>();
        expectedProductDetails.put("INSTALLED PRODUCT NAME", INSTALLED_PRODUCT_NAME);
        expectedProductDetails.put("SERIAL NO", (searchFields.get("SERIAL NUMBER") != null && !searchFields.get("SERIAL NUMBER").isEmpty()) ? searchFields.get("SERIAL NUMBER") : "VALUE NOT FOUND");
        expectedProductDetails.put("Life Cycle", (searchFields.get("LIFECYCLE STATUS") != null && !searchFields.get("LIFECYCLE STATUS").isEmpty()) ? transformInput(searchFields.get("LIFECYCLE STATUS")) : "VALUE NOT FOUND");


        String[] specificHeaders = {
                "INSTALLED PRODUCT NAME",
                "SERIAL NO",
                "Life Cycle"
        };

        Map<String, String> actualProductDetails = new HashMap<>();

        for (String headerText : specificHeaders) {
            ElementsCollection headers = $$x(TABLE_HEADERS);
            int columnIndex = -1;
            for (int i = 1; i <= headers.size(); i++) {
                SelenideElement header = headers.get(i);
                if ((header.getText() != null && header.getText().equals(headerText)) || (header.getDomAttribute("aria-label") != null && header.getDomAttribute("aria-label").equals(headerText))) {
                    columnIndex = i;
                    break;
                }

            }

            if (columnIndex != -1) {
                SelenideElement row = $$x(TABLE_ROWS).get(0); // Assuming we want the first data row
                String actualValue = row.$$("td").get(columnIndex).$("div").getText();
                actualProductDetails.put(headerText, actualValue);
            }
        }

        Assert.assertEquals(expectedProductDetails, actualProductDetails);
        CONSTANTS.captureScreen = true;
    }


    public static String transformInput(String value) {
        Map<String, String> transformations = new HashMap<>();
        transformations.put("Scrapped", "SCRAPPED");
        transformations.put("In Supply Chain", "SUPPLY_CHAIN");
        transformations.put("Critical Inventory", "");
        transformations.put("At Customer Location - Not Used", "NOT_USED");
        transformations.put("Commissioned / In Use", "IN_USE");
        transformations.put("Removed for Repair", "REMOVED");
        transformations.put("Lost or Stolen", "LOST");

        return transformations.getOrDefault(value, "");
    }


    public void filterAndCreatenewIP(Map<String, String> searchFields) {

        String brand = searchFields.get("BRAND");
        String deviceType = searchFields.get("DEVICE TYPE");
        String range = searchFields.get("RANGE");
        String subRange = searchFields.get("SUB RANGE");
        String successTitle = searchFields.get("EXPECTED TOAST TITLE ON SAVE");
        String successText = searchFields.get("EXPECTED TOAST TEXT ON SAVE");

        waitForElementToBeVisibleAndClickable($x(SEARCH_FROM_PRODUCT_CATALOG_TEXT)); // check

        // select dropdown values to filter products based on these values
        if (brand != null && !brand.isEmpty()) {
            selectBrand(brand);
        }
        if (deviceType != null && !deviceType.isEmpty()) {
            selectDeviceType(deviceType);
        }
        if (range != null && !range.isEmpty()) {
            selectRange(range);
        }
        if (subRange != null && !subRange.isEmpty()) {
            selectSubRange(subRange);
        }
        CONSTANTS.captureScreen = true;
        if (isNoRecordsTextDisplayed()) {
            selectUnabletoFindProductCheckbox();
            clickOnNextbuttonInNewIPCreationPopUp();
            enterCreateInstalledProductDetails(searchFields);
            verifySuccessToastMessgaeOnSavingCreateInstalledProduct(successTitle, successText);
        }
    }

    public void validateNewIPCreated(Map<String, String> searchFields) {
        setSearchFromProductCatalogText();
        ClickOnGoButton();
        verifyProductDetailsAfterCreation(searchFields);
    }

}
