Feature: ATP Check messages validation in parts order.
  As a user
  I want to navigate to the application and validate ATP Check messages for added parts in Work Order
  So that I can create parts order efficiently

  Scenario Outline: ATP Check messages validation in parts order for a specific Work Order
    Given I work in application "BFO" and environment "UAT"
    And I login to "BFO" as user "coordinator-1550@bridge-fo.com.uatbfo26"
    When I navigate to "SE - Services Lightning" from app launcher
    And I wait for "10" seconds
    And I navigate to "Work Orders" from app launcher
    And I click on bfo button "New"
    And I fill work order details for creating new work order from Work Order Page:
      | Field Name                | Field Value                         |
      | Select Record Type        | Standalone Work Order               |
      | Installed At Account      | 0001340233:Ampcontrol (QLD) Pty Ltd |
      | Location                  | 0045144542:Ampcontrol QLD Pty Ltd   |
      | Work Order Type           | Repair                              |
      | Contact                   | chandra.vamsi kumar                 |
      | Customer Requested Date   | today                               |
      | Country of Back Office    | Australia                           |
      | Back Office System        | SAP Bridge AP                       |
      | Work Order Category       | Onsite                              |
      | Services Business Unit    | POWER SYSTEMS                       |
      | Is Billable               | Yes                                 |
      | Customer Reference Number | 1234                                |
      | Priority                  | Normal-Medium                       |
      | Service Commercial Ref    | QWPFSRVPLNNSGEN                     |
      | Work Order Reason         | Testing                             |
      | Work Order Name           | Testing                             |
      | Sold To Account           | 0001340233:Ampcontrol (QLD) Pty Ltd |
    Then user should be able to see the work order number and memorize work order number
    And I should see the work order status as "New" in work order page
    And I click on "Create/Update Work Order" button from SFM Tab
    And I check the message "SUCCESS : INITIATED SYNC" on sync window
    And I click on "Ok" button on sync window
    Then I should see the work order status as "Unscheduled" in work order page
    And I wait for back Office reference number
    And I check the "First Synchronization date" and "Last Synchronization date" in work order page
    And I check the "Synchronization Log" as "Work Order CREATED in Back Office" in work order page
    And I add work order to "FSR-1550" in Service Board
    Then I should see the work order status as "Scheduled" in work order page
    And the user selects the "<Tab Name>" tab in Work Order Details
    And the user selects the "New Parts Order" in "<Tab Name>" Tab
    And the user selects the "Parts Order Type" as "<Parts Order Type>", "Requested Ship Date" and "<Ship From Plant>" in New Parts Order

#    Added 1 available part, 1 not available part and 1 part with error
    And the user adds multiple Parts to validate messages of ATP Check
      | Parts Order Type | Requested Ship Date | Ship From Plant | Product Name | Tab         |
      | Ship only        | dd MMM yyyy         | AU10            | 47053        | Parts Order |
      | Ship only        | dd MMM yyyy         | AU27            | RGE1401120   | Parts Order |
      | Ship only        | dd MMM yyyy         | AU27            | PAS600       | Parts Order |

    And the user selects the "<Tab Name>" tab in Work Order Details
    Then the parts order status should be "Released" in "<Tab Name>"
    And the Part Reference value should be displayed on expanding Added Parts Order Lines
#    And the parts order should be memorized
#    And the user selects the "<Work Details Tab>" tab in Work Order Details
#    And the work detail line number should be displayed and memorize work detail
    And I navigate to bfo tab "Details"
    And I check the "Synchronization Log" as "Work Order RELEASED Successfully in Back Office" in work order page
    And I memorized current work order number as "current_work_order_number_Url" and "current_work_order_number"
    Then Change work order status to customer confirmed
    Then I should see the work order status as "Customer Confirmed" in work order page
    And I logout from bfo application

    Examples:
      | Menu Item   | Work Order  | Tab Name    | Parts Order Type | Ship From Plant | Product Name | Line Status | Shipped Qty | Work Details Tab | Installed Quantity |
      | Work Orders | WO-12264768 | Parts Order | Ship only        | AU10            | 47053        | Received    | 1           | Work Details     | 1                  |




