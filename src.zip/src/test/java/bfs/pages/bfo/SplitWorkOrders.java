package bfs.pages.bfo;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import com.codeborne.selenide.WebDriverRunner;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import org.junit.Assert;
import org.openqa.selenium.interactions.Actions;
import bfs.Pojo.WorkOrdersCreatedPOJO;

import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static bfs.pages.BasePage.waitForPageLoad;
import static bfs.pages.bfo.ApplicationCommonMethods.*;
import static com.codeborne.selenide.Condition.enabled;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.*;

public class SplitWorkOrders {

    // XPaths for elements
    private static final String LINK_SPLIT_WORK_ORDER = "//span[text()='%s']/parent::a";
    private static final String MAIN_IP_LOCATOR = "(//span[text()='Yes']/parent::span/../parent::div/parent::td[@data-label='Main IP']/following-sibling::td[@data-label='Serial/Lot Number']/div)[last()]";
    private static final String DETAILS_BUTTON_LOCATOR = "//div[text()='%s']/../parent::div/preceding-sibling::div/button[contains(@class, 'DetailsDataGrid')]";
    private static final String DELETE_LINK_LOCATOR = "//span[text()='Delete']/parent::a";
    private static final String RANDOM_CHECKBOX_LOCATOR = "//div[contains(@class, 'MIP_Flag')]/span/div/div/label/span";
    private static final String SERIAL_NUMBERS_LOCATOR = "//div[contains(@class, 'SVMXC__Serial_Number_List')]/span/div";
    private static final String INSTALLED_PRODUCTS_LOCATOR = "//div[contains(@class, 'Work_Detail')]/following-sibling::div[not(contains(@class, 'SVMXC__Serial_Number_List')) and contains(@class, 'SVMXC__Serial_Number')]";
    private static final String WORK_ORDER_REASON_LOCATOR = "//label[text()='Work Order Reason']/parent::div/div/textarea";
    private static final String CUSTOMER_REQUESTED_DATE = "//label[contains(text(), '%s')]/parent::div/div/div/div/div/input";
    private static final String SPLIT_WO_FRAME = "//iframe[@title='Service Delivery']";
    private static final String SAVE_SPLIT_WO = "//span[text()='Save']/parent::button";
    private static final String SPLIT_WO_TEXT = "(//h1/div[contains(@class, 'entityNameTitle')]/following-sibling::slot/lightning-formatted-text)[last()]";



    private String mainIP;
    private String splitWorkOrderNumber;
    private List<String> serialNumbers;
    private static boolean isFirstIteration = true;

    public SplitWorkOrders clickSplitOrder(String labelText) {
        try {
            waitForGivenTime(8000);
            String xpath = String.format(LINK_SPLIT_WORK_ORDER, labelText);
            SelenideElement newWorkOrder = $x(xpath);
            waitForElementToBeVisibleAndClickable(newWorkOrder);
            newWorkOrder.scrollIntoView("{block: \"center\"}");
            Actions actions = new Actions(WebDriverRunner.getWebDriver());
            actions.moveToElement(newWorkOrder, 0, 0).click().perform();

            waitForGivenTime(8000);
        } catch (Exception e) {
            ApplicationCommonMethods.handleException("Error clicking on New Work Order", e);
        }
        return this;

    }

    // ✅ Get and Store Main IP for Reuse
    public String getMainIP() {
        waitForGivenTime(5000);
        if (mainIP == null) {
            mainIP = $x(MAIN_IP_LOCATOR).shouldBe(visible).getAttribute("title");
        }
        return mainIP;
    }

    public String getSplitWorkOrderNumber() {
        waitForGivenTime(15000);
        if (splitWorkOrderNumber == null) {
            splitWorkOrderNumber = $x(SPLIT_WO_TEXT).shouldBe(visible).getText();
        }
        return splitWorkOrderNumber;
    }
    public String getServiceOrderId() {
        String currentUrl = WebDriverRunner.url(); // Get the current URL
        System.out.println("Current URL: " + currentUrl);

        // Extract the Service Order ID from the URL
        String[] parts = currentUrl.split("/");
        String serviceOrderId = parts[parts.length - 2]; // Get the second last part of the URL

        System.out.println("Extracted Service Order ID: " + serviceOrderId);
        return serviceOrderId;
    }

        public SplitWorkOrders enterWorkOrderReason(String labelText) {
        ApplicationCommonMethods.switchToFrame(SPLIT_WO_FRAME);
        $x(WORK_ORDER_REASON_LOCATOR).shouldBe(visible, enabled).clear();
        $x(WORK_ORDER_REASON_LOCATOR).setValue(labelText);
        return this;
    }

    // ✅ Click Details Button (Uses Main IP)
    public SplitWorkOrders clickDetailsButton(String mainIP) {
        String dynamicLocator = String.format(DETAILS_BUTTON_LOCATOR, mainIP);

        $x(dynamicLocator).scrollIntoView("{block: \"center\"}").shouldBe(visible, enabled).click();
        return this;
    }

    // ✅ Click Delete Link
    public void clickDeleteLink() {
        waitForGivenTime(8000);
        $x(DELETE_LINK_LOCATOR).shouldBe(visible, enabled).click();
    }

    // ✅ Select a Random Checkbox
    public SplitWorkOrders selectRandomCheckbox() {
        waitForGivenTime(8000);
        ElementsCollection checkboxes = $$x(RANDOM_CHECKBOX_LOCATOR);
        if (checkboxes.isEmpty()) {
            throw new IllegalStateException("No checkboxes found");
        }
        SelenideElement checkbox = checkboxes.get((int) (Math.random() * checkboxes.size()));

        // Scroll into view
        executeJavaScript("arguments[0].scrollIntoView(true);", checkbox);

        // Double click using Actions class
        Actions actions = new Actions(WebDriverRunner.getWebDriver());
        actions.doubleClick(checkbox).perform();
        waitForGivenTime(8000);

        return this;
    }


    // ✅ Get and Store Serial Numbers for Reuse
    public List<String> getSerialNumbers() {
        if (serialNumbers == null) {
            serialNumbers = $$x(SERIAL_NUMBERS_LOCATOR).texts();
        }
        return serialNumbers;
    }

    // ✅ Get Installed Products List
    public List<String> getInstalledProducts() {
        return $$x(INSTALLED_PRODUCTS_LOCATOR).texts();
    }

    public SplitWorkOrders selectCustomerRequestDate(String labelText, String dateFormat) {
        ApplicationCommonMethods.clickAndEnterDynamicDate(labelText, CUSTOMER_REQUESTED_DATE, dateFormat);
        return this;
    }

    public SplitWorkOrders clickSaveSplitWorkOrder() {
        try {
            SelenideElement saveWorkOrder = $x(SAVE_SPLIT_WO);
            waitForElementToBeVisibleAndClickable(saveWorkOrder);
            saveWorkOrder.click();
            waitForGivenTime(15000);
        } catch (Exception e) {
            handleException("Error clicking on Continue Work Order", e);
        }
        return this;
    }

    public void storeWorkorders(String workOrder, String workOrderFileName) {

        String fileName = System.getProperty("user.dir") + "/TestData/" + workOrderFileName;
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.enable(SerializationFeature.INDENT_OUTPUT); // Enable pretty print

        try {

            // Clear the file only before the first iteration
            if (isFirstIteration) {
                FileWriter fileWriter = new FileWriter(fileName);
                fileWriter.write("[]");
                fileWriter.close();
                isFirstIteration = false;
            }

            // Read existing JSON file
            File file = new File(fileName);
            List<Object> dataList;
            dataList = objectMapper.readValue(file, List.class);

            // Create new data to append
            String dateTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss")).toString();
            WorkOrdersCreatedPOJO newData = new WorkOrdersCreatedPOJO(dateTime, workOrder);

            // Append new data to list
            dataList.add(newData);

            // Write updated list to JSON file
            objectMapper.writeValue(file, dataList);

            System.out.println("Data has been appended to " + fileName);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
