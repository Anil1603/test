//package bfs.stepdefinition;
//
//import com.jacob.activeX.ActiveXComponent;
//import bfs.sap.*;
//import io.cucumber.datatable.DataTable;
//import io.cucumber.java.en.And;
//import io.cucumber.java.en.Given;
//import io.cucumber.java.en.Then;
//import io.cucumber.java.en.When;
//
//import java.io.IOException;
//import java.util.List;
//import java.util.Map;
//
//public class SAP_StepDefinition {
//    private ActiveXComponent wnd;
//    @Given("I work in application {string}")
//    public void iWorkInApplication(String arg0) throws InterruptedException {
//        SAPLogin.initializeSAP();
//
//
//    }
//
//    @When("I navigate to {string}")
//    public void iNavigateTo(String arg0) throws InterruptedException {
//        SAPLogin.loginToTRASystem("(Bridge) ECC 6.0 SSO - QRH - Pre-Production APAC");
//
//    }
//
//    @And("I Search Standard Order in Order field")
//    public void iSearchInOrderField() throws InterruptedException, IOException {
//       LandingPage.enterTransactionCode("iw33");
//       LandingPage.enterOrderNumber(backOfficeNumber);
//       LandingPage.selectEnhancement();
//       LandingPage.getWorkOrderId();
//       LandingPage.getBfoNumber();
//       LandingPage.getWorkOrderType();
//
//
//
//    }
//
//    @Then("check all items following LIG:")
//    public void checkAllItemsFollowingLIG(DataTable dataTable) throws InterruptedException, IOException {
//        List<Map<String, String>> items = dataTable.asMaps(String.class, String.class);
//        SAPStandardOrderOverviewScreen.checkAllItemsFollowingLIG(items);
//      //  SAPStandardOrderOverviewScreen.closeSapgui(wnd);
//    }
//
//}
