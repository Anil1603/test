Feature: Case Management Work Order Creation.
  As a user
  I want to navigate to the application and create a Work Order for a specific Case
  So that I can manage cases efficiently


  Scenario Outline: Create a Work Order for a specific Case
    Given I work in application "BFO" and environment "UAT"
    When I login to "bfo" as user "coordinator-1660@bridge-fo.com.uatbfo26"
    And the user selects "<Menu Item>" from the Search menu
    And the user enters "<Case ID>" in Global Search
    And the user selects the "<Case ID>" from search results
    And the user selects the "<Tab Name>" tab in Case Details
    And the user selects "Show All" and chooses "<Sub Option>"
    And the user selects "<Create Option>"
    And the user selects "Services Business Unit" as "<Business Unit Value>"
    And the user selects "Country of Back Office" as "<Country Back Office>"
    And the user selects "Back Office System" as "<Back Office System>"
    And the user enters the "Location" as "<Location>"
    And the user selects Save Work Order
    Then I should see the work order status as "New" in work order page
    And I click on "Create/Update Work Order" button from SFM Tab
#    And I click on "Sync" button from Sync page
    And I check the message "SUCCESS : INITIATED SYNC" on sync window
    And I click on "Ok" button on sync window
    Then I should see the work order status as "Unscheduled" in work order page
    And I wait for back Office reference number
    And I check the "First Synchronization date" and "Last Synchronization date" in work order page
    And I check the "Synchronization Log" as "Work Order CREATED in Back Office" in work order page
    And I add work order to "FSR-1528" in Service Board
    Then I should see the work order status as "Scheduled" in work order page
    And I memorized current work order number as "current_work_order_number_Url" and "current_work_order_number"
    Then Change work order status to customer confirmed
    Then I should see the work order status as "Customer Confirmed" in work order page
    And I logout from bfo application
	#FSR User
    Given I work in application "BFO" and environment "UAT"
		#And I navigate to url "https://test.salesforce.com"
    And I login to "BFO" as user "fsr-1528@bridge-fo.com.uatbfo26"
    And FSR accepts the work order "current_work_order_number_Url"
    Then check fsr response is "Acknowledge FSR"
    And I click on "Update WO" button from SFM Tab
    And I select the fsr response as "Acknowledge FSR" from update wo page in servicemax
    And I click on "Save" button in update wo page in servicemax
    And I click on "Update WO" button from SFM Tab
    And I select the fsr response as "Under Preparation" from update wo page in servicemax
    And I click on "Save" button in update wo page in servicemax
    Then I should see the work order status as "WIP" in work order page
    And I click on "Update WO" button from SFM Tab
    And I select the fsr response as "On-Site" from update wo page in servicemax
    And I click on "Save" button in update wo page in servicemax
    And I click on "Update WO" button from SFM Tab
    And I select the fsr response as "WIP" from update wo page in servicemax
    And I fill the Risk Assessment details in WIP FSR response:
      |Field Name 		                |Field Value |
      |Is Risk Assessment Attached        |No|
      |NO Risk Assessment Reason          |Other|
      |No Risk Assessment Details         |Testing|
    And I click on "Save" button in update wo page in servicemax
    And I click on "Update WO" button from SFM Tab
    And I select the fsr response as "Delivered" from update wo page in servicemax
    And I fill the service details in delivered fsr response:
      |Field Name 		                |Field Value |
      |Work Performed                     |Testing|
      |Opportunity Detected               |No|
    And I click on add my time  and select the activity as "Service" in delivered fsr response
    And I update the time and click on "Save" button in update wo page in servicemax
    Then I should see the work order status as "Service Delivered" in work order page
    When I click on "Complete WO Tasks" button from SFM Tab
    And I click on "Save" button two times in Complete WO Task page
    Then I should see the work order status as "Service Completed" in work order page
    And I logout from bfo application
	#FSR Manager
    Given I work in application "BFO" and environment "UAT"
		#And I navigate to url "https://test.salesforce.com"
    And I login to "BFO" as user "fsrmanager-1528@bridge-fo.com.uatbfo26"
    When I click on "My Team Assigned FSR" from home page
    And I search for WONumber "Work Order"
    And I selects the "Work Order" section from "Work Orders"
#    And I look for the service completed work order "current_work_order_number" and open it
    And I click on "Review Time And Expense Lightning" button from SFM Tab
    Then I verify the all details and click button two times:
      |Field Name 		                |Field Value |
      |Opportunity Detected               |No|
      |Work Order                         |current_work_order_number|
      |Work Performed                     |Testing|
      |Completed By                       |FSR 1528|
      |Completed On                       |07/10/2024|
      |Installed At Account               |Sharma Electric works(1003)|
    And I changed the work order status to service validated
    Then I should see the work order status as "Service Validated" in work order page
    And I check the "First Synchronization date" and "Last Synchronization date" in work order page
    And I check the "Synchronization Log" as "Work Order RELEASED Successfully in Back Office" in work order page
    Examples:
      | Menu Item | Case ID 		| Tab Name | Sub Option | Create Option | Business Unit Value | Country Back Office	      | Back Office System		 | Location |
#      | Cases     | 110949736     | Related  | Work Orders| Create WO     | POWER SYSTEMS       |	France				      | SAP Bridge EU            | SEI_Industry - SITE |
#      | Cases     | 110952233     | Related  | Work Orders| Create WO     | SECURE POWER        | Global                | IT Oracle                | G4S SECURITY SYSTEMS - SITE |
      | Cases     | 110952248     | Related  | Work Orders| Create WO     | SECURE POWER        | Global                | IT Oracle                | SUTTER DELTA MEDICAL CENTER - SITE |