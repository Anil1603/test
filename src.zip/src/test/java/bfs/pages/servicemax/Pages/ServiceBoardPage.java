package bfs.pages.servicemax.Pages;

import bfs.CONSTANTS;
import bfs.pages.bfo.PartsOrder;
import bfs.pages.servicemax.PageObjects.ServiceBoardPageObjects;
import bfs.stepdefinition.Work_Order_StepDefinition;
import com.codeborne.selenide.Condition;
import com.codeborne.selenide.Condition;
import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;
import com.codeborne.selenide.WebDriverRunner;
import org.junit.Assert;
import  bfs.pages.BasePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.time.LocalDate;

import static com.codeborne.selenide.Selenide.*;

public class ServiceBoardPage {
  public  WebDriverWait wait;

    public void searchAndAddFSRToWorkOrder(String fsrName) {
        switchTo().window(1);
        Selenide.sleep(10000);
        $$("button.system-announcement__close.btn--icon").iterator().forEachRemaining(selenideElement -> {
            if (selenideElement.is(Condition.visible)) {
                selenideElement.click();
            }
        });
        ServiceBoardPageObjects serviceBoardPageObjects = new ServiceBoardPageObjects();
        serviceBoardPageObjects.setResourceNameOnSearchBoxAndClickEnter("\"" + fsrName + "\"");
        Selenide.sleep(5000);
        serviceBoardPageObjects.dragAndDropWorkOrderToFSR();
        serviceBoardPageObjects.setStartTimeIfWorngingMessageAppear("12");

    }

    public void clickOnSaveAndReturnTomainWindow(){
        ServiceBoardPageObjects serviceBoardPageObjects = new ServiceBoardPageObjects();
        Selenide.sleep(2000);
        serviceBoardPageObjects.clickOnSaveButton();
        Selenide.sleep(4000);
        closeWindow();
        switchTo().window(0);
        Selenide.sleep(5000);
    }

    public void clickOnSave() {
        ServiceBoardPageObjects serviceBoardPageObjects = new ServiceBoardPageObjects();
        Selenide.sleep(2000);
        serviceBoardPageObjects.clickOnSaveButton();
        Selenide.sleep(4000);
    }

    public void returnToMainWindow() {
        closeWindow();
        switchTo().window(0);
        Selenide.sleep(5000);
    }

    public void enterRecurringWorkOrderData(String frequency, String frequencyUnit, String numberOfDaysForEndDate, boolean skipWeekend) {
        new ServiceBoardPageObjects().getChildElementForRecurrentFields().enterFrequency(frequency).selectFrequencyUnit(frequencyUnit).enterRecurrenceEndDate(numberOfDaysForEndDate).selectSkipWeekendCheckBox(skipWeekend);
        CONSTANTS.captureScreen = true;
    }

    public void verifyRecurringAssignment(String workOrderNumber, String frequency, String frequencyUnit, String numberOfDaysForEndDate, boolean skipWeekend) {
        int expectedCount;
        int weekendDays;
        int freq = Integer.valueOf(frequency);
        LocalDate startDate = LocalDate.now();
        LocalDate endDate = startDate.plusDays(Integer.valueOf(numberOfDaysForEndDate));
        int totalDays = (int) BasePage.calculateDaysBetween(startDate, endDate) + 1;
        int actualCount = new ServiceBoardPageObjects().getCountofRecurringSlots_CurrentWorkOrder(workOrderNumber);
        switch (frequencyUnit) {
            case "Days" -> {
                weekendDays = (skipWeekend) ? BasePage.countWeekendDays(startDate, endDate) : (0);
                float expCount = (float) (totalDays - weekendDays) / freq;
                expectedCount = (int) Math.ceil(expCount);
                Assert.assertEquals("Actual number of recurring slots does not match the expected count", expectedCount, actualCount);
            }
            case "Weeks" -> {
                float numofWeeks = (float) totalDays / 7;
                expectedCount = (int) Math.ceil(numofWeeks / freq);
                Assert.assertEquals("Actual number of recurring slots does not match the expected count", expectedCount, actualCount);
            }
            case "Months" -> {
                float numOfmonths = (float) totalDays / 31;
                expectedCount = (int) Math.ceil(numOfmonths / freq);
                Assert.assertEquals("Actual number of recurring slots does not match the expected count", expectedCount, actualCount);
            }
            default -> throw new RuntimeException("Not implemented for " + frequencyUnit);
        }
    }

    public void addFSR_ToGroupAppointment(String fsr1) {
        ServiceBoardPageObjects serviceBoardPageObjects = new ServiceBoardPageObjects();
        serviceBoardPageObjects.setResourceNameOnSearchBoxAfterClearingAndClickEnter("\"" + fsr1 + "\"").clickPlusIconForFSR(fsr1);
    }

    public void setTimeWithMultipleFSR() {
        new ServiceBoardPageObjects().clickFirstFsrSlot().clickEditAppointment().setStartTimeIfWorngingMessageAppear("12");
        new ServiceBoardPageObjects().clickOnSaveButton().clickSaveAndExit();
        clickOnSaveAndReturnTomainWindow();
    }

    public void switchToWindowAndCloseAnnouncementPopUP() {
        Selenide.sleep(5000);
        switchTo().window(1);
        Selenide.sleep(10000);
        $$("button.system-announcement__close.btn--icon").iterator().forEachRemaining(selenideElement -> {
            if (selenideElement.is(Condition.visible)) {
                selenideElement.click();
            }
        });
    }

    public void changePrimaryFSR(String newFSR) {
        switchToWindowAndCloseAnnouncementPopUP();
        new ServiceBoardPageObjects().hoverOnWorkOrder().clickWorkOrderMenu().selectManageMultipleReourcesOptions().hoverOnFSR(newFSR).clickFSRMenu(newFSR).clickSetAsPrimaryResource().clickOnYesButton().clickOnExitButton();
        closeServiceBoardWindowandSwitchTomainWindow();
    }

    public void closeServiceBoardWindowandSwitchTomainWindow() {
        Selenide.sleep(4000);
        closeWindow();
        switchTo().window(0);
        Selenide.sleep(5000);
    }

    public void verifyPrimaryFSR(String expectedFSR) {
        int maxAttempts = 3;
        int attempts = 0;
        boolean statusFound = false;
        ServiceBoardPageObjects serviceBoardPageObjects = new ServiceBoardPageObjects();
        do {
            if (serviceBoardPageObjects.getPrimaryFSR().contains(expectedFSR)) {
                Assert.assertTrue(serviceBoardPageObjects.getPrimaryFSR().contains(expectedFSR));
                CONSTANTS.captureScreen = true;
                statusFound = true;
                break;
            }
            refresh();
            Selenide.sleep(15000);
            attempts++;
        } while (attempts < maxAttempts && !statusFound);
        if (!statusFound) {
            Assert.fail("Status did not match after " + maxAttempts + " attempts");
        }
    }

}
