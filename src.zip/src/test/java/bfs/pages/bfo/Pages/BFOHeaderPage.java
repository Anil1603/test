package bfs.pages.bfo.Pages;

import bfs.pages.bfo.PageObjects.BFO_HeaderPageObjects;

public class BFOHeaderPage {

    private final BFO_HeaderPageObjects bfo_headerPageObjects = new BFO_HeaderPageObjects();

    public void logoutFromBFO(){
        bfo_headerPageObjects.clickOnUserProfile().clickOnLogout();
    }
}
