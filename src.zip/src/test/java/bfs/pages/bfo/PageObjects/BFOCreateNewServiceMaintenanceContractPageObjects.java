package bfs.pages.bfo.PageObjects;

import com.codeborne.selenide.Selenide;
import org.openqa.selenium.By;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.*;

public class BFOCreateNewServiceMaintenanceContractPageObjects {
    private static final By New_Button = By.xpath("//a[@title='New']");
    private static final By CONTRACT_RECORD_NUMBER_TEXTBOX = By.xpath("//label[contains(text(),'Contract Record Name/Number')]/following-sibling::div//input");
    private static final By SOLD_TO_ACCOUNT_TEXT_BOX = By.xpath("//label[contains(text(),'Sold To Account')]/following-sibling::div//input[@placeholder='Select an Account']");
    private static final By MAIN_INSTALLED_AT_ACCOUNT_TEXT_BOX = By.xpath("//label[contains(text(),'Main Installed At Account')]/following-sibling::div//input[@placeholder='Select an Account']");
    private static final By MAIN_INSTALLED_AT_CONTACT_TEXT_BOX = By.xpath("//label[contains(text(),'Main Installed at Contact')]/following-sibling::div//input[@placeholder='Select a Contact']");
    private static final By BILL_TO_ACCOUNT_TEXT_BOX = By.xpath("//label[contains(text(),'Bill To Account')]/following-sibling::div//input[@placeholder='Select an Account']");
    private static final By REMOTE_SERVICE_CONTACT_TEXT_BOX = By.xpath("//label[contains(text(),'Remote Service Contact')]/following-sibling::div//input[@placeholder='Select a Contact']");
    private static final By START_DATE_TEXT_BOX = By.xpath("//label[contains(text(),'Start Date')]/following-sibling::div//input");
    private static final By END_DATE_TEXT_BOX = By.xpath("//label[contains(text(),'End Date')]/following-sibling::div//input");
    private static final By Description_TEXT_BOX = By.xpath("//input[@name='Description']");



   private static final By SALES_REP_TEXT_BOX = By.xpath("//label[contains(text(),'Sales Rep')]/following-sibling::div//input[@placeholder='Select a User']");
   private static final By BILL_TO_CONTACT_TEXT_BOX = By.xpath("//label[contains(text(),'Bill To Contact')]/following-sibling::div//input[@placeholder='Select a Contact']");
   private static final By SOLD_TO_CONTACT_TEXT_BOX = By.xpath("//label[contains(text(),'Sold To Contact')]/following-sibling::div//input[@placeholder='Select a Contact']");
   private static final By PO_DATE_TEXT_BOX = By.xpath("//label[contains(text(),'PO Date')]/following-sibling::div//input");
   private static final By PO_NUMBER_TEXT_BOX = By.xpath("//label[contains(text(),'PO Number')]/following-sibling::input");
   private static final By SAVE_AND_NEXT_BUTTON = By.xpath("//button[contains(text(),'Save And Next')]");

//Dynamic one

    //li[@role='presentation']//div[contains(text(),'"+accountname+"')]

    public BFOCreateNewServiceMaintenanceContractPageObjects clickOnNewButton(){
        $(New_Button).shouldBe(visible,enabled).click();
        return this;
    }
    public BFOCreateNewServiceMaintenanceContractPageObjects setContractRecordNumberTextBox(String value){
        $(CONTRACT_RECORD_NUMBER_TEXTBOX).shouldBe(visible,enabled).setValue(value);
        return this;
    }
    public BFOCreateNewServiceMaintenanceContractPageObjects setSoldToAccountTextBox(String account){

        $(SOLD_TO_ACCOUNT_TEXT_BOX).shouldBe(visible,enabled).setValue(account.split(":")[0]);
        $x("//li[@role='presentation']//div[contains(text(),'"+account.split(":")[1]+"')]").shouldBe(visible,interactable,enabled).click();
        Selenide.sleep(5000);
        return this;
    }
    public BFOCreateNewServiceMaintenanceContractPageObjects setMainInstalledAtAccountTextBox(String account){
        $(MAIN_INSTALLED_AT_ACCOUNT_TEXT_BOX).shouldBe(visible,enabled).setValue(account.split(":")[0]);
        if (!$$x("//div[contains(@class,'slds-lookup__menu')]//*[contains(text(),'"+account.split(":")[1]+"')]/following-sibling::*").isEmpty()){
            $x("//div[contains(@class,'slds-lookup__menu')]//*[contains(text(),'"+account.split(":")[1]+"')]/following-sibling::*[normalize-space()]").click();
        }
        else {
            $$x("//div[contains(@class,'slds-lookup__menu')]//*[contains(text(),'"+account.split(":")[1]+"')]/following-sibling::*").get(0).click();
        }
        return this;
    }
    public BFOCreateNewServiceMaintenanceContractPageObjects setMainInstalledAtContactTextBox(String contact){
        $(MAIN_INSTALLED_AT_CONTACT_TEXT_BOX).shouldBe(visible,enabled).setValue(contact.split(":")[0]);
        $x("//li[@role='presentation']//div[contains(text(),'"+contact.split(":")[1]+"')]").shouldBe(visible,interactable,enabled).click();
        return this;
    }
    public BFOCreateNewServiceMaintenanceContractPageObjects setBillToAccountTextBox(String account){
        $(BILL_TO_ACCOUNT_TEXT_BOX).shouldBe(visible,enabled).setValue(account.split(":")[0]);
        if (!$$x("//div[contains(@class,'slds-lookup__menu')]//*[contains(text(),'"+account.split(":")[1]+"')]/following-sibling::*").isEmpty()){
            $x("//div[contains(@class,'slds-lookup__menu')]//*[contains(text(),'"+account.split(":")[1]+"')]/following-sibling::*[normalize-space()]").click();
        }
        else {
            $$x("//div[contains(@class,'slds-lookup__menu')]//*[contains(text(),'"+account.split(":")[1]+"')]/following-sibling::*").get(0).click();
        }
        return this;
    }
    public BFOCreateNewServiceMaintenanceContractPageObjects setRemoteServiceContactTextBox(String contact){
        $(REMOTE_SERVICE_CONTACT_TEXT_BOX).shouldBe(visible,enabled).setValue(contact.split(":")[0]);
        $x("//li[@role='presentation']//div[contains(text(),'"+contact.split(":")[1]+"')]").shouldBe(visible,interactable,enabled).click();
        return this;
    }
    public BFOCreateNewServiceMaintenanceContractPageObjects setStartDateTextBox(String date){
        if (date.isEmpty()){
            LocalDate today = LocalDate.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            date = today.format(formatter);
        }
        $(START_DATE_TEXT_BOX).shouldBe(visible,enabled).setValue(date);
        return this;
    }
    public BFOCreateNewServiceMaintenanceContractPageObjects setEndDateTextBox(String date){
        if (date.isEmpty()){
            LocalDate nextYear = LocalDate.now().plusYears(1);
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            date = nextYear.format(formatter);
        }
        $(END_DATE_TEXT_BOX).shouldBe(visible,enabled).setValue(date);
        return this;
    }



}

