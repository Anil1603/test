package bfs.pages.bfo.PageObjects;

import com.codeborne.selenide.ElementsCollection;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.*;

public class BFOServiceLinePageObjects {
    private static  final String SEARCH_PLACEHOLDER_TEXTBOX = "//input[@id='SearchString']";
    private static final String GO_BUTTON = "//button[contains(text(),'Go')]";
    private static final String SKU_WITH_SERVICE_PLAN_CHECKBOX = "//span[@class='slds-checkbox_faux']";
    private static final String PRODUCT_NAME_CHECKBOX = "(//a[contains(text(),'FSMASPPLU')])[2]/../..//label/span[@class='slds-checkbox--faux']";
    private static final String QUANTITY_TEXTBOX = "(//span[contains(text(),'Quantity')]/../../../../following-sibling::tbody//input)[7]";
    private static final String CONTRACT_PRICE_TEXTBOX = "//div[contains(@class,'cLCMP_FSServiceLineCreation')]//table//*[contains(text(),'Contract Price')]/../../../../../tbody//tr//td[7]//input";
    private static final String DESCRIPTION_TEXTBOX = " //div[contains(@class,'cLCMP_FSServiceLineCreation')]//table//*[contains(text(),'Description')]/../../../../../tbody//tr//td[9]//input";
    private static final String SAVE_AND_NEXT_BUTTON = "//button[contains(text(),'Save And Next')]";

    public BFOServiceLinePageObjects setProductNameOnSearchPlaceHolderField(String productName){
        $(By.xpath(SEARCH_PLACEHOLDER_TEXTBOX)).shouldBe(visible,enabled).setValue(productName);
        return this;
    }
    public BFOServiceLinePageObjects clickOnGoButton(){
        $(By.xpath(GO_BUTTON)).shouldBe(visible,enabled).click();
        return this;
    }
    public BFOServiceLinePageObjects clickOnSkuWithServicePlanCheckBox(){
        $(By.xpath(SKU_WITH_SERVICE_PLAN_CHECKBOX)).shouldBe(visible,enabled).click();
        return this;
    }
    public BFOServiceLinePageObjects clickOnProductNameCheckBox(String productName){
        String CHECKBOX = "//a[contains(text(),'"+productName+"')]/parent::td/preceding-sibling::th//span[@class='slds-checkbox--faux']";
        $x(CHECKBOX).shouldBe(visible,enabled).click();
        return this;
    }
    public BFOServiceLinePageObjects setQuantityInTextBox(String quantity){
        /*
        String QUANTITY_TEXTBOX = "//span[contains(text(),'"+quantity.split(":")[0]+"')]/ancestor::thead/following-sibling::tbody//div[@class='slds-form-element__control slds-grow']//input[@required]";
        $x(QUANTITY_TEXTBOX).shouldBe(visible,enabled).setValue(quantity.split(":")[1]);
        */
        $(By.xpath(QUANTITY_TEXTBOX)).shouldBe(visible,enabled).setValue(quantity);
        return this;
    }
    public BFOServiceLinePageObjects setContractPriceInTextBox(String headerName, String contractPrice){
        /*
        String CONTRACT_PRICE_TEXTBOX = "//span[contains(text(),'"+contractPrice.split(":")[0]+"')]/ancestor::thead/following-sibling::tbody//div[@class='slds-form-element__control slds-grow']//input[[@id='input-586']";
        $x(CONTRACT_PRICE_TEXTBOX).shouldBe(visible,enabled).setValue(contractPrice.split(":")[1]);
        */
      //  $(By.xpath(CONTRACT_PRICE_TEXTBOX)).shouldBe(visible,enabled).setValue(contractPrice);
        setValueByHeader(headerName, contractPrice);
        return this;
    }
    public BFOServiceLinePageObjects setDescriptionInTextBox(String headerName,String description){
        /*
        String DESCRIPTION_TEXTBOX = "//span[contains(text(),'"+description.split(":")[0]+"')]/ancestor::thead/following-sibling::tbody//div[@class='slds-form-element__control slds-grow']//input[@id='input-587']";
        $x(DESCRIPTION_TEXTBOX).shouldBe(visible,enabled).setValue(description.split(":")[1]);
        */
      //  $(By.xpath(DESCRIPTION_TEXTBOX)).shouldBe(visible,enabled).setValue(description);
        setValueByHeader(headerName, description);
        return this;
    }
 public BFOServiceLinePageObjects clickOnSaveAndNextButton(){
        $(By.xpath(SAVE_AND_NEXT_BUTTON)).shouldBe(visible,enabled).click();
        return this;
    }

    public void setProuctDeatilsOnServiceLine(String fieldName,String value){
        switch (fieldName.toLowerCase()) {
            case "quantity" ->
                    setQuantityInTextBox(value);
            case "contract price" ->
                    setContractPriceInTextBox(value.split(":")[0], value.split(":")[1]);
            case "description"  ->
                      setDescriptionInTextBox(value.split(":")[0], value.split(":")[1]);
            default -> throw new RuntimeException("Not implemented for " + fieldName);

        }
    }

    private static final String SKU_COMM_REF_LOCATOR = "//*[contains(text(),'SKU/COMM REF')]/../../../../tr//th//a";
    private static final String QUANTITY_TEXTBOX_LOCATOR_TEMPLATE = "//div[contains(@class,'cLCMP_FSServiceLineCreation')]//table//*[contains(text(),'Quantity')]/../../../../../tbody//tr//td[%d]//input";

    public Map<String, Integer> getHeaderIndex() {
        Map<String, Integer> headerIndexMap = new HashMap<>();
        ElementsCollection elements = $$(By.xpath(SKU_COMM_REF_LOCATOR));
        for (int i = 0; i < elements.size(); i++) {
            String headerText = elements.get(i).getText().trim().replace("Sort by:\n", "");
            headerIndexMap.put(headerText, i + 1); // Store index as 1-based
        }
      //  System.out.println("Header Index Map: "+headerIndexMap);
        return headerIndexMap;

    }
    public BFOServiceLinePageObjects setValueByHeader(String headerName, String value) {
        Map<String, Integer> headerIndexMap = getHeaderIndex();
       if (headerIndexMap.containsKey(headerName)) {
            int index = headerIndexMap.get(headerName);
            String fieldLocator = String.format(QUANTITY_TEXTBOX_LOCATOR_TEMPLATE, index);
            $(By.xpath(fieldLocator)).shouldBe(visible, enabled).setValue(value);
        //    System.out.println("Field Locator: "+fieldLocator);
        } else {
            throw new RuntimeException("Header not found: " + headerName);
          //  System.out.println("Header not found: " + headerName);
        }
        return this;
    }


/*
    public class BFOServiceLinePageObjects {
        private static final String SKU_COMM_REF_LOCATOR = "//*[contains(text(),'SKU/COMM REF')]/../../../../tr//th//a";
        private static final String QUANTITY_TEXTBOX_LOCATOR_TEMPLATE = "//div[contains(@class,'cLCMP_FSServiceLineCreation')]//table//*[contains(text(),'Quantity')]/../../../../../tbody//tr//td[%d]//input";

        public Map<String, Integer> getSkuCommRefValues() {
            Map<String, Integer> skuCommRefMap = new HashMap<>();
            List<WebElement> elements = $$(By.xpath(SKU_COMM_REF_LOCATOR));
            for (int i = 0; i < elements.size(); i++) {
                skuCommRefMap.put(elements.get(i).getText(), i + 1); // Store index as 1-based
            }
            return skuCommRefMap;
        }

        public bfs.pages.bfo.PageObjects.BFOServiceLinePageObjects setQuantityBySkuCommRef(String skuCommRef, String quantity) {
            Map<String, Integer> skuCommRefMap = getSkuCommRefValues();
            if (skuCommRefMap.containsKey(skuCommRef)) {
                int index = skuCommRefMap.get(skuCommRef);
                String quantityLocator = String.format(QUANTITY_TEXTBOX_LOCATOR_TEMPLATE, index);
                $(By.xpath(quantityLocator)).shouldBe(visible, enabled).setValue(quantity);
            }
            return this;
        }
    }

*/


}
