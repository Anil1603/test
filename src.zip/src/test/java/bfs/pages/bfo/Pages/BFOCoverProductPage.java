package bfs.pages.bfo.Pages;

import bfs.pages.bfo.PageObjects.BFOCoverProductPageObjetcs;

public class BFOCoverProductPage {
    public void addCoverProduct(String productName) {
        BFOCoverProductPageObjetcs coverProductPageObjetcs = new BFOCoverProductPageObjetcs();
        coverProductPageObjetcs.clickOnProductCheckBox(productName)
                .clickOnAddCoverProductButton();
    }
}
