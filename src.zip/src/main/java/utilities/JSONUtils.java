package utilities;
import io.cucumber.core.internal.com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

public class JSONUtils {

	@SuppressWarnings("unchecked")
	public static String getPassword(String username, String filename) {
		HashMap<String, Object> map = null;
		try {
			map = new ObjectMapper().readValue(
					Paths.get(System.getProperty("user.dir") + "/TestData/" + filename).toFile(), HashMap.class);
			if (map.get(username) == null) {
				System.out.println("Password is not available for " + username);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return map.get(username).toString();
	}
	
	@SuppressWarnings("unchecked")
	public static String getData(String key, String filename) {
		HashMap<String, Object> map = null;
		try {
			map = new ObjectMapper().readValue(
					Paths.get(System.getProperty("user.dir") + "/TestData/" + filename).toFile(), HashMap.class);
			if (map.get(key) == null) {
				System.out.println("Password is not available for " + key);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return map.get(key).toString();
	}

	// Pass Raw Json Filename and get value while Passing Key
	@SuppressWarnings("unchecked")
	public static String getValueFromRawJsonFile(String key, String filepath, String filename) {
		HashMap<String, Object> map = null;
		try {
			map = new ObjectMapper().readValue(Paths.get(System.getProperty("user.dir") + filepath + filename).toFile(),
					HashMap.class);
			if (map.get(key) == null) {
				System.out.println("Value is not available for " + key);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return map.get(key).toString();
	}



	/*public static void main(String[] args)
			throws JsonProcessingException, ClassNotFoundException, InstantiationException, IllegalAccessException {
		Xls_Reader xls = new Xls_Reader("./customers.xlsx");
		Map<String, Map<String, String>> data = TestUtil.convertExcelDataToHashMap(xls, "Customers");
		writeObjects2JsonFile(data, "customers.json");
	}*/

	/**
	 * Convert Java Objects to JSON File
	 * @param data
	 * @param pathFile
	 */
	public static void writeObjects2JsonFile(Map<String, Map<String, String>> data, String pathFile) {
		ObjectMapper mapper = new ObjectMapper();

		File file = new File(pathFile);
		try {
			// Serialize Java object info JSON file.
			mapper.writeValue(file, data);
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("failed to write hashmap to json file.");
		}
	}

	public static void writeObjects2JsonFile1(Map<String, String> data, String pathFile) {
		ObjectMapper mapper = new ObjectMapper();

		File file = new File(pathFile);
		try {
			// Serialize Java object info JSON file.
			mapper.writeValue(file, data);
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("failed to write hashmap to json file.");
		}
		
	}

}
