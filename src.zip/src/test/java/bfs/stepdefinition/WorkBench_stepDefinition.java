package bfs.stepdefinition;

import bfs.pages.workbench.WorkBench_HomePage;
import io.cucumber.java.en.And;

public class WorkBench_stepDefinition {

    @And("I navigated to {string} page from {string} tab")
    public void iNavigatedToPageFromTab(String pageName, String tabName) {
        new WorkBench_HomePage().navigatetospacificpage(tabName, pageName);
    }

    @And("I execute {string} with {string} records to download work order details in {string} format")
    public void iExecuteQueryWithRecordsToDownloadWorkOrderDetailsInFormat(String queryName, String recordCount, String format) {
        new WorkBench_HomePage().executeQueryAndDownloadResults(queryName, recordCount, format);
    }
}
