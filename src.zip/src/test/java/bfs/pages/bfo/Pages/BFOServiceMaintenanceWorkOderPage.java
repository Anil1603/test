package bfs.pages.bfo.Pages;

import bfs.pages.bfo.PageObjects.BFOServiceMaintenanceWorkOrderPageObjects;
import bfs.pages.bfo.PageObjects.BFOValidateContractPageObjects;

public class BFOServiceMaintenanceWorkOderPage {
 public void setMandatoryDetailsForWorkOrder(String fieldName,String value){
     BFOServiceMaintenanceWorkOrderPageObjects workOrderPageObjects = new BFOServiceMaintenanceWorkOrderPageObjects();
     BFOValidateContractPageObjects validateContractPageObjects = new BFOValidateContractPageObjects();
     switch (fieldName.toLowerCase()){
         case "work order name" -> workOrderPageObjects.setWorkOrderName(value);
         case "work order reason"-> workOrderPageObjects.setWorkOrderReason(value);
         case "customer requested date"-> workOrderPageObjects.setCustomerRequestedDate(value);
         case "location"-> workOrderPageObjects.setLocation(value);
         case "country of back office"-> workOrderPageObjects.setCountryOfBackOffice(value);
         case "back office system" -> workOrderPageObjects.setBackOfficeSystem(value);
         case "mip flag" -> workOrderPageObjects.clickOnMIPFlag();
         default -> throw new RuntimeException("Not implemented for " + fieldName);
     }
 }
}
