package bfs.pages.bfo.PageObjects;

import bfs.CONSTANTS;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.Selenide;
import org.junit.Assert;

import java.time.Duration;
import java.util.HashMap;
import java.util.LinkedHashMap;

import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.*;
import static java.lang.Thread.sleep;

public class BFOVerifyWorkOrderStatus {
    private static final String STATUS_TEXT = "//span[@class='current slds-path__stage']/..//span[@class='title slds-path__title']";
/*
    public void checkWorkOrderStatus(String status){
        switchTo().defaultContent();
        int maxAttempts = 10;
        int attempts = 0;
        while (attempts < maxAttempts) {
            if ($x(STATUS_TEXT).shouldBe(visible).getText().contains(status)) {
                Assert.assertTrue($x(STATUS_TEXT).shouldBe(visible).getText().contains(status));
                CONSTANTS.captureScreen = true;
                return;
            }
            refresh();
            Selenide.sleep(10000);
            attempts++;
            }

        Assert.fail("Status did not match after " + maxAttempts + " attempts");
    }
*/

  //   @Ashutosh : I added with Do - While , please use this and test it. and let me know if it works or not.
  public void checkWorkOrderStatus(String status) {
     switchTo().defaultContent();
     int maxAttempts = 10;
     int attempts = 0;
     boolean statusFound = false;

     do {
        if ($x(STATUS_TEXT).shouldBe(visible).getText().contains(status)) {
           Assert.assertTrue($x(STATUS_TEXT).shouldBe(visible).getText().contains(status));
           CONSTANTS.captureScreen = true;
           statusFound = true;
           break;
        }
        refresh();
        Selenide.sleep(15000);
        attempts++;
     } while (attempts < maxAttempts && !statusFound);

     if (!statusFound) {
        Assert.fail("Status did not match after " + maxAttempts + " attempts");
     }
  }
     public String getWorkOrderNumber(){
            ElementsCollection workOrderNumber = $$x("//*[contains(text(),'Work Order')]/../../parent::h1/*/*[@slot='primaryField']");
            String wo = workOrderNumber.get(0).getText();
            System.out.println("Work Order Number is: "+wo);
        return wo;
     }

}
