Feature: Recurring assignment of Work order to FSR.
  As a user
  I want to navigate to the application and Assign Recurring assignment of Work order to FSR

  Scenario Outline: Recurring assignment of Work order to FSR
    Given I work in application "BFO" and environment "UAT"
    And I login to "BFO" as user "coordinator-1550@bridge-fo.com.uatbfo26"
    When I navigate to "SE - Services Lightning" from app launcher
    And I wait for "10" seconds
    And I navigate to "Work Orders" from app launcher
    And I click on bfo button "New"
    And I fill work order details for creating new work order from Work Order Page:
      | Field Name                | Field Value                         |
      | Select Record Type        | Standalone Work Order               |
      | Installed At Account      | 0001340233:Ampcontrol (QLD) Pty Ltd |
      | Location                  | 0045144542:Ampcontrol QLD Pty Ltd   |
      | Work Order Type           | Repair                              |
      | Contact                   | chandra.vamsi kumar                 |
      | Customer Requested Date   | today                               |
      | Country of Back Office    | Australia                           |
      | Back Office System        | SAP Bridge AP                       |
      | Work Order Category       | Onsite                              |
      | Services Business Unit    | POWER SYSTEMS                       |
      | Is Billable               | Yes                                 |
      | Customer Reference Number | 1234                                |
      | Priority                  | Normal-Medium                       |
      | Service Commercial Ref    | QWPFSRVPLNNSGEN                     |
      | Work Order Reason         | Testing                             |
      | Work Order Name           | Testing                             |
      | Sold To Account           | 0001340233:Ampcontrol (QLD) Pty Ltd |
    Then user should be able to see the work order number and memorize work order number for recurring Assignment
    And I should see the work order status as "New" in work order page
    And I click on "Create/Update Work Order" button from SFM Tab
    And I check the message "SUCCESS : INITIATED SYNC" on sync window
    And I click on "Ok" button on sync window
    Then I should see the work order status as "Unscheduled" in work order page
    And I wait for back Office reference number
    And I check the "First Synchronization date" and "Last Synchronization date" in work order page
    And I check the "Synchronization Log" as "Work Order CREATED in Back Office" in work order page
    And I add work order in Service Board as Recurring assignment
      | FSR Name | Frequency | Frequency Unit | Number of Days From today for end date | Skip Weekend |
      | FSR-1660 | 1         | Days           | 5                                      | true         |
    Then I should see the work order status as "Scheduled" in work order page
    And I check the "Synchronization Log" as "Work Order CREATED in Back Office" in work order page
    Then Change work order status to customer confirmed
    Then I should see the work order status as "Customer Confirmed" in work order page
    And I logout from bfo application

    Examples:
      | Tab Name    | Parts Order Type | Ship From Plant |
      | Parts Order | Ship only        | AU10            |