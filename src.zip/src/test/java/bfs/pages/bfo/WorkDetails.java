package bfs.pages.bfo;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import com.codeborne.selenide.WebDriverRunner;
import org.openqa.selenium.interactions.Actions;
import java.util.*;
import static bfs.pages.bfo.ApplicationCommonMethods.*;
import static com.codeborne.selenide.Condition.enabled;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.*;

public class WorkDetails {

    // XPaths for elements
    private static final String WORK_DETAIL_NUMBER = "//a[@data-label='WORK DETAIL']";
    private static final String LINK_UPDATE_WORK_ORDER = "//span[text()='%s']/parent::a";
    private static final String LINK_PLANNED_PARTS = "//a[text()='%s']/parent::span/parent::li";
    private static final String DETAILS_BUTTON_LOCATOR = "//div[text()='%s']/../parent::div/preceding-sibling::div/button[contains(@class, 'DetailsDataGrid')]";
    private static final String EDIT_LINK_LOCATOR = "//span[text()='Edit']/parent::a";
    private static final String INSTALLED_QTY = "//label[text()='%s']/parent::div/div/div/input";
    private static final String SPLIT_WO_FRAME = "//iframe[@title='Service Delivery']";
    private static final String UPDATE_PLANNED_PARTS = "//span[text()='Update']/parent::button";
    private static final String SAVE_PLANNED_PARTS = "//span[text()='Save']/parent::button";


    public List<String> getWorkDetailTitles() {
        waitForGivenTime(5000);
        List<String> titles = new ArrayList<>();

        for (SelenideElement element : $$x(WORK_DETAIL_NUMBER)) {
            if (element.exists() && element.isDisplayed()) { // Ensure element exists and is visible
                element.shouldBe(Condition.visible.because("WORK DETAIL link should be visible"))
                        .scrollIntoView("{block: \"center\"}");

                String title = element.getAttribute("title");
                if (title == null || title.isEmpty()) {
                    throw new RuntimeException("Title attribute is missing or empty for WORK DETAIL link.");
                }
                titles.add(title);
            }
        }

        System.out.println("WORK DETAIL Titles: " + titles);
        return titles;
    }

    public WorkDetails clickUpdateWorkOrder(String labelText) {
        try {
            waitForGivenTime(5000);
            String xpath = String.format(LINK_UPDATE_WORK_ORDER, labelText);
            SelenideElement newWorkOrder = $x(xpath);
            waitForElementToBeVisibleAndClickable(newWorkOrder);
            newWorkOrder.scrollIntoView("{block: \"center\"}");
            Actions actions = new Actions(WebDriverRunner.getWebDriver());
            actions.moveToElement(newWorkOrder, 0, 0).click().perform();

            waitForGivenTime(8000);
        } catch (Exception e) {
            ApplicationCommonMethods.handleException("Error clicking on New Work Order", e);
        }
        return this;

    }

    public WorkDetails clickPlannedPartsLink(String linkText) {
        ApplicationCommonMethods.switchToFrame(SPLIT_WO_FRAME);
        waitForGivenTime(15000);
        String xpath = String.format(LINK_PLANNED_PARTS, linkText);

        SelenideElement linkElement = $x(xpath)
                .shouldBe(Condition.visible.because(linkText + " link should be visible"))
                .scrollIntoView("{block: \"center\"}");

        linkElement.click();
        System.out.println("Clicked on: " + linkText);
        return this;
    }


    public WorkDetails clickDetailsButton(String lineNumber) {
        waitForGivenTime(5000);
        String dynamicLocator = String.format(DETAILS_BUTTON_LOCATOR, lineNumber);

        $x(dynamicLocator).scrollIntoView("{block: \"center\"}").shouldBe(visible, enabled).click();
        return this;
    }

    public WorkDetails clickEditLink() {
        $x(EDIT_LINK_LOCATOR).shouldBe(visible, enabled).click();
        return this;
    }

    public WorkDetails enterInstalledQuantity(String labelText, String quantity) {
        waitForGivenTime(5000);
        String xpath = String.format(INSTALLED_QTY, labelText);

        SelenideElement inputField = $x(xpath)
                .shouldBe(Condition.visible.because(labelText + " input field should be visible"))
                .scrollIntoView("{block: \"center\"}");
        inputField.clear();
        sleep(2000);
        inputField.setValue(quantity);
        System.out.println("Entered value '" + quantity + "' in: " + labelText);
        return this;
    }

    public WorkDetails clickUpdatePlannedParts() {
        try {
            SelenideElement saveWorkOrder = $x(UPDATE_PLANNED_PARTS);
            waitForElementToBeVisibleAndClickable(saveWorkOrder);
            saveWorkOrder.click();
            waitForGivenTime(15000);
        } catch (Exception e) {
            handleException("Error clicking on Continue Work Order", e);
        }
        return this;
    }

    public WorkDetails clickSavePlannedParts() {
        try {
            SelenideElement saveWorkOrder = $x(SAVE_PLANNED_PARTS);
            waitForElementToBeVisibleAndClickable(saveWorkOrder);
            saveWorkOrder.click();
            waitForGivenTime(15000);
            switchTo().defaultContent();

        } catch (Exception e) {
            handleException("Error clicking on Continue Work Order", e);
        }
        return this;
    }

}
