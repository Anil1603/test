package bfs.pages.bfo.PageObjects;

import bfs.CONSTANTS;
import bfs.pages.BasePage;
import com.codeborne.selenide.ClickOptions;
import com.codeborne.selenide.Selenide;
import groovy.lang.GString;
import org.junit.Assert;
import org.openqa.selenium.By;

import java.time.Duration;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.*;
import static com.codeborne.selenide.Selenide.$;

public class BFOSyncPageObjetcs {
    private static final String FIRST_LEGACY_ID_FROM_SOLD_TO_ACCOUNT = "//c-data-view[@main-heading='Sold to Account']//span[contains(text(),'Select Item 1')]/parent::label";
    private static final String SECOND_LEGACY_ID_FROM_SOLD_TO_ACCOUNT = "//c-data-view[@main-heading='Sold to Account']//span[contains(text(),'Select Item 2')]/parent::label";
    private static final String FIRST_LEGACY_ID_FROM_INSTALLED_AT = "//c-data-view[@main-heading='Installed At']//span[contains(text(),'Select Item 1')]/parent::label";
    private  static final String SECOND_LEGACY_ID_FROM_INSTALLED_AT = "//c-data-view[@main-heading='Installed At']//span[contains(text(),'Select Item 2')]/parent::label";
    private static final String SYNC_BUTTON = "//button[@title='Sync']";
    private static final String SYNC_PAGE_OK_Button = "//button[@title='OK']";
    private static final String SYNC_PAGE_MESSAGE ="//h2[@class='slds-text-title_caps slds-line-height_reset']";
    private static final String first_cosr_center_radio_button = "//c-data-view//span[contains(text(),'Select Item 2')]/parent::label";





    public BFOSyncPageObjetcs selectFirstLegacyIdRadioButtonFromSoldToAccount(){
        $x(FIRST_LEGACY_ID_FROM_SOLD_TO_ACCOUNT).shouldBe(visible,enabled).click();
        return this;
    }
    public BFOSyncPageObjetcs selectSecondLegacyIdRadioButtonFromSoldToAccount(){
        $x(SECOND_LEGACY_ID_FROM_SOLD_TO_ACCOUNT).shouldBe(visible,enabled).click();
        return this;
    }
    public BFOSyncPageObjetcs selectFirstLegacyIdRadioButtonFromInstalledAt(){
        $x(FIRST_LEGACY_ID_FROM_INSTALLED_AT).shouldBe(visible,enabled).click();
        return this;
    }
    public BFOSyncPageObjetcs selectSecondLegacyIdRadioButtonFromInstalledAt(){
        $x(SECOND_LEGACY_ID_FROM_INSTALLED_AT).shouldBe(visible,enabled).click();
        return this;
    }
    public BFOSyncPageObjetcs clickOnSyncButton(){
        $x(SYNC_BUTTON).shouldBe(visible,enabled).click();
        return this;
    }
    public BFOSyncPageObjetcs clickOnSyncPageOkButton(){
       BasePage.highLightElement($x(SYNC_PAGE_OK_Button).shouldBe(visible,enabled,interactable));
        Selenide.sleep(4000);
     //   executeJavaScript("arguments[0].click();", $(By.xpath(SYNC_PAGE_OK_Button)));
        $x(SYNC_PAGE_OK_Button).shouldBe(visible,enabled,interactable).click();
     //  actions().moveToElement($x(SYNC_PAGE_OK_Button).shouldBe(visible, enabled)).click().perform();
        return this;
    }
    public void checkSyncPageMessage(String message){
        switchTo().window(1);
        String textvalue = $x(SYNC_PAGE_MESSAGE).shouldBe(visible).getText();
        System.out.println("textvalue: "+textvalue);
        Selenide.sleep(3000);
        Assert.assertTrue($x(SYNC_PAGE_MESSAGE).shouldBe(visible).getText().contains(message));
        CONSTANTS.captureScreen=true;
    }

    public void selectFirstCosrCenterRadioButton(String message){
        String textValue= $x("//c-data-view//span[contains(text(),'Select Item 2')]//ancestor::tr//th").shouldBe(visible,Duration.ofSeconds(160)).getAttribute("data-cell-value");
        System.out.println("textValue: "+textValue);
        $x(first_cosr_center_radio_button).shouldBe(visible,enabled).click();
       // Assert.assertTrue($x(SYNC_PAGE_MESSAGE).shouldBe(visible).getText().contains(message));
        CONSTANTS.captureScreen=true;
    }
}
