Feature: create work order in sap and verify in bfs.
  As a user
  I want to navigate to the sap application and create work order and memorize work order number
  So that I can verify work order in bfs

  Scenario Outline: contact creation in sap ad verify in bfs
      #SAP
    Given I work in application "SAP"
    When I navigate to "(Bridge) ECC 6.0 SSO - QRH - Pre-Production APAC"
    And I create work order
    And I log out sap
#
###    #bfs
    Given I work in application "BFO" and environment "UAT"
    And I login to "BFO" as user "coordinator-1660@bridge-fo.com.uatbfo26"
    And I search BFO Work Order
    Then user should be able to see the work order number and memorize work order number
    And bfs work order and sap work order should match
#    And I logout from bfo application
#

    Examples:
      | Menu Item      | Work Order       | Tab Name      | Parts Order Type | Ship From Plant | Product Name | Line Status | Shipped Qty | Work Details Tab     | Installed Quantity |
      | Search: Service/Maintenance Contracts    | WO-12264768     | Parts Order   | Ship only        | AU10            | 47053       | Received     | 1           |   Work Details       |  1                 |




