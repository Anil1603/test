package bfs.pages.servicemax.PageObjects;

import bfs.CONSTANTS;
import bfs.pages.bfo.ApplicationCommonMethods;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;
import com.codeborne.selenide.WebDriverRunner;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

import static com.codeborne.selenide.Condition.enabled;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.*;
import static bfs.pages.BasePage.highLightElement;

public class FSRResponseUpdateWorkOrderPageObjects {
    private static final String FSR_RESPONSE_DROPDOWN = "//input[@name='SVMXC__Dispatch_Response__c']";
    private static final String IS_RISK_ASSESSMENT_ATTACHED_DROPDOWN= "//input[@name='IsRiskAssessmentAttached__c']";
    private static final String NO_RISK_ASSESSMENT_REASON = "//input[@name='NoRiskAssessmentReason__c']";
    private static final String NO_RISK_ASSESSMENT_DETAILS = "//input[@name='NoRiskAssessmentDetails__c']";
    private static final String OPPERTUNITY_DETECTED_DROPDOWN= "//input[@name='OpportunityDetected__c']";
    private static final String WORK_PERFORMED_TEXTBOX= "//textarea[@name='SVMXC__Work_Performed__c']";
   //NEED TO GET O
    private static final String ADD_MY_TIME_BUTTON_OLD= "//button[@class='Button addChildlineButton slds-button Button--type-neutral slds-button--neutral slds-button_neutral slds-button--x-small']";
    private static final String ADD_MY_TIME_BUTTON = "//button[text()='Add My Time']";
    //NEED TO GET O
    private static final String ACTIVITY_TYPE_DROPDOWN= "//input[@name='SVMXC__Activity_Type__c']";
    private static final String NUMBER_OF_RECORDS = "(//div[@class='DetailsDataGrid_Panel']//label[@class='Label slds-form-element__label'])[1]";
    //NEED TO GET 0
    private static final String DROPDOWN_button= "//button[@class='Button Dropdown__button DetailsDataGrid_MenuButton slds-button Button--type-icon-border slds-button--icon-border slds-button_icon-border slds-button--icon-x-small']";
    //TO GET TIME VALUE VALUE using get attribute title
    private static final String CUSTOMER_END_TIME_VALUE="//label[contains(text(),'Customer End Date and Time')]/following-sibling::div//div[@class='InputWrapper slds-size--block InputWrapper__has-icon slds-input-has-icon slds-input-has-icon--right']";
    private static final String CUSTOMER_START_TIME_VALUE = "//label[contains(text(),'Customer Start Date and Time')]/following-sibling::div//div[@class='InputWrapper slds-size--block InputWrapper__has-icon slds-input-has-icon slds-input-has-icon--right']";
   private static final String DATE_FIELD = "//ancestor::div[contains(@class,'Grid__item DateTimeInput--now')]//preceding-sibling::div//input[@class='Input slds-input']";

    // TO INPUT THE UPDATE TIME
    private static final String CUSTOMER_START_TIME_TEXTBOX = "//label[contains(text(),'Customer Start Date and Time')]/following-sibling::div//div[@class='InputWrapper slds-size--block InputWrapper__has-icon slds-input-has-icon slds-input-has-icon--right']/input";
    private static final String CUSTOMER_END_TIME_TEXTBOX =   "//label[contains(text(),'Customer End Date and Time')]/following-sibling::div//div[@class='InputWrapper slds-size--block InputWrapper__has-icon slds-input-has-icon slds-input-has-icon--right']/input";
    private static final String UPDATE_BUTTON= "//span[text()='Update']/parent::button";
    private static final String SAVE_BUTTON = "//span[text()='Save']/parent::button[@class='Button slds-button Button--type-brand slds-button--brand slds-button_brand slds-button--x-small']";
    private static final String WARNING_MESSAGE_POP_UP = "//h2[contains(text(),'Review the warning message')]";
    private static final String TIME_OVERLAP_ERROR_MESSAGE = "//div[contains(@class, 'Alert slds-notify slds-notify--alert slds-theme--error slds-theme--alert-texture')]//h2[@style='display: contents;']//div";
    private static final String ERROR_TEXT = "//div[@class='PopoverBody slds-popover__body']//span";
    private static final String CUSTOMER_START_DATE_TIME_DISPLAYED_UNDER_MY_TIME = "//div[contains(@class,'CustomerStartDateandTime')]//div[@class='slds-truncate']";//04/29/2025 5:41 AM
    private static final String CUSTOMER_END_DATE_TIME_DISPLAYED_UNDER_MY_TIME = "//div[contains(@class,'CustomerEndDateandTime')]//div[@class='slds-truncate']";
    private static final String SPINNER_POST_SAVE = "//div[@class='Spinner slds-spinner slds-spinner--large slds-spinner--brand']";
    private static final String FRAME_IN_UPDATE_WO_PAGE = "//iframe[@title='Service Delivery']";

    // CUSTOMER HOUR TYPES
    private static final String CUSTOMER_HOUR_TYPE_DROPDOWN = "//input[@name='CustomerHourType__c']";
    private static final String CUSTOMER_HOUR_TYPE_DROPDOWN_VALUES = "//label[text()='Customer Hour Type']//following-sibling::div//li//span[text()='%s']//ancestor::a";
    String[] values = {
            "Normal hours", "Out of Normal Hours", "Night Time",
            "Saturdays", "Sundays", "Weekend Nights",
            "Bank Holiday", "Major Holiday", "Weekend"
    };
    String[] errorMessages = {"Please ensure that Customer Start Date is before Customer End Date.","Please ensure that Start Date is before End Date."};



public FSRResponseUpdateWorkOrderPageObjects selectFSRResponse(String value) {
    switchTo().frame($x("//iframe[@title='Service Delivery']"));
    $x(FSR_RESPONSE_DROPDOWN).shouldBe(visible, enabled).click();
    $x("//span[@title='"+value+"']").shouldBe(visible, enabled).click();
    CONSTANTS.captureScreen = true;
    return this;
}
public FSRResponseUpdateWorkOrderPageObjects clickOnSaveButton(){
    Selenide.sleep(4000);
    $x(SAVE_BUTTON).shouldBe(visible,enabled).click();
    waitUntilSpinnerIsInvisible();
    Selenide.sleep(4000);
      return this;}

    public FSRResponseUpdateWorkOrderPageObjects handlingErrorWarningPostSaveInUpdateWOPage(){
        if (iSWarningMessageDisplayed()) {
            clickOnSaveButton();
        }
        while (isTimeOverlapErrorMessageDisplayed() || isErrorMessageDisplayed()) {
            clickOnDropdownButtonAndSelect("Edit")
                    .fetchCustomerStartAndEndTimeAndUpdate()
                    .clickOnUpdateButton()
                    .clickOnSaveButton();
        }
        if (iSWarningMessageDisplayed()) {
            clickOnSaveButton();
        }
        return this;
    }

    public boolean iSWarningMessageDisplayed() {
        return $x(WARNING_MESSAGE_POP_UP).isDisplayed();
    }

    public FSRResponseUpdateWorkOrderPageObjects waitUntilSpinnerIsInvisible() {

        int maxAttempts = 4;
        int attempts = 0;
        boolean statusFound = false;
        while (attempts < maxAttempts && !statusFound) {
            if ($$x(SPINNER_POST_SAVE).size() < 0) {
                statusFound = true;
            } else {
                Selenide.sleep(5000);
                attempts++;
            }
        }
        return this;
    }



    public FSRResponseUpdateWorkOrderPageObjects selectIsRiskAssessmentAttached(String value) {
    $x(IS_RISK_ASSESSMENT_ATTACHED_DROPDOWN).shouldBe(visible, enabled).scrollIntoView(false);
        $x(IS_RISK_ASSESSMENT_ATTACHED_DROPDOWN).shouldBe(visible, enabled).click();
        $x("//input[@name='IsRiskAssessmentAttached__c']/../following-sibling::div//span[@title='"+value+"']").shouldBe(visible, enabled).click();
        return this;
    }
    public FSRResponseUpdateWorkOrderPageObjects selectNoRiskAssessmentReason(String value) {
        $x(NO_RISK_ASSESSMENT_REASON).shouldBe(visible, enabled).click();
        $x("//input[@name='NoRiskAssessmentReason__c']/../following-sibling::div//span[@title='"+value+"']").shouldBe(visible, enabled).click();
        return this;
    }
    public FSRResponseUpdateWorkOrderPageObjects setNoRiskAssessmentDetails(String value) {
        $x(NO_RISK_ASSESSMENT_DETAILS).shouldBe(visible, enabled).setValue(value);
        return this;
    }
    public FSRResponseUpdateWorkOrderPageObjects selectOpportunityDetected(String value) {
        $x(OPPERTUNITY_DETECTED_DROPDOWN).shouldBe(visible, enabled).scrollIntoView(false);
        $x(OPPERTUNITY_DETECTED_DROPDOWN).shouldBe(visible, enabled).click();
        $x("//input[@name='OpportunityDetected__c']/../following-sibling::div//span[@title='"+value+"']").shouldBe(visible, enabled).click();
        return this;
    }

    public FSRResponseUpdateWorkOrderPageObjects setWorkPerformed(String value) {
        $x(WORK_PERFORMED_TEXTBOX).shouldBe(visible, enabled).setValue(value);
    //    executeJavaScript("arguments[0].innerText = arguments[1];", $x(WORK_PERFORMED_TEXTBOX), value);
        return this;
    }
    public FSRResponseUpdateWorkOrderPageObjects clickOnAddMyTimeButton_old() {
        $$x(ADD_MY_TIME_BUTTON).get(0).shouldBe(visible, enabled).click();
        return this;
    }

    public FSRResponseUpdateWorkOrderPageObjects clickOnAddMyTimeButton() {
        $x(ADD_MY_TIME_BUTTON).shouldBe(visible, enabled).scrollIntoView(false).click();
        return this;
    }
    public FSRResponseUpdateWorkOrderPageObjects selectActivityType(String value) {
        $x(ACTIVITY_TYPE_DROPDOWN).shouldBe(visible, enabled).click();
        $x("//input[@name='SVMXC__Activity_Type__c']/../following-sibling::div//span[@title='"+value+"']").shouldBe(visible, enabled).click();
        return this;
    }
    public FSRResponseUpdateWorkOrderPageObjects clickOnDropdownButtonAndSelect(String value) {
        $$x(DROPDOWN_button).get(0).shouldBe(visible, enabled).click();
        $x("//a[@class='Menu__item-link slds-truncate react-slds-menuitem']/span[@title='"+value+"']").shouldBe(visible, enabled).click();
        return this;
    }

    public FSRResponseUpdateWorkOrderPageObjects scrollIntoViewDropdwonButton() {
        $$x(DROPDOWN_button).get(0).scrollIntoView(false);
        return this;
    }

    public FSRResponseUpdateWorkOrderPageObjects switchToFrameinUpdateWOPage() {
        switchTo().frame($x(FRAME_IN_UPDATE_WO_PAGE));
        return this;
    }

    /*
    public FSRResponseUpdateWorkOrderPageObjects fetchCustomerEndTimeAndIncreaseByOneHour() {
        String time = $x(CUSTOMER_END_TIME_VALUE).getAttribute("title");
        System.out.println("Time is: " + time);
        String[] timeArray1 = time.split(":");
        if (timeArray1.length < 2) {
            throw new IllegalArgumentException("Unexpected time format: " + timeArray1[1]);
        }
        int hour = Integer.parseInt(timeArray1[0]);
        hour++;
        String newTime = hour + ":" + timeArray1[1];
        System.out.println("New Time is: " + newTime);
        Selenide.sleep(2000);
        $x(CUSTOMER_END_TIME_TEXTBOX).shouldBe(visible, enabled).setValue(newTime);
        return this;
    }
    */
//    public FSRResponseUpdateWorkOrderPageObjects fetchCustomerEndTimeAndIncreaseByOneHour() {
//        String time = $x(CUSTOMER_END_TIME_VALUE).getAttribute("title");
//        System.out.println("Time is: " + time);
//        String[] timeArray1 = time.split(":");
//        if (timeArray1.length < 2) {
//            throw new IllegalArgumentException("Unexpected time format: " + timeArray1[1]);
//        }
//        int hour = Integer.parseInt(timeArray1[0]);
//        hour++;
//        String newTime = String.format("%02d:%s", hour, timeArray1[1]);
//        System.out.println("New Time is: " + newTime);
//        Selenide.sleep(2000);
//        $x(CUSTOMER_END_TIME_TEXTBOX).shouldBe(visible, enabled).setValue(newTime);
//        return this;
//    }


    public FSRResponseUpdateWorkOrderPageObjects fetchCustomerEndTimeAndIncreaseByOneHour() {
        String time = $x(CUSTOMER_END_TIME_VALUE).getAttribute("title");
        System.out.println("Time is: " + time);

        String[] timeArray1 = time.split(":");
        if (timeArray1.length < 2) {
            throw new IllegalArgumentException("Unexpected time format: " + time);
        }

        int hour = Integer.parseInt(timeArray1[0]);
        hour++;

        // Handle overflow (e.g., 23 -> 0)
        if (hour == 24) {
            hour = 0;
        }

        String newTime = String.format("%d:%s", hour, timeArray1[1]);
        System.out.println("New Time is: " + newTime);

        Selenide.sleep(2000);
        $x(CUSTOMER_END_TIME_TEXTBOX).shouldBe(visible, enabled).setValue(newTime);

        return this;
    }


    public FSRResponseUpdateWorkOrderPageObjects setDate(String startOrEndTimeValue) {
        String actualdate = $x(startOrEndTimeValue + DATE_FIELD).getValue(); // 04/24/2025
        String reqdate = dateFormatterForTimeActivitiesForFSR(actualdate);
        SelenideElement dateField = $x(startOrEndTimeValue + DATE_FIELD).shouldBe(visible, enabled);
        executeJavaScript("arguments[0].value='';", dateField);
        dateField.shouldBe(visible, enabled).setValue(reqdate);
        return this;
    }

    public String setTime(LocalTime actualTime, int NumberOfHours, DateTimeFormatter formatter, String timeTextBox) {
        LocalTime reqTime = actualTime.plusHours(NumberOfHours);
        String newTime = reqTime.format(formatter);
        $x(timeTextBox).shouldBe(visible, enabled).setValue(newTime);
        CONSTANTS.captureScreen = true;
        return newTime;
    }

    public FSRResponseUpdateWorkOrderPageObjects fetchCustomerStartAndEndTimeAndUpdate() {
        String startTime = $x(CUSTOMER_START_TIME_VALUE).getAttribute("title");    // 11:00 AM // keeping as single method for both start time and end time

//        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("h:mm a", Locale.ENGLISH);

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm", Locale.ENGLISH);
        LocalTime actualStartTime = LocalTime.parse(startTime, formatter);

        if (actualStartTime.isAfter(LocalTime.of(17, 00))) {
            setDate(CUSTOMER_START_TIME_VALUE)
                    .setDate(CUSTOMER_END_TIME_VALUE);
            $x(CUSTOMER_START_TIME_TEXTBOX).shouldBe(visible, enabled).setValue("10:00 AM");
            $x(CUSTOMER_END_TIME_TEXTBOX).shouldBe(visible, enabled).setValue("11:00 AM");

        } else if (actualStartTime.isBefore(LocalTime.of(9, 59))) {
            $x(CUSTOMER_START_TIME_TEXTBOX).shouldBe(visible, enabled).setValue("10:00 AM");
            $x(CUSTOMER_END_TIME_TEXTBOX).shouldBe(visible, enabled).setValue("11:00 AM");
        } else {
            setTime(actualStartTime, 1, formatter, CUSTOMER_START_TIME_TEXTBOX);
            setTime(actualStartTime, 2, formatter, CUSTOMER_END_TIME_TEXTBOX); // check
        }

        CONSTANTS.captureScreen = true;
        return this;
    }

    public HashMap<String, String> updateTimeInMyTime(int increaseStartTimeByHrs, int increaseEndTimeByHrs) {
        HashMap<String, String> updatedTimes = new HashMap<>();
        String startTime = $x(CUSTOMER_START_TIME_VALUE).getAttribute("title");
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("h:mm a", Locale.ENGLISH);
        LocalTime actualStartTime = LocalTime.parse(startTime, formatter);
        updatedTimes.put("startTime", setTime(actualStartTime, increaseStartTimeByHrs, formatter, CUSTOMER_START_TIME_TEXTBOX));
        updatedTimes.put("endTime", setTime(actualStartTime, increaseEndTimeByHrs, formatter, CUSTOMER_END_TIME_TEXTBOX));
        return updatedTimes;
    }

    public String startTimeDisplayedUnderMyTime() {
        return $x(CUSTOMER_START_DATE_TIME_DISPLAYED_UNDER_MY_TIME).shouldBe(visible, enabled).getText();
    }

    public String endTimeDisplayedUnderMyTime() {
        return $x(CUSTOMER_END_DATE_TIME_DISPLAYED_UNDER_MY_TIME).shouldBe(visible, enabled).getText();
    }

    public FSRResponseUpdateWorkOrderPageObjects deleteTimeRowUnderMyTimeInFSR() {
        clickOnDropdownButtonAndSelect("Delete"); // clickSaveButton();
        return this;
    }

    public int numberOfRecordsUnderMyTime() {
        return Integer.valueOf($x(NUMBER_OF_RECORDS).shouldBe(visible, enabled).getText().split(" ")[0]);
    }

    public String dateFormatterForTimeActivitiesForFSR(String actualDate) {
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.ENGLISH);
        LocalDate date = LocalDate.parse(actualDate, dateFormatter);
        LocalDate requiredDate = date.plusDays(1);
        if (requiredDate.getDayOfWeek().equals(DayOfWeek.SATURDAY)) {
            requiredDate = requiredDate.plusDays(2);
        } else if (requiredDate.getDayOfWeek().equals(DayOfWeek.SUNDAY)) {
            requiredDate = requiredDate.plusDays(1);
        }
        String reqDate = requiredDate.format(dateFormatter);
        return reqDate;
    }

    public FSRResponseUpdateWorkOrderPageObjects clickOnUpdateButton() {
        Selenide.sleep(5000);
        $x(UPDATE_BUTTON).shouldBe(visible, enabled).click();
        return this;
    }

    public void setRiskAssessment(String fieldName, String value){
    switch (fieldName.toLowerCase()){
        case "is risk assessment attached" ->
                selectIsRiskAssessmentAttached(value);
        case "no risk assessment reason"  ->
                selectNoRiskAssessmentReason(value);
        case "no risk assessment details" ->
                 setNoRiskAssessmentDetails(value);
        default -> throw new RuntimeException("Not implemented for " + fieldName);
    }

    }
    public void setServiceDetails(String fieldName,String value){
    switch (fieldName.toLowerCase()){
        case "work performed" ->
                setWorkPerformed(value);
        case "opportunity detected" ->
                selectOpportunityDetected(value);
        default -> throw new RuntimeException("Not implemented for " + fieldName);
    }
    }
    public void clickSaveButtonTwice(){
       $x("//iframe[@title='Service Delivery']").shouldBe(visible, Duration.ofSeconds(60));
        switchTo().frame($x("//iframe[@title='Service Delivery']"));
        clickOnSaveButton();
        if(iSWarningMessageDisplayed()){
            clickOnSaveButton();
        }


    }

    public void clickSaveButtonAndHandleWarningPopUp(){
        $x("//iframe[@title='Service Delivery']").shouldBe(visible, Duration.ofSeconds(60));
        switchTo().frame($x("//iframe[@title='Service Delivery']"));
        clickOnSaveButton();
        if(iSWarningMessageDisplayed()){
            clickOnSaveButton();
        }
    }

    public FSRResponseUpdateWorkOrderPageObjects selectCustomerHourType(String value) {
        highLightElement($x(CUSTOMER_HOUR_TYPE_DROPDOWN).shouldBe(visible, enabled));
        $x(CUSTOMER_HOUR_TYPE_DROPDOWN).shouldBe(visible, enabled).click();
        highLightElement($x(String.format(CUSTOMER_HOUR_TYPE_DROPDOWN_VALUES, value)).shouldBe(visible, enabled));
        $x(String.format(CUSTOMER_HOUR_TYPE_DROPDOWN_VALUES, value)).shouldBe(visible, enabled).click();
        return this;
    }

    public String getRandomCustomerHourTypeValue() {
        Random random = new Random();
        int index = random.nextInt(values.length);
        String randomCustomerHourType = values[index];
         return randomCustomerHourType;
    }

    public boolean isTimeOverlapErrorMessageDisplayed() {
        boolean status = false;
        ApplicationCommonMethods.waitForGivenTime(6000);
        try {
            WebElement errorElement = WebDriverRunner.getWebDriver().findElement(By.xpath(TIME_OVERLAP_ERROR_MESSAGE));
            if (errorElement != null && errorElement.getText().contains("My Time : Time overlaps")) {
                status = true;
            } else {
                status = false;
            }
        } catch (Exception e) {
            status = false;
        }
        return status;
    }

    public boolean isErrorMessageDisplayed() {
        boolean status = false;
        ApplicationCommonMethods.waitForGivenTime(6000);
        try {
            ElementsCollection errorElement = $$x(ERROR_TEXT);
            for(SelenideElement errorMessage : errorElement){
                if (errorMessage.getText().contains("Please ensure that Customer Start Date is before Customer End Date.") || errorMessage.getText().contains("Please ensure that Start Date is before End Date.")) {
                    status = true;
                    break;
                } else {
                    status = false;
                }
            }

        } catch (Exception e) {
            status = false;
        }
        return status;
    }



}
