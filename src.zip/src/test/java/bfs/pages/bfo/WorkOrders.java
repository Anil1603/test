package bfs.pages.bfo;

import com.codeborne.selenide.*;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;

import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.atomic.AtomicReference;

import static bfs.pages.BasePage.highLightElement;
import static bfs.pages.BasePage.waitForPageLoad;
import static bfs.pages.bfo.ApplicationCommonMethods.*;
import static com.codeborne.selenide.Condition.enabled;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.*;
import java.util.ArrayList;
import java.util.List;

public class WorkOrders {

    // XPaths for elements
    private static final String CLONE_WORK_ORDER = "//button[text()='Clone WO']";
    private static final String CASE_VALUE = "//span[contains(text(), '%s')]/parent::span/parent::label/following-sibling::div/div/div/div/div";
    private static final String CASE_TEXT_BOX = "//span[contains(text(), '%s')]/parent::span/parent::label/following-sibling::div/div/div/div/div//input";
    private static final String DROPDOWN_XPATH = "//span[contains(text(),'%s')]/parent::span/parent::label/following-sibling::div/div/div/following-sibling::div";
    private static final String DROPDOWN_ITEM_XPATH = "//li[text()='%s']";
    private static final String SAVE_CLONE_WORK_ORDER = "//span[text()='Save']/parent::span/../parent::a";
    private static final String CASE_WORk_ORDER_FRAME = "//iframe[@title='Service Delivery']";
    private static final String Service_Maintance_contract_Header="//button[@title='Edit Service/Maintenance Contract']//span[@class='slds-grid highlights-primary-row inline-edit-trigger-icon']";
    private static final String Service_Maintance_contract_Line="//button[@title='Edit Service Line']//span[@class='slds-grid highlights-primary-row inline-edit-trigger-icon']";
    private static final By ShowMoreButtonVisable= By.xpath("//div[@class='scroll-container container show-less']");
    private static final By ShowMoreButton = By.xpath("//div[@class='scroll-container container show-less']//div//a[text()='Show More']");
    private static final By CreateDependentGroup = By.xpath("//span[contains(text(), 'Create Dependency Group')]");
    private static final String SAVE_BUTTON = "//span[text()='Save']/parent::button[@class='Button slds-button Button--type-brand slds-button--brand slds-button_brand slds-button--x-small']";
    private static final String TOTAL_QUOTED_HRS = "//span[text()='Total Quoted Hrs']//ancestor::label//following-sibling::div//input";


    public WorkOrders clickCloneWorkOrder() {
        clickElement(CLONE_WORK_ORDER, "Error clicking on Create Work Order");
        waitForGivenTime(8000);
        waitForPageLoad();
        waitForGivenTime(10000);
        switchToFrame(CASE_WORk_ORDER_FRAME);
        return this;
    }

    public WorkOrders verifyCaseDetails(String labelText, String value) {
        return checkAttributeAndEnterCaseText(labelText, CASE_VALUE, CASE_TEXT_BOX, value);
    }

    public WorkOrders selectCloneReason(String labelText, String value) {
        try {
            selectDropdownValue(labelText, DROPDOWN_XPATH, DROPDOWN_ITEM_XPATH, value);
        } catch (Exception e) {
            handleException("Error selecting Clone Reason", e);
        }
        return this;
    }

    public WorkOrders selectCustomerRequestDate(String labelText, String dateFormat) {
        return clickAndEnterDynamicDate(labelText, CASE_TEXT_BOX, dateFormat);
    }

    public WorkOrders saveCloneWorkOrder() {
        return clickElement(SAVE_CLONE_WORK_ORDER, "Error clicking on Save Clone Work Order");
    }

    private WorkOrders clickElement(String xpath, String errorMessage) {
        try {
            SelenideElement element = $x(xpath);
            waitForElementToBeVisibleAndClickable(element);
            element.click();
            waitForGivenTime(8000);
        } catch (Exception e) {
            handleException(errorMessage, e);
        }
        return this;
    }

    private WorkOrders checkAttributeAndEnterCaseText(String labelText, String xpathAttribute, String xpathInput, String value) {
        try {
            String dynamicXpathAttribute = String.format(xpathAttribute, labelText);
            String dynamicXpathInput = String.format(xpathInput, labelText);

            SelenideElement element = $x(dynamicXpathAttribute);
            String qtipValue = element.getAttribute("data-qtip");

            if (qtipValue == null || qtipValue.isEmpty()) {
                SelenideElement inputElement = $x(dynamicXpathInput);
                inputElement.shouldBe(Condition.visible, Condition.enabled)
                        .scrollIntoView(true)
                        .setValue(value);
            } else {
                System.out.println("Attribute 'data-qtip' exists. No need to enter text.");
            }
        } catch (Exception e) {
            handleException("Error checking attribute and entering text", e);
        }
        return this;
    }

    private WorkOrders clickAndEnterDynamicDate(String labelText, String xpath, String dateFormat) {
        try {
            String dynamicXpath = String.format(xpath, labelText);
            SelenideElement element = $x(dynamicXpath);

            element.shouldBe(Condition.visible, Condition.enabled)
                    .scrollIntoView(true)
                    .click();

            new Actions(WebDriverRunner.getWebDriver()).sendKeys(Keys.ESCAPE).perform();

            String formattedDate = LocalDate.now().plusDays(1).format(DateTimeFormatter.ofPattern(dateFormat));
            element.setValue(formattedDate);
        } catch (Exception e) {
            handleException("Error interacting with the date input field", e);
        }
        return this;
    }

    public String WorkOrderNumber(){
        AtomicReference<String> WorkOrderNumber = new AtomicReference<>();
        $$x("//div[@data-target-selection-name='sfdc:RecordField.SVMXC__Service_Order__c.Name']//lightning-formatted-text").iterator().forEachRemaining(element ->
        {
            if(element.isDisplayed()){
                highLightElement(element);
                System.out.println("Work Order Number: "+element.getText());

                SelenideElement ele = element.shouldBe(Condition.visible);
                WorkOrderNumber.set(ele.getText());
            }
        });
        return WorkOrderNumber.get();
    }

    public void add_Service_Maintanance_Heder_to_Work_Order(String Service_contract_Header){
        $$x(Service_Maintance_contract_Header).iterator().forEachRemaining(element ->{
            if(element.isDisplayed()){
                highLightElement(element);
                element.click();
            }
        });
        $x("//div[@data-target-selection-name='sfdc:RecordField.SVMXC__Service_Order__c.ServiceLine__c']//input").setValue(Service_contract_Header);
        $x("//lightning-base-combobox-formatted-text[@title='"+Service_contract_Header+"']").shouldBe(visible).click();
    }

    public void add_Service_Maintanance_Line_to_Work_Order(String Service_contract_Line){
        $$x(Service_Maintance_contract_Line).iterator().forEachRemaining(element ->{
            if(element.isDisplayed()){
                highLightElement(element);
                element.click();
            }
        });
        $x("//div[contains(@data-position-id, 'lgcp-')]//input[@class='slds-combobox__input slds-input']").setValue(Service_contract_Line);
        $x("//lightning-base-combobox-formatted-text[@title='"+Service_contract_Line+"']").shouldBe(visible).click();
    }

    public void clickShowMoreButton(){
        $$(ShowMoreButtonVisable).iterator().forEachRemaining(element ->{
            if(element.isDisplayed()){
                highLightElement(element);
                // element.click();
                $$(ShowMoreButton).iterator().forEachRemaining(element1 ->{
                    if(element1.isDisplayed()){
                        highLightElement(element1);
                        //actions().moveToElement(element1).build().perform();

                        element1.shouldBe(visible,Duration.ofSeconds(30)).click(ClickOptions.usingJavaScript());
                    }
                });
                //$(ShowMoreButton).click();
            }
        });
//        if($(ShowMoreButtonVisable).scrollIntoView(true).isDisplayed()){
//            $(ShowMoreButton).click();
//        }
    }


    public void createDependentGroup(){
        clickShowMoreButton();
        $$(CreateDependentGroup).iterator().forEachRemaining(element ->{
            if(element.isDisplayed()){
                highLightElement(element);
                element.click(ClickOptions.usingJavaScript());
            }
        });
        //shouldBe(visible, Duration.ofSeconds(60)).click();
    }
    public static String getFormattedDateFromElement(String in_element_property) {
        SelenideElement dataElement = $x(in_element_property);
        String originalDate = dataElement.getText(); // e.g., "07/04/2025"
        DateTimeFormatter inputFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        DateTimeFormatter outputFormat = DateTimeFormatter.ofPattern("dd.MM.yyyy");

        LocalDate parsedDate = LocalDate.parse(originalDate, inputFormat);
        return parsedDate.format(outputFormat); // returns "07.04.2025"
    }
    public static String getStartDate(String lblStartDate) {
        Selenide.sleep(4000);
        String xpath = "//p[contains(@title, '"+lblStartDate+"')]/following::p/slot/lightning-formatted-text";
        String startDateValue = getFormattedDateFromElement(xpath);
        return startDateValue ;
    }

    public static String getEndDate(String lblEndDate) {
        String xpath = "//p[contains(@title, '"+lblEndDate+"')]/following::p/slot/lightning-formatted-text";
        String endDateValue = getFormattedDateFromElement(xpath);
        return endDateValue;
    }

    public WorkOrders clickOnSaveButton(){
        switchTo().frame($x("//iframe[@title='Service Delivery']"));
        Selenide.sleep(4000);
        $x(SAVE_BUTTON).shouldBe(visible,enabled).click();
        Selenide.sleep(4000);
        switchTo().defaultContent();
        return this;
    }
    public static String[] getContractNames() {
        Selenide.sleep(4000);
        ElementsCollection contractElements = $$x("//div[text()='Contract Name']/parent::th/parent::tr/parent::thead/parent::table/tbody/tr/td[2]/lightning-formatted-url/a");

        String[] contractNames = new String[contractElements.size()];

        for (int i = 0; i < contractElements.size(); i++) {
            SelenideElement element = contractElements.get(i);
            contractNames[i] = element.getText().trim();
        }

        return contractNames;
    }
    public static String[] getContractsku() {
        Selenide.sleep(4000);
        ElementsCollection contractElements = $$x("//div[text()='Contract Name']/parent::th/parent::tr/parent::thead/parent::table/tbody/tr/td[3]/lightning-formatted-url/a");

        String[] contractSku = new String[contractElements.size()];

        for (int i = 0; i < contractElements.size(); i++) {
            SelenideElement element = contractElements.get(i);
            contractSku[i] = element.getText().trim();
        }

        return contractSku;
    }
    public static String getStatusText() {
        Selenide.sleep(8000);
        String xpath = "(//span[text()='Status']/../parent::dt/following-sibling::dd/div/span/slot/lightning-formatted-text)[last()]";
        SelenideElement statusElement = $x(xpath).scrollIntoView("{block: \"center\"}");
        String statusText = statusElement.getText().trim();
        System.out.println("Status Text: " + statusText);
        return statusText;
    }

    public void clickShowMoreResults() {
        try {
            SelenideElement showMoreLink = $x("//span[contains(@title, 'Show more results')]");

            // Wait and click if visible
            showMoreLink.shouldBe(visible, Duration.ofSeconds(10))
                    .scrollIntoView("{block: \"center\"}")
                    .click();

            System.out.println("Clicked 'Show more results' successfully.");
        } catch (Exception e) {
            System.err.println("'Show more results' link not found or not clickable: " + e.getMessage());
        }
    }

    public void selectRadioButtonByFieldValue(String fieldValue) {
        try {
            // Build dynamic XPath for selecting the radio button
            String xpath = "//th[@data-cell-value='" + fieldValue + "']/preceding-sibling::td/lightning-primitive-cell-checkbox/span[@class='slds-radio']";

            // Find the radio button and click it
            SelenideElement radioButton = $x(xpath);

            // Wait for visibility and click the radio button
            radioButton.shouldBe(visible).click();

            System.out.println("Selected the radio button for: " + fieldValue);
        } catch (Exception e) {
            System.err.println("Could not select the radio button for value: " + fieldValue + ". Error: " + e.getMessage());
        }
    }

    public void clickSelectButton() {
        try {
            // Locate the "Select" button using XPath
            SelenideElement selectButton = $x("//button[text()='Select']");

            // Wait for the button to be visible and click
            selectButton.shouldBe(visible, Duration.ofSeconds(10)).click();

            System.out.println("Clicked 'Select' button successfully.");
        } catch (Exception e) {
            System.err.println("Could not click the 'Select' button. Error: " + e.getMessage());
        }
    }


    public WorkOrders modifyContractDetails(String fieldName, String fieldValue) {
        waitForGivenTime(8000);
        waitForPageLoad();
        // Wait for visibility of the Edit button for the field

        SelenideElement editButton = $x("(//button[@title='Edit " + fieldName + "'])[last()]");
        editButton.scrollIntoView("{block: \"center\"}");
        waitForGivenTime(3000);
        // Click the edit button for the field, if visible
        if (editButton.isDisplayed()) {
            editButton.shouldBe(Condition.visible).click();
        }

        // Locate the dropdown button for the field
        SelenideElement dropdownButton = $x("//label[(text()= '" + fieldName + "')]/parent::lightning-grouped-combobox/div//button");
        waitForGivenTime(3000);
        // Check if the dropdown button is displayed
        if (dropdownButton.isDisplayed()) {
            dropdownButton.shouldBe(Condition.visible).click();
            waitForGivenTime(3000);
        }

        // Set the value for the field in the input field
        SelenideElement inputField = $x("//label[(text()= '" + fieldName + "')]/parent::lightning-grouped-combobox/div//input");
        inputField.shouldBe(Condition.visible).scrollIntoView("{block: \"center\"}").click();
        inputField.shouldBe(Condition.visible).scrollIntoView("{block: \"center\"}").val(fieldValue);
//        for (char ch : fieldValue.toCharArray()){
//            inputField.sendKeys(String.valueOf(ch));
//            Selenide.sleep(1000);
//        }
        waitForGivenTime(5000);
        // Select the value from the dropdown
//        String modifiedValue = fieldValue.substring(0, 1).toUpperCase() + " " + fieldValue.substring(1); // "C oordinator 1060"
//        $x("//ul[@role='group']/li/lightning-base-combobox-item/span/span/lightning-base-combobox-formatted-text[contains(@title, '"+fieldValue+"')]")
//                .shouldBe(Condition.visible)
//                .scrollIntoView("{block: \"center\"}")
//                .click();
        clickShowMoreResults();
        selectRadioButtonByFieldValue(fieldValue);
        clickSelectButton();
        waitForGivenTime(3000);
        // Save the changes
        $x("//runtime_platform_actions-action-renderer[@title='Save']/parent::li")
                .shouldBe(Condition.visible, Condition.enabled)
                .click();
        return this;
    }

    public void setTotalQuotedHrs(String value){
        $x(TOTAL_QUOTED_HRS).shouldBe(visible,enabled);
        $x(TOTAL_QUOTED_HRS).shouldBe(visible,enabled).setValue(value);
    }

}
