package bfs.stepdefinition;

import bfs.pages.BasePage;
import bfs.pages.bfo.PageObjects.BFOFlowOfWorkOrderPageObjects;
import bfs.pages.bfo.PageObjects.BFOLendingPageObjects;
import bfs.pages.bfo.PageObjects.BFOMyTeamAssignedFSRPageObjects;
import bfs.pages.servicemax.PageObjects.FSRResponseUpdateWorkOrderPageObjects;
import bfs.pages.servicemax.PageObjects.ReviewTimeAndExpensePageObjects;
import com.codeborne.selenide.Selenide;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import java.util.Map;

import static bfs.CONSTANTS.captureScreen;
import static com.codeborne.selenide.Selenide.switchTo;
import static com.sun.xml.fastinfoset.alphabet.BuiltInRestrictedAlphabets.table;

public class FSR_Manager_StepDefinition {
    @When("I click on {string} from home page")
    public void iClickOnFromHomePage(String arg0) {
        new BFOLendingPageObjects().clickOnMyTeamAssignedFSR();
    }
    @And("I look for the service completed work order {string} and open it")
    public void iLookForTheServiceCompletedWorkOrderAndOpenIt(String workOrderNumber) {
       new BFOMyTeamAssignedFSRPageObjects().clickOnWorkOrderNumberWithServiceCompleted(BasePage.data.get(workOrderNumber));
    //    new BFOMyTeamAssignedFSRPageObjects().clickOnWorkOrderNumberWithServiceCompleted(workOrderNumber);
    }


    @Then("I verify the all details and click button two times:")
    public void iVerifyTheAllDetailsAndClickButtonTwoTimes(DataTable table) {
        Map<String, String> fields = new BasePage().storeFieldsIn(table.asMap());
        for (Map.Entry<String, String> entry : fields.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();
            new ReviewTimeAndExpensePageObjects().verifyAllDetails(key,value);
        }
        // new code added inside save button method
        new FSRResponseUpdateWorkOrderPageObjects().clickSaveButtonTwice();
        Selenide.sleep(2000);
        switchTo().defaultContent();
        captureScreen=true;
    }

    @Then("I verify the all details and click Save button:")
    public void iVerifyTheAllDetailsAndClickSaveButton(DataTable table) {
        Map<String, String> fields = new BasePage().storeFieldsIn(table.asMap());
        for (Map.Entry<String, String> entry : fields.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();
            new ReviewTimeAndExpensePageObjects().verifyAllDetails(key,value);
        }
        new FSRResponseUpdateWorkOrderPageObjects().clickSaveButtonAndHandleWarningPopUp();
        Selenide.sleep(2000);
        switchTo().defaultContent();
        captureScreen=true;
    }

    @And("I changed the work order status to service validated")
    public void iChangedTheWorkOrderStatusToServiceValidated() {
        new BFOFlowOfWorkOrderPageObjects().clickOnServiceValidatedStepButton()
                .clickOnMarkAsCurrentWorkOrderStatus();
        Selenide.sleep(5000);
        Selenide.sleep(5000);
    }

    @And("I click on {string} button two times")
    public void iClickOnButtonTwoTimes(String arg0) {
        new FSRResponseUpdateWorkOrderPageObjects().clickSaveButtonTwice();
        Selenide.sleep(2000);
        switchTo().defaultContent();
        captureScreen=true;
    }
}
