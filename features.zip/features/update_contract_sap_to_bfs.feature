Feature: create contact in sap and verify in bfs.
  As a user
  I want to navigate to the sap application and create contact abd memorize contract number
  So that I can verify contract in bfs

  Scenario Outline: contact creation in sap ad verify in bfs
      #SAP
    Given I work in application "SAP"
    When I navigate to "(Bridge) ECC 6.0 SSO - QRH - Pre-Production APAC"
    And I create contract
    And I log out sap
#
##    #bfs
    Given I work in application "BFO" and environment "UAT"
    And I login to "BFO" as user "coordinator-1660@bridge-fo.com.uatbfo26"
    And I search sap contract "maintainanceContractId"
    And I select the sap contract "maintainanceContractId" section from "Service/Maintenance Contracts"
    And verify contract "Start Date" and "End Date"
    And I logout from bfo application


##    #SAP
    Given I work in application "SAP"
    When I navigate to "(Bridge) ECC 6.0 SSO - QRH - Pre-Production APAC"
    And I changed the contract in sap
    And I log out sap

        #bfs
    Given I work in application "BFO" and environment "UAT"
    And I login to "BFO" as user "coordinator-1660@bridge-fo.com.uatbfo26"
    And I search sap contract "maintainanceContractId"
    And I select the sap contract "maintainanceContractId" section from "Service/Maintenance Contracts"
    And verify updated contract "Start Date" and "End Date"
    And I navigates to "Service Lines" tab
    And memorize the contact in service lines and compare
    And memorize sku's in the service lines and compare
#

    Examples:
      | Menu Item      | Work Order       | Tab Name      | Parts Order Type | Ship From Plant | Product Name | Line Status | Shipped Qty | Work Details Tab     | Installed Quantity |
      | Search: Service/Maintenance Contracts    | WO-12264768     | Parts Order   | Ship only        | AU10            | 47053       | Received     | 1           |   Work Details       |  1                 |




