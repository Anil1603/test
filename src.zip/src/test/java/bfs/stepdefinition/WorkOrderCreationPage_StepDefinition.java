package bfs.stepdefinition;

import bfs.pages.BasePage;
import bfs.pages.bfo.BFONewServiceContractBasicInfoPageObjects;
import bfs.pages.bfo.BFOStandaloneNewWorkOrderPageObjects;
import bfs.pages.bfo.BFOWorkOrderPageObjects;
import bfs.pages.bfo.PageObjects.BFOValidateContractPageObjects;
import bfs.pages.bfo.BFO_Landing_Header_Objects;
import bfs.pages.bfo.PageObjects.BFOVerifyWorkOrderStatus;
import bfs.pages.bfo.Pages.BFOSyncPage;
import bfs.pages.bfo.SplitWorkOrders;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import bfs.Pojo.WorkOrderData;

import java.io.IOException;
import java.util.Map;

import static bfs.CONSTANTS.captureScreen;
import static com.codeborne.selenide.Selenide.*;

public class WorkOrderCreationPage_StepDefinition {
    private WorkOrderData workOrderData;

    @And("I fill work order details for creating new work order from Work Order Page:")
    public void iCreateANewServiceMaintenanceContractWithFollowingDetails(DataTable table) {
        Map<String, String> fields = new BasePage().storeFieldsIn(table.asMap());
        for (Map.Entry<String, String> entry : fields.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();
            switch (key.toLowerCase()) {
                case "select record type" -> new BFOWorkOrderPageObjects().WOselectRecordType(value);
                case "installed at account" -> {
                    new BFOStandaloneNewWorkOrderPageObjects().waitForNewStandAloneWorkOrderPageLoaded()
                            .selectAccountNameUsingGoldenID(value.split(":")[0], value.split(":")[1]);
                }
                case "location" -> new BFOStandaloneNewWorkOrderPageObjects()
                        .selectLocationNameUsingGoldenID(value.split(":")[0], value.split(":")[1]);
                case "customer requested date" ->
                        new BFOStandaloneNewWorkOrderPageObjects().enterCustomerRequestedDate(value);
                case "work order category" -> new BFOStandaloneNewWorkOrderPageObjects().selectWorkOrderCategory(value);
                case "services business unit" ->
                        new BFOStandaloneNewWorkOrderPageObjects().selectServicesBusinessUnit(value.toUpperCase());
                case "is billable" -> new BFOStandaloneNewWorkOrderPageObjects().selectIsBillable(value);
                case "customer reference number" -> new BFOStandaloneNewWorkOrderPageObjects().enterCustomerReferenceNumber(value);
                case "non billing reason" -> new BFOStandaloneNewWorkOrderPageObjects().selectNonBillingReason(value);
                case "priority" -> new BFOStandaloneNewWorkOrderPageObjects().selectPriority(value);
                case "skill category" -> new BFOStandaloneNewWorkOrderPageObjects().selectSkillCategory(value);
                case "work order reason" -> new BFOStandaloneNewWorkOrderPageObjects().enterWorkOrderReason(value);
                case "work order name" -> new BFOStandaloneNewWorkOrderPageObjects().enterWorkOrderName(value);
                case "total quoted hrs" -> new BFOStandaloneNewWorkOrderPageObjects().enterTotalQuotedHrs(value);
                case "sold to account" ->
                        new BFOStandaloneNewWorkOrderPageObjects().selectSoldToAccount(value.split(":")[0], value.split(":")[1]);
                case "work order type"->new BFOStandaloneNewWorkOrderPageObjects().selectWorkOrderType(value);
                case "work order sub-type" ->new BFOStandaloneNewWorkOrderPageObjects().selectWorkOrderSubType(value);
                case "contact"->new BFOStandaloneNewWorkOrderPageObjects().searchSelectContact(value);
                case "country of back office"->new BFOStandaloneNewWorkOrderPageObjects().selectCountryOfBackOffice(value);
                case "back office system"-> new BFOStandaloneNewWorkOrderPageObjects().selectBackOfficeSystem(value);
                case "service commercial ref"->new BFOStandaloneNewWorkOrderPageObjects().enterServiceCommercialRef(value);

                default -> System.out.println("Not Implemented for " + key);
            }
            captureScreen = true;
        }
        new BFOStandaloneNewWorkOrderPageObjects().clickOnSaveButton();
    }



    @And("I click on Sync button from Sync page with Header {string}")
    public void iClickOnSyncButtonFromSyncPageWithHeader(String header) {
        BFOSyncPage bfoSyncPage = new BFOSyncPage();
        if ("Cost Center".equals(header)) {
            bfoSyncPage.performSyncActionsForCostCenter(header);
        } else {
            bfoSyncPage.performSyncActions();
        }
    }

    @And("Work Order input data is loaded from json file")
    public void loadWorkOrderData() throws IOException {
        String filePath = System.getProperty("user.dir") + "/TestData/workOrdersCreation_InputData.json";
        workOrderData = WorkOrderData.load(filePath);
    }

    @And("I create multiple work orders from json file data and store the Work Orders id in Json:")
    public void createMultipleWorkOrders(DataTable table) {
        BFOStandaloneNewWorkOrderPageObjects bfoStandaloneNewWorkOrderPageObjects = new BFOStandaloneNewWorkOrderPageObjects();

        //Iterate work order creation based on json file data
        for (WorkOrderData.WorkOrder workOrder : workOrderData.workOrders) {

            // And I click on bfo button "New"
            new BFOWorkOrderPageObjects().clickOnNewButton().waitForRecordTypePopUp();

            // enter Work Order Fields
            new BFOWorkOrderPageObjects().WOselectRecordType(workOrder.SelectRecordType);
            {
                new BFOStandaloneNewWorkOrderPageObjects().waitForNewStandAloneWorkOrderPageLoaded()
                        .selectAccountNameUsingGoldenID(workOrder.InstalledAtAccount.split(":")[0], workOrder.InstalledAtAccount.split(":")[1]);
            }
            bfoStandaloneNewWorkOrderPageObjects
                    .selectLocationNameUsingGoldenID(workOrder.Location.split(":")[0], workOrder.Location.split(":")[1]);
            bfoStandaloneNewWorkOrderPageObjects.selectWorkOrderType(workOrder.WorkOrderType);
            if (workOrder.WorkOrderSubType != null) {
                bfoStandaloneNewWorkOrderPageObjects.selectWorkOrderSubType(workOrder.WorkOrderSubType);
            }
            bfoStandaloneNewWorkOrderPageObjects.searchSelectContact(workOrder.Contact);
            bfoStandaloneNewWorkOrderPageObjects.enterCustomerRequestedDate(workOrder.CustomerRequestedDate);
            bfoStandaloneNewWorkOrderPageObjects.selectCountryOfBackOffice(workOrder.CountryOfBackOffice);
            bfoStandaloneNewWorkOrderPageObjects.selectBackOfficeSystem(workOrder.BackOfficeSystem);
            bfoStandaloneNewWorkOrderPageObjects.selectWorkOrderCategory(workOrder.WorkOrderCategory);
            bfoStandaloneNewWorkOrderPageObjects.selectServicesBusinessUnit(workOrder.ServicesBusinessUnit.toUpperCase());
            bfoStandaloneNewWorkOrderPageObjects.selectIsBillable(workOrder.IsBillable);
            bfoStandaloneNewWorkOrderPageObjects.selectPriority(workOrder.Priority);
            if (workOrder.NonBillingReason != null) {
                bfoStandaloneNewWorkOrderPageObjects.selectNonBillingReason(workOrder.NonBillingReason);
            }
            bfoStandaloneNewWorkOrderPageObjects.enterServiceCommercialRef(workOrder.ServiceCommercialRef);
            if (workOrder.SkillCategory != null) {
                bfoStandaloneNewWorkOrderPageObjects.selectSkillCategory(workOrder.SkillCategory);
            }
            bfoStandaloneNewWorkOrderPageObjects.enterWorkOrderReason(workOrder.WorkOrderReason);
            bfoStandaloneNewWorkOrderPageObjects.enterWorkOrderName(workOrder.WorkOrderName);
            bfoStandaloneNewWorkOrderPageObjects.selectSoldToAccount(workOrder.SoldToAccount.split(":")[0], workOrder.SoldToAccount.split(":")[1]);

            captureScreen = true;
            bfoStandaloneNewWorkOrderPageObjects.clickOnSaveButton();

            // fetch work order number
            String WorkOrder = new SplitWorkOrders().getSplitWorkOrderNumber();

            // And work order number is stored in json file
            new SplitWorkOrders().storeWorkorders(WorkOrder, "workOrdersCreated.json");

            //work order status should be "New" in work order page
            refresh();
            sleep(10000);
            new BFOVerifyWorkOrderStatus().checkWorkOrderStatus("New");

            //click on WorkOrders Tab for New Button
            new BFOWorkOrderPageObjects().clickOnWorkOrdersTab();
        }

    }

}
