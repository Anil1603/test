package bfs.pages.bfo.PageObjects;

import org.openqa.selenium.By;
import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$x;

public class BFOCoverProductPageObjetcs {
    private static final String PRODUCT_NAME_CHECKBOX = "//div[@title='%s']/../preceding-sibling::td[@role='gridcell']//span[@class='slds-checkbox']";
    private static final String ADD_COVER_PRODUCT_BUTTON = "//button[contains(text(),'Add Covered Products')]";
    private static final String INSTALLED_PRODUCT_SEARCH_TEXTBOX = "//input[@name='enter-search']";
    private static final String GO_BUTTON = "//button[contains(text(),'Go')]";
    private static final String INSTALLED_PRODUCT_NAME_CHECKBOX = "//div[@title='%s']/../following-sibling::td/div[@class='slds-truncate slds-text-align_center']/img[@alt='ActiveContract']/ancestor::td//preceding-sibling::td//input[@type='checkbox']";
    private static final String ATTACH_IP_BUTTON = "//button[contains(text(),'Attach IP')]";
    private static final String SAVE_BUTTON = "//button[contains(text(),'Save')]";
    public BFOCoverProductPageObjetcs clickOnProductCheckBox(String productName){
        By PRODUCT_CHECKBOX = By.xpath(String.format(PRODUCT_NAME_CHECKBOX,productName));
        $(PRODUCT_CHECKBOX).shouldBe(visible,enabled).click();
        return this;
    }
    public BFOCoverProductPageObjetcs clickOnAddCoverProductButton(){
        $x(ADD_COVER_PRODUCT_BUTTON).shouldBe(visible,enabled).click();
        return this;
    }
    public BFOCoverProductPageObjetcs setInstalledProductSearchTextBox(String productName){
        $x(INSTALLED_PRODUCT_SEARCH_TEXTBOX).shouldBe(visible,enabled).setValue(productName);
        return this;
    }
    public BFOCoverProductPageObjetcs clickOnGoButton(){
        $x(GO_BUTTON).shouldBe(visible,enabled).click();
        return this;
    }
    public BFOCoverProductPageObjetcs clickOnInstalledProductCheckBox(String productName){
        By INSTALLED_PRODUCT_CHECKBOX = By.xpath(String.format(INSTALLED_PRODUCT_NAME_CHECKBOX,productName));
        $(INSTALLED_PRODUCT_CHECKBOX).shouldBe(visible,enabled).click();
        return this;
    }
    public BFOCoverProductPageObjetcs clickOnAttachIPButton(){
        $x(ATTACH_IP_BUTTON).shouldBe(visible,enabled).click();
        return this;
    }
    public BFOCoverProductPageObjetcs clickOnSaveButton(){
        $x(SAVE_BUTTON).shouldBe(visible,enabled).click();
        return this;
    }

}
