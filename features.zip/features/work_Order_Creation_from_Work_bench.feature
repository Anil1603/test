Feature: work Order Creation from Work bench.
	#@BFSTST-2032 @BFSTST-2033
  Scenario: Work Order Creation from work bench for system SAP BBO AP
		#Coordinator
    Given I work in application "BFO" and environment "UAT"
    And I login to "BFO" as user "coordinator-1660@bridge-fo.com.uatbfo26"
    And I open New tab in Browser
    And I work in application "WORKBENCH" and environment "UAT"
    And I login to "WORKBENCH" as user "Sandbox"
    And I navigated to "SOQL Query" page from "queries" tab
    And I execute "WORK_ORDER_SOQL_QUERY" with "10" records to download work order details in "bulkcsv" format
    And I wait for "20" seconds


