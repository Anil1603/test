package bfs.B2F;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

//import org.apache.poi.ss.usermodel.DataFormatter;
//import org.apache.poi.xssf.usermodel.XSSFSheet;
//import org.apache.poi.xssf.usermodel.XSSFWorkbook;
//import org.apache.poi.xwpf.usermodel.XWPFDocument;
//import org.apache.poi.xwpf.usermodel.XWPFParagraph;
//import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class one_Header_Multipule_ServiceLines_two_CoverdProducts_to_each_ServiceLine_with_assetIdNumber_and_schneiderAssetIdNumber extends getAccessToken {


		@Test
		public void CreatingServiceLinesforFindErrors() throws IOException {
			String SID=accessToken;
			int z=0;
			FileInputStream fi=new FileInputStream(new File(System.getProperty("user.dir")+"/TestDataFilesFolder/serviceContracts/"+"ServiceContract_shippedSN.xlsx"));
			XSSFWorkbook xf=new XSSFWorkbook(fi);
			XSSFSheet sh=xf.getSheet("Sheet12");
			
			String assetIdNumber="a1aA0000007h0k6IAA";
			String schneiderAssetIdNumber="0029596139";
			String schneiderAssetIdNumber2="18275486";
			String assetIdNumber1="a1aA0000005hsppIAA";
			
			DataFormatter formatter = new DataFormatter();
			
			
			XWPFDocument document = new XWPFDocument();
			 FileOutputStream out = new FileOutputStream(new File(System.getProperty("user.dir")+"/TestDataFilesFolder/serviceContracts/output/"+"one_Header_Multipule_ServiceLines_two_CoverdProducts_to_each_ServiceLine_with_assetIdNumber_and_schneiderAssetIdNumber_output.docx"));
			
			 XWPFDocument document1 = new XWPFDocument(); 
			 FileOutputStream out1 = new FileOutputStream(new File(System.getProperty("user.dir")+"/TestDataFilesFolder/serviceContracts/payload/"+"one_Header_Multipule_ServiceLines_two_CoverdProducts_to_each_ServiceLine_with_assetIdNumber_and_schneiderAssetIdNumber_payload.docx"));
 	

			RestAssured.baseURI="https://se--uat24.sandbox.my.salesforce.com/services/apexrest/field-services/service-contracts";
			int boReferenceLineNumber=20364900;
			int boReferenceCoveredProductNumber=20360900;
			int nameNumber=1;
			int boReferenceHeaderNumber=2018945;
					
				int x;
				int y;
			String coverdProducts="";
			for(x=1;x<=199;x++) {
				assetIdNumber=sh.getRow(x).getCell(1).getStringCellValue().toString();
				coverdProducts=coverdProducts+","+"{"
			              +"\"asset\": {"
			                +"\"assetId\": \""+assetIdNumber+"\""
			              +"},"
			              +"\"boReferenceLine\": \"48188619786004983455606191212265"+boReferenceLineNumber+"\","
			              +"\"installedProductStartDate\": \"2024-01-01\","
			              +"\"installedProductEndDate\": \"2024-12-31\","
			              +"\"boReferenceCoveredProduct\": \"48188619786021908417080796020711"+boReferenceCoveredProductNumber+"\","
			              +"\"pduIpBfoId\": \"\""
			            +"}";
				boReferenceLineNumber++;
				boReferenceCoveredProductNumber++;
			}
			String coverdProducts1=coverdProducts.substring(1, coverdProducts.length());
			//System.out.println(coverdProducts1);
			
			
			
			String servicelines="";
			for(y=0;y<1;y++) {
				servicelines=servicelines+","+"{"
				          +"\"name\": "+nameNumber+","
				          +"\"description\": \"APC Symmetra PX 100kW Power Frame 208V\","
				          +"\"previousContractLineId\": \"\","
				          +"\"startDate\": \"2024-01-01\","
				          +"\"endDate\": \"2025-12-31\","
				          +"\"coveredProducts\": ["
				            +coverdProducts1
				          +"],"
				          +"\"installedAtAccount\": {"
				            +"\"bfoId\": \"0011200001FplKFAAZ\""
				          +"},"
				          +"\"skuComRef\": \"01tA0000004zVyQIAU\","
				          +"\"entitlement\": \"\","
				          +"\"price\": 6013.64,"
				          +"\"currencyCode\": \"USD\","
				          +"\"quantity\": 1,"
				          +"\"lineComment\": \"\","
				          +"\"boReferenceLine\": \"48188619786004983455606191212265"+boReferenceLineNumber+"\","
				          +"\"unitPrice\": 6013.64,"
				          +"\"volumeDiscount\": 0,"
				          +"\"additionalDiscount\": 22.4,"
				          +"\"cpqQuoteNumber\": \"2024-1850605\","
				          +"\"partsDiscount\": 100,"
				          +"\"laborDiscount\": 100,"
				          +"\"yearlyUnitPriceBeforeDiscount\": 6013.64,"
				          +"\"requestedPrice\": 6013.64,"
				          +"\"requestedPriceFlag\": true,"
				          +"\"quantityOfYear\": 1,"
				          +"\"proRateApplied\": true,"
				          +"\"upLift\": 6,"
				          +"\"discountValue\": 6013.64,"
				          +"\"discountType\": \"Net\","
				          +"\"initialDiscount\": 22.4,"
				          +"\"cumulativeDiscount\": 22.4,"
				          +"\"parentContractBoRef\": 50537379,"
				          +"\"boLastUpdateTimeStamp\": \"2024-01-01 01:44:46\","
				          +"\"schedulingUpgradeLineBoRef\": \"\","
				          +"\"slaUpgradeLineBoRef\": \"\""
				        +"}";
				
				boReferenceLineNumber++;
				nameNumber++;
				
			}
			String servicelines1=servicelines.substring(1, servicelines.length());
			//System.out.println(servicelines1);
			
			
			String servicelines2=servicelines1;
			//for(int x=0; x<=10;x++) {
					
	RequestSpecification httpReqest1=RestAssured.given().auth().oauth2(SID).and().body("{"
			  +"\"serviceContracts\": ["
			    +"{"
			      +"\"contractNumber\": \"IT-1012762-"+x+"coverdProducts"+(y-1)+"serviceLines"+boReferenceHeaderNumber+"\","
			      +"\"boReferenceHeader\": 906373"+boReferenceHeaderNumber+","
			      +"\"status\": \"PCV\","
			      +"\"soldToAccount\": {"
			        +"\"bfoId\": \"001A000000jyEflIAE\","
			        +"\"name\": \"CISCO-SJC-MTV5\""
			      +"},"
			      +"\"poNumber\": 101972,"
			      +"\"startDate\": \"2024-01-01\","
			      +"\"endDate\": \"2025-12-31\","
			      +"\"serviceLines\": ["
			        +servicelines1
			      +"],"
			      +"\"description\": \"CISCO - SJC + MTV5 - 1 Year Addition\","
			      +"\"soldToContact\": {"
			        +"\"firstName\": \"DEBBIE\","
			        +"\"lastName\": \"POLLOCK\""
			      +"},"
			      +"\"price\": 413820.14,"
			      +"\"currencyCode\": \"USD\","
			      +"\"leadingBu\": \"IT\","
			      +"\"evergreen\": false,"
			      +"\"sendCustomerRenewalNotification\": false,"
			      +"\"billToAccount\": {"
			        +"\"bfoId\": \"001A000000v58mnIAA\","
			        +"\"name\": \"CBRE – CISCO FM US\""
			      +"},"
			      +"\"billToContact\": {"
			        +"\"firstName\": \"Coordinator\","
			        +"\"lastName\": \"1660\""
			      +"},"
			      +"\"salesRepSesaId\": \"COORDINATOR_1660\","
			      +"\"mainInstalledAtAccount\": {"
			        +"\"bfoId\": \"001A000000jyEflIAE\""
			      +"},"
			      +"\"mainInstalledAtContact\": {"
			        +"\"firstName\": \"DEBBIE\","
			        +"\"lastName\": \"POLLOCK\""
			      +"},"
			      +"\"cpqQuoteNumber\": \"2024-1850605\","
			      +"\"renewalNotes\": \"\","
			      +"\"countryOfBo\": \"Global\","
			      +"\"boSystem\": \"ITB_ORA\","
			      +"\"billingSchedule\": \"Quarterly\","
			      +"\"invoiceSchedule\": \"1st of Month\","
			      +"\"invoiceOption\": \"Not Applicable\","
			      +"\"renewalOpportunityReference\": \"OP-210503-10816016\","
			      +"\"amendmentOpportunityReference\": \"\","
			      +"\"ownerSesaId\": \"COORDINATOR_1660\","
			      +"\"createdByBoUser\": \"\","
			      +"\"lastModifiedByBoUser\": \"\","
			      +"\"boLastUpdateTimeStamp\": \"2024-01-01 08:58:46\","
			      +"\"boBillToRecordId\": 3736908"
			    +"}"
			  +"]"
			+"}"); 
	Response response1=httpReqest1.request(Method.POST); 
	String responsebody1=response1.getBody().asString();
	System.out.println(responsebody1);
	XWPFParagraph paragraph = document.createParagraph();
	XWPFRun run = paragraph.createRun();
	run.setText(responsebody1);
	
	XWPFParagraph paragraph1 = document1.createParagraph();
	XWPFRun run1 = paragraph1.createRun();
	run1.setText("{"
			  +"\"serviceContracts\": ["
			    +"{"
			      +"\"contractNumber\": \"IT-1012762\","
			      +"\"boReferenceHeader\": 906373"+boReferenceHeaderNumber+","
			      +"\"status\": \"PCV\","
			      +"\"soldToAccount\": {"
			        +"\"bfoId\": \"001A000000jyEflIAE\","
			        +"\"name\": \"CISCO-SJC-MTV5\""
			      +"},"
			      +"\"poNumber\": 101972,"
			      +"\"startDate\": \"2024-01-01\","
			      +"\"endDate\": \"2025-12-31\","
			      +"\"serviceLines\": ["
			        +servicelines1
			      +"],"
			      +"\"description\": \"CISCO - SJC + MTV5 - 1 Year Addition\","
			      +"\"soldToContact\": {"
			        +"\"firstName\": \"DEBBIE\","
			        +"\"lastName\": \"POLLOCK\""
			      +"},"
			      +"\"price\": 413820.14,"
			      +"\"currencyCode\": \"USD\","
			      +"\"leadingBu\": \"IT\","
			      +"\"evergreen\": false,"
			      +"\"sendCustomerRenewalNotification\": false,"
			      +"\"billToAccount\": {"
			        +"\"bfoId\": \"001A000000v58mnIAA\","
			        +"\"name\": \"CBRE – CISCO FM US\""
			      +"},"
			      +"\"billToContact\": {"
			        +"\"firstName\": \"Coordinator\","
			        +"\"lastName\": \"1660\""
			      +"},"
			      +"\"salesRepSesaId\": \"COORDINATOR_1660\","
			      +"\"mainInstalledAtAccount\": {"
			        +"\"bfoId\": \"001A000000jyEflIAE\""
			      +"},"
			      +"\"mainInstalledAtContact\": {"
			        +"\"firstName\": \"DEBBIE\","
			        +"\"lastName\": \"POLLOCK\""
			      +"},"
			      +"\"cpqQuoteNumber\": \"2023-1850605-1\","
			      +"\"renewalNotes\": \"\","
			      +"\"renewedFrom\": \"a281H000001zsROQAY\","
			      +"\"countryOfBo\": \"Global\","
			      +"\"boSystem\": \"ITB_ORA\","
			      +"\"billingSchedule\": \"Quarterly\","
			      +"\"invoiceSchedule\": \"1st of Month\","
			      +"\"invoiceOption\": \"Not Applicable\","
			      +"\"renewalOpportunityReference\": \"OP-210503-10816016\","
			      +"\"amendmentOpportunityReference\": \"\","
			      +"\"ownerSesaId\": \"SESA367580\","
			      +"\"createdByBoUser\": \"\","
			      +"\"lastModifiedByBoUser\": \"\","
			      +"\"boLastUpdateTimeStamp\": \"2023-09-25 08:58:46\","
			      +"\"boBillToRecordId\": 3736908"
			    +"}"
			  +"]"
			+"}");
	servicelines2=servicelines1+","+"{"
	          +"\"name\": "+nameNumber+","
	          +"\"description\": \"APC Symmetra PX 100kW Power Frame 208V\","
	          +"\"previousContractLineId\": \"\","
	          +"\"startDate\": \"2023-09-01\","
	          +"\"endDate\": \"2026-08-31\","
	          +"\"coveredProducts\": ["
	            +coverdProducts1
	          +"],"
	          +"\"installedAtAccount\": {"
	            +"\"bfoId\": \"0011200001FplKFAAZ\""
	          +"},"
	          +"\"skuComRef\": \"01tA0000004zVyQIAU\","
	          +"\"entitlement\": \"\","
	          +"\"price\": 6013.64,"
	          +"\"currencyCode\": \"USD\","
	          +"\"quantity\": 1,"
	          +"\"lineComment\": \"\","
	          +"\"boReferenceLine\": \"48188619786004983455606191212265"+boReferenceLineNumber+"\","
	          +"\"unitPrice\": 6013.64,"
	          +"\"volumeDiscount\": 0,"
	          +"\"additionalDiscount\": 22.4,"
	          +"\"cpqQuoteNumber\": \"2023-1850605-1\","
	          +"\"partsDiscount\": 100,"
	          +"\"laborDiscount\": 100,"
	          +"\"yearlyUnitPriceBeforeDiscount\": 6013.64,"
	          +"\"requestedPrice\": 6013.64,"
	          +"\"requestedPriceFlag\": true,"
	          +"\"quantityOfYear\": 1,"
	          +"\"proRateApplied\": true,"
	          +"\"upLift\": 6,"
	          +"\"discountValue\": 6013.64,"
	          +"\"discountType\": \"Net\","
	          +"\"initialDiscount\": 22.4,"
	          +"\"cumulativeDiscount\": 22.4,"
	          +"\"parentContractBoRef\": 50537379,"
	          +"\"boLastUpdateTimeStamp\": \"2023-09-13 01:44:46\","
	          +"\"schedulingUpgradeLineBoRef\": \"\","
	          +"\"slaUpgradeLineBoRef\": \"\""
	        +"}";
	servicelines1=servicelines2;
	//System.out.println(servicelines1);
	boReferenceLineNumber++;
	boReferenceHeaderNumber++;
	nameNumber++;			
				//}	
	document.write(out);
	out.close();
	document1.write(out1);
	out1.close();
	System.out.println("createparagraph.docx written successfully");
		}
}
