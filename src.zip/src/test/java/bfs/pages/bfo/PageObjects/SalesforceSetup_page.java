package bfs.pages.bfo.PageObjects;

import com.codeborne.selenide.ClickOptions;
import com.codeborne.selenide.Selenide;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import java.time.Duration;

import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.*;

public class SalesforceSetup_page {

    private static final By Global_Search_box = By.xpath("//input[contains(@title, 'Search')]");
    private static final String User_Click_from_Table="//h2//*[text()='Users']//ancestor::div[contains(@class,'resultsItem')]//table//a[text()='USER_VALUE']";
    private static final String userheader="//h1[text()='User']//parent::div//h2[contains(text(),'USER_NAME')]";
    private static final By login_button = By.xpath("//*[@id='topButtonRow']//input[@title='Login'][@type='button']");
    private static final String userloged_message = "//*[contains(text(),'Logged in as USER_NAME')]";
    private static final By iframe = By.xpath("//iframe[starts-with(@name,'vfFrameId_')]");

    public void searchFor(String value) throws InterruptedException {
        $(Global_Search_box).shouldBe(visible, Duration.ofSeconds(180));
        $(Global_Search_box).setValue(value);
        Selenide.sleep(2000);
        $(Global_Search_box).sendKeys(Keys.ENTER);
       // Selenide.sleep(10000);
    }

    public void loginAsProxyUser(String UserName) throws InterruptedException {
        searchFor(UserName);
        $x(User_Click_from_Table.replace("USER_VALUE", UserName)).click(ClickOptions.withTimeout(Duration.ofSeconds(120)));
        switchTo().frame($(iframe));
        $(By.xpath(userheader.replace("USER_NAME", UserName))).shouldBe(visible,Duration.ofSeconds(180));
        $(login_button).click(ClickOptions.withTimeout(Duration.ofSeconds(120)));
        switchTo().defaultContent();
        $(By.xpath(userloged_message.replace("USER_NAME", UserName))).shouldBe(visible,Duration.ofSeconds(180));
        refresh();
        Selenide.sleep(5000);
    }

    public void loginAsProxyUser(String UserName, String searchResult) throws InterruptedException {
        searchFor(UserName);
        $x(User_Click_from_Table.replace("USER_VALUE", searchResult)).click(ClickOptions.withTimeout(Duration.ofSeconds(120)));
        switchTo().frame($(iframe));
        $(By.xpath(userheader.replace("USER_NAME", searchResult))).shouldBe(visible,Duration.ofSeconds(180));
        $(login_button).click(ClickOptions.withTimeout(Duration.ofSeconds(120)));
        switchTo().defaultContent();
        $(By.xpath(userloged_message.replace("USER_NAME", searchResult))).shouldBe(visible,Duration.ofSeconds(180));
        refresh();
        Selenide.sleep(5000);
    }
}

