package bfs.pages.bfo.PageObjects;

import com.codeborne.selenide.ClickOptions;
import com.codeborne.selenide.Condition;
import org.openqa.selenium.By;

import java.time.Duration;

import static com.codeborne.selenide.Selenide.$;

public class DependencyGroup_Page {

    private static final By dependencyGroupNumberLocator = By.xpath("//records-record-layout-item[@field-label='Dependency Group Number']//lightning-formatted-text");
    private static final By RelatedTab = By.xpath("//a[@id='relatedListsTab__item']");
    private static final By Work_Order_Dependency_NumberLocator=By.xpath("//lightning-primitive-cell-factory[@data-label='Work Order Dependency Number']//span[starts-with(text(),'WOD')]");



    public String getDependencyGroupNumber() {
         $(dependencyGroupNumberLocator).shouldBe(Condition.visible,Duration.ofSeconds(120));
        return $(dependencyGroupNumberLocator).getText();
    }

    public String getWorkOrderDependencyNumber() {
        $(RelatedTab).shouldBe(Condition.visible,Duration.ofSeconds(120)).click(ClickOptions.usingJavaScript());
        $(Work_Order_Dependency_NumberLocator).shouldBe(Condition.visible,Duration.ofSeconds(120));
        return $(Work_Order_Dependency_NumberLocator).getText();
    }
}
