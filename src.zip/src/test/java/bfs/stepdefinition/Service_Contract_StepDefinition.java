package bfs.stepdefinition;
import bfs.CONSTANTS;
import com.codeborne.selenide.Selenide;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import bfs.pages.bfo.*;
import bfs.sap.*;
import io.cucumber.datatable.DataTable;

import static bfs.CONSTANTS.memorizedData;


public class Service_Contract_StepDefinition {

    public static String statusValue;

    //private final Map<String, String> memorizedData = new HashMap<>();

    @When("I search for contract {string}")
    public void iSearchForContract(String contractNumber) {
        new BFO_Landing_Header_Objects().searchContract(contractNumber);

    }
    @When("I search sap contract {string}")
    public void iSearchSapContract(String contractNumber) {
        System.out.println("SAP Contract Number: " + memorizedData.get(contractNumber));
        new BFO_Landing_Header_Objects().searchContract(memorizedData.get(contractNumber));
//        new BFO_Landing_Header_Objects().searchContract("QRH200-0040182062");

    }
    @And("verify contract {string} and {string}")
    public void iVerifyStartAndEndDates(String startDate, String endDate) {
        String startDateValue = WorkOrders.getStartDate(startDate);
        String endDateValue = WorkOrders.getEndDate(endDate);
        LandingPage.compareText(startDateValue, Work_Order_StepDefinition.contractStartDateValue);
        LandingPage.compareText(endDateValue, Work_Order_StepDefinition.contractEndDateValue);

    }

    @And("verify updated contract {string} and {string}")
    public void iVerifyUpdatedStartAndEndDates(String startDate, String endDate) {
        String updatedStartDateValue = WorkOrders.getStartDate(startDate);
        String updatedEndDateValue = WorkOrders.getEndDate(endDate);
        LandingPage.compareText(updatedStartDateValue, Work_Order_StepDefinition.contractTomorrowStartDateValue);
        LandingPage.compareText(updatedEndDateValue, Work_Order_StepDefinition.contractTomorrowYearEndDateValue);

    }


    @And("update contract details in bfs")
    public void iUpdateContractDetails() {
        new WorkOrders().modifyContractDetails("Sales Rep","Coordinator 1060");
        new WorkOrders().modifyContractDetails("Sold to Contact","chandra.vamsi kumar");


    }

    @And("I search for WONumber {string}")
    public void iSearchForWorkOrder(String WONumber) {
        new BFO_Landing_Header_Objects().searchContract(CONSTANTS.memorizedData.get(WONumber));
    }
//    @When("I selects the {string} section from {string}")
//    public void iNavigatesToContracts(String contractNumber,  String appName) {
//        new BFO_Landing_Header_Objects().navigateToContract(contractNumber, appName);
//
//    }


    //    @And("I search for WONumber {string}")
//    public void iSearchForWorkOrder(String WONumber) {
//        new BFO_Landing_Header_Objects().searchContract(CONSTANTS.memorizedData.get(WONumber));
//    }
    @And("I navigate to bfo tab {string}")
    public void iNavigateToBfoTab(String tabName) {
        new BFONewServiceContractDetailsPageObjects().selectBfoTab(tabName);
    }

    @And("I memorize Product from Service lines as {string}")
    public void iMemorizeProductFromServiceLinesAs(String skuName) {
        // Get the attribute values for the specified field (skuName)
        Map<String, String> productAttributes = new BFONewServiceContractDetailsPageObjects().getFieldAttributes(List.of(skuName));

        // Store the values in the memorizedData map for later use
        memorizedData.putAll(productAttributes);

        // Print the stored values (optional for debugging)
        productAttributes.forEach((field, value) -> {
            System.out.println("Memorized " + field + ": " + value);
        });
    }

    @Then("the following Service Line details should not be empty:")
    public void verifyServiceLineDetails(Map<String, String> fieldDetails) {
        new BFONewServiceContractDetailsPageObjects().clickOpenContractsAndCheckServiceLines(fieldDetails);

    }

    @And("I memorize field sold to account as {string}")
    public void iMemorizeFieldSoldToAccountAs(String key) {
        new BFONewServiceContractDetailsPageObjects().memorizeSoldToAccount(key, memorizedData);
    }


    @Then("Check bfo Service Maintenance Contracts Details Fields:")
    public void checkBfoServiceMaintenanceContractsDetailsFields(DataTable dataTable) {
        new BFONewServiceContractDetailsPageObjects().selectBfoTab("Details");
        Map<String, String> contactFields = new HashMap<>(dataTable.asMap(String.class, String.class));
        new BFONewServiceContractDetailsPageObjects().verifyContractDetails(contactFields);
    }

    @And("I navigate to Disposable Email in New window")
    public void iNavigateToDisposableEmailInNewWindow() {
        new BFONewServiceContractDetailsPageObjects().openDisposableEmailPage();
    }

    @And("I memorized Disposable Email as {string}")
    public void iMemorizedDisposableEmailAs(String key) {
        String email = new BFONewServiceContractDetailsPageObjects().getConcatenatedEmail();
        memorizedData.put(key, email);
        System.out.println("Memorized Data" + memorizedData);
    }

    @And("I create new contact from {string} with following values:")
    public void iCreateNewContactFromWithFollowingValues(String accountKey, DataTable dataTable) {
        // Get Sold To Account dynamically from memorizedData
        String soldToAccount = memorizedData.get(accountKey);
        if (soldToAccount == null || soldToAccount.isEmpty()) {
            throw new AssertionError("Sold To Account not found in memorized data for key: " + accountKey);
        }

        // Convert the DataTable into a mutable HashMap for field names and values
        Map<String, String> contactFields = new HashMap<>(dataTable.asMap(String.class, String.class));

        // Replace dynamic values (e.g., Email) with values from memorizedData
        contactFields.replaceAll((fieldName, value) -> {
            if (memorizedData.containsKey(value)) {
                return memorizedData.get(value); // Replace value with memorized data if it exists
            }
            return value; // Otherwise, use the original value
        });

        // Add Sold To Account explicitly to the fields
        contactFields.put("Sold To Account", soldToAccount);

        // Pass the contact fields to the page object to create the new contact
        new BFONewServiceContractDetailsPageObjects().createContact(contactFields, accountKey);

        // Log for debugging purposes
        System.out.println("Created contact with fields: " + contactFields);
    }

    @And("I memorize contact as {string}")
    public void iMemorizeContactAs(String key) {
        String contactName = new BFONewServiceContractDetailsPageObjects().memorizeContact();

        // Store the contact name in the memorizedData map
        memorizedData.put(key, contactName);

        // Log for debugging purposes
        System.out.println("Memorized contact with key '" + key + "': " + contactName);
    }

    @And("I update contact fields in the contract:")
    public void iUpdateContactFieldsInTheContract(DataTable dataTable) {
        // Convert the DataTable into a mutable HashMap for field names and values
        Map<String, String> contactFields = new HashMap<>(dataTable.asMap(String.class, String.class));
        String fieldValue = memorizedData.get("Contact");
        System.out.println("CONTACT" + fieldValue);
        new BFONewServiceContractDetailsPageObjects().updateContact(contactFields, fieldValue);


    }

    @And("I Validate bfo Contract")
    public void iValidateBfoContract() {
        new BFONewServiceContractDetailsPageObjects().validateContract();
    }

    @And("i updated the {string} in Email Section")
    public void iUpdatedTheEmailToDisposable(String key, DataTable dataTable) {
        // Convert the DataTable into a map
        Map<String, String> contactFields = new HashMap<>(dataTable.asMap(String.class, String.class));

        // Update the email with the disposable email value from the data table
        String disposableEmail = memorizedData.get(key);
        new BFONewServiceContractDetailsPageObjects().updateEmailWithDisposable(contactFields, disposableEmail);


    }

    @And("I create bfo new Contract Value Chain Player to Service Contract with following details:")
    public void iCreateBfoNewContractValueChainPlayer(DataTable dataTable) {
        // Convert the DataTable into a mutable HashMap for field names and values
        Map<String, String> contactFields = new HashMap<>(dataTable.asMap(String.class, String.class));
        String fieldValue = memorizedData.get("Contact");
        new BFONewServiceContractDetailsPageObjects().createContactChainPlayers(contactFields, fieldValue);
    }

    @And("I navigates to {string} tab")
    public void iNavigatesToTab(String tabName) {
        new ApplicationCommonMethods().navigateToTab(tabName);
    }

    @And("Click on Save")
    public void clickOnSave() {
        new WorkOrders().clickOnSaveButton();
    }

    @And("memorize the status")
    public void memorizeTheStatus() {
        Service_Contract_StepDefinition.statusValue = WorkOrders.getStatusText();
    }
}
