package bfs.pages.bfo.Pages;

import bfs.pages.bfo.PageObjects.BFOValidateContractPageObjects;
import bfs.pages.bfo.PageObjects.BFO_SFMTabObjects;

public class BFOValidateContract {
    public void validateContract(String validationNotes) {
        BFO_SFMTabObjects sfmTabObjects = new BFO_SFMTabObjects();
        BFOValidateContractPageObjects validateContractPageObjects = new BFOValidateContractPageObjects();
        sfmTabObjects.clickOnValidateContract();
        validateContractPageObjects.setValidationNotes(validationNotes)
                .clickOnSaveButton();
    }
}
