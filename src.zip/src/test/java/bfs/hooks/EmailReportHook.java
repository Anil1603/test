package bfs.hooks;

import bfs.hooks.*;

import org.testng.ISuite;

import org.testng.ISuiteListener;

public class EmailReportHook implements ISuiteListener {

    @Override

    public void onStart(ISuite suite) {

        // No need for implementation in onStart

    }

    @Override

    public void onFinish(ISuite suite) {

        // This method is called when the suite finishes.

        System.out.println("📤 Sending email with the final Extent Report...");

        ReportEmailSender.sendReportEmail();

    }

}

