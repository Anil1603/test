package bfs.pages.bfo.PageObjects;

import bfs.pages.BasePage;

import static com.codeborne.selenide.Condition.enabled;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.*;

public class BFOServiceMaintenanceWorkOrderPageObjects {
    private static final String WORK_ORDER_NAME_TEXTBOX = "//label[contains(text(),'Work Order Name')]/../div/textarea";
    private static final String WORK_ORDER_REASON_TEXTBOX = "//label[contains(text(),'Work Order Reason')]/../div/textarea";
    private static final String CUSTOMER_REQUESTED_DATE_TEXTBOX = "//label[contains(text(),'Customer Requested Date')]/../div//input";
 //   private static final String CUSTOMER_REQUESTED_TIME_TEXT_BOX = "//label[contains(text(),'Customer Requested Time')]/../div//input";
    private static final String LOCATION_TEXTBOX = "//label[contains(text(),'Location *')]/../div//input";
  //  private static final String SKILL_CATEGORY_DROPDOWN = "//label[contains(text(),'Skill Category')]/../div//input";
    private static final String COUNTRY_OF_BACK_OFFICE_DROPDOWN = "//label[contains(text(),'Country of Back Office')]/../div//input";
    private static final String BACK_OFFICE_SYSTEM_DROPDOWN = "//label[contains(text(),'Back Office System')]/../div//input";
    private static final String MIP_FLAG_CHECKBOX = "//div[contains(@class,'MIP_Flag')]//span[@class='slds-checkbox_faux']";

     public BFOServiceMaintenanceWorkOrderPageObjects setWorkOrderName(String workOrderName){
         switchTo().frame($x("//iframe[@title='Service Delivery']"));
         $x(WORK_ORDER_NAME_TEXTBOX).shouldBe(visible,enabled).setValue(workOrderName);
         return this;
     }
        public BFOServiceMaintenanceWorkOrderPageObjects setWorkOrderReason(String workOrderReason){
            $x(WORK_ORDER_REASON_TEXTBOX).shouldBe(visible,enabled).setValue(workOrderReason);
            return this;
        }
        public BFOServiceMaintenanceWorkOrderPageObjects setCustomerRequestedDate(String customerRequestedDate){
            String date =  BasePage.getTodayDate("MM/dd/yyyy");
            $x(CUSTOMER_REQUESTED_DATE_TEXTBOX).shouldBe(visible,enabled).setValue(date);
            return this;
        }
       public BFOServiceMaintenanceWorkOrderPageObjects setLocation(String location){
           $x(LOCATION_TEXTBOX).shouldBe(visible,enabled).setValue(location.split(":")[0]);
           $x("//li[@role='menuitem']//span[contains(text(),'"+location.split(":")[1]+"')]/../../..").shouldBe(visible,enabled).click();
           return this;
       }
       public BFOServiceMaintenanceWorkOrderPageObjects setCountryOfBackOffice(String countryName){
           $x(COUNTRY_OF_BACK_OFFICE_DROPDOWN).shouldBe(visible,enabled).click();
           $x("//span[@title='"+countryName+"']").shouldBe(visible,enabled).click();
           return this;
       }

       public BFOServiceMaintenanceWorkOrderPageObjects setBackOfficeSystem(String backOfficeSystemName){
           $x(BACK_OFFICE_SYSTEM_DROPDOWN).shouldBe(visible,enabled).click();
           $x("//span[@title='"+backOfficeSystemName+"']").shouldBe(visible,enabled).click();
           return this;
       }
         public BFOServiceMaintenanceWorkOrderPageObjects clickOnMIPFlag(){
              $x(MIP_FLAG_CHECKBOX).shouldBe(visible,enabled).doubleClick();
              return this;
         }




}
