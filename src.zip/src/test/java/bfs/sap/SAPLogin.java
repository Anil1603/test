package bfs.sap;

import com.jacob.activeX.ActiveXComponent;
import com.jacob.com.ComThread;
import com.jacob.com.Dispatch;
import com.jacob.com.Variant;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.awt.AWTException;


import java.io.IOException;

public class SAPLogin {
    static ActiveXComponent SAPROTWr;
    static ActiveXComponent GUIApp;
    static ActiveXComponent Connection;
    static ActiveXComponent Session;
    static ActiveXComponent Obj;
    ActiveXComponent SAPGIRD;
    static Dispatch ROTEntry;
    Variant Value;
    static Variant ScriptEngine;
    private static Process p;
    static SAPGeneric sapGenric;
    static Dispatch connection;



    public static void initializeSAP() throws InterruptedException {
        ComThread.InitSTA();

        try {
            p = Runtime.getRuntime().exec("C:\\Program Files (x86)\\SAP\\FrontEnd\\SAPgui\\saplogon.exe");
        } catch (IOException e) {
            e.printStackTrace();
        }
        Thread.sleep(5000);

        SAPROTWr = new ActiveXComponent("SapROTWr.SapROTWrapper");
        ROTEntry = SAPROTWr.invoke("GetROTEntry", "SAPGUI").toDispatch();
        ScriptEngine = Dispatch.call(ROTEntry, "GetScriptingEngine");
        GUIApp = new ActiveXComponent(ScriptEngine.toDispatch());



    }

    public static void loginToTRASystem(String systemName) {
        // SAP Connection Name
        Connection = new ActiveXComponent(
                GUIApp.invoke("OpenConnection", systemName).toDispatch());

        // Initialization for the SAPGeneric
        sapGenric = new SAPGeneric(Connection);
        sapGenric.setSession(new ActiveXComponent(sapGenric.getSession().invoke("FindById", "wnd[0]").toDispatch()));
        Session = sapGenric.getSession();
    }

    public static void closeSAPWithAltF4() {

        try {
            Robot robot = new Robot();

            // Step 1: Press ALT + F4 to close SAP
            robot.keyPress(KeyEvent.VK_ALT);
            robot.keyPress(KeyEvent.VK_F4);
            robot.keyRelease(KeyEvent.VK_F4);
            robot.keyRelease(KeyEvent.VK_ALT);

            Thread.sleep(5000); // Wait for the logoff confirmation popup

            // Step 2: Press LEFT ARROW to select "Yes" (or appropriate option)
            robot.keyPress(KeyEvent.VK_TAB);
            robot.keyRelease(KeyEvent.VK_TAB);

            Thread.sleep(5000); // Small delay for stability

            // Step 3: Press ENTER to confirm logoff
            robot.keyPress(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_ENTER);

            System.out.println("SAP Log Off process completed.");

        } catch (AWTException | InterruptedException e) {
            System.out.println("Error closing SAP: " + e.getMessage());
        }

    }
    public static void acceptPopUp() {

        try {
            Robot robot = new Robot();

            // Step 1: Press ALT + F4 to close SAP
//            robot.keyPress(KeyEvent.VK_ALT);
//            robot.keyPress(KeyEvent.VK_F4);
//            robot.keyRelease(KeyEvent.VK_F4);
//            robot.keyRelease(KeyEvent.VK_ALT);

            Thread.sleep(5000); // Wait for the logoff confirmation popup

            // Step 2: Press LEFT ARROW to select "Yes" (or appropriate option)
            robot.keyPress(KeyEvent.VK_TAB);
            robot.keyRelease(KeyEvent.VK_TAB);

            Thread.sleep(5000); // Small delay for stability

            // Step 3: Press ENTER to confirm logoff
            robot.keyPress(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_ENTER);


            System.out.println("SAP accept popup");
            Thread.sleep(15000);

        } catch (AWTException | InterruptedException e) {
            System.out.println("Error pop SAP: " + e.getMessage());
        }

    }
    public static void enter() {

        try {
            Robot robot = new Robot();
            Thread.sleep(5000); // Wait for the logoff confirmation popup
            robot.keyPress(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_ENTER);

            Thread.sleep(5000); // Small delay for stability

        } catch (AWTException | InterruptedException e) {
            System.out.println("Error no : " + e.getMessage());
        }

    }
    public static void acceptSavePopUp() {

        try {
            Robot robot = new Robot();

            // Step 1: Press ALT + F4 to close SAP
//            robot.keyPress(KeyEvent.VK_ALT);
//            robot.keyPress(KeyEvent.VK_F4);
//            robot.keyRelease(KeyEvent.VK_F4);
//            robot.keyRelease(KeyEvent.VK_ALT);

            Thread.sleep(5000); // Wait for the logoff confirmation popup

            // Step 2: Press LEFT ARROW to select "Yes" (or appropriate option)
            robot.keyPress(KeyEvent.VK_TAB);
            robot.keyRelease(KeyEvent.VK_TAB);
            Thread.sleep(5000);

            robot.keyPress(KeyEvent.VK_TAB);
            robot.keyRelease(KeyEvent.VK_TAB);
            Thread.sleep(5000);
            robot.keyPress(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_ENTER);


            System.out.println("SAP accept popup");

        } catch (AWTException | InterruptedException e) {
            System.out.println("Error pop SAP: " + e.getMessage());
        }

    }
    public static void acceptDisplayPopUp() {

        try {
            Robot robot = new Robot();

            // Step 1: Press ALT + F4 to close SAP
//            robot.keyPress(KeyEvent.VK_ALT);
//            robot.keyPress(KeyEvent.VK_F4);
//            robot.keyRelease(KeyEvent.VK_F4);
//            robot.keyRelease(KeyEvent.VK_ALT);

            Thread.sleep(5000); // Wait for the logoff confirmation popup

            // Step 2: Press LEFT ARROW to select "Yes" (or appropriate option)
            robot.keyPress(KeyEvent.VK_TAB);
            robot.keyRelease(KeyEvent.VK_TAB);
            Thread.sleep(5000);
            robot.keyPress(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_ENTER);

            Thread.sleep(5000);
            robot.keyPress(KeyEvent.VK_TAB);
            robot.keyRelease(KeyEvent.VK_TAB);
            Thread.sleep(5000);
            robot.keyPress(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_ENTER);

            Thread.sleep(5000);
            robot.keyPress(KeyEvent.VK_TAB);
            robot.keyRelease(KeyEvent.VK_TAB);
            Thread.sleep(5000);
            robot.keyPress(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_ENTER);

            Thread.sleep(5000);
            robot.keyPress(KeyEvent.VK_TAB);
            robot.keyRelease(KeyEvent.VK_TAB);
            Thread.sleep(5000);
            robot.keyPress(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_ENTER);



            System.out.println("SAP accept display popup");

        } catch (AWTException | InterruptedException e) {
            System.out.println("Error pop SAP: " + e.getMessage());
        }

    }
    public static void clickSalesDocument() {

        try {
            Robot robot = new Robot();

            // Step 1: Press and release ALT
            robot.keyPress(KeyEvent.VK_ALT);
            robot.keyRelease(KeyEvent.VK_ALT);
            Thread.sleep(500); // Small delay to allow menu to open (if any)

            // Step 2: Press and release D
            robot.keyPress(KeyEvent.VK_D);
            robot.keyRelease(KeyEvent.VK_D);

            System.out.println("Pressed ALT then D");

        } catch (AWTException | InterruptedException e) {
            System.out.println("Error while pressing ALT then D: " + e.getMessage());
        }
    }
    public static void clickOrder() {

        try {
            Robot robot = new Robot();

            // Step 1: Press and release ALT
            robot.keyPress(KeyEvent.VK_ALT);
            robot.keyRelease(KeyEvent.VK_ALT);
            Thread.sleep(500); // Small delay to allow menu to open (if any)

            // Step 2: Press and release D
            robot.keyPress(KeyEvent.VK_D);
            robot.keyRelease(KeyEvent.VK_D);

            System.out.println("Pressed ALT then D");

        } catch (AWTException | InterruptedException e) {
            System.out.println("Error while pressing ALT then D: " + e.getMessage());
        }
    }

    public static void clickChangeSalesDocument() {

        try {
            Robot robot = new Robot();
            Thread.sleep(5000);
            // Step 1: Press and release ALT
            robot.keyPress(KeyEvent.VK_ALT);
            robot.keyRelease(KeyEvent.VK_ALT);
            Thread.sleep(5000); // Small delay to allow menu to open (if any)

            // Step 2: Press and release D
            robot.keyPress(KeyEvent.VK_H);
            robot.keyRelease(KeyEvent.VK_H);

            System.out.println("Pressed ALT then H");

        } catch (AWTException | InterruptedException e) {
            System.out.println("Error while pressing ALT then H: " + e.getMessage());
        }
    }




}