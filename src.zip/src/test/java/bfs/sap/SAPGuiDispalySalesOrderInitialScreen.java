package bfs.sap;

import com.jacob.activeX.ActiveXComponent;
import bfs.CONSTANTS;
import utilities.CommonUtils;

import java.io.IOException;
import java.util.Random;

import static bfs.sap.SAPLogin.Session;

//import static ecocare.sap.test.LoginTest.Session;

public class SAPGuiDispalySalesOrderInitialScreen {
    public static void searchSalesOrder(String salesOrder) throws InterruptedException, IOException {
        Thread.sleep(2000);

        // Set sales order number
        ActiveXComponent vbeln = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/ctxtCAUFVD-AUFNR").toDispatch());
        vbeln.setProperty("text", salesOrder);
        vbeln.setProperty("caretPosition", 10);
        Thread.sleep(2000);
        String screenshotBase64 = CommonUtils.addScreen();
        String filePath = System.getProperty("user.dir") + "\\Screenshots\\screenshot.png";
        CommonUtils.convertBase64ToImage(screenshotBase64, filePath);
        byte[] screenshotBytes = java.nio.file.Files.readAllBytes(java.nio.file.Paths.get(filePath));
        CONSTANTS.scenario.attach(screenshotBytes, "image/png", "Screenshot-" + new Random().nextInt());
        Thread.sleep(3000);
        ActiveXComponent btnSearch = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/btnBT_SUCH").toDispatch());
        btnSearch.invoke("press");
        Thread.sleep(3000);
//        String screenshotBase64 = CommonUtils.addScreen();
//        String filePath = System.getProperty("user.dir") + "\\Screenshots\\screenshot.png";
//        CommonUtils.convertBase64ToImage(screenshotBase64, filePath);
//        byte[] screenshotBytes = java.nio.file.Files.readAllBytes(java.nio.file.Paths.get(filePath));
//        CONSTANTS.scenario.attach(screenshotBytes, "image/png", "Screenshot-" + new Random().nextInt());
//        Thread.sleep(3000);
    }
}
