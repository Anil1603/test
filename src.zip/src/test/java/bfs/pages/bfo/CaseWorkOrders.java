package bfs.pages.bfo;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;

import static bfs.pages.BasePage.waitForPageLoad;
import static bfs.pages.bfo.ApplicationCommonMethods.*;
import static com.codeborne.selenide.Condition.enabled;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.*;

public class CaseWorkOrders {

    // XPaths for elements
    private static final String CREATE_WORK_ORDER_XPATH = "//button[text()='Create WO']";
    private static final String DROPDOWN_XPATH_TEMPLATE = "//span[text()='%s']/parent::span/parent::label/following-sibling::div/div/div/input[contains(@id, 'sfm-picklist')]";
    private static final String DROPDOWN_ITEM_XPATH_TEMPLATE = "//li[text()='%s']";
    private static final String LOCATION_INPUT_XPATH_TEMPLATE = "//span[contains(text(), '%s')]/parent::span/parent::label/following-sibling::div/div/div//input";
    private static final String TRIGGER_SEARCH_XPATH_TEMPLATE = "//span[contains(text(), '%s')]/parent::span/parent::label/following-sibling::div//div[@data-ref='triggerWrap']/div/following-sibling::div[contains(@id, 'trigger-search')]";
    private static final String SAVE_WORK_ORDER_XPATH = "//span[text()='Save']/../../parent::a";
    private static final String CASE_WORk_ORDER_FRAME = "//iframe[@title='Service Delivery']";


    public CaseWorkOrders clickCreateWorkOrder() {
        clickElement(CREATE_WORK_ORDER_XPATH, "Error clicking on Create Work Order");
        waitForGivenTime(8000);
        waitForPageLoad();
        waitForGivenTime(10000);
        switchToFrame(CASE_WORk_ORDER_FRAME);
        return this;
    }

    public CaseWorkOrders selectServicesBusinessUnit(String labelText, String value) {
        selectDropdownValueSafely(labelText, value, "Error selecting on Service Business Unit");
        return this;
    }

    public CaseWorkOrders countryOfBackOffice(String labelText, String value) {
        selectDropdownValueSafely(labelText, value, "Error selecting on Country Of Back Office");
        return this;
    }

    public CaseWorkOrders backOfficeSystem(String labelText, String value) {
        selectDropdownValueSafely(labelText, value, "Error selecting on Back Office System");
        return this;
    }

    public CaseWorkOrders selectLocation(String labelText, String textToEnter) {
        try {
            enterTextInField(labelText, LOCATION_INPUT_XPATH_TEMPLATE, textToEnter);
            clickElement(String.format(TRIGGER_SEARCH_XPATH_TEMPLATE, labelText), "Error clicking trigger search element");
            clickDynamicLink(textToEnter);
        } catch (Exception e) {
            handleException("Error selecting location", e);
        }
        return this;
    }

    public CaseWorkOrders clickSaveWorkOrder() {
        waitForGivenTime(3000);
        clickElement(SAVE_WORK_ORDER_XPATH, "Error clicking on Saving Work Order");
        waitForGivenTime(10000);
        return this;
    }

    private void selectDropdownValueSafely(String labelText, String value, String errorMessage) {
        try {
            selectDropdownValue(labelText, DROPDOWN_XPATH_TEMPLATE, DROPDOWN_ITEM_XPATH_TEMPLATE, value);
        } catch (Exception e) {
            handleException(errorMessage, e);
        }
    }

    private void clickElement(String xpath, String errorMessage) {
        try {
            SelenideElement element = $x(xpath);
            waitForElementToBeVisibleAndClickable(element);
            element.click();
        } catch (Exception e) {
            handleException(errorMessage, e);
        }
    }

    private void enterTextInField(String labelText, String inputXpathTemplate, String textToEnter) {
        try {
            SelenideElement inputField = $x(String.format(inputXpathTemplate, labelText));
            inputField.shouldBe(visible, enabled).scrollIntoView(true).click();
            inputField.clear();
            inputField.setValue(textToEnter);
        } catch (Exception e) {
            handleException("Error entering text into field", e);
        }
    }


    private void clickDynamicLink(String linkText) {
        try {
            waitForGivenTime(4000);
            ElementsCollection links = $$x(String.format("//a[text()='%s']", linkText));

            if (!links.isEmpty()) { // Check if at least one link exists
                for (SelenideElement link : links) {
                    if (link.isDisplayed()) {
                        link.scrollIntoView("{block: \"center\"}"); // Prevent excessive scrolling
                        try {
                            link.click(); // Normal click
                        } catch (Exception e) {
                            executeJavaScript("arguments[0].click();", link); // JavaScript click fallback
                        }
                        return; // Stop after clicking the first visible link
                    }
                }
            }
        } catch (Exception e) {
            handleException("Error clicking dynamic link: " + linkText, e);
        }
    }
}


//    private void clickDynamicLink(String linkText) {
//        try {
//            SelenideElement link = $x(String.format("//a[text()='%s']", linkText));
//            link.shouldBe(visible, enabled).scrollIntoView(true).click();
//        } catch (Exception e) {
//            handleException("Error clicking dynamic link: " + linkText, e);
//        }
//    }
//
//
//}
