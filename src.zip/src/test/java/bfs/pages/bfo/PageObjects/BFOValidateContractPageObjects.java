package bfs.pages.bfo.PageObjects;

import static com.codeborne.selenide.Condition.enabled;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$x;
import static com.codeborne.selenide.Selenide.switchTo;

public class BFOValidateContractPageObjects {
    private static final String VALIDATION_NOTES_TEXTBOX = "//div[@id='expando-unique-id']//label[contains(text(),'Validation Notes')]/..//textarea";

    private static final String ORGANIZATION_TEXTBOX = "//label[contains(text(),'Organization')]/..//input[@placeholder='Search']";

    private static final String SAVE_BUTTON = "//button[@type='button']/span[contains(text(),'Save') and @class='Button__label']";

    public BFOValidateContractPageObjects setValidationNotes(String notes){
     //   BasePage.switchToChildFrame();
        switchTo().frame($x("//iframe[@title='Service Delivery']"));
        $x(VALIDATION_NOTES_TEXTBOX).shouldBe(visible,enabled).setValue(notes);
        return this;
    }
    public BFOValidateContractPageObjects setOrganizationName(String organization){
        $x(ORGANIZATION_TEXTBOX).shouldBe(visible,enabled).setValue(organization);
        return this;
    }
    public BFOValidateContractPageObjects clickOnSaveButton(){
        $x(SAVE_BUTTON).shouldBe(visible,enabled).click();
        return this;
    }



}
