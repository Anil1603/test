package bfs.pages.bfo.Pages;

import bfs.pages.bfo.PageObjects.BFOServiceLinePageObjects;

public class BFOServiceLinePage {
    public void searchAndSelectTheProduct(String productName) {
        BFOServiceLinePageObjects serviceLinePageObjects = new BFOServiceLinePageObjects();
        serviceLinePageObjects.setProductNameOnSearchPlaceHolderField(productName)
                .clickOnSkuWithServicePlanCheckBox()
                .clickOnGoButton()
                .clickOnProductNameCheckBox(productName);
    }
}
