Feature: Split work order.
  As a user
  I want to navigate to the application and split work order
  So that I can split work order efficiently

  Scenario Outline: Split work order for a specific Work Order
    Given I work in application "BFO" and environment "UAT"
    And I login to "BFO" as user "coordinator-1660@bridge-fo.com.uatbfo26"
    When I navigate to "SE - Services Lightning" from app launcher
    And I wait for "10" seconds
    And I navigate to "Work Orders" from app launcher
    And I click on bfo button "New"
    And I fill work order details for creating new work order from Work Order Page:
      |Field Name                            | Field Value                               |
      |Select Record Type                    | Standalone Work Order                     |
      |Installed At Account                  | 0001340233:Ampcontrol (QLD) Pty Ltd       |
      |Location                              | 0045144542:Ampcontrol QLD Pty Ltd         |
      |Work Order Type                       | Repair                                    |
#    |Work Order Sub-Type                   |                                           |
      |Contact                               |   chandra.vamsi kumar                     |
      |Customer Requested Date               | today                                     |
      |Country of Back Office                | Australia                                 |
      | Back Office System                   |SAP Bridge AP                              |
      |Work Order Category                   |Onsite                                     |
      |Services Business Unit                |POWER SYSTEMS                              |
      |Is Billable                           | Yes                                       |
      |Customer Reference Number             |1234                                       |
      |Priority                              | Normal-Medium                             |
#    |Non Billing Reason                    |                                           |
      |Service Commercial Ref                |QWPFSRVPLNNSGEN                            |
#    |Skill Category                        |                                           |
      |Work Order Reason                     | Testing                                   |
      |Work Order Name                       | Testing                                   |
      |Sold To Account                       |0001340233:Ampcontrol (QLD) Pty Ltd        |
    Then user should be able to see the work order number and memorize work order number
    And I should see the work order status as "New" in work order page
#    And the user selects the "<Tab Name>" tab in Work Order Details
#    And the user perform "Search and Create Installed Product"
    And the user selects the "<Tab Name>" tab in Work Order Details
    And the user perform "Search and Create Installed Product"
    Then the added Installed Products should be displayed
    And memorize the Main IP
    And I click on "Create/Update Work Order" button from SFM Tab
#    And I click on "Sync" button from Sync page
    And I check the message "SUCCESS : INITIATED SYNC" on sync window
    And I click on "Ok" button on sync window
    Then I should see the work order status as "Unscheduled" in work order page
#    Given I work in application "BFO" and environment "UAT"
#    When I login to "bfo" as user "coordinator-1660@bridge-fo.com.uat24"
#    And the user selects "<Menu Item>" from the Search menu
#    And the user enters "<Work Order>" in Global Search
#    And the user selects the "<Work Order>" from search results
#    And the user selects the "<Tab Name>" tab in Work Order Details
#    And the user perform "Search and Create Installed Product"
#    Then the added Installed Products should be displayed
#    And the user selects the "<Tab Name>" tab in Work Order Details
    And the user selects the "Split Work Order" tab in SFM
    And the user enters "Work Order Reason" as "<Reason>"
    And the user selects date from "Customer Requested Date" from Split Work Order
    And the user deletes the Main IP from Service Installed Product
    And the user selects one of "MIP Flag"
    And the user selects Save Split Work Order
    And the user selects the "<Tab Name>" tab in Work Order Details
    Then the split work orders should be displayed
#    When the user selects the "<Work Order>" from search results
    And the user selects "<Menu Item>" from the Search menu
    When the user search and selects the "<Menu Item>"
    And the user selects the "<Tab Name>" tab in Work Order Details
    Then the Main IP should be displayed



    Examples:
      | Menu Item 	  | Work Order 	  | Tab Name      | Reason |
      | Work Orders     | WO-12263832   |	IP and Skills | Test   |


