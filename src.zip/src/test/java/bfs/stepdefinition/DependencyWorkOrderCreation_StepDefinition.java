package bfs.stepdefinition;

import bfs.CONSTANTS;
import bfs.pages.bfo.PageObjects.CreateDependencyGroupfromWorkOrder_page;
import bfs.pages.bfo.PageObjects.DependencyGroup_Page;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;

import java.util.List;
import java.util.Map;

public class DependencyWorkOrderCreation_StepDefinition {

    @And("I created dependent work order with following details")
    public void iCreatedDependentWorkOrderWithFollowingDetails(DataTable table) {
//        Map<String, String> data = table.asMap(String.class, String.class);
        List<Map<String, String>> dataAll = table.asMaps(String.class, String.class);
        for (Map<String, String> data : dataAll) {
            String primaryWO = data.get("PrimaryWO");
            String secondaryWO = data.get("SecondryWO");
            String dependencyGroupName = data.get("Dependency Group Name");
            String description = data.get("Description");
            String timeDependency = data.get("Time Dependency");

            String primary_wo = CONSTANTS.memorizedData.get(primaryWO);
            String secondary_wo = CONSTANTS.memorizedData.get(secondaryWO);

            new CreateDependencyGroupfromWorkOrder_page().CreateDependencyGroupfromWorkOrder(
                    dependencyGroupName, description, primary_wo, secondary_wo, timeDependency);
        }
    }

    @And("I memorize Dependency Group Number as {string}")
    public void iMemorizeDependencyGroupNumberAs(String key) {
        String dependencyGroupNumber = new DependencyGroup_Page().getDependencyGroupNumber();
        CONSTANTS.memorizedData.put(key, dependencyGroupNumber);
        System.out.println("Dependency Group Number: " + CONSTANTS.memorizedData.get(key));
    }

    @And("I memorize Work Order Dependency Number as {string}")
    public void iMemorizeWorkOrderDependencyNumberAs(String key) {
        String workOrderDependencyNumber = new DependencyGroup_Page().getWorkOrderDependencyNumber();
        CONSTANTS.memorizedData.put(key, workOrderDependencyNumber);
        System.out.println("Work Order Dependency Number: " + CONSTANTS.memorizedData.get(key));
    }




}
