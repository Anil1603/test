package bfs.pages.bfo.PageObjects;

import bfs.pages.BasePage;
import com.codeborne.selenide.ClickOptions;
import com.codeborne.selenide.SelenideElement;
import com.codeborne.selenide.WebDriverRunner;
import org.junit.Assert;
import org.kohsuke.rngom.parse.host.Base;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

import java.time.Duration;

import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$x;

public class BFO_CustomerConfirmedPageObjects {

    private static final String CUSTOMER_CONFIRMED_TAB = "//li[@data-name='Customer Confirmed']";
    private static final String MARK_WORD_ORDER_STATUS_BUTTON = "//div//button//span[contains(text(),'Mark')]";
    private static final String DONE_BUTTON = "div.modal-footer.slds-modal__footer>button[type='submit']";

    public BFO_CustomerConfirmedPageObjects clickOnCustomerConfirmedTab() {
        $x(CUSTOMER_CONFIRMED_TAB).shouldBe(visible).click(ClickOptions.usingJavaScript());
        return this;
    }

    public BFO_CustomerConfirmedPageObjects clickOnMarkAsCurrentWorkOrderStatus() {
        $x(MARK_WORD_ORDER_STATUS_BUTTON).shouldBe(visible).click(ClickOptions.usingJavaScript());
        return this;
    }

    public BFO_CustomerConfirmedPageObjects clickOnDoneButton() {
        $(DONE_BUTTON).shouldBe(visible, Duration.ofSeconds(30)).click(ClickOptions.usingJavaScript());
        return this;
    }

    public String getWorkOrderStatus() {
    //    SelenideElement ele = $x("//span[contains(text(),'Work Order Status')]/../div//span").shouldBe(visible);
        SelenideElement ele = $x("//span[@class='current slds-path__stage']/..//span[@class='title slds-path__title']").shouldBe(visible);
        BasePage.highLightElement(ele);
        Assert.assertTrue(ele.isDisplayed());
        return ele.getText();
    }

}
