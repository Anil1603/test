package bfs.hooks;
import com.codeborne.selenide.Configuration;
import com.codeborne.selenide.WebDriverRunner;
import configuration.ConfigManager;
import io.cucumber.java.*;
import org.apache.commons.io.FilenameUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import bfs.CONSTANTS;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.safari.SafariOptions;
import utilities.BorwserStackAPIUtils;
import utilities.CloudSetup;
import utilities.MyScreenRecorder;
// import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.IOException;

import static bfs.CONSTANTS.EXECUTION_ID;
import static com.codeborne.selenide.Selenide.open;
import static com.codeborne.selenide.Selenide.webdriver;
import static com.codeborne.selenide.WebDriverRunner.getWebDriver;


public class Hooks {


    @Before(order = 0) //New Framework Change
    public void setUp() {
        String executionType = System.getProperty("EXECUTION_TYPE", "local");  // Read from TestNG XML
        System.out.println("Execution Type: " + executionType);

        switch (executionType.toLowerCase()) {
            case "local" -> setLocalExecution();
            case "remote" -> setRemoteExecution();
            default -> throw new IllegalStateException("Unexpected value: " + executionType);
        }
    }
    @Before(order = 1) // New Framework Changes
    public void recordingStart(Scenario scenario) {
        String executionType = System.getProperty("EXECUTION_TYPE", "local"); // Fetch from system properties
        String scenarioID = getScenarioID(scenario);
        String scenarioName = scenario.getName();

        if ("remote".equalsIgnoreCase(executionType)) {  // Avoiding null pointer
            JavascriptExecutor jse = (JavascriptExecutor) WebDriverRunner.getWebDriver();
            jse.executeScript("browserstack_executor: {\"action\": \"setSessionName\", \"arguments\": {\"name\":\"" + scenarioID + "_" + scenarioName + " \" }}");
        }
        else if ("local".equalsIgnoreCase(executionType)) {
            try {
                MyScreenRecorder.startRecording(FilenameUtils.getName(scenario.getUri().toString()));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    private static String getScenarioID(Scenario scenario) {
        String projectKey = "BFSTST";
        String[] tags= scenario.getSourceTagNames().stream().toList().toArray(new String[0]);
        if(tags.length>0){
            EXECUTION_ID = tags[0].replace("@","");
            System.out.println(EXECUTION_ID);
            for(String tag :tags){
                System.out.println(tag);
                if(tag.startsWith("@"+projectKey) && !EXECUTION_ID.equalsIgnoreCase(tag.replace("@",""))){
                    CONSTANTS.SCENARIO_ID=tag.replace("@","");
                    break;
                }
            }
        }
        return CONSTANTS.SCENARIO_ID;
    }

    public byte[] getByteScreenshot()
    {
        return ((TakesScreenshot) getWebDriver()).getScreenshotAs(OutputType.BYTES);
    }
    @AfterStep
    public void afterStep(Scenario scenario){
        if(CONSTANTS.captureScreen)
            scenario.attach(getByteScreenshot(), "image/png", scenario.getName());
        CONSTANTS.captureScreen=false;
    }


    @After //New Framework Changes
    public void tearDown(Scenario scenario) {
        String executionType = System.getProperty("EXECUTION_TYPE", "local"); // Fetch execution type safely
        String session = WebDriverRunner.driver().getSessionId().toString();

        // Stop recording for local execution
        if ("local".equalsIgnoreCase(executionType)) {
            try {
                MyScreenRecorder.stopRecording();
            } catch (Exception e) {
                throw new RuntimeException("Error stopping screen recording", e);
            }
        }

        // Capture and attach screenshot for failed scenarios
        if (scenario.isFailed()) {
            scenario.attach(getByteScreenshot(), "image/png", scenario.getName());

            if ("remote".equalsIgnoreCase(executionType)) {
                BorwserStackAPIUtils.setExecutionResult(session, "failed", "Scenario failed.");
            }
        } else {
            scenario.attach(getByteScreenshot(), "image/png", scenario.getName());

            if ("remote".equalsIgnoreCase(executionType)) {
                BorwserStackAPIUtils.setExecutionResult(session, "passed", "Scenario has passed.");
            }
        }

        // Quit WebDriver session
        WebDriverRunner.getWebDriver().quit();
//        ReportEmailSender.sendReportEmail();
    }


    private void setCommonConfiguration(){
        Configuration.browser=ConfigManager.getProperty("BROWSER_NAME","application");
        setBrowserOptions();
        Configuration.browserVersion=ConfigManager.getProperty("BROWSER_VERSION","application");
        Configuration.timeout = Long.parseLong(ConfigManager.getProperty("TIME_OUT","application"));
        // Set the interval between polling for element presence
        Configuration.pollingInterval = 1000;
        Configuration.browserSize = ConfigManager.getProperty("BROWSER_SIZE","application");
    }

    private static void setBrowserOptions() {
        switch (ConfigManager.getProperty("BROWSER_NAME","application").toLowerCase()){
            case "chrome"->{


                Map<String, Object> prefs = new HashMap<String, Object>();
                prefs.put("profile.default_content_setting_values.notifications", 2);
                ChromeOptions options = new ChromeOptions();
                // WebDriverManager.chromedriver().setup();
                // options.addArguments("--disable-popup-blocking");
                options.setExperimentalOption("prefs", prefs);
                options.addArguments("--disable-notification");
                options.addArguments("--start-maximized");
                options.addArguments("--disable-infobars");
                options.addArguments("--disable-extensions");
                options.addArguments("--disable-gpu");
                options.addArguments("--no-sandbox");
                options.addArguments("--disable-dev-shm-usage");
                // Remove or specify a unique user data directory
                // options.addArguments("--user-data-dir=./drivers/");

//                try {
//                    Path tempDirPath = Paths.get("temp/chrome_user_data");
//                    if (!Files.exists(tempDirPath)) {
//                        Files.createDirectories(tempDirPath);
//                    }
//                    String temp_dir = tempDirPath.toString();
////                    options.addArguments("--user-data-dir=" + temp_dir);
//                } catch (IOException e) {
//                    e.printStackTrace();
//                    throw new RuntimeException("Failed to create temp directory for Chrome user data", e);
//                }

//                WebDriver driver = new ChromeDriver(options);
//                if (driver != null) {
//                    // Quit the existing session
//                    driver.quit();
//                }
//                WebDriverRunner.setWebDriver(driver);
                // options.addArguments("--headless=new");
                Configuration.browserCapabilities = options;
//                driver.quit();
            }
            case "firefox"->{
                FirefoxOptions options = new FirefoxOptions();
                //options.addArguments("-headless");
                Configuration.browserCapabilities = options;
            }
            case "edge"->{
                EdgeOptions  options = new EdgeOptions();
                //options.addArguments("--headless=new");
                Configuration.browserCapabilities = options;
            }
            case "safari"->{
                SafariOptions options = new SafariOptions();

            }
        }
    }

    private void  setLocalExecution(){

//         System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
//          System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/drivers/chromedriver.exe");
        String os = System.getProperty("os.name").toLowerCase();

        if (os.contains("win")) {
            Configuration.headless = false;
            System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/drivers/chromedriver");
        } else {
            Configuration.headless = true;
            System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/drivers/chromedriver");
//            System.out.println("ChromeDriver Path: " + System.getProperty("user.dir") + "/drivers/chromedriver");

        }
        Map<String, Object> prefs = new HashMap<String, Object>();
        String projectRoot = System.getProperty("user.dir");
        String downloadPath = projectRoot + File.separator + "downloads";
        Configuration.downloadsFolder = downloadPath;
        prefs.put("download.default_directory", downloadPath);
        prefs.put("download.prompt_for_download", false);
        prefs.put("download.directory_upgrade", true);
        prefs.put("safebrowsing.enabled", true);
        prefs.put("savefile.default_directory", downloadPath);
        prefs.put("download_restrictions", 0);
        prefs.put("download.use_build_in_sandbox", false);
        prefs.put("automatic_downloads",1);
        prefs.put("popups",0);
        prefs.put("notifications",2);


//        Map<String,Object> contentSettings = new HashMap<>();
//        contentSettings.put("automatic_downloads",1);
//        contentSettings.put("popups",0);
//        contentSettings.put("notifications",2);
//        prefs.put("profile.default_content_settings",contentSettings);
////        prefs.put("profile.default_content_setting_values.notifications", 2);
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--disable-popup-blocking");
        // options.addArguments("--user-data-dir=/tmp/chrome-user-data-" + System.currentTimeMillis());
        //options.addArguments("--disable-notification");
        options.setExperimentalOption("prefs", prefs);
        options.addArguments("--headless=new");
        Configuration.browserCapabilities = options;
//        Configuration.headless = false;
        setCommonConfiguration();
        open();
    }
    private void setRemoteExecution(){
        Configuration.browser=ConfigManager.getProperty("BROWSER_NAME","application");
        Configuration.timeout = Long.parseLong(ConfigManager.getProperty("TIME_OUT","application"));
        Configuration.pollingInterval = 1000;
        Configuration.browserVersion= ConfigManager.getProperty("BROWSER_VERSION","application");
        String URL ="https://" + ConfigManager.getProperty("USERNAME","browserstack") + ":"
                + ConfigManager.getProperty("AUTOMATE_KEY","browserstack")
                +ConfigManager.getProperty("URL","browserstack");
        Configuration.browserCapabilities= CloudSetup.setBrowserStackConfiguration();
        Configuration.remote=URL;
        open();

    }

    public static void setDebugExecution() {
        Configuration.browser="chrome";
        Configuration.timeout=5000;
        ChromeOptions options = new ChromeOptions();
        options.setExperimentalOption("debuggerAddress", "127.0.0.1:9222");
        options.addArguments("--disable-popup-blocking");
        ChromeDriver driver = new ChromeDriver(options);
        WebDriverRunner.setWebDriver(driver);
        Configuration.browserCapabilities = options;
        open();
    }

}