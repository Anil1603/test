package bfs.pages.bfo.PageObjects;

import bfs.CONSTANTS;
import com.codeborne.selenide.Selenide;
import org.openqa.selenium.By;

import java.time.Duration;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.*;

public class BFOMyTeamAssignedFSRPageObjects {
    private static final String WORK_ORDER_NUMBER_WITH_SERVICE_COMPLETED = "//a[text()='%s']";

    public BFOMyTeamAssignedFSRPageObjects clickOnWorkOrderNumberWithServiceCompleted(String workOrderNumber){
//        workOrderNumber = "WO-13215740"; // todo delete
        $x("//iframe[@title='Report Viewer']").shouldBe(visible, Duration.ofSeconds(60));
        switchTo().frame($x("//iframe[@title='Report Viewer']"));
        Selenide.sleep(10000);
        By workOrderNumberWithServiceCompleted = By.xpath(String.format(WORK_ORDER_NUMBER_WITH_SERVICE_COMPLETED,workOrderNumber));
        $(workOrderNumberWithServiceCompleted).scrollIntoView(true).shouldBe(visible,enabled,interactable).click();
        CONSTANTS.captureScreen = true;
        Selenide.sleep(3000);
        switchTo().defaultContent();
        return this;
    }
}
