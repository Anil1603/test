package bfs.sap;

import com.jacob.activeX.ActiveXComponent;
import bfs.CONSTANTS;
import org.junit.Assert;
import utilities.CommonUtils;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Random;

import static bfs.sap.SAPLogin.*;

public class SAPStandardOrderOverviewScreen {
 //   static ActiveXComponent Session;
//    static SAPGeneric sapGenric;
    /*
    public static void checkAllItemsFollowingLIG() throws InterruptedException {
        Thread.sleep(10000);
        ActiveXComponent table = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/tabsTAXI_TABSTRIP_OVERVIEW/tabpT\\01/ssubSUBSCREEN_BODY:SAPMV45A:4400/subSUBSCREEN_TC:SAPMV45A:4900/tblSAPMV45ATCTRL_U_ERF_AUFTRAG").toDispatch());
        ActiveXComponent columns = new ActiveXComponent(table.invoke("columns").toDispatch());
        ActiveXComponent column = new ActiveXComponent(columns.invoke("elementAt", 26).toDispatch());
        column.setProperty("width", 20);
        // Set focus on dropdown
        ActiveXComponent dropdown_0 = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/tabsTAXI_TABSTRIP_OVERVIEW/tabpT\\01/ssubSUBSCREEN_BODY:SAPMV45A:4400/subSUBSCREEN_TC:SAPMV45A:4900/tblSAPMV45ATCTRL_U_ERF_AUFTRAG/cmbVBAP-ABGRU[26,0]").toDispatch());
        dropdown_0.invoke("setFocus");
        String test_0 = dropdown_0.getPropertyAsString("text");
        System.out.println(test_0.isBlank());
        ActiveXComponent dropdown_1 = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/tabsTAXI_TABSTRIP_OVERVIEW/tabpT\\01/ssubSUBSCREEN_BODY:SAPMV45A:4400/subSUBSCREEN_TC:SAPMV45A:4900/tblSAPMV45ATCTRL_U_ERF_AUFTRAG/cmbVBAP-ABGRU[26,1]").toDispatch());
        dropdown_1.invoke("setFocus");
        String test_1 = dropdown_1.getPropertyAsString("text");
        System.out.println(test_1);
        ActiveXComponent dropdown_2 = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/tabsTAXI_TABSTRIP_OVERVIEW/tabpT\\01/ssubSUBSCREEN_BODY:SAPMV45A:4400/subSUBSCREEN_TC:SAPMV45A:4900/tblSAPMV45ATCTRL_U_ERF_AUFTRAG/cmbVBAP-ABGRU[26,2]").toDispatch());
        dropdown_2.invoke("setFocus");
        String test_2 = dropdown_2.getPropertyAsString("text");
        System.out.println(test_2);
    }
    */
    public static void checkAllItemsFollowingLIG(List<Map<String, String>> items) throws InterruptedException, IOException {
        /*
        Thread.sleep(10000);
        ActiveXComponent table = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/tabsTAXI_TABSTRIP_OVERVIEW/tabpT\\01/ssubSUBSCREEN_BODY:SAPMV45A:4400/subSUBSCREEN_TC:SAPMV45A:4900/tblSAPMV45ATCTRL_U_ERF_AUFTRAG").toDispatch());
        ActiveXComponent columns = new ActiveXComponent(table.invoke("columns").toDispatch());

        for (int i = 0; i < items.size(); i++) {
            ActiveXComponent column = new ActiveXComponent(columns.invoke("elementAt", 26).toDispatch());
            column.setProperty("width", 20);

            ActiveXComponent dropdown = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/tabsTAXI_TABSTRIP_OVERVIEW/tabpT\\01/ssubSUBSCREEN_BODY:SAPMV45A:4400/subSUBSCREEN_TC:SAPMV45A:4900/tblSAPMV45ATCTRL_U_ERF_AUFTRAG/cmbVBAP-ABGRU[26," + i + "]").toDispatch());
            dropdown.invoke("setFocus");
            String text = dropdown.getPropertyAsString("text");
            System.out.println(text);
        }
        */
        Thread.sleep(10000);
        ActiveXComponent table = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/tabsTAXI_TABSTRIP_OVERVIEW/tabpT\\01/ssubSUBSCREEN_BODY:SAPMV45A:4400/subSUBSCREEN_TC:SAPMV45A:4900/tblSAPMV45ATCTRL_U_ERF_AUFTRAG").toDispatch());
        ActiveXComponent columns = new ActiveXComponent(table.invoke("columns").toDispatch());

        for (int i = 0; i < items.size(); i++) {
            Map<String, String> item = items.get(i);
            String expectedMaterial = item.get("Material");
            String expectedReason = item.get("Reason for rejection");

            ActiveXComponent column = new ActiveXComponent(columns.invoke("elementAt", 26).toDispatch());
            column.setProperty("width", 20);

            ActiveXComponent dropdown = new ActiveXComponent(Session.invoke("findById", "wnd[0]/usr/tabsTAXI_TABSTRIP_OVERVIEW/tabpT\\01/ssubSUBSCREEN_BODY:SAPMV45A:4400/subSUBSCREEN_TC:SAPMV45A:4900/tblSAPMV45ATCTRL_U_ERF_AUFTRAG/cmbVBAP-ABGRU[26," + i + "]").toDispatch());
            dropdown.invoke("setFocus");
            String actualReason = dropdown.getPropertyAsString("text");

            if ("null".equals(expectedReason)) {
                expectedReason = "";
            }

            System.out.println("Material: " + expectedMaterial + ", Expected Reason: " + expectedReason + ", Actual Reason: " + actualReason);
            Assert.assertEquals("Reason for rejection does not match for material " + expectedMaterial, expectedReason, actualReason);
            String screenshotBase64 = CommonUtils.addScreen();
            String filePath = System.getProperty("user.dir") + "\\Screenshots\\screenshot.png";
            CommonUtils.convertBase64ToImage(screenshotBase64, filePath);
            byte[] screenshotBytes = java.nio.file.Files.readAllBytes(java.nio.file.Paths.get(filePath));
            CONSTANTS.scenario.attach(screenshotBytes, "image/png", "Screenshot-" + new Random().nextInt());
            Thread.sleep(3000);
        }
    }



    public static void LogOff() throws InterruptedException{
       Session.invoke("findById", "wnd[1]/usr/btnSPOP-OPTION1").toDispatch();
        Session.invoke("press");
        Thread.sleep(4000);
    }


    public static void closeSapgui(ActiveXComponent wnd) throws InterruptedException {
      //  ActiveXComponent button = new ActiveXComponent(Session.invoke("findById", "wnd[0]/mbar/menu[3]/menu[12]").toDispatch());
     //   button.invoke("select");
     //   Thread.sleep(8000);
        wnd.invoke("close");
        Thread.sleep(20000);
        ActiveXComponent btnClose = new ActiveXComponent(Session.invoke("findById", "wnd[1]/usr/btnSPOP-OPTION1").toDispatch());
        Thread.sleep(6000);
        btnClose.invoke("press");
        //Session = sapGenric.getSession();
    //    LogOff();
//        Variant secondWndVariant = Session.invoke("findById", "wnd[1]");
//        if (secondWndVariant != null) {
//            ActiveXComponent secondWnd = new ActiveXComponent(secondWndVariant.toDispatch());
//
//            // Interact with the controls in the second window
//            ActiveXComponent btnClose = new ActiveXComponent(secondWnd.invoke("findById", "wnd[1]/usr/btnSPOP-OPTION1").toDispatch());
//            btnClose.invoke("press");




    }


    }

