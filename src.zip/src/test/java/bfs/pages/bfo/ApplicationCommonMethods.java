package bfs.pages.bfo;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;
import com.codeborne.selenide.WebDriverRunner;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import static org.junit.Assert.assertEquals;
import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static bfs.pages.BasePage.waitForPageLoad;
import static com.codeborne.selenide.Condition.enabled;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$x;
import static com.codeborne.selenide.Selenide.*;
import static com.codeborne.selenide.Selenide.sleep;

public class ApplicationCommonMethods {

    // XPaths for elements
    private static final String SEARCH_MENU_XPATH = "//input[@data-value='Search: All']";
    private static final String APP_SEARCH_TEXTBOX_XPATH = "//input[contains(@title, 'Search')]";
    private static final String SHOW_ALL_LINK_XPATH = "//a[contains(text(), 'Show All')]";
    private static final String DROPDOWN_OPTION_XPATH = "(//span[text()='%s']/parent::span/parent::lightning-base-combobox-item/parent::li)[last()]";
    private static final String SEARCH_RESULT_XPATH = "//a[@title='%s']";
    private static final String TAB_XPATH = "(//a[text()='%s']/parent::li)[last()]";
    private static final String RELATED_LIST_LINK_XPATH = "//slot[contains(text(), '%s')]/parent::span/parent::a";
    private static final String CASE_HEADER_TEXT = "//div[contains(@class, 'forceSearchSearchResultsGridHeader')]/div/div/h2/div";

    // Enter text in the search menu
    public ApplicationCommonMethods enterTextInSearchMenu(String inputText) {
        performAction(() -> {
            waitForPageLoad();
            waitForGivenTime(9000);
            SelenideElement searchBox = highlightElement($x(SEARCH_MENU_XPATH));
            waitForElementToBeVisibleAndClickable(searchBox);
            waitForGivenTime(3000);
            searchBox.click();
            waitForGivenTime(6000);
            searchBox.click();
        }, "Error interacting with search menu");
        return this;
    }

    // Select an option from the search menu
    public ApplicationCommonMethods selectOptionFromSearchMenu(String menuValue) {
        waitForGivenTime(9000);
        String optionXpath = String.format(DROPDOWN_OPTION_XPATH, menuValue);
        performAction(() -> {
            waitForGivenTime(9000);
            SelenideElement dropdownOption = highlightElement($x(optionXpath));
            waitForElementToBeVisibleAndClickable(dropdownOption);
            dropdownOption.scrollIntoView(true);
            dropdownOption.click();
        }, "Error selecting dropdown option");
        return this;
    }

    // Perform a global search
    public ApplicationCommonMethods globalSearch(String searchValue) {
        performAction(() -> {
            SelenideElement searchField = highlightElement($x(APP_SEARCH_TEXTBOX_XPATH));
            waitForElementToBeVisibleAndClickable(searchField);
            searchField.setValue(searchValue).pressEnter();
        }, "Error performing global search for: " + searchValue);
        return this;
    }

    // Navigate to a search result based on search value
    public ApplicationCommonMethods navigateToSearchValue(String searchValue) {
        String xpath = String.format(SEARCH_RESULT_XPATH, searchValue);
        performAction(() -> {
            waitForPageLoad();
            SelenideElement contractLink = highlightElement($x(xpath));
            waitForElementToBeVisibleAndClickable(contractLink);
            contractLink.click();
            waitForGivenTime(8000);
        }, "Error navigating to: " + searchValue);
        return this;
    }

    // Navigate to a tab
    public ApplicationCommonMethods navigateToTab(String tabName) {
        waitForGivenTime(8000);
        String tabXPath = String.format(TAB_XPATH, tabName);
        performAction(() -> {
            waitForPageLoad();
            waitForGivenTime(8000);
            SelenideElement tabElement = highlightElement($x(tabXPath).shouldBe(Condition.visible,Duration.ofSeconds(120)));
//            waitForElementToBeVisibleAndClickable(tabElement);
//            tabElement.click();
            tabElement.scrollIntoView("{block: \"center\"}");
            waitForGivenTime(3000);
            // Perform JavaScript click
            executeJavaScript("arguments[0].click();", tabElement);

        }, "Error navigating to the tab: " + tabName);
        return this;
    }


    // Click on 'Show All'
    public ApplicationCommonMethods clickShowAll() {
        performAction(() -> {
            waitForGivenTime(3000);
            SelenideElement showAllElement = highlightElement($x(SHOW_ALL_LINK_XPATH));
            waitForElementToBeVisibleAndClickable(showAllElement);
            showAllElement.click();
        }, "Error clicking on Show All");
        return this;
    }

    // Click on a related list link
    public ApplicationCommonMethods clickOnRelatedList(String quickLink) {
        String dynamicXPath = String.format(RELATED_LIST_LINK_XPATH, quickLink);
        performAction(() -> {
            waitForGivenTime(3000);
            SelenideElement linkElement = highlightElement($x(dynamicXPath));
            linkElement.shouldBe(Condition.visible);

            // Perform JavaScript click
            executeJavaScript("arguments[0].click();", linkElement);

        }, "Error clicking on link: " + quickLink);
        return this;
    }


    // Select a dropdown value
    public static void selectDropdownValue(String labelText, String dropdownXpath, String itemXpath, String value) {
        performAction(() -> {
            String dynamicDropdownXpath = String.format(dropdownXpath, labelText);
            System.out.println("Trying XPath: " + dynamicDropdownXpath);
            screenshot("before_dropdown_click");

            // Locate the dropdown element
            SelenideElement dropdown = $x(dynamicDropdownXpath)
                    .shouldBe(Condition.appear.because("Dropdown should appear for: " + labelText))
                    .scrollIntoView("{block: \"center\"}");

            // Perform the click action separately to avoid 'void' assignment issues
            dropdown.click();

            // Add small wait to ensure dropdown options are rendered
            sleep(1000);

            // Use Down Arrow key after dropdown opens
            dropdown.sendKeys(Keys.ARROW_DOWN);

            // Select the desired item from the dropdown
            String dynamicItemXpath = String.format(itemXpath, value);
            System.out.println("Trying Item XPath: " + dynamicItemXpath);
            screenshot("before_item_click");

            SelenideElement dropdownItem = $x(dynamicItemXpath)
                    .shouldBe(Condition.visible, Condition.enabled)
                    .scrollIntoView(true);

            dropdownItem.click();

        }, "Error selecting value from dropdown");
    }

    // Common utility method to switch to a frame
    public static void switchToFrame(String frameXpath) {
        SelenideElement frame = $x(frameXpath).shouldBe(Condition.visible, Condition.enabled);
        switchTo().frame(frame);
    }


    // Helper method to update a specific field
    public ApplicationCommonMethods updateField(String fieldName, String fieldValue) {
        waitForGivenTime(8000);
        waitForPageLoad();
        // Wait for visibility of the Edit button for the field
        SelenideElement editButton = $x("//span[contains(text(),'Edit " + fieldName + "')]/parent::button");
        editButton.scrollIntoView("{block: \"center\"}");
        waitForGivenTime(3000);
        // Click the edit button for the field, if visible
        if (editButton.isDisplayed()) {
            editButton.shouldBe(Condition.visible).click();
        }

        // Locate the dropdown button for the field
        SelenideElement dropdownButton = $x("//label[contains(text(), '" + fieldName + "')]/parent::lightning-grouped-combobox/div//button");

        // Check if the dropdown button is displayed
        if (dropdownButton.isDisplayed()) {
            dropdownButton.shouldBe(Condition.visible).click();
        }

        // Set the value for the field in the input field
        SelenideElement inputField = $x("//label[contains(text(), '" + fieldName + "')]/parent::lightning-grouped-combobox/div//input");
        inputField.shouldBe(Condition.visible).setValue(fieldValue);
        waitForGivenTime(3000);
        // Select the value from the dropdown
        $x("//ul[@role='group']/li/lightning-base-combobox-item/span/span/lightning-base-combobox-formatted-text[@title='" + fieldValue + "']")
                .shouldBe(Condition.visible)
                .scrollIntoView("{block: \"center\"}")
                .click();

        // Save the changes
        $x("//runtime_platform_actions-action-renderer[@title='Save']/parent::li")
                .shouldBe(Condition.visible, Condition.enabled)
                .click();
        return this;
    }


    // Helper method to update a specific field
    public ApplicationCommonMethods updateTextAreaField(String fieldName, String fieldValue) {
        waitForGivenTime(8000);
        waitForPageLoad();
        // Wait for visibility of the Edit button for the field
        SelenideElement editButton = $x("//span[contains(text(),'Edit " + fieldName + "')]/parent::button");
        editButton.scrollIntoView("{block: \"center\"}");
        waitForGivenTime(3000);
        // Click the edit button for the field, if visible
        if (editButton.isDisplayed()) {
            editButton.shouldBe(Condition.visible).click();
        }

        waitForGivenTime(3000);
        // Select the value from the dropdown
        $x("//label[contains(text(), '" + fieldName + "')]/parent::lightning-textarea/div/textarea")
                .shouldBe(Condition.visible)
                .scrollIntoView("{block: \"center\"}")
                .setValue(fieldValue);

        // Save the changes
        $x("//runtime_platform_actions-action-renderer[@title='Save']/parent::li")
                .shouldBe(Condition.visible, Condition.enabled)
                .click();
        waitForGivenTime(8000);
        return this;
    }



    // Helper method to wait for a specific condition for a specified amount of time using a while loop
    public static void waitForGivenTime(long timeout) {
        long startTime = System.currentTimeMillis();

        // Keep looping until the timeout is over
        while (System.currentTimeMillis() - startTime < timeout) {
            // You can check for a specific condition here if needed, for example:
            // Example: $(SomeLocator).shouldBe(Condition.visible);

            // You can also add a small sleep to prevent tight looping (optional)
            Selenide.sleep(1000); // Sleep for 1 second to reduce CPU usage
        }
    }

    // Helper method to get elements with highlight
    public static SelenideElement highlightElement(SelenideElement element) {
        element.shouldBe(Condition.visible, Duration.ofSeconds(120));
        return element;
    }

    // Helper method to wait for element visibility and clickability
    public static void waitForElementToBeVisibleAndClickable(SelenideElement element) {
        element.shouldBe(Condition.visible, Duration.ofSeconds(120));
        element.shouldBe(Condition.enabled, Duration.ofSeconds(120));
    }

    // Helper method to perform actions with exception handling
    public static void performAction(Runnable action, String errorMessage) {
        try {
            action.run();
        } catch (Exception e) {
            handleException(errorMessage, e);
        }
    }

    public static void copyAndBackspace(SelenideElement element) {
        try {
            element.sendKeys(Keys.CONTROL + "a");
            element.sendKeys(Keys.CONTROL + "c");

            element.sendKeys(Keys.BACK_SPACE);
        } catch (Exception e) {
            handleException("Error clearing the textbox", e);
        }
    }

    // Handle exceptions
    public static void handleException(String message, Exception exception) {
        System.err.println(message + ": " + exception.getMessage());
        exception.printStackTrace();
        throw new RuntimeException(message, exception);
    }

    // Validate text presence in an element
    public ApplicationCommonMethods validateTextInElement(String expectedText) {
        performAction(() -> {
            SelenideElement element = highlightElement($x(CASE_HEADER_TEXT));
            waitForElementToBeVisibleAndClickable(element);
            if (!element.getText().contains(expectedText)) {
                throw new AssertionError("Expected text: " + expectedText + " not found in element.");
            }
        }, "Error validating text in element");
        return this;
    }
    public void compareSelectedAndInstalledProducts(List<String> selectedTitles, List<String> installedProducts) {
        if (selectedTitles == null || installedProducts == null) {
            throw new IllegalStateException("One or both lists are not initialized.");
        }

        // Convert lists to sets for easy comparison
        Set<String> selectedSet = new HashSet<>(selectedTitles);
        Set<String> installedSet = new HashSet<>(installedProducts);

        // Find common elements
        Set<String> commonElements = new HashSet<>(selectedSet);
        commonElements.retainAll(installedSet);

        // Find differences
        Set<String> selectedOnly = new HashSet<>(selectedSet);
        selectedOnly.removeAll(installedSet);


        Set<String> installedOnly = new HashSet<>(installedSet);
        installedOnly.removeAll(selectedSet);

        // Log results
        System.out.println("✅ Matching Elements: " + commonElements);
        System.out.println("❌ Selected but not in Installed: " + selectedOnly);
        System.out.println("❌ Installed but not in Selected: " + installedOnly);

        // Assert both lists are identical
        Assert.assertEquals("❌ Lists do not match!", selectedSet, installedSet);

        System.out.println("🎯 Both lists match exactly!");
    }


    public ApplicationCommonMethods compareStrings(String actualText, String expectedText) {
        assertEquals("Strings do not match!", expectedText, actualText);

        return this;
    }
    public static void clickAndEnterDynamicDate(String labelText, String xpath, String dateFormat) {
        try {
            waitForGivenTime(5000);
            String dynamicXpath = String.format(xpath, labelText);
            SelenideElement element = $x(dynamicXpath);

            element.shouldBe(visible, enabled)
                    .scrollIntoView("{block: \"center\"}")
                    .click();

            new Actions(WebDriverRunner.getWebDriver()).sendKeys(Keys.ESCAPE).perform();

            String formattedDate = LocalDate.now().plusDays(1).format(DateTimeFormatter.ofPattern(dateFormat));
            element.setValue(formattedDate);
            waitForGivenTime(5000);
        } catch (Exception e) {
            handleException("Error interacting with the date input field", e);
        }
    }
    public static void clickAndEnterCurrentDate(String labelText, String xpath, String format) {
        try {
            String dynamicXpath = String.format(xpath, labelText);
            SelenideElement element = $x(dynamicXpath);

            element.shouldBe(visible, enabled)
                    .scrollIntoView("{block: \"center\"}")
                    .click();

            new Actions(WebDriverRunner.getWebDriver()).sendKeys(Keys.ESCAPE).perform();

            // Format current date as dd/MM/yyyy
            String formattedDate = LocalDate.now().format(DateTimeFormatter.ofPattern(format));
            element.setValue(formattedDate);
        } catch (Exception e) {
            handleException("Error interacting with the date input field", e);
        }
    }
}
