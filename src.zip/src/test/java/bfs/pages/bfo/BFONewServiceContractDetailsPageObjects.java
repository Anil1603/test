package bfs.pages.bfo;
import bfs.pages.BasePage;
import com.codeborne.selenide.*;
import io.cucumber.java.eo.Se;
import org.openqa.selenium.By;

import static bfs.pages.BasePage.highLightElement;
import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.*;

import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;

import java.util.Random;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


public class BFONewServiceContractDetailsPageObjects {

    private static final By SALES_REP_TEXT_BOX = By.xpath("//label[contains(text(),'Sales Rep')]/following-sibling::div//input");
    private static final By BILL_TO_CONTACT_TEXT_BOX = By.xpath("//label[contains(text(),'Bill To Contact')]/following-sibling::div//input[@placeholder='Select a Contact']");
    private static final By SOLD_TO_CONTACT_TEXT_BOX = By.xpath("//label[contains(text(),'Sold To Contact')]/following-sibling::div//input[@placeholder='Select a Contact']");
    private static final By PO_DATE_TEXT_BOX = By.xpath("//label[contains(text(),'PO Date')]/following-sibling::div//input");
    private static final By PO_NUMBER_TEXT_BOX = By.xpath("//label[contains(text(),'PO Number')]/following-sibling::input");
    private static final By SAVE_AND_NEXT_BUTTON = By.xpath("//button[contains(text(),'Save And Next')]");
    ElementsCollection collections= $$x("//div[@role='listbox']//li//div[@class='slds-lookup__result-text']");

    //Contract Details
    ElementsCollection openContracts = $$x("//td[@data-label='CONTRACT NAME']/../td/a/button");
    private static final By CONTACT_VALUE = By.xpath("//a[contains(@href, 'Contacts')]");
    private static final By CONTRACT_CHAIN_PLAYERS = By.xpath("//a[contains(@href, 'Chain_Players')]");
    private static final By NEW_CONTACT_BUTTON = By.xpath("(//button[text()='New'])[last()]");
    private static final By CONTINUE_BUTTON = By.xpath("//button[text()='Continue']");
    private static final By ACCOUNT_ROLE = By.xpath("//button[@aria-label='Account Role']");
    private static final By CONTACT_ROLE = By.xpath("//button[@aria-label='Contact Role']");
    private static final By CASE_ACCESS = By.xpath("//button[@aria-label='Case Access']");
    private static final By DOCUMENT_ACCESS = By.xpath("//button[@aria-label='Document Vault Access']");
    private static final By CONTACT_LOCATOR = By.xpath("//slot[@name='primaryField']/lightning-formatted-name");
    private static  final  By APP_SEARCH= By.xpath("//input[contains(@title, 'Search')]");
    private static  final  By VALIDATE_CONTRACT= By.xpath("(//div[@id='wizardComponentLoad']//div//span[@title='Contract Activation']/a/span)[last()]");

    //ElementsCollection lists = $$(".slds-lookup__result-text").shouldHave(CollectionCondition.sizeGreaterThan(0));

    public BFONewServiceContractDetailsPageObjects selectSalesRep(String salesRepName){
        String salesRep= salesRepName.split(":")[0];
        $(SALES_REP_TEXT_BOX).shouldBe(visible,enabled).setValue(salesRep);
        collections.filterBy(text(salesRepName.split(":")[1])).first().click();
        return this;
    }

    public BFONewServiceContractDetailsPageObjects selectBillToContact(String contact){
        String contactName = contact.split(":")[0].split(" ")[0];
        $(BILL_TO_CONTACT_TEXT_BOX).shouldBe(visible,enabled).setValue(contactName);
        /* Selenide.sleep(10000);
         ElementsCollection lists = $$(".slds-lookup__result-text").shouldHave(CollectionCondition.sizeGreaterThan(0));
         for (int i = 0; i < lists.size(); i++) {
             if(lists.get(i).getText().equalsIgnoreCase(contact.split(":")[1])){
                 lists.get(i).click();
                 break;
             }
         }*/
        collections.filterBy(text(contact.split(":")[1])).first().click();
        return this;
    }

    public BFONewServiceContractDetailsPageObjects  selectSoldToContact(String contact){
        String contactName = contact.split(":")[0].split(" ")[0];
        $(SOLD_TO_CONTACT_TEXT_BOX).shouldBe(visible,enabled).setValue(contactName);
         /*Selenide.sleep(10000);
         ElementsCollection lists = $$(".slds-lookup__result-text").shouldHave(CollectionCondition.sizeGreaterThan(0));
         for (int i = 0; i < lists.size(); i++) {
             if(lists.get(i).getText().equalsIgnoreCase(contact.split(":")[1])){
                 lists.get(i).click();
                 break;
             }
         }*/
        collections.filterBy(text(contact.split(":")[1])).first().click();
        return this;
    }

    public BFONewServiceContractDetailsPageObjects setPODate(String date){
        String poDate =  BasePage.getTodayDate("MM/dd/yyyy");
        $(PO_DATE_TEXT_BOX).shouldBe(visible,enabled).setValue(poDate);
        return this;
    }

    public BFONewServiceContractDetailsPageObjects setPONumber(String poNumber){
        $(PO_NUMBER_TEXT_BOX).shouldBe(visible,enabled).setValue(poNumber);
        return this;
    }

    public BFONewServiceContractDetailsPageObjects clickSaveAndNextButton(){
        $(SAVE_AND_NEXT_BUTTON).shouldBe(visible,enabled).click();
        return this;
    }

    public void setContractDetailsForServiceContract(String fieldName,String value){
        switch (fieldName.toLowerCase()){
            case "sales rep" ->selectSalesRep(value);
            case "po date"-> setPODate(value);
            case "po number"->setPONumber(value);
            case "bill to contact"->selectBillToContact(value);
            case "sold to contact"->selectSoldToContact(value);
            default -> throw new RuntimeException("Not implemented for " + fieldName);
        }
    }


    // Utility method to highlight and ensure element visibility
    private SelenideElement getElementWithHighlight(String xpath) {
        SelenideElement element = $(By.xpath(xpath));
        highLightElement(element.shouldBe(visible, enabled));
        return element;
    }

    // Contract Details: Method to select a BFO tab by its name with JavaScript click
    public void selectBfoTab(String tabName) {
        sleep(2000);
        executeJavaScript("window.scrollTo(0, 0);");
        // Build the XPath dynamically for the tab
        sleep(2000);
        executeJavaScript("window.scrollTo(0, 0);");
        String tabXPath = "(//a[@data-label='" + tabName + "'])[last()]";
        if ($x(tabXPath).isDisplayed()) {
            SelenideElement tabElement = $x(tabXPath);
            tabElement.scrollIntoView(true);
            highLightElement(tabElement);
            tabElement.click();
        } else if ($x("//*[@slot='main']//button[@title='More Tabs'][@class='slds-button']//*[@variant='bare']").isDisplayed()) {

            SelenideElement tabElement = $x("//*[@slot='main']//button[@title='More Tabs'][@class='slds-button']//*[@variant='bare']");
            // tabElement.scrollIntoView(true);
            actions().moveToElement(tabElement).build().perform();
            highLightElement(tabElement);
            Selenide.sleep(5000);
            tabElement.click(ClickOptions.usingJavaScript());
            SelenideElement deatlstabLocator=$x("//*[@part='menu-item']//a//span[text()='"+tabName+"']");
            highLightElement(deatlstabLocator);
            deatlstabLocator.click(ClickOptions.usingJavaScript());
        } else {
            throw new AssertionError("Tab not found: " + tabName);
        }
//        // Build the XPath dynamically for the tab
//        String tabXPath = "(//a[@data-label='" + tabName + "'])[last()]";
//
//
//        // Locate the element and ensure it's highlighted
//        SelenideElement tabElement = getElementWithHighlight(tabXPath);
//
//        // Use JavaScript to click the element
//        Selenide.executeJavaScript("arguments[0].click();", tabElement);

    }


    // Method to get attribute values for a list of fields and store them in a HashMap
    public Map<String, String> getFieldAttributes(List<String> fieldNames) {
        Map<String, String> attributeMap = new HashMap<>();

        for (String fieldName : fieldNames) {
            // Build the XPath dynamically for the field
            String fieldXPath = "//a[@data-label='" + fieldName + "']";

            // Get the element and retrieve its "data-value" attribute
            String attributeValue = getElementWithHighlight(fieldXPath).getAttribute("data-value");

            // Store the field name and its attribute value in the map
            attributeMap.put(fieldName, attributeValue);


        }

        return attributeMap;
    }


    // Method to click each "Open" button and verify the details
    public void clickOpenContractsAndCheckServiceLines(Map<String, String> fieldDetails) {
        // Ensure that we have at least one "Open" button
        if (openContracts.isEmpty()) {
            System.out.println("No 'Open' buttons found on the page.");
            return;
        }

        // Iterate through each element in the collection
        for (int i = 0; i < openContracts.size(); i++) {
            // Wait for the button to be visible and enabled
            openContracts.get(i).shouldBe(visible, enabled);

            // Scroll to the element if needed
            openContracts.get(i).scrollIntoView(true);

            // Use JavaScript to click the button
            SelenideElement button = openContracts.get(i);
            executeJavaScript("arguments[0].click();", button);

            System.out.println("Clicked on Open button " + (i + 1));

            // Call a separate method to validate Service Line details
            validateServiceLines(fieldDetails, i);
        }
    }

    // Method to validate Service Line details (e.g., 'Included Services' and 'Covered Products')
    private void validateServiceLines(Map<String, String> fieldDetails, int contractIndex) {
        fieldDetails.forEach((fieldName, expectedValue) -> {
            System.out.println("FIELD NAME " + (fieldName));
            waitForGivenTime(5000);
            // Find all matching elements for the field
            ElementsCollection elements = $$x("(//h2[text()='Included Services'])[last()]/../../../../../parent::div[contains(@class, 'slds-page-header')]/following-sibling::div/div/div[contains(@class,'slds-border_right slds-border_left tableScroll')]/div/table/tbody/tr/td/a");
            // Ensure that at least one element exists for the field
            if (elements.isEmpty()) {
                throw new AssertionError("No elements found for field: " + fieldName);
            }

            // Verify that each element's 'title' attribute is not empty
            for (int j = 0; j < elements.size(); j++) {
                String titleValue = elements.get(j).shouldBe(visible).getAttribute("title");

                // Validate the title attribute
                if (titleValue == null || titleValue.isEmpty()) {
                    throw new AssertionError("Field '" + fieldName + "' has an empty or missing title attribute at index " + j + " in contract " + (contractIndex + 1));
                }

                // Log the valid title for debugging purposes
                System.out.println("Field '" + fieldName + "', Title " + (j + 1) + ": " + titleValue);
            }

            // Log success for this field
            System.out.println("Verified that all title attributes for field '" + fieldName + "' in contract " + (contractIndex + 1) + " are valid and not empty.");
        });
    }

    public void memorizeSoldToAccount(String key, Map<String, String> memorizedData) {
        // Define the XPath for the field
        Selenide.executeJavaScript("window.scrollTo(0, 0)");
        String xpath = "//p[contains(@title,'"+key+"')]/following-sibling::p/slot//div//a//slot/span/slot/span";

        // Locate the element using the XPath
        SelenideElement element = $(By.xpath(xpath)).shouldBe(Condition.visible);
        element.scrollIntoView(true);
        // Get the text of the element
        String value = element.getText();

        // Store the value in the memorizedData map using the provided key
        memorizedData.put(key, value);

        // Print the value for debugging (optional)
        System.out.println("Memorized " + key + " as " + key + ": " + value);


    }

    // Method to verify that the Status field does not equal the invalid value "Validation"
    public void verifyStatus(Map<String, String> fieldDetails) {
        String fieldName = "Status"; // Field name is "Status"
        String invalidValue = "Validation"; // The invalid value to check for (can be customized)

        // Define the XPath for the Status element
        String xpath = "(//span[text()='"+fieldName+"']/parent::div/../following-sibling::dd/div/span/slot/lightning-formatted-text)[last()]"; // Adjust XPath if needed

        // Locate the Status element and get the text
        SelenideElement statusElement = $(By.xpath(xpath)).shouldBe(Condition.visible);
        String statusText = statusElement.getText();

        // Assert that the status is not "Validation"
        if (invalidValue.equals(statusText)) {
            throw new AssertionError(fieldName + " should not be '" + invalidValue + "'. Found: " + statusText);
        }

        // Log success
        System.out.println("Verified " + fieldName + ": " + statusText);
    }

    // Method to verify the Active checkbox is disabled (not clickable)
    public void verifyActiveCheckbox(Map<String, String> fieldDetails) {
        String fieldName = "Active"; // Field name is "Active"
        String expectedState = fieldDetails.get(fieldName); // Fetch the expected state (e.g., "False") from HashMap

        // Define the XPath for the Active checkbox (disabled state)
        String xpath = "(//span[text()='"+fieldName+"']/preceding-sibling::span/parent::label/parent::span/input)[last()]";

        // Locate the Active checkbox element
        SelenideElement activeCheckbox = $(By.xpath(xpath)).shouldBe(Condition.visible);

        // Assert that the checkbox is disabled (not clickable) if the expected state is "False"
        if ("False".equals(expectedState) && activeCheckbox.isEnabled()) {
            throw new AssertionError("The 'Active' checkbox should be disabled, but it is enabled.");
        } else if ("True".equals(expectedState) && !activeCheckbox.isEnabled()) {
            throw new AssertionError("The 'Active' checkbox should be enabled, but it is disabled.");
        }

        // Log success
        System.out.println("Verified 'Active' checkbox is " + (activeCheckbox.isEnabled() ? "enabled" : "disabled") + ".");
    }

    public void openDisposableEmailPage() {
        com.codeborne.selenide.Selenide.executeJavaScript("window.open('https://yopmail.com/en/email-generator');");
        com.codeborne.selenide.Selenide.switchTo().window(1);
    }

    public String getConcatenatedEmail() {
        // Wait for the email elements to load
        waitForGivenTime(5000);

        // Locate the list of elements using the XPath (replace with your actual XPath)
        ElementsCollection emailElements = $$x("//span[@class='genytxt']"); // Replace with the actual XPath of your elements

        // Initialize an empty StringBuilder to concatenate the text from each element
        StringBuilder concatenatedEmail = new StringBuilder();

        // Ensure there are at least two elements (username and domain parts)
        if (emailElements.size() < 2) {
            throw new AssertionError("Insufficient elements found to construct an email address.");
        }

        // Get the text from the first element and append "@"
        concatenatedEmail.append(emailElements.get(0).getText()).append("@");

        // Get the text from the second element and append it
        concatenatedEmail.append(emailElements.get(1).getText());

        // If there are additional parts, concatenate them (optional)
        for (int i = 2; i < emailElements.size(); i++) {
            concatenatedEmail.append(emailElements.get(i).getText());
        }

        // Print the concatenated email for debugging
        System.out.println("Disposable Email: " + concatenatedEmail);

        // Switch back to the main window (if applicable)
        com.codeborne.selenide.Selenide.switchTo().window(0);

        // Return the concatenated email string
        return concatenatedEmail.toString();
    }

    private String generateRandomString(int length) {
        // Characters to choose from
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder randomString = new StringBuilder();
        Random rand = new Random();

        // Generate random string of specified length
        for (int i = 0; i < length; i++) {
            int index = rand.nextInt(characters.length());
            randomString.append(characters.charAt(index));
        }

        return randomString.toString();
    }


    // Method to create a new contact using the field details provided in the map
    public void createContact(Map<String, String> contactFields, String key) {
        // Generate a random string of 10 characters
        String randomString = generateRandomString(10);

        // Scroll to the top of the page
        Selenide.executeJavaScript("window.scrollTo(0, 0)");

        // Locate the Sold-To Account element using XPath
        String xpathSoldToAccount = "//p[contains(@title,'" + key + "')]/following-sibling::p/slot//div//a//slot/span/slot/span";
        SelenideElement soldToAccountElement = $(By.xpath(xpathSoldToAccount)).shouldBe(Condition.visible);
        soldToAccountElement.scrollIntoView(true).click();

        // Navigate to the "Related" tab and click the "Contact" section
        waitForGivenTime(5000);
        $(By.xpath("(//a[text()='Related']/parent::li)[last()]")).shouldBe(Condition.visible, Condition.enabled).click();
        $(CONTACT_VALUE).shouldBe(Condition.visible, Condition.enabled).click();
        $(NEW_CONTACT_BUTTON).shouldBe(Condition.visible, Condition.enabled).click();

        // Handle "Select Record Type" explicitly if present
        if (contactFields.containsKey("Select Record Type")) {
            String recordType = contactFields.get("Select Record Type");
            $x("//select[@name='selectItem']").selectOption(recordType);
            $(CONTINUE_BUTTON).shouldBe(Condition.visible, Condition.enabled).click();
        }

        // Iterate through the remaining fields and fill the form
        contactFields.forEach((fieldName, value) -> {
            waitForGivenTime(5000); // Add a slight delay for stability
            System.out.println("FIELD NAME: " + fieldName);

            // Fill fields using a switch statement
            switch (fieldName) {
                case "First Name":
                case "Last Name":
                    setInputValue(fieldName, value + randomString);
                    break;

                case "Email":
                    setInputValue(fieldName, "anilkumar.bhusarapalli@se.com");
                    break;

                case "Account":
                    setInputValue(fieldName, value);
                    break;

                default:
                    System.out.println("Unhandled field: " + fieldName);
            }
        });

        // Submit or save the contact
        $x("//button[text()='Save']").shouldBe(Condition.visible, Condition.enabled).click();
        waitForGivenTime(5000);

        // Log success
        System.out.println("Contact creation submitted successfully.");
    }

    // Helper method to set the value for an input field based on its label
    private void setInputValue(String fieldName, String value) {
        String fieldXPath = "//span[text()='" + fieldName + "']/parent::label/parent::div/input";
        SelenideElement fieldElement = $x(fieldXPath).shouldBe(Condition.visible);
        fieldElement.click();
        fieldElement.setValue(value);
    }


    public String memorizeContact() {
        // Locate the contact element and ensure it's visible
        SelenideElement contactElement = $(CONTACT_LOCATOR).shouldBe(Condition.visible);

        // Get the text of the contact element
        String contactName = contactElement.getText();

        // Check if the contact name is empty
        if (contactName.isEmpty()) {
            throw new AssertionError("Contact name is empty and cannot be memorized.");
        }

        // Log the retrieved contact name
        System.out.println("Memorized Contact: " + contactName);

        // Return the contact name
        return contactName;
    }


    public void updateContact(Map<String, String> contactFields, String fieldValue) {

        // Iterate through the fields and update accordingly
        contactFields.forEach((fieldName, value) -> {
            waitForGivenTime(5000); // Optional: Add a slight delay for stability
            System.out.println("FIELD NAME: " + fieldName);

            // Perform actions based on the field name using a switch statement
            switch (fieldName) {
                case "Main Installed at Contact":
                    navigateToTab("Basic");
                    updateField(fieldName, fieldValue);
                    break;

                case "Sold to Contact":
                    navigateToTab("Advanced");
                    updateField(fieldName, fieldValue);
                    break;

                case "Remote Service Contact":
                    navigateToTab("Details");
                    scrollToSection("Contract Details");
                    updateField(fieldName, fieldValue);
                    waitForGivenTime(20000);
                    break;

                default:
                    System.out.println("Unhandled field: " + fieldName);
            }
        });

        // Log success
        System.out.println("Contact update submitted successfully.");
    }

    // Helper method to navigate to a specific tab
    private void navigateToTab(String tabName) {
        Selenide.executeJavaScript("window.scrollTo(0, 0)");
        String tabXPath = "(//a[text()='" + tabName + "']/parent::li)[last()]";
        $(By.xpath(tabXPath)).shouldBe(Condition.visible, Condition.enabled).click();
    }

    // Helper method to scroll to a specific section
    private void scrollToSection(String sectionName) {
        $x("//span[text()='" + sectionName + "']/parent::button")
                .shouldBe(Condition.visible)
                .scrollIntoView(true);
    }

    // Helper method to update a specific field
    private void updateField(String fieldName, String fieldValue) {
        waitForGivenTime(5000);
        // Wait for visibility of the Edit button for the field
        SelenideElement editButton = $x("//span[contains(text(),'Edit " + fieldName + "')]/parent::button");

        // Click the edit button for the field, if visible
        if (editButton.isDisplayed()) {
            editButton.shouldBe(Condition.visible).click();
        }

        // Locate the dropdown button for the field
        SelenideElement dropdownButton = $x("//label[contains(text(), '" + fieldName + "')]/parent::lightning-grouped-combobox/div//button");

        // Check if the dropdown button is displayed
        if (dropdownButton.isDisplayed()) {
            dropdownButton.shouldBe(Condition.visible).click();
        }

        // Set the value for the field in the input field
        SelenideElement inputField = $x("//label[contains(text(), '" + fieldName + "')]/parent::lightning-grouped-combobox/div//input");
        inputField.shouldBe(Condition.visible).setValue(fieldValue);

        // Select the value from the dropdown
        $x("//ul[@role='group']/li")
                .shouldBe(Condition.visible)
                .click();

        // Save the changes
        $x("//runtime_platform_actions-action-renderer[@title='Save']/parent::li")
                .shouldBe(Condition.visible, Condition.enabled)
                .click();
    }


    public void updateEmailWithDisposable(Map<String, String> contactFields, String fieldValue) {


        // Iterate through the fields and update accordingly
        contactFields.forEach((fieldName, value) -> {
            waitForGivenTime(5000); // Optional: Add a slight delay for stability
            System.out.println("FIELD NAME: " + fieldName);

            // Perform actions based on the field name using a switch statement
            if (fieldName.equals("Email")) {// Click the edit button for the field
                waitForGivenTime(5000);
                $x("//span[contains(text(),'Edit " + fieldName + "')]/parent::button")
                        .shouldBe(visible)
                        .click();
                waitForGivenTime(5000);

                $x("//label[contains(text(), '" + fieldName + "')]/parent::div/parent::lightning-primitive-input-simple//div//input")
                        .shouldBe(visible)
                        .clear();
                $x("//label[contains(text(), '" + fieldName + "')]/parent::div/parent::lightning-primitive-input-simple//div//input")
                        .shouldBe(visible)
                        .setValue(fieldValue);

                // Save the changes
                $x("//runtime_platform_actions-action-renderer[@title='Save']/parent::li")
                        .shouldBe(visible, enabled)
                        .click();
                waitForGivenTime(5000);
            } else {
                System.out.println("Unhandled field: " + fieldName);
            }
        });

        // Log success
        System.out.println("Contact update submitted successfully.");

    }


    public void validateContract(){
        waitForGivenTime(5000);
        // Locate the element
        SelenideElement targetElement = $x("(//div[@id='wizardComponentLoad']//div//span[@title='Contract Activation']/a/span)[last()]");

        // Perform an offset click
        Actions actions = new Actions(WebDriverRunner.getWebDriver());
        actions.moveToElement(targetElement, 0, 0).click().perform();

        waitForGivenTime(30000);
        // Create Actions instance
        Actions actions1 = new Actions(WebDriverRunner.getWebDriver());

        // Send TAB 2 times
        actions1.sendKeys(Keys.TAB).sendKeys(Keys.TAB).perform();

        // Send ENTER
        actions1.sendKeys(Keys.ENTER).perform();

        System.out.println("Successfully navigated and interacted with the page.");


    }

    public void verifyContractDetails(Map<String, String> contactFields) {
        // Iterate through the fields and verify their values
        contactFields.forEach((fieldName, value) -> {
            waitForGivenTime(5000);// Optional: Add a slight delay for stability
            System.out.println("Verifying field: " + fieldName); // Debug log for current field

            switch (fieldName) {
                case "Status":
                    verifyStatus(fieldName, value);
                    break;

                case "Active":
                    verifyCheckboxState(fieldName, value);
                    break;

                case "Synchronization Log":
                    verifyFieldValue(fieldName, value, "//span[text()='" + fieldName + "']/../../../dd//lightning-formatted-text");
                    break;

                case "Last Synchronization":
                    verifyLastSynchronization(fieldName, value);
                    break;

                default:
                    System.out.println("No specific verification logic implemented for: " + fieldName);
            }
        });

        System.out.println("Contract details validated successfully.");
    }

    // Helper method to verify the "Status" field
    private void verifyStatus(String fieldName, String expectedValue) {
        String xpath = "(//span[text()='" + fieldName + "']/parent::div/../following-sibling::dd/div/span/slot/lightning-formatted-text)[last()]";
        SelenideElement statusElement = $(By.xpath(xpath)).shouldBe(Condition.visible);
        String statusText = statusElement.getText();

        if ("Validated".equals(statusText)) {
            System.out.println(fieldName + " is 'Validated'. This is acceptable.");
        } else if ("Validation".equals(statusText)) {
            throw new AssertionError(fieldName + " should not be 'Validation'. Found: " + statusText);
        } else {
            System.out.println("Verified " + fieldName + ": " + statusText);
        }
    }

    // Helper method to verify the checkbox state
    private void verifyCheckboxState(String fieldName, String expectedState) {
        String xpath = "(//span[text()='" + fieldName + "']/preceding-sibling::span/parent::label/parent::span/input)[last()]";
        SelenideElement checkboxElement = $(By.xpath(xpath)).shouldBe(Condition.visible);
        boolean isCheckboxEnabled = checkboxElement.isEnabled();

        if ("True".equals(expectedState) && !isCheckboxEnabled) {
            throw new AssertionError("The '" + fieldName + "' checkbox should be enabled, but it is disabled.");
        } else if ("False".equals(expectedState) && isCheckboxEnabled) {
            throw new AssertionError("The '" + fieldName + "' checkbox should be disabled, but it is enabled.");
        }

        System.out.println("Verified '" + fieldName + "' checkbox is " + (isCheckboxEnabled ? "enabled" : "disabled"));
    }

    // Helper method to verify a field's value
    private void verifyFieldValue(String fieldName, String expectedValue, String xpath) {
        SelenideElement fieldElement = $(By.xpath(xpath)).shouldBe(Condition.visible);
        String actualValue = fieldElement.getText();

        if (!actualValue.equals(expectedValue)) {
            throw new AssertionError(fieldName + " mismatch: Expected '" + expectedValue + "', but found '" + actualValue + "'.");
        }

        System.out.println("Verified '" + fieldName + "' is: " + actualValue);
    }

    // Helper method to verify the "Last Synchronization" field
    private void verifyLastSynchronization(String fieldName, String expectedValue) {
        String xpath = "//span[text()='" + fieldName + "']/../../../dd//lightning-formatted-text";
        SelenideElement fieldElement = $(By.xpath(xpath)).shouldBe(Condition.visible);
        String actualValue = fieldElement.getText();
        String currentTimestamp = getCurrentTimestamp();

        if (!actualValue.contains(currentTimestamp)) {
            throw new AssertionError(fieldName + " mismatch: Expected timestamp '" + currentTimestamp + "', but found '" + actualValue + "'.");
        }

        System.out.println("Verified '" + fieldName + "' is: " + actualValue);
    }


    public static String getCurrentTimestamp() {
        // Get the current date and time
        LocalDateTime now = LocalDateTime.now();

        // Define the desired format
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

        // Format and return the current timestamp
        return now.format(formatter);
    }



    // Method to create a new contact using the field details provided in the map
    public void createContactChainPlayers(Map<String, String> contactFields, String fieldValue) {

        // Scroll to the top of the page
        Selenide.executeJavaScript("window.scrollTo(0, 0)");

        // Navigate to the "Related" tab and click the "Contact" section
        waitForGivenTime(5000);
        navigateToRelatedTab("Related");
        $(CONTRACT_CHAIN_PLAYERS).shouldBe(Condition.visible, Condition.enabled).click();
        $(NEW_CONTACT_BUTTON).shouldBe(Condition.visible, Condition.enabled).click();

        // Iterate through the fields and handle them dynamically
        contactFields.forEach((fieldName, value) -> {
            waitForGivenTime(8000); // Add a slight delay for stability
            System.out.println("Processing FIELD: " + fieldName);

            switch (fieldName) {
                case "Account Role":
                    selectDropdownValue($(ACCOUNT_ROLE), value);
                    break;

                case "Contact Role":
                    selectDropdownValue($(CONTACT_ROLE), value);
                    break;

                case "Contact":
                    setFieldValueWithDropdown(fieldName, fieldValue);
                    break;

                case "Case Access":
                    selectDropdownValue($(CASE_ACCESS), value);
                    break;

                case "Document Vault Access":
                    selectDropdownValue($(DOCUMENT_ACCESS), value);
                    break;

                default:
                    System.out.println("Unhandled field: " + fieldName);
            }
        });

        // Submit or save the contact
        $x("//button[@name='SaveEdit']").shouldBe(Condition.visible, Condition.enabled).click();
        waitForGivenTime(5000);

        // Log success
        System.out.println("Contact creation submitted successfully.");
    }

    // Helper method to navigate to a specific tab
    private void navigateToRelatedTab(String tabName) {
        String tabXPath = "(//a[text()='" + tabName + "']/parent::li)[last()]";
        $(By.xpath(tabXPath)).shouldBe(Condition.visible, Condition.enabled).click();
    }

    // Helper method to select a dropdown value
    private void selectDropdownValue(SelenideElement dropdown, String value) {
        // Scroll the dropdown into view and click to open it
        dropdown.shouldBe(Condition.visible, Condition.enabled).scrollIntoView(true).click();

        // Locate the dropdown item based on the value and scroll it into view before clicking
        SelenideElement dropdownItem = $(By.xpath("//lightning-base-combobox-item[@data-value='" + value + "']"));
        dropdownItem.shouldBe(Condition.visible, Condition.enabled).scrollIntoView(true).click();
    }

    // Helper method to set a field value and select from a dropdown
    private void setFieldValueWithDropdown(String fieldName, String fieldValue) {
        // Locate the input field
//        SelenideElement inputField = $x("//label[contains(text(), '" + fieldName + "')]/parent::lightning-grouped-combobox/div//input");
        SelenideElement inputField = $x("//input[contains(@placeholder, 'Search Contacts')]");

        // Wait until the input field is visible and enabled (including waiting for animations, if needed)
        inputField.shouldBe(Condition.visible, Duration.ofSeconds(10));
        inputField.scrollIntoView(true).click();


        // Set the value in the input field
        inputField.scrollIntoView(true).setValue(fieldValue);  // Scroll into view and set the value

        // Locate the dropdown option and scroll it into view before clicking it
        SelenideElement dropdownOption = $x("//ul[@role='group']/li");
        dropdownOption.shouldBe(Condition.visible);  // Wait for the dropdown option to be visible
        dropdownOption.scrollIntoView(true).click();  // Scroll into view and click the option
    }


    // Helper method to wait for a specific condition for a specified amount of time using a while loop
    public void waitForGivenTime(long timeout) {
        long startTime = System.currentTimeMillis();

        // Keep looping until the timeout is over
        while (System.currentTimeMillis() - startTime < timeout) {
            // You can check for a specific condition here if needed, for example:
            // Example: $(SomeLocator).shouldBe(Condition.visible);

            // You can also add a small sleep to prevent tight looping (optional)
            Selenide.sleep(1000); // Sleep for 1 second to reduce CPU usage
        }
    }



}
