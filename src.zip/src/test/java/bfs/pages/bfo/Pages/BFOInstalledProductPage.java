package bfs.pages.bfo.Pages;

import bfs.pages.bfo.PageObjects.BFOInstalledProductPageObjects;

public class BFOInstalledProductPage {
    public void addInstalledProduct( String installedProduct) {
        BFOInstalledProductPageObjects installedProductPageObjects = new BFOInstalledProductPageObjects();
        installedProductPageObjects.setInstalledProductSearchTextBox(installedProduct)
                .clickOnGoButton()
                .clickOnInstalledProductCheckBox(installedProduct)
                .clickOnAttachIPButton();
    }

}
