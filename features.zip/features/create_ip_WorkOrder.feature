Feature: Create IP.
  As a user
  I want to navigate to the application and Create new ip for Work Order

  Scenario Outline: Create IP for work order
    #Coordinator
    Given I work in application "BFO" and environment "UAT"
    And I login to "BFO" as user "coordinator-1550@bridge-fo.com.uatbfo26"
    When I navigate to "SE - Services Lightning" from app launcher
    And I wait for "10" seconds
    And I navigate to "Work Orders" from app launcher
    And I click on bfo button "New"
    And I fill work order details for creating new work order from Work Order Page:
      | Field Name                | Field Value                         |
      | Select Record Type        | Standalone Work Order               |
      | Installed At Account      | 0001340233:Ampcontrol (QLD) Pty Ltd |
      | Location                  | 0045144542:Ampcontrol QLD Pty Ltd   |
      | Work Order Type           | Repair                              |
#    |Work Order Sub-Type                   |                                           |
      | Contact                   | chandra.vamsi kumar                 |
      | Customer Requested Date   | today                               |
      | Country of Back Office    | Australia                           |
      | Back Office System        | SAP Bridge AP                       |
      | Work Order Category       | Onsite                              |
      | Services Business Unit    | POWER SYSTEMS                       |
      | Is Billable               | No                                  |
      | Customer Reference Number | 1234                                |
      | Priority                  | Normal-Medium                       |
      | Non Billing Reason        | Warranty                            |
      | Service Commercial Ref    | QWPFSRVPLNNSGEN                     |
#    |Skill Category                        |                                           |
      | Work Order Reason         | Testing                             |
      | Work Order Name           | Testing                             |
      | Sold To Account           | 0001340233:Ampcontrol (QLD) Pty Ltd |
    Then I should see the work order status as "New" in work order page
    And the user selects the "<Tab Name>" tab in Work Order Details
    And the user creates new IP with following data and Validates the Created IP
      | BRAND              | DEVICE TYPE                                | RANGE             | SUB RANGE | SERIAL NUMBER | CUSTOMER INSTALLED PRODUCT REFERENCE | DATE SHIPPED | COMMISSIONING DATE INSTALL DATE | MANUFACTURING DATE | LIFECYCLE STATUS      | EXPECTED TOAST TITLE ON SAVE | EXPECTED TOAST TEXT ON SAVE |
      | Schneider Electric | LV equipment - Low voltage circuit breaker | Compact NS > 630A |           | XYZ123        | Test_123_78                          | today        | today                           | today              | Commissioned / In Use | Success                      | IP is created Successfully. |

    Examples:
      | Menu Item   | Work Order  | Tab Name      |
      | Work Orders | WO-12263068 | IP and Skills |




