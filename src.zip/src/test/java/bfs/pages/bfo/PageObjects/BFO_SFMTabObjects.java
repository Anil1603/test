package bfs.pages.bfo.PageObjects;

import bfs.CONSTANTS;
import bfs.pages.BasePage;
import com.codeborne.selenide.Selenide;
import org.openqa.selenium.By;

import java.time.Duration;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.*;

public class BFO_SFMTabObjects {
    private static final String VALIDATE_CONTRACT_BUTTON = "//span[contains(text(),'Validate Contract')]";
    private static final String CREATE_UPDATE_WORK_ORDER_BUTTON = "//span[contains(text(),'Create/Update Work Order')]";
    private static final String CLICK_ON_OK_BUTTON = "//button[@title='OK']";
    private static final String CREATE_WORK_ORDER_BUTTON = "//span[contains(text(),'Create Work Order')]";
    private static final String SERVICE_BOARD_BUTTON = "//span[contains(text(),'Service Board')]/parent::a";
    private static final String UPDATE_WO_BUTTON = "//span[contains(text(),'Update WO')]";
    private static final String COMPLATE_WO_TASKS_BUTTON = "//span[contains(text(),'Complete WO Tasks')]";
    private static final String REVIEW_TIME_AND_EXPENSE_LIGHTNING_BUTTON = "//span[text()='Review Time & Expense Lightning']";
    private static final String ACCPET_REJECT_LINK = "//span[contains(text(),'Accept & Reject')]/parent::a";
//    private static final String REVIEW_TIME_EXPENSE_LIGHTNING_LINK = "//span[contains(text(),'Review Time & Expense Lightning')]/parent::a";

    public BFO_SFMTabObjects clickOnValidateContract(){
        $x(VALIDATE_CONTRACT_BUTTON).shouldBe(visible,enabled).scrollIntoView(true);
        executeJavaScript("arguments[0].click();", $(By.xpath(VALIDATE_CONTRACT_BUTTON)));
     //   $x(VALIDATE_CONTRACT).shouldBe(visible,enabled).click();
        CONSTANTS.captureScreen = true;
        return this;
    }

    public BFO_SFMTabObjects clickOnCreateWorkOrderButton(){
        $x(CREATE_WORK_ORDER_BUTTON).shouldBe(visible,enabled).scrollIntoView(true);
        executeJavaScript("arguments[0].click();", $(By.xpath(CREATE_WORK_ORDER_BUTTON)));
        CONSTANTS.captureScreen = true;
        return this;
    }

    public BFO_SFMTabObjects clickOnCreateUpdateWorkOrderButton(){
        $x(CREATE_UPDATE_WORK_ORDER_BUTTON).shouldBe(visible,enabled).scrollIntoView(false);
      //  executeJavaScript("arguments[0].click();", $(By.xpath(CREATE_UPDATE_WORK_ORDER_BUTTON)));
     //   $x(CREATE_UPDATE_WORK_ORDER_BUTTON).shouldBe(visible,enabled).click();
        actions().moveToElement($x(CREATE_UPDATE_WORK_ORDER_BUTTON).shouldBe(visible, enabled)).click().perform();
        CONSTANTS.captureScreen = true;
        return this;
    }
    public BFO_SFMTabObjects clickOnServiceBoardButton(){
       BasePage.highLightElement( $x(SERVICE_BOARD_BUTTON).shouldBe(visible,enabled).scrollIntoView(false));
    //    executeJavaScript("arguments[0].click();", $(By.xpath(SERVICE_BOARD_BUTTON)));
       actions().moveToElement($x(SERVICE_BOARD_BUTTON).shouldBe(visible, enabled)).click().perform();
     //  $x(SERVICE_BOARD_BUTTON).shouldBe(visible,enabled).click();
        CONSTANTS.captureScreen = true;
        return this;
    }
    public BFO_SFMTabObjects clickOnUpdateWOButton(){
        $x(UPDATE_WO_BUTTON).shouldBe(visible,enabled).scrollIntoView(false);
        executeJavaScript("arguments[0].click();", $(By.xpath(UPDATE_WO_BUTTON)));
        CONSTANTS.captureScreen = true;
        return this;
    }
    public BFO_SFMTabObjects clickOnCompleteWOTasksButton(){
        $x(COMPLATE_WO_TASKS_BUTTON).shouldBe(visible,enabled).scrollIntoView(false);
        executeJavaScript("arguments[0].click();", $(By.xpath(COMPLATE_WO_TASKS_BUTTON)));
        CONSTANTS.captureScreen = true;
        return this;
    }
    public BFO_SFMTabObjects clickOnReviewTimeAndExpenseLightningButton(){
        $x(REVIEW_TIME_AND_EXPENSE_LIGHTNING_BUTTON).shouldBe(visible,Duration.ofSeconds(60));
        $x(REVIEW_TIME_AND_EXPENSE_LIGHTNING_BUTTON).shouldBe(visible,enabled).scrollIntoView(false);
        executeJavaScript("arguments[0].click();", $(By.xpath(REVIEW_TIME_AND_EXPENSE_LIGHTNING_BUTTON)));
   //     actions().moveToElement($x(REVIEW_TIME_EXPENSE_LIGHTNING_LINK).shouldBe(visible,enabled)).click().perform();
        CONSTANTS.captureScreen = true;
        return this;
    }

    public BFO_SFMTabObjects clickOnAcceptAndReject() {
        $x(ACCPET_REJECT_LINK).shouldBe(visible,Duration.ofSeconds(60));
        $x(ACCPET_REJECT_LINK).shouldBe(visible,enabled).scrollIntoView(false);
        actions().moveToElement($x(ACCPET_REJECT_LINK).shouldBe(visible, enabled)).click().perform();
        CONSTANTS.captureScreen = true;
        return this;
    }


    public void clickOnSFMTabButtons(String fieldName){
        switch (fieldName.toLowerCase()){
            case "validate contract" -> clickOnValidateContract();
            case "create work order" -> clickOnCreateWorkOrderButton();
            case "create/update work order" -> clickOnCreateUpdateWorkOrderButton();
            case "service board" -> clickOnServiceBoardButton();
            case "accept & reject" -> clickOnAcceptAndReject();
            case "update wo" -> clickOnUpdateWOButton();
            case "complete wo tasks" ->clickOnCompleteWOTasksButton();
            case "review time and expense lightning" -> clickOnReviewTimeAndExpenseLightningButton();
                default -> throw new RuntimeException("Not implemented for " + fieldName);

        }

    }
/*
    public BFO_SFMTabObjects clickOnReviewTimeAndExpenseLightning(){
        $x(REVIEW_TIME_EXPENSE_LIGHTNING_LINK).shouldBe(visible,Duration.ofSeconds(60));
        $x(REVIEW_TIME_EXPENSE_LIGHTNING_LINK).shouldBe(visible,enabled).scrollIntoView(false);
        actions().moveToElement($x(REVIEW_TIME_EXPENSE_LIGHTNING_LINK).shouldBe(visible, enabled)).click().perform();
        return this;
    }

*/

}
