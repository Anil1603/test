package utilities;

import com.codeborne.selenide.Configuration;
import configuration.ConfigManager;
import org.openqa.selenium.MutableCapabilities;
import org.openqa.selenium.chrome.ChromeOptions;

import java.util.HashMap;

public class CloudSetup {

    public static MutableCapabilities setBrowserStackConfiguration(){
        HashMap<String, Object> browserstackOptions = new HashMap<String, Object>();
        MutableCapabilities capabilities = new MutableCapabilities();
        // other capability declarations
        capabilities.setCapability("browserName", ConfigManager.getProperty("BROWSER_NAME","application"));
        if (ConfigManager.getProperty("BROWSER_NAME","application").equalsIgnoreCase("chrome")){
            ChromeOptions options = new ChromeOptions();
           // options.addArguments("--headless");  // ChromeOptions for starting chrome in incognito mode
            capabilities.setCapability(ChromeOptions.CAPABILITY, options);
        }
        capabilities.setCapability("browserVersion",ConfigManager.getProperty("BROWSER_VERSION","application"));
        browserstackOptions.put("os", ConfigManager.getProperty("OS_NAME","application"));
        browserstackOptions.put("osVersion", ConfigManager.getProperty("OS_VERSION","application"));
        browserstackOptions.put("projectName", ConfigManager.getProperty("PROJECT_NAME","application"));
        browserstackOptions.put("buildName", TimeUtility.getTimewithTimeStamp(ConfigManager.getProperty("BUILD_NAME","application")));
        //browserstackOptions.put("proxyHost", "165.225.104.32");
        //browserstackOptions.put("proxyPort", "443");
        capabilities.setCapability("bstack:options", browserstackOptions);
        return capabilities;
    }



    //chrome options for chrome plus browser stack options

    //firefox options for firefox plus browser stack options

    //safari options for safari plus browser stack options

    //edge options for edge plus browser stack options




}
