package requestPojo;

public class BrowserStackStatusPojo {

    private String status;
    private String reason;

    public BrowserStackStatusPojo(String status, String reason) {
        this.status = status;
        this.reason = reason;
    }


    //Getters and setters
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }
}
