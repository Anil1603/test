package bfs.B2F;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;

public class Work_Order_Creation_B2F extends getAccessToken {



    @Test
    public void create_Work_Order_From() {
        System.out.println(accessToken);
        String SID = accessToken;
        RestAssured.baseURI = "https://se--uat24.sandbox.my.salesforce.com/services/apexrest/field-services/work-order/v1?";
        String workOrder_Creation_Payload = "[\n" +
                "\n" +
                "   {\n" +
                "\n" +
                "      \"workOrderIdentity\":{\n" +
                "\n" +
                "         \"workOrderBackOfficeReference\":\"TRO200-005100028039P\",\n" +
                "\n" +
                "         \"workOrderBackOfficeRecordId\":\"TRO200-005100028039P\",  \n" +
                "\n" +
                "         \"woGroupBackOfficeReference\":\"TRO200-0006592779P\"\n" +
                "\n" +
                "      },\n" +
                "\n" +
                "      \"workOrderCategory\":\"Onsite\",\n" +
                "\n" +
                "      \"workOrderReason\":\"----------------------------------------\\nSCOPE OF WORK\\n\\nTest scope of  work 2\\n\\n----------------------------------------\\n\\nCLARIFICATIONS\\n\\nTe st clarifications 2\\n\\n\\n----------------------------------------\\n\\nCUSTO MER RESPONSIBILITIES\\n\\ntest customer responsibilities 2\\n\\n------------- ---------------------------\\n\\nWORK NOT INCLUDED\\n\\nwork not included2\\n\\n- ---------------------------------------\\n\\nSCHEDULE\\n\\nschedule2\\n\\n------- ---------------------------------\\n\\nLabor Type\\n\\nThis job is being quot ed for work to be\\nperformed during normal working hours (M-F\\n8:00 AM - 5:00 PM excluding Schneider Electric\\nholidays) unless otherwise not ed.\\n\\n---------------------------------------- \",\n" +
                "\n" +
                "      \"workOrderSubType\":\"\",\n" +
                "\n" +
                "      \"workOrderType\":\"Repair\",\n" +
                "\n" +
                "      \"backOfficeEntity\":\"USAB\",\n" +
                "\n" +
                "      \"backOfficeSystem\":\"BBO_AM\",\n" +
                "\n" +
                "      \"countryOfBackOffice\":\"US\",\n" +
                "\n" +
                "      \"customerReferenceNumber\":\"Q-4013544-TEST\",\n" +
                "\n" +
                "      \"customerRequestedDate\":\"01\\/08\\/2023\",\n" +
                "\n" +
                "      \"installedAtAccountInfo\":\"CARGILL COCOA AND CHOCOLATE INC,,20 N BROAD ST,17543,LITITZ,PA,USA\",\n" +
                "\n" +
                "      \"isBillable\":\"Sales Order\",\n" +
                "\n" +
                "      \"poNumber\":\"51307821-2  #000020\",\n" +
                "\n" +
                "      \"priority\":\"Normal-Medium\",\n" +
                "\n" +
                "      \"projectNumber\":\"\",\n" +
                "\n" +
                "      \"cpqQuoteNumber\":\"\",\n" +
                "\n" +
                "      \"salesOrderCurrency\":\"USD\",\n" +
                "\n" +
                "      \"salesOrderLineNumber\":\"000020\",\n" +
                "\n" +
                "      \"salesOrderLineValue\":8183.38,\n" +
                "\n" +
                "      \"salesOrderNumber\":\"TRO200-0006592779\",\n" +
                "\n" +
                "      \"serviceBusinessUnit\":\"PP\",\n" +
                "\n" +
                "      \"installedAtAccount\":{\n" +
                "\n" +
                "         \"accountBfoId\":\"001A0000011n5taIAA\"\n" +
                "\n" +
                "      },\n" +
                "\n" +
                "      \"mainInstalledProduct\":{\n" +
                "\n" +
                "         \"installedAtAccount\":{\n" +
                "\n" +
                "            \"goldenId\":\"\"\n" +
                "\n" +
                "         }\n" +
                "\n" +
                "      },\n" +
                "\n" +
                "      \"soldToAccountBfoId\":\"001A0000011n5taIAA\",\n" +
                "\n" +
                "      \"workOrderName\":\"Reactive Maintenance on LV Assembled Pro\",\n" +
                "\n" +
                "      \"serviceCommericalRefName\":\"SRVODSCOR\",\n" +
                "\n" +
                "      \"quoteLineID\":\"QL-115335560\",\n" +
                "\n" +
                "      \"transactionID\":\"QL-115335560\",\n" +
                "\n" +
                "      \"quotationSystem\":\"SEA\"\n" +
                "\n" +
                "   }\n" +
                "\n" +
                "]";
        RequestSpecification httpReqest1 = given().auth().oauth2(SID).and().body(workOrder_Creation_Payload);
        Response response1=httpReqest1.request(Method.POST);
        String responsebody1=response1.getBody().asString();
        System.out.println(responsebody1);
    }
}