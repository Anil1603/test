#@BFSTST-2031
Feature: Default
	#@BFSTST-2032 @BFSTST-2033
	Scenario: Service Contract Creation using service lines , cover products and service products
		#Coordinator
        Given I work in application "BFO" and environment "UAT"
		And I login to "BFO" as user "coordinator-1532@bridge-fo.com.uat24"
		When I navigate to "Service/Maintenance Contracts" from app launcher
		And I click on button "New"
		And I fill basic info details for creating new service contract:
		| Field Name 		  | Field Value |
		| Contract Name       | Test Contract Name|
		| Sold to account     | 0001614376:Sharma Electric works(1003) |
		| Main Installed At Account | 0001614376:Sharma Electric works(1003) |
		| Bill To Account     | 0001614376:Sharma Electric works(1003) |
		| Main Installed at Contact | AZHARUDDIN KHAN:AZHARUDDIN KHAN |
		| Remote Service Contact | AZHARUDDIN KHAN:AZHARUDDIN KHAN |
		|Start Date              |10/01/2025      |
		| End Date               |10/01/2026      |
		And I fill contract details for creating new service contract:
		|Field Name 		  |Field Value |
		|Sales Rep       	  |1532:Coordinator 1532|
		|Po Date              |10/01/2025|
		|Po Number            |666987896|
		|Bill To Contact      |AZHARUDDIN KHAN:AZHARUDDIN KHAN|
		|Sold To Contact      |AZHARUDDIN KHAN:AZHARUDDIN KHAN|
		And I click on button "Save And Next" on service contract creation page
		And I search and select the product "SRVAPE9IN0054" from service line
		And I fill the service line details for product :
		|Field Name 		  |Field Value |
		|Quantity             |1|
		|Contract Price       |CONTRACT PRICE:100|
		|Description          |DESCRIPTION:Testing|
		And I click on button "Save And Next" on service contract creation page
		And I search and select the product "SRVAPE9IN0054" from new service and maintenance contract
		And I Search  and select installed product "ASSEMBLY PCB MT ABU 850VA INVERTER" from service and maintenence
		And I click on button "save" in new service maintenance contract page
		Then validate contract and check contract status as "Active" and work order status as "Validated"
		And I click on create pm plan button from contract name "Sharma Electric works(1003)"
		And I fill Pm plan details for creating new pm plan:
		|Field Name 		  |Field Value |
		|Pm Plan Template     |Test:MGRID Sequence of Ops|
		|Work Order Type       |Preventive Maintenance|
		|Work Order Sub Type   |Regular Preventive Maintenance|
		|Work Order Duration  |6,00|
		And click on button "Create"
		When I click on "Create Work Order" button to create work order
		And I fill work order details for creating new work order from service maintenance contract:
		|Field Name 		      |Field Value |
		|Work Order Name          |Testing|
		|Work Order Reason        |Testing|
		|Customer Requested Date  |today|
		|Location                 |Sharma Electric Works -Chandigarh SITE:Sharma Electric Works -Chandigarh SITE|
		|Country Of Back Office   |India|
		|Back Office System       |SAP Bridge AP|
		|Mip Flag                 ||
		And I click on "Save" button in work order page
		Then I should see the work order status as "New" in work order page
		And I click on "Create/Update Work Order" button from SFM Tab
		And I click on "Sync" button from Sync page
		And I check the message "SUCCESS : INITIATED SYNC" on sync window
		And I click on "Ok" button on sync window
		Then I should see the work order status as "Unscheduled" in work order page
		And I wait for back Office reference number
		And I check the "First Synchronization date" and "Last Synchronization date" in work order page
		And I check the "Synchronization Log" as "Work Order CREATED in Back Office" in work order page
	    And I add work order to "FSR-1532" in Service Board
		Then I should see the work order status as "Scheduled" in work order page
		And I memorized current work order number as "current_work_order_number_Url" and "current_work_order_number"
	    Then Change work order status to customer confirmed
		Then I should see the work order status as "Customer Confirmed" in work order page
		And I logout from bfo application
	#FSR User
		Given I work in application "BFO" and environment "UAT"
		#And I navigate to url "https://test.salesforce.com"
		And I login to "BFO" as user "fsr-1532@bridge-fo.com.uat24"
		And FSR accepts the work order "current_work_order_number_Url"
		Then check fsr response is "Acknowledge FSR"
		And I click on "Update WO" button from SFM Tab
		And I select the fsr response as "Acknowledge FSR" from update wo page in servicemax
		And I click on "Save" button in update wo page in servicemax
		And I click on "Update WO" button from SFM Tab
		And I select the fsr response as "Under Preparation" from update wo page in servicemax
		And I click on "Save" button in update wo page in servicemax
		Then I should see the work order status as "WIP" in work order page
		And I click on "Update WO" button from SFM Tab
		And I select the fsr response as "On-Site" from update wo page in servicemax
		And I click on "Save" button in update wo page in servicemax
		And I click on "Update WO" button from SFM Tab
		And I select the fsr response as "WIP" from update wo page in servicemax
		And I fill the Risk Assessment details in WIP FSR response:
			|Field Name 		                |Field Value |
			|Is Risk Assessment Attached        |No|
			|NO Risk Assessment Reason          |Other|
			|No Risk Assessment Details         |Testing|
		And I click on "Save" button in update wo page in servicemax
		And I click on "Update WO" button from SFM Tab
		And I select the fsr response as "Delivered" from update wo page in servicemax
		And I fill the service details in delivered fsr response:
			|Field Name 		                |Field Value |
			|Work Performed                     |Testing|
			|Opportunity Detected               |No|
		And I click on add my time  and select the activity as "Service" in delivered fsr response
		And I update the time and click on "Save" button in update wo page in servicemax
		Then I should see the work order status as "Service Delivered" in work order page
		When I click on "Complete WO Tasks" button from SFM Tab
		And I click on "Save" button two times in Complete WO Task page
		Then I should see the work order status as "Service Completed" in work order page
		And I logout from bfo application
	#FSR Manager
		Given I work in application "BFO" and environment "UAT"
		#And I navigate to url "https://test.salesforce.com"
		And I login to "BFO" as user "fsrmanager-1532@bridge-fo.com.uat24"
		When I click on "My Team Assigned FSR" from home page
		And I look for the service completed work order "current_work_order_number" and open it
		And I click on "Review Time And Expense Lightning" button from SFM Tab
		Then I verify the all details and click button two times:
			|Field Name 		                |Field Value |
			|Opportunity Detected               |No|
			|Work Order                         |current_work_order_number|
			|Work Performed                     |Testing|
			|Completed By                       |FSR 1532|
			|Completed On                       |10/01/2025|
			|Installed At Account               |Sharma Electric works(1003)|
		And I changed the work order status to service validated
		Then I should see the work order status as "Service Validated" in work order page
		And I check the "First Synchronization date" and "Last Synchronization date" in work order page
		And I check the "Synchronization Log" as "Work Order RELEASED Successfully in Back Office" in work order page















