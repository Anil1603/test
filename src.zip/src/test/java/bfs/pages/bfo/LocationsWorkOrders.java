package bfs.pages.bfo;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;
import com.codeborne.selenide.WebDriverRunner;
import org.openqa.selenium.interactions.Actions;

import java.time.Duration;

import static com.codeborne.selenide.Condition.enabled;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$x;

public class LocationsWorkOrders {

    // XPaths for elements
    private static final String NEW_WORK_ORDER = "//button[text()='New WO']";
    private static final String EMERGENCY_WORK_ORDER = "//button[text()='Create Emergency WO']";
    private static final String CONTINUE_WORK_ORDER = "//button[text()='Continue']";



    public LocationsWorkOrders clickNewWorkOrder() {
        try {
            waitForGivenTime(5000);
            SelenideElement newWorkOrder = $x(NEW_WORK_ORDER);
            waitForElementToBeVisibleAndClickable(newWorkOrder);
//            newWorkOrder.click();
            Actions actions = new Actions(WebDriverRunner.getWebDriver());
            actions.moveToElement(newWorkOrder, 0, 0).click().perform();

            waitForGivenTime(8000);
        } catch (Exception e) {
            handleException("Error clicking on New Work Order", e);
        }
        return this;
    }

    public LocationsWorkOrders clickEmergencyWorkOrder() {
        try {
            waitForGivenTime(5000);
            SelenideElement emergencyWorkOrder = $x(EMERGENCY_WORK_ORDER);
            waitForElementToBeVisibleAndClickable(emergencyWorkOrder);
//            newWorkOrder.click();
            Actions actions = new Actions(WebDriverRunner.getWebDriver());
            actions.moveToElement(emergencyWorkOrder, 0, 0).click().perform();

            waitForGivenTime(8000);
        } catch (Exception e) {
            handleException("Error clicking on New Work Order", e);
        }
        return this;
    }

    public LocationsWorkOrders clickContinueWorkOrder() {
        try {
            SelenideElement continueWorkOrder = $x(CONTINUE_WORK_ORDER);
            waitForElementToBeVisibleAndClickable(continueWorkOrder);
            continueWorkOrder.click();
            waitForGivenTime(8000);
        } catch (Exception e) {
            handleException("Error clicking on Continue Work Order", e);
        }
        return this;
    }

    public void waitForGivenTime(long timeout) {
        long startTime = System.currentTimeMillis();

        // Keep looping until the timeout is over
        while (System.currentTimeMillis() - startTime < timeout) {
            // You can check for a specific condition here if needed, for example:
            // Example: $(SomeLocator).shouldBe(Condition.visible);

            // You can also add a small sleep to prevent tight looping (optional)
            Selenide.sleep(1000); // Sleep for 1 second to reduce CPU usage
        }
    }


    // Helper method to get elements with highlight for better visibility during execution
    private SelenideElement getElementWithHighlight(SelenideElement element) {
        element.shouldBe(Condition.visible, Duration.ofSeconds(10)); // wait until element is visible
        return element;
    }

    // Helper method to explicitly wait until an element is visible and clickable
    private void waitForElementToBeVisibleAndClickable(SelenideElement element) {
        element.shouldBe(visible, Duration.ofSeconds(10));  // Wait until the element is visible
        element.shouldBe(enabled, Duration.ofSeconds(10));  // Wait until the element is enabled
    }

    // Helper method to handle exceptions and log details
    private void handleException(String message, Exception exception) {
        // Log the error message and exception details
        System.err.println(message + ": " + exception.getMessage());
        exception.printStackTrace();

        // Rethrow the exception to fail the test
        throw new RuntimeException(message, exception);
    }


}
