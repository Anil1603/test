

Feature: Default
  Scenario: Service Contract Creation using service lines , cover products and service products

Given I work in application "BFO" and environment "UAT"
And I login to "BFO" as user "coordinator-1532@bridge-fo.com.uat24"
And I logout from bfo application
    Given I work in application "BFO" and environment "UAT"
#And I navigate to url "https://test.salesforce.com"
#Given I work in application "BFO" and environment "UAT"
 And I login to "BFO" as user "coordinator-1532@bridge-fo.com.uat24"
 And I logout from bfo application