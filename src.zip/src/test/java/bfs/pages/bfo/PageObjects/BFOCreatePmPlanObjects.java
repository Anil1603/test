package bfs.pages.bfo.PageObjects;

import org.openqa.selenium.By;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.*;

public class BFOCreatePmPlanObjects {
    private static final String RELATED_TAB = "//a[contains(text(),'Related')]";
    private static final String SERVICE_LINES_BUTTON = "//slot[contains(text(),'Service Lines')]/../..";
    private static final String CREATE_PM_PLAN_BUTTON = "//button[contains(text(),'Create PM Plan')]";
    private static final String CREATE_PM_PLAN2_BUTTON = "//section/button[contains(text(),'Create PM Plan')]";
    private static final String PM_PLAN_TEMPLATE_TEXTBOX = "//label[contains(text(),'PM Plan Template')]/..//input[@role='combobox']";
    private static final String WORK_ORDER_TYPE_DROPDOWN = "//button[@name='WorkOrderType__c']";
    private static final String WORK_ORDER_SUB_TYPE_DROPDOWN = "//button[@name='WorkOrderSubType__c']";
    private static final String WORK_ORDER_DURATION_PER_WO_TEXTBOX = "//label[contains(text(),'Work Order Duration per WO')]/..//input[@name='WorkOrderDurationperWO__c']";
    private static final String CREATE_BUTON = "//button[@type='submit']";
    private static final String CLOSE_THIS_WINDOW = "//button[@title='Cancel and close']";  // Close this window
    private static final String SUCCESS_MESSAGE = "//span[contains(text(),'Record is saved Successfully')]";

    public  BFOCreatePmPlanObjects clickOnRelatedTab(){
        $x((RELATED_TAB)).shouldBe(visible,enabled).click();
        return this;
    }
    public  BFOCreatePmPlanObjects clickOnServiceLinesButton(){
        $x((SERVICE_LINES_BUTTON)).shouldBe(visible,enabled).click();
        return this;
    }
    public BFOCreatePmPlanObjects clickOnContractName(String accountName){
        By CONTRACT_NAME_LINK = By.xpath("//a[@title='"+accountName+"']/ancestor::td/preceding-sibling::th/lightning-primitive-cell-factory/span/div");
        $(CONTRACT_NAME_LINK).shouldBe(visible,enabled).click();
        return this;
    }

    public  BFOCreatePmPlanObjects clickOnCreatePmPlanButton(){
        $x((CREATE_PM_PLAN_BUTTON)).shouldBe(visible,enabled).click();
        return this;
    }
    public  BFOCreatePmPlanObjects clickOnCreatePmPlanButtonOnPopUp(){
        $x((CREATE_PM_PLAN2_BUTTON)).shouldBe(visible,enabled).click();
        return this;
    }
    public  BFOCreatePmPlanObjects setPmPlanTemplateTextBox(String value){
        $x((PM_PLAN_TEMPLATE_TEXTBOX)).shouldBe(visible,enabled).setValue(value.split(":")[0]);
        $x("//ul[@role='group']//lightning-base-combobox-formatted-text[contains(text(),'"+value.split(":")[1]+"')]")
                .shouldBe(visible,enabled).click();
        return this;
    }
    public BFOCreatePmPlanObjects selectWorkOrderTypeFromDropdown(String value){
        $x((WORK_ORDER_TYPE_DROPDOWN)).shouldBe(visible,enabled).click();
        $x("//div[@aria-label='Work Order Type']/lightning-base-combobox-item[@data-value='"+value+"']").shouldBe(visible,enabled).click();
        return this;
    }
    public BFOCreatePmPlanObjects selectWorkOrderSubTypeFromDropdown(String value){
        $x((WORK_ORDER_SUB_TYPE_DROPDOWN)).shouldBe(visible,enabled).click();
        $x("//div[@aria-label='Work Order Sub-Type']/lightning-base-combobox-item[@data-value='"+value+"']")
                .shouldBe(visible,enabled).click();
        return this;
    }
    public BFOCreatePmPlanObjects setWorkOrderDurationPerWo(String value){
        $x((WORK_ORDER_DURATION_PER_WO_TEXTBOX)).shouldBe(visible,enabled).setValue(value);
        return this;
    }
    public BFOCreatePmPlanObjects clickOnCreateButton(){
        $x((CREATE_BUTON)).shouldBe(visible,enabled).click();
        return this;
    }
    public BFOCreatePmPlanObjects clickOnCloseThisWindow(){
        $x((CLOSE_THIS_WINDOW)).shouldBe(visible,enabled).click();
        return this;
    }

    public void setPmPlanDetails(String fieldName,String value){
        switch (fieldName.toLowerCase()){
            case "pm plan template" ->setPmPlanTemplateTextBox(value);
            case "work order type"-> selectWorkOrderTypeFromDropdown(value);
            case "work order sub type"->selectWorkOrderSubTypeFromDropdown(value);
            case "work order duration"->setWorkOrderDurationPerWo(value);
            default -> throw new RuntimeException("Not implemented for " + fieldName);
        }

    }

}
