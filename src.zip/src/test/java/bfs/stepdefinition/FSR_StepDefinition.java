package bfs.stepdefinition;

import bfs.CONSTANTS;
import bfs.pages.BasePage;
import bfs.pages.bfo.PageObjects.BFO_FSR_WODetailsPageObjects;
import bfs.pages.bfo.PageObjects.BFO_SFMTabObjects;
import bfs.pages.servicemax.PageObjects.FSRResponseUpdateWorkOrderPageObjects;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.junit.Assert;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

import static bfs.CONSTANTS.captureScreen;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$x;
import static com.codeborne.selenide.Selenide.switchTo;

public class FSR_StepDefinition {
    BFO_FSR_WODetailsPageObjects bfo_fsr_woDetailsPageObjects = new BFO_FSR_WODetailsPageObjects();


    @And("FSR accepts the work order {string}")
    public void fsrAcceptWorkOrder(String workorder) throws InterruptedException {
//        String workOrderURL = "https://se--uat25.sandbox.lightning.force.com/lightning/r/SVMXC__Service_Order__c/a2HKS0000009KB42AM/view"; //todo delete
        String workOrderURL = new BasePage().getWorkOrderNumberURL(workorder);
        System.out.println( "Work Order URL: " + workOrderURL);

        bfo_fsr_woDetailsPageObjects.fsrAcceptWorkOrder(workOrderURL);
    }

    @Then("check fsr response is {string}")
    public void checkFsrResponseIs(String status) {
        new BFO_FSR_WODetailsPageObjects().checkFSRResponseStatusIsExist(status);
    }
    @And("I select the fsr response as {string} from update wo page in servicemax")
    public void iSelectTheFSRResponseAsFromUpdateWOPageInServicemax(String value) {
        new FSRResponseUpdateWorkOrderPageObjects().selectFSRResponse(value);

    }

    @And("I click on {string} button in update wo page in servicemax")
    public void iClickOnButtonInUpdateWOPageInServicemax(String arg0) {
        new FSRResponseUpdateWorkOrderPageObjects().clickOnSaveButton();
        switchTo().defaultContent();
        //  Selenide.sleep(3000);
    }

    @And("I fill the Risk Assessment details in WIP FSR response:")
    public void iFillTheRiskAssessmentDetailsInWIPFSRResponse(DataTable table) {
        Map<String, String> fields = new BasePage().storeFieldsIn(table.asMap());
        for (Map.Entry<String, String> entry : fields.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();
            new FSRResponseUpdateWorkOrderPageObjects().setRiskAssessment(key,value);
        }
        captureScreen=true;

    }

    @And("I fill the service details in delivered fsr response:")
    public void iFillTheServiceDetailsInDeliveredFsrResponse(DataTable table) {
        Map<String, String> fields = new BasePage().storeFieldsIn(table.asMap());
        for (Map.Entry<String, String> entry : fields.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();
            new FSRResponseUpdateWorkOrderPageObjects().setServiceDetails(key,value);
        }
        captureScreen=true;

        
        
    }

    @And("I click on add my time  and select the activity as {string} in delivered fsr response")
    public void iClickOnAddMyTimeAndSelectTheActivityAsInDeliveredFsrResponse(String value) {
        new FSRResponseUpdateWorkOrderPageObjects().clickOnAddMyTimeButton()
                .selectActivityType(value)
                .clickOnDropdownButtonAndSelect("Edit");

    }

    @And("I click on add my time  and select the activity type as {string} in delivered fsr response")
    public void iClickOnAddMyTimeAndSelectTheActivityTypeAsInDeliveredFsrResponse(String value) {
        new FSRResponseUpdateWorkOrderPageObjects().clickOnAddMyTimeButton()
                .selectActivityType(value)
                .clickOnDropdownButtonAndSelect("Edit");
    }

    @And("I update the time and click on {string} button in update wo page in servicemax")
    public void iUpdateTheTimeAndClickOnButtonInUpdateWOPageInServicemax(String arg0) {
        new FSRResponseUpdateWorkOrderPageObjects().fetchCustomerEndTimeAndIncreaseByOneHour()
                .clickOnUpdateButton()
                .clickOnSaveButton()
        // Below code is added to handle Warning messages and Time Overlap Error on click of save button
                .handlingErrorWarningPostSaveInUpdateWOPage();

    }

    @And("I update Customer Hour Type and time and click on {string} button in update wo page in servicemax")
    public void iUpdateCustomerHourType_TimeAndClickOnButtonInUpdateWOPageInServicemax(String arg0) {
        FSRResponseUpdateWorkOrderPageObjects fsrResponseUpdateWorkOrderPageObjects = new FSRResponseUpdateWorkOrderPageObjects();
        fsrResponseUpdateWorkOrderPageObjects
                .selectCustomerHourType(new FSRResponseUpdateWorkOrderPageObjects().getRandomCustomerHourTypeValue())
                .fetchCustomerEndTimeAndIncreaseByOneHour();
        captureScreen = true;
        fsrResponseUpdateWorkOrderPageObjects.clickOnUpdateButton()
                .clickOnSaveButton().handlingErrorWarningPostSaveInUpdateWOPage();
        switchTo().defaultContent();
    }


    @And("I update the start time by {string} and end time by {string} and click on Save")
    public void iUpdateTheTimeAgainAndClickOnSave(String startTimeHrs, String endTimeHrs){

        FSRResponseUpdateWorkOrderPageObjects fsrResponseUpdateWorkOrderPageObjects = new FSRResponseUpdateWorkOrderPageObjects();

        fsrResponseUpdateWorkOrderPageObjects.switchToFrameinUpdateWOPage().scrollIntoViewDropdwonButton().clickOnDropdownButtonAndSelect("Edit");
        HashMap<String, String> updatedTimes = fsrResponseUpdateWorkOrderPageObjects.updateTimeInMyTime(Integer.valueOf(startTimeHrs), Integer.valueOf(endTimeHrs)); //11:00 AM
        fsrResponseUpdateWorkOrderPageObjects.clickOnUpdateButton();

        String displayedStartTime = fsrResponseUpdateWorkOrderPageObjects.startTimeDisplayedUnderMyTime().substring(11); //11:00 AM
        String displayedEndTime = fsrResponseUpdateWorkOrderPageObjects.endTimeDisplayedUnderMyTime().substring(11);
        fsrResponseUpdateWorkOrderPageObjects.clickOnSaveButton().handlingErrorWarningPostSaveInUpdateWOPage();
        switchTo().defaultContent();

        new BFO_SFMTabObjects().clickOnSFMTabButtons("Update WO");
        fsrResponseUpdateWorkOrderPageObjects.switchToFrameinUpdateWOPage().scrollIntoViewDropdwonButton();
        captureScreen=true;
        Assert.assertTrue(updatedTimes.get("startTime").equals(displayedStartTime));
        Assert.assertTrue(updatedTimes.get("endTime").equals(displayedEndTime));

        fsrResponseUpdateWorkOrderPageObjects.clickOnSaveButton().handlingErrorWarningPostSaveInUpdateWOPage();

    }

    @And("I delete the Time entered under My Time and click on Save")
    public void iDeleteTheTimeAndClickOnSave(){

        FSRResponseUpdateWorkOrderPageObjects fsrResponseUpdateWorkOrderPageObjects = new FSRResponseUpdateWorkOrderPageObjects();

        fsrResponseUpdateWorkOrderPageObjects.switchToFrameinUpdateWOPage().scrollIntoViewDropdwonButton();
        int numberOfRecordsBeforeDeletion = fsrResponseUpdateWorkOrderPageObjects.numberOfRecordsUnderMyTime();
        fsrResponseUpdateWorkOrderPageObjects.clickOnDropdownButtonAndSelect("Delete");
        captureScreen=true;
        fsrResponseUpdateWorkOrderPageObjects.clickOnSaveButton().handlingErrorWarningPostSaveInUpdateWOPage();
        switchTo().defaultContent();

        new BFO_SFMTabObjects().clickOnSFMTabButtons("Update WO");
        fsrResponseUpdateWorkOrderPageObjects.waitUntilSpinnerIsInvisible().switchToFrameinUpdateWOPage().scrollIntoViewDropdwonButton();
        int numberOfRecordsAfterDeletion = fsrResponseUpdateWorkOrderPageObjects.numberOfRecordsUnderMyTime();
        Assert.assertEquals(numberOfRecordsAfterDeletion, numberOfRecordsBeforeDeletion - 1);

        fsrResponseUpdateWorkOrderPageObjects.clickOnSaveButton().handlingErrorWarningPostSaveInUpdateWOPage();

    }

    @And("I click on {string} button two times in Complete WO Task page")
    public void iClickOnButtonTwoTimesInCompleteWOTaskPage(String arg0) {
        new FSRResponseUpdateWorkOrderPageObjects().clickSaveButtonTwice();

    }

    @And("I click on {string} button in Complete WO Task page")
    public void iClickOnButtonInCompleteWOTaskPage(String arg0) {
        FSRResponseUpdateWorkOrderPageObjects fsrResponseUpdateWorkOrderPageObjects = new FSRResponseUpdateWorkOrderPageObjects();
        $x("//iframe[@title='Service Delivery']").shouldBe(visible, Duration.ofSeconds(60));
        switchTo().frame($x("//iframe[@title='Service Delivery']"));
        fsrResponseUpdateWorkOrderPageObjects.clickOnSaveButton().handlingErrorWarningPostSaveInUpdateWOPage();

    }



}
