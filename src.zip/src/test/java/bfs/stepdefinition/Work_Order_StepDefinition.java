package bfs.stepdefinition;
import bfs.pages.bfo.PageObjects.BFODurationPageObjects;
import com.beust.ah.A;
import com.jacob.activeX.ActiveXComponent;
import bfs.CONSTANTS;
import bfs.pages.BasePage;
import bfs.pages.bfo.*;
import bfs.pages.bfo.PageObjects.BFOFlowOfWorkOrderPageObjects;
import com.jacob.activeX.ActiveXComponent;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.java.jv.Lan;
import org.apache.commons.collections4.list.PredicatedList;
import bfs.sap.*;
import org.junit.Assert;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.*;

import static bfs.CONSTANTS.captureScreen;
import static bfs.CONSTANTS.memorizedData;
import static bfs.pages.BasePage.waitForPageLoad;
import static bfs.pages.bfo.ApplicationCommonMethods.waitForGivenTime;
import static com.codeborne.selenide.Selenide.*;

public class Work_Order_StepDefinition {

    private String selectedMenu;
    private String mainIP;
    private String splitWorkOrderNumber;
    private String firstMaterialItem;
    private String secondMaterialItem;
    private String firstMaterial;
    private String secondMaterial;
    //    private String maintainanceContractId;
    private String workOrderType;
    private String seAccountId;
    private String workOrderOwner;
    private String workOrderSubType;
    private String mainWorkOrderNumber;
    private String sapWorkOrderNumber;
    private String workOrderId;
    private String partsReferenceValue;
    private String backOfficeNumber;
    private String workOrderName;
    private String  workOrderReason;
    private String additionalProductName;
    private String clipboardContent;
    private String additionalNonReferenceProductName;
    private List<String> selectedTitles;
    private List<String> installedProducts;
    private List<String> serialNumbers;
    private SplitWorkOrders SplitWorkOrders = new SplitWorkOrders();
    private List<String> actualSerialNumbers;
    private List<String> actualInstalledProducts;
    private List<String> lineItemNumbers;
    private String lineNumber;
    private List<String> additionalProductNames = new ArrayList<>();
    private List<String> availablePartsAdded = new ArrayList<>();
    private List<String> workDetailTitles;
    private List<String> partsOrderNumber;
    private List<String> lineNumberValue;
    private static String workOrderNumber;
    public static String contractStartDateValue;
    public static  String contractEndDateValue;
    public static  String contractTomorrowStartDateValue;
    public static  String contractTomorrowYearEndDateValue;
    public static List<String> workOrderNumbers = new ArrayList<>();


    private ActiveXComponent wnd;
    @Given("I work in application {string}")
    public void iWorkInApplication(String arg0) throws InterruptedException {
        SAPLogin.initializeSAP();


    }

    @When("I navigate to {string}")
    public void iNavigateTo(String arg0) throws InterruptedException {
        SAPLogin.loginToTRASystem("(Bridge) ECC 6.0 SSO - QRH - Pre-Production APAC");

    }

    //    @And("I Search Standard Order in Order field")
//    public void iSearchInOrderField() throws InterruptedException, IOException {
//        LandingPage.enterTransactionCode("iw33");
//        LandingPage.enterOrderNumber(backOfficeNumber);
//        LandingPage.selectEnhancement();
//        String OrderId = LandingPage.getWorkOrderId();
//        LandingPage.compareText(OrderId, workOrderId);
//        String bfoNumber = LandingPage.getBfoNumber();
//        LandingPage.compareText(bfoNumber, mainWorkOrderNumber);
//        String workOrderType = LandingPage.getWorkOrderType();
//        LandingPage.compareText(workOrderType, "Repair");
//
//
//
//    }
    @And("I Search Order and verify")
    public void iSearchInOrderField() throws InterruptedException, IOException {
        LandingPage.enterTransactionCode("iw33");
        LandingPage.enterOrderNumber(backOfficeNumber);
//        LandingPage.enterOrderNumber("005200514162");
        String workOrderNameReason = LandingPage.getStatus();
        String [] parts = workOrderNameReason.split(" ", 5);
        String sapWorkOrderCreate = parts[0];
        LandingPage.compareText(sapWorkOrderCreate, "CRTD");
        String workOrderMnWkCtr = LandingPage.getMnWkCtr();
        System.out.println("Memorized order MnWkCtr is : " + workOrderMnWkCtr);
//        LandingPage.compareText(workOrderMnWkCtr,workOrderOwner);
//        LandingPage.assertPartialMatch(workOrderOwner,workOrderMnWkCtr);
//        LandingPage.compareText(workOrderOwner,workOrderMnWkCtr);
//        LandingPage.assertPartialMatchs(workOrderOwner,workOrderMnWkCtr);
        LandingPage.assertDynamicPartialMatch(workOrderOwner,workOrderMnWkCtr);
        LandingPage.selectOperations();
        String workOrderFirstActValue = LandingPage.getOperationFirstActValue();
        System.out.println("Memorized FirstActValue is : " + workOrderFirstActValue);
        LandingPage.compareText(workOrderFirstActValue, "0010");
        String workOrderSecondActValue = LandingPage.getOperationSecondActValue();
        System.out.println("Memorized SecondActValue is : " + workOrderSecondActValue);
        LandingPage.compareText(workOrderSecondActValue, "0020");
        LandingPage.selectEnhancement();
        String OrderId = LandingPage.getWorkOrderId();
        LandingPage.compareText(OrderId, workOrderId);
        String bfoNumber = LandingPage.getBfoNumber();
        LandingPage.compareText(bfoNumber, mainWorkOrderNumber);
        String workOrderType = LandingPage.getWorkOrderType();
//        LandingPage.compareText(workOrderType, "Repair");
        LandingPage.compareText(workOrderType, workOrderType);
        String workOrderSubType = LandingPage.getWorkOrderSubType();
        LandingPage.compareText(workOrderSubType, workOrderSubType);
        LandingPage.selectPartner();
        String shipToParty = LandingPage.getPartnerShipToParty();
        System.out.println("Memorized SecondActValue is : " + shipToParty);
        String soldToParty = LandingPage.getPartnerSoldToParty();
        System.out.println("Memorized SecondActValue is : " + soldToParty);
        LandingPage.enterTransactionCode("/ose16n");
        clipboardContent = LandingPage.enterTableName("kna1",seAccountId);
        LandingPage.compareText(clipboardContent, shipToParty);
        LandingPage.compareText(clipboardContent, soldToParty);

    }
    @And("I create contract")
    public void createContract() throws InterruptedException, IOException {
        LandingPage.enterTransactionCode("va41");
        LandingPage.enterContractType("ZWV2");
        LandingPage.enterSalesOrganization("AU01");
        LandingPage.enterDistributionChannel("OG");
        LandingPage.enterDivision("01");
        LandingPage.enterSoldtoParty("45327");
        LandingPage.enterShiptoParty("45327");
        LandingPage.enterPurchOrderNumber("test67");
        Work_Order_StepDefinition.contractStartDateValue = LandingPage.enterContractStartDate();
        System.out.println("Contract Start Date Value: " + contractStartDateValue);
//        SAPLogin.acceptPopUp();
        Work_Order_StepDefinition.contractEndDateValue = LandingPage.enterContractEndDate();
        System.out.println("Contract End Date Value: " + contractEndDateValue);
        LandingPage.enterMaterial("Srvapadvpln_plus");
        LandingPage.enterTargetQuantity("1");
        LandingPage.enterOrderQuantity("1");
        LandingPage.clickSaveButton();
        SAPLogin.acceptPopUp();
        SAPLogin.clickSalesDocument();
        String contractId = LandingPage.getContractId();
        memorizedData.put("contractIdnNumber", contractId);
        String MaintainanceContractId = "QRH200-00" + contractId;
        System.out.println(contractId + " " + MaintainanceContractId);
        memorizedData.put("maintainanceContractId", "QRH200-00" + contractId);
        System.out.println("Contract ID: " + memorizedData.get("maintainanceContractId"));
//        System.out.println("Contract Start Date: " + memorizedData.get("QRH200-00" + contractId));

//        SAPLogin.acceptPopUp();
//        SAPLogin.acceptSavePopUp();

//        LandingPage.entercontractOrderNumber("0040182222");
//        SAPLogin.acceptPopUp();
////        LandingPage.click();
//        LandingPage.clickDisplayHeaderdetails();
//        SAPLogin.acceptDisplayPopUp();
////        LandingPage.click();
//        LandingPage.clickStatusTab();
//        SAPLogin.acceptPopUp();
//        String contractStatus = LandingPage.contractUserStatus();
//        LandingPage.compareText(contractStatus, "Vali");

    }
    @And("I create work order")
    public void createWorkOrderInSap() throws InterruptedException, IOException {
        LandingPage.enterTransactionCode("IW31");
        LandingPage.enterOrderType("ZS01");
        LandingPage.enterPriority("3");
        LandingPage.enterPingPlant("AU50");
        SAPLogin.enter();
        LandingPage.enterPriority("3");
        LandingPage.enterPingPlant("AU50");
        LandingPage.enterWorkOrderSoldToParty("46313");
        LandingPage.enterServiceProduct("SRVAPELVCOMS_0QGP");
        LandingPage.enterWorkOrderQuantity("1");
        LandingPage.enterWorkOrderAccountIndicator("41");
        LandingPage.enterWorkOrderMnWkCtrFirst("SGENI0WA");
        LandingPage.enterWorkOrderMnWkCtrSecond("AU50");
        LandingPage.enterWorkOrderOperationValue("BFS EXPENSES");
        LandingPage.enterWorkOrderWkCtrPlnt("SGENI0");
        LandingPage.enterWorkOrderCrlkey("ZSM9");
        LandingPage.selectPartner();
        LandingPage.enterWorkOrderShipToParty("SH");
        LandingPage.enterWorkOrderPartnerValue("46313");
        SAPLogin.enter();
        LandingPage.clickSaveButton();
        SAPLogin.enter();
        SAPLogin.clickOrder();
        String createdWorkOrderValue = LandingPage.getOrderNumber();
        System.out.println("Created work order Value is : " + createdWorkOrderValue);
        LandingPage.enterOrderNumber(createdWorkOrderValue);
        LandingPage.selectEnhancement();
        sapWorkOrderNumber = LandingPage.getBfoNumber();
    }
    @And("I log out sap")
    public void sapLogOut() throws InterruptedException, IOException {
        SAPLogin.closeSAPWithAltF4();

    }


    @And("I verify updated contract")
    public void verifyUpdatedContractSap() throws InterruptedException, IOException {
        LandingPage.enterTransactionCode("va43");
//        LandingPage.entercontractOrderNumber("40182521");
        LandingPage.entercontractOrderNumber(memorizedData.get("contractIdnNumber"));
//        SAPLogin.acceptPopUp();
        LandingPage.clickDisplayHeaderdetails();
//        SAPLogin.acceptDisplayPopUp();
        LandingPage.clickStatusTab();
//        SAPLogin.acceptPopUp();
        String contractStatus = LandingPage.contractUserStatus();
        LandingPage.compareText(Service_Contract_StepDefinition.statusValue,contractStatus);

    }
    @And("I changed the contract in sap")
    public void verifyChangedContractSap() throws InterruptedException, IOException {
        LandingPage.enterTransactionCode("va43");

        SAPLogin.clickChangeSalesDocument();
//        LandingPage.entercontractOrderNumber("40182521");
        LandingPage.entercontractOrderNumber(memorizedData.get("contractIdnNumber"));
        Work_Order_StepDefinition.contractTomorrowStartDateValue = LandingPage.enterContractTomorrowStartDateInSAP();
        System.out.println("Contract Start Date Value: " + contractTomorrowStartDateValue);
        Work_Order_StepDefinition.contractTomorrowYearEndDateValue = LandingPage.enterContractTomorrowYearEndDateInSAP();
        System.out.println("Contract End Date Value: " + contractTomorrowYearEndDateValue);
        LandingPage.enterSecondMaterial("Srvapadvpln_plus");
        LandingPage.enterSecondTargetQuantity("1");
        LandingPage.enterSecondOrderQuantity("1");


        LandingPage.clickSaveButton();
        LandingPage.entercontractOrderNumber(memorizedData.get("contractIdnNumber"));
        firstMaterialItem = LandingPage.getFirstMaterialItem();
        secondMaterialItem = LandingPage.getSecondMaterialItem();
        firstMaterial = LandingPage.getFirstMaterial();
        secondMaterial = LandingPage.getSecondMaterial();

    }


    @Then("I Search Order and verify updated details")
    public void  updatedDetails() throws InterruptedException, IOException {
        LandingPage.enterTransactionCode("iw33");
        LandingPage.enterOrderNumber(backOfficeNumber);
        String workOrderNameReason = LandingPage.getWorkOrderNameReason();
        String [] parts = workOrderNameReason.split(" ", 2);
        String sapWorkOrderName = parts[0];
        String sapWorkOrderReason = parts[1];
        LandingPage.compareText(sapWorkOrderName, workOrderName);
        LandingPage.compareText(sapWorkOrderReason, workOrderReason);
        SAPLogin.closeSAPWithAltF4();

    }

    @And("I Search Order and verify parts order")
    public void iSearchPartsOrder() throws Exception {
        LandingPage.enterTransactionCode("iw33");
        LandingPage.enterOrderNumber(backOfficeNumber);
//        LandingPage.enterOrderNumber("005200514187");
        String workOrderNameReason = LandingPage.getStatus();
        String [] parts = workOrderNameReason.split(" ", 4);
        String sapWorkOrderRelease = parts[0];
        LandingPage.compareText(sapWorkOrderRelease, "REL");
        LandingPage.selectComponent();
        String partsOrderValue = LandingPage.getPartsOrder();
//        LandingPage.compareText(partsOrderValue, "PAS600");
        LandingPage.compareText(partsOrderValue, partsReferenceValue);
        LandingPage.clickDocumentFlowButton();
        String refPartsOrder = LandingPage.pressDownTabAndCopy();
        System.out.println("Memorized ref parts order is : " + refPartsOrder);
        LandingPage.assertPartialRefNumberMatch(refPartsOrder, "Consig Fill up");
    }

    @When("the user selects {string} from the Search menu")
    public void selectMenuFromSearch(String menu) {
        sleep(3000);
        selectedMenu = menu;
        new ApplicationCommonMethods().enterTextInSearchMenu(menu).selectOptionFromSearchMenu(menu);


    }

    @And("the user enters {string} in Global Search")
    public void searchCaseId(String case_id) {
        new ApplicationCommonMethods().globalSearch(case_id).validateTextInElement(selectedMenu);
    }


    @And("the user selects the {string} from search results")
    public void selectCaseIdFromSearchResults(String case_id) {
        new ApplicationCommonMethods().navigateToSearchValue(case_id);
    }

    @And("the user selects the {string} tab in Case Details")
    public void selectsTabFromCase(String tab_name) {
        new ApplicationCommonMethods().navigateToTab(tab_name);
    }

    @And("the user selects {string} and chooses {string}")
    public void selectsWorkOrderFromCases(String show_all, String option) {
        new ApplicationCommonMethods().clickShowAll().clickOnRelatedList(option);
    }

    @And("the user selects {string}")
    public void createWorkOrder(String create_work_order) {
        new CaseWorkOrders().clickCreateWorkOrder();

    }


    @And("the user selects {string} as {string}")
    public void selectsBusinessUnitField(String labelText, String value) {
        new CaseWorkOrders().selectServicesBusinessUnit(labelText, value);
    }


    @And("the user enters the {string} as {string}")
    public void selectsTheLocation(String labelText, String location) {
        new CaseWorkOrders().selectLocation(labelText, location);
    }

    @Then("I memorize work Order as {string}")
    public void i_memorize_work_order_as(String WOnumber) {
        String WONumber =new WorkOrders().WorkOrderNumber();
        memorizedData.put(WOnumber, WONumber);
        System.out.println("Memorized Work Order Number: " + WONumber);
    }

    @And("the user selects Save Work Order")
    public void clickSaveWorkOrder() {
        new CaseWorkOrders().clickSaveWorkOrder();
    }

    @And("the user selects the {string}")
    public void clickCloneWorkOrder(String cloneWO) {
        new WorkOrders().clickCloneWorkOrder();
    }

    @And("the user verifies the {string} as {string}")
    public void verifyCaseDetails(String labelText, String case_id) {
        new WorkOrders().verifyCaseDetails(labelText, case_id);
    }

    @And("i update the Total Quoted Hrs in the Clone Page for Clone Work order to {string}")
    public void updateTotalQuotedHrsForCloneWO(String hrs) {
        new WorkOrders().setTotalQuotedHrs(hrs);
    }

    @And("the user selects date from {string} Date Picker")
    public void selectCustomerRequestedDate(String labelText) {
        new WorkOrders().selectCustomerRequestDate(labelText, "MM/dd/yyyy");
    }

    @When("the user update {string} as {string}")
    public void selectServiceCommercialRef(String labelText, String value) {
        new ApplicationCommonMethods().updateField(labelText, value);
    }

    @When("the user modify {string} as {string}")
    public void modifyWorkOrderDetails(String labelText, String value) {
        new ApplicationCommonMethods().updateTextAreaField(labelText, value);
    }

//    @And("I add Service/Maintance Contract to Work Order:")
//    public void addServiceMaintanceToWorkOrder(DataTable dataTable) {
//
//    }

    @And("the user selects the {string} from Location Details")
    public void clickNewWorkOrderFromLocation(String labelText) {
        new LocationsWorkOrders().clickNewWorkOrder().clickContinueWorkOrder();
    }
    @And("the user select the {string} from Location Details")
    public void clickEmergencyWorkOrderFromLocation(String labelText) {
        new LocationsWorkOrders().clickEmergencyWorkOrder();
    }
    @And("the user selects the {string} tab in Work Order Details")
    public void selectInstalledProducts(String tab) {
        new ApplicationCommonMethods().navigateToTab(tab);

    }

    @And("the user perform {string}")
    public void theUserPerform(String headerText) {
        new WorkOrdersIpAndSkills().clickNewInstalledProducts().validateInstalledProductText("Search and Create Installed Product");
        selectedTitles = new WorkOrdersIpAndSkills().selectInstalledProductCheckboxes(); // Call the Page Class method
        System.out.println("Stored Titles in Step Definition: " + selectedTitles);
        new WorkOrdersIpAndSkills().selectInstalledProductsRadio();
        new WorkOrdersIpAndSkills().clickAttachIP();
    }

    @Then("the added Installed Products should be displayed")
    public void verifySelectedInstalledProducts() {
        installedProducts = new WorkOrdersIpAndSkills().getInstalledProductTitles();
        System.out.println("Get Titles in Installed Products: " + installedProducts);
        new WorkOrdersIpAndSkills().compareSelectedAndInstalledProducts(selectedTitles, installedProducts);
    }

    @And("the user creates new IP with following data and Validates the Created IP")
    public void createIP(DataTable table) {
        WorkOrdersIpAndSkills workOrdersIpAndSkills = new WorkOrdersIpAndSkills();
        workOrdersIpAndSkills.clickNewInstalledProducts().validateInstalledProductText("Search and Create Installed Product");
        List<Map<String, String>> filters = table.asMaps(String.class, String.class);
        for (int i = 0; i < filters.size(); i++) {
            Map<String, String> fields = filters.get(i);
            workOrdersIpAndSkills.clickOnCreateNewbutton();
            workOrdersIpAndSkills.filterAndCreatenewIP(fields);
            workOrdersIpAndSkills.validateNewIPCreated(fields);
            workOrdersIpAndSkills.clickOnCloseButton();
        }
    }



//    @Then("I add Service Maintenance Contract to Work Order:")
//    public void i_add_service_maintenance_contract_to_work_order(io.cucumber.datatable.DataTable dataTable) {
//        Map<String, String> fields = new BasePage().storeFieldsIn(dataTable.asMap());
//        for (Map.Entry<String, String> entry : fields.entrySet()) {
//            String key = entry.getKey();
//            String value = entry.getValue();
//            switch (key.toLowerCase()) {
//                case "service/maintenance contract" -> new WorkOrders().add_Service_Maintanance_Heder_to_Work_Order(value);
//                case "service contract line" -> new WorkOrders().add_Service_Maintanance_Line_to_Work_Order(value);
//                default -> System.out.println("Not Implemented for " + key);
//            }
//        }
//    }

    @Then("I add Service Maintenance Contract to Work Order:")
    public void i_add_service_maintenance_contract_to_work_order(DataTable dataTable) {
        Map<String, String> fields = new BasePage().storeFieldsIn(dataTable.asMap());
        for (Map.Entry<String, String> entry : fields.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();
            switch (key.toLowerCase()) {
                case "service/maintenance contract" -> new WorkOrders().add_Service_Maintanance_Heder_to_Work_Order(value);
                case "service contract line" -> new WorkOrders().add_Service_Maintanance_Line_to_Work_Order(value);
                default -> System.out.println("Not Implemented for " + key);
            }
        }
        captureScreen = true;
        new BFOStandaloneNewWorkOrderPageObjects().clickOnSaveButton();
    }

    @And("I click on Create Dependency Group button from work order page")
    public void iClickOnCreateDependencyGroupButtonFromWorkOrderPage() {
        new WorkOrders().createDependentGroup();

    }
    @And("memorize the Main IP")
    public void memorizeMainIP() {
        mainIP = new SplitWorkOrders().getMainIP();
        System.out.println("MAIN IP: " + mainIP);
    }
    //Split Work Order or follow up work order
    @And("the user selects the {string} tab in SFM")
    public void selectSplitWorkOrder(String labelText) {
//        mainIP = new SplitWorkOrders().getMainIP();
//        System.out.println("MAIN IP: " + mainIP);
        new SplitWorkOrders().clickSplitOrder(labelText);
    }

    @And("the user enters {string} as {string}")
    public void enterWorkOrderReason(String arg0, String reason) {
        new SplitWorkOrders().enterWorkOrderReason(reason);
    }

    @And("the user selects date from {string} from Split Work Order")
    public void selectCustomerRequestDate(String labelText) {
        new SplitWorkOrders().selectCustomerRequestDate(labelText, "dd/MM/yyyy");
    }

    @And("the user deletes the Main IP from Service Installed Product")
    public void clickDeleteForMainIp() {
        new SplitWorkOrders().clickDetailsButton(mainIP).clickDeleteLink();
    }

    @And("the user selects one of {string}")
    public void selectOneOfMipFlag(String arg0) {
        new SplitWorkOrders().selectRandomCheckbox();
        actualSerialNumbers = SplitWorkOrders.getSerialNumbers();
        System.out.println("SERIAL NUMBERS: " + actualSerialNumbers);
        actualInstalledProducts = SplitWorkOrders.getInstalledProducts();
        System.out.println("PRODUCTS INSTALLED: " + actualInstalledProducts);
    }

    @And("the user selects Save Split Work Order")
    public void theUserSelectsSaveSplitWorkOrder() {
        new SplitWorkOrders().clickSaveSplitWorkOrder();


    }


    @Then("the split work orders should be displayed")
    public void verifySplitWorkOrders() {
        splitWorkOrderNumber = new SplitWorkOrders().getSplitWorkOrderNumber();
        System.out.println("splitWorkOrderNumber: " + splitWorkOrderNumber);
        installedProducts = new WorkOrdersIpAndSkills().getInstalledProductTitles();
        serialNumbers = new WorkOrdersIpAndSkills().getSerialNumbers();
        new ApplicationCommonMethods().compareSelectedAndInstalledProducts(actualInstalledProducts, installedProducts);
        new ApplicationCommonMethods().compareSelectedAndInstalledProducts(actualSerialNumbers, serialNumbers);

    }

    @Then("the Main IP should be displayed")
    public void verifyMainIP() {
        String mainWoIp = new SplitWorkOrders().getMainIP();
        new ApplicationCommonMethods().compareStrings(mainIP, mainWoIp);
    }

    // Follow Up Work Order

    @And("the user selects {string} as {string} in Follow up Work Order")
    public void selectRevisitReason(String labelText, String value) {
        new FollowUpWorkOrder().selectRevisitReason(labelText, value);
    }

    @And("the user selects date from {string} from Follow up Work Order")
    public void selectFollowUpCustReqDate(String labelText) {
        new SplitWorkOrders().selectCustomerRequestDate(labelText, "MM/dd/yyyy");
    }

    @And("the user selects Save Follow Up Work Order")
    public void saveFollowUpOrder() {
        new FollowUpWorkOrder().clickSaveFollowUpWorkOrder();
    }

    @When("the user search and selects the {string}")
    public void searchAndSelectSplitWorkOrder(String menuName) {
//        mainWorkOrderNumber = "WO-13215733"; // todo delete this line
        new ApplicationCommonMethods().globalSearch(mainWorkOrderNumber).validateTextInElement(menuName);
        new ApplicationCommonMethods().navigateToSearchValue(mainWorkOrderNumber);
    }
//    @When("the user search contract and selects the {string}")
//    public void searchContactId(String menuName) {
//        new ApplicationCommonMethods().globalSearch(maintainanceContractId).validateTextInElement(menuName);
//        new ApplicationCommonMethods().navigateToSearchValue(maintainanceContractId);
//    }

    @Then("user should be able to see the work order number and memorize work order number")
    public void getWorkOrderNumber() {
        mainWorkOrderNumber = new SplitWorkOrders().getSplitWorkOrderNumber();
        System.out.println("mainWorkOrderNumber: " + mainWorkOrderNumber);
    }

    @Then("I save the Work Order number")
    public void storeWorkOrders() {
        workOrderNumbers.add(mainWorkOrderNumber);
    }

    @Then("switch to Work order page")
    public void switchToDefaultContent() {
        switchTo().defaultContent();
    }

    @Then("user should be able to see the work order number and memorize work order number for recurring Assignment")
    public void getWorkOrderNumberForRecurringAssignment() {
        mainWorkOrderNumber = new SplitWorkOrders().getSplitWorkOrderNumber();
        workOrderNumber=mainWorkOrderNumber;
        System.out.println("mainWorkOrderNumber: " + mainWorkOrderNumber);
    }
    @And("user should be able to get the work order id from the url and memorize")
    public void getWorkOrderIdFromUrl() {
        workOrderId = new SplitWorkOrders().getServiceOrderId();
        System.out.println("WorkOrderIdUrl: " + workOrderId);
    }
    @And("memorize the Work order type")
    public void getWorkOrderType() {
        workOrderType = new BFOFlowOfWorkOrderPageObjects().getWorkOrderType();
        System.out.println("work order type is: " + workOrderType);
    }

    @And("memorize the Work order owner")
    public void getWorkOrderOwner() {
        workOrderOwner = new BFOFlowOfWorkOrderPageObjects().getWorkOrderOwner();
        System.out.println("work order owner is : " + workOrderOwner);
    }
    @And("memorize the Work order subtype")
    public void getWorkOrderSubType() {
        workOrderSubType = new BFOFlowOfWorkOrderPageObjects().getWorkOrderSubType();
        System.out.println("work order type is: " + workOrderSubType);
    }
    @And("memorize the Work order name and reason")
    public void getWorkOrderNameReason() {
        workOrderName = new BFOFlowOfWorkOrderPageObjects().getWorkOrderName();
        System.out.println("work order type is: " + workOrderName);
        workOrderReason = new BFOFlowOfWorkOrderPageObjects().getWorkOrderReason();
        System.out.println("work order type is: " + workOrderReason);
    }

    @And("memorize the back office reference number")
    public void getBackOfficeNumber() {
        backOfficeNumber = new BFOFlowOfWorkOrderPageObjects().getBackOfficeReferenceNumber();
        System.out.println("backOfficeNumber: " + backOfficeNumber);

    }
    @And("click on account link")
    public void clickOnAccount() {
        new BFOFlowOfWorkOrderPageObjects().clickOnAccount();


    }
    @And("memorize SEAccountId")
    public void getSEAccountId() {
        seAccountId = new BFOFlowOfWorkOrderPageObjects().getAccountIdText();
        System.out.println("se account id is: " + seAccountId);
    }



//    @And("memorize the Work order type")
//    public void getWorkOrderType() {
//        workOrderType = new BFOFlowOfWorkOrderPageObjects().getWorkOrderType();
//        System.out.println("work type is: " + workOrderType);
//    }


    @And("the user selects the {string} in {string} Tab")
    public void clickNewPartOrder(String arg0, String arg1) {
        new PartsOrder().clickNewPartsOrders();

    }
    @And("^the user creates multiple Parts Orders$")
    public void createMultiplePartsOrders(DataTable table) {
        List<Map<String, String>> orders = table.asMaps(String.class, String.class);

        for (int i = 0; i < orders.size(); i++) {
            Map<String, String> order = orders.get(i);

            // Navigate to the tab in each iteration
            System.out.println("Navigating to tab: " + order.get("Tab"));
            new ApplicationCommonMethods().navigateToTab(order.get("Tab"));

            // Click "New Parts Order"
            new PartsOrder().clickNewPartsOrders();

            // Select Parts Order Details
            new PartsOrder().selectPartsOrderType(
                    "Parts Order Type",
                    order.get("Parts Order Type"),
                    "Requested Ship Date",
                    order.get("Requested Ship Date"),
                    "Ship From Plant",
                    order.get("Ship From Plant")
            ).clickNextButton();

            // Add Additional Products
            new PartsOrder().clickAddLine().enterProductName(order.get("Product Name"));
            String additionalProductName = new PartsOrder().clickGo().selectAdditionalProduct(order.get("Product Name"));

            // Store additional product name in the global list
            additionalProductNames.add(additionalProductName);

            // Save and Release Parts Order
            new PartsOrder().clickAdd().selectPartsOrderLineItems(additionalProductName)
                    .clickAtpCheck()
                    .clickSaveReleasePartsOrder();
        }

        // Optional: Print collected product names
        System.out.println("Collected Additional Product Names: " + additionalProductNames);
    }

    @And("^the user adds multiple Parts to validate messages of ATP Check$")
    public void addMultiplePartsToValidateMessagesOfATPChecks(DataTable table) {
        List<Map<String, String>> orders = table.asMaps(String.class, String.class);
        for (int i = 0; i < orders.size(); i++) {
            Map<String, String> order = orders.get(i);
            new PartsOrder().clickAddLine().enterProductName(order.get("Product Name"));
            String additionalProductName = new PartsOrder().clickGo().selectAdditionalProduct(order.get("Product Name"));
            additionalProductNames.add(additionalProductName);
            new PartsOrder().clickAdd().selectPartsOrderLineItems(additionalProductName);
        }
        availablePartsAdded = new PartsOrder().clickAtpCheck().validateATPCheckMessages(additionalProductNames).deleteOrangesAndReds(additionalProductNames);
    }

    @And("^the user adds multiple Parts and validates ATP Check status$")
    public void validateATPChecksStatus(DataTable table) {
        List<Map<String, String>> orders = table.asMaps(String.class, String.class);
        for (int i = 0; i < orders.size(); i++) {
            Map<String, String> order = orders.get(i);
            new PartsOrder().clickAddLine().enterProductName(order.get("Product Name"));
            String additionalProductName = new PartsOrder().clickGo().selectAdditionalProduct(order.get("Product Name"));
            additionalProductNames.add(additionalProductName);
            new PartsOrder().clickAdd().selectPartsOrderLineItems(additionalProductName);
        }
        new PartsOrder().clickAtpCheck().validateATPErrorAndWarningForAddedPart(additionalProductNames).clickSaveReleasePartsOrder();
    }

    @And("^the user creates multiple Parts Orders Lines$")
    public void createMultipleReferencePartsOrdersLINES(DataTable table) {
        List<Map<String, String>> orders = table.asMaps(String.class, String.class);

        for (int i = 0; i < orders.size(); i++) {
            Map<String, String> order = orders.get(i);

            // Add Additional Products
            new PartsOrder().clickAddLine().enterProductName(order.get("Product Name"));
            String additionalProductName = new PartsOrder().clickGo().selectAdditionalProduct(order.get("Product Name"));

            // Store additional product name in the global list
            additionalProductNames.add(additionalProductName);

            // Save and Release Parts Order
            new PartsOrder().clickAdd().selectPartsOrderLineItems(additionalProductName)
                    .clickAtpCheck();

        }
        new PartsOrder().clickSaveReleasePartsOrder();

        // Optional: Print collected product names
        System.out.println("Collected Additional Product Names: " + additionalProductNames);
    }

    @And("^the user creates multiple Parts Orders Lines and save$")
    public void createMultipleReferencePartsOrdersAndSave(DataTable table) {
        List<Map<String, String>> orders = table.asMaps(String.class, String.class);

        for (int i = 0; i < orders.size(); i++) {
            Map<String, String> order = orders.get(i);

            // Add Additional Products
            new PartsOrder().clickAddLine().enterProductName(order.get("Product Name"));
            String additionalProductName = new PartsOrder().clickGo().selectAdditionalProduct(order.get("Product Name"));

            // Store additional product name in the global list
            additionalProductNames.add(additionalProductName);

            // Save and Release Parts Order
            new PartsOrder().clickAdd().selectPartsOrderLineItems(additionalProductName)
                    .clickAtpCheck();

        }
        new PartsOrder().clickSavePartsOrder();

        // Optional: Print collected product names
        System.out.println("Collected Additional Product Names: " + additionalProductNames);
    }

    @And("select {string} as {string} in line order")
    public void enterEntitlementReasonInLineOrder(String fieldname, String value) {
        new PartsOrder().selectEntitlementReasonFromLineOrder(fieldname, value);
    }

    @And("verify Sync in ERP from Parts Order is successful with message {string}")
    public void verifySyncInERP(String expectedMessage) {
        new PartsOrder().verifySyncInERPInPartsOrder(expectedMessage);
    }

    @And("^the user creates multiple Non Reference Parts Orders$")
    public void createMultipleNonReferencePartsOrders(DataTable table) {
        List<Map<String, String>> orders = table.asMaps(String.class, String.class);
        int j=1;
        for (int i = 0; i < orders.size(); i++) {
            Map<String, String> order = orders.get(i);

            // Navigate to the tab in each iteration
            System.out.println("Navigating to tab: " + order.get("Tab"));
            new ApplicationCommonMethods().navigateToTab(order.get("Tab"));

            // Click "New Parts Order"
            new PartsOrder().clickNewPartsOrders();

            // Select Parts Order Details
            new PartsOrder().selectPartsOrderType(
                    "Parts Order Type",
                    order.get("Parts Order Type"),
                    "Requested Ship Date",
                    order.get("Requested Ship Date"),
                    "Ship From Plant",
                    order.get("Ship From Plant")
            ).clickNextButton();

            new PartsOrder().clickAddLine_NonReferenceSparePart();

            for (Map.Entry<String, String> entry : order.entrySet()) {
                String key = entry.getKey();
                String value = entry.getValue();
                switch (key) {
                    case "Text Reference" -> {
                        new PartsOrder().enterTextReference(value,j);
                        additionalProductName = value;
                    }
                    case "Unit Of Measure" -> new PartsOrder().selectUnitOfMeasure(value,j);
                    case "Order Type" -> new PartsOrder().selectOrderType(value,j);
                    case "Committed Ship date" -> new PartsOrder().enterCommittedShipDate(value,j);
                    default -> System.out.println("Not Implemented for " + key);
                }
            }

            // Store additional product name in the global list
            additionalProductNames.add(additionalProductName);

            // Save and Release Parts Order
            new PartsOrder().clickSaveReleasePartsOrder();
        }

        // Optional: Print collected product names
        System.out.println("Collected Additional Product Names: " + additionalProductNames);
    }


    @Then("the parts order status should be {string} in {string}")
    public void verifyPartsOrderStatus(String status, String tab) {
        new PartsOrder().checkPartsOrderStatus(tab, status);
    }

    @And("the parts order should be memorized")
    public void getPartsOrderNumber() {
        partsOrderNumber = new PartsOrder().getPartsOrderNumber();
        System.out.println("Parts Order Numbers: " + partsOrderNumber);
        lineNumberValue = new PartsOrder().getLineNumbers();
        System.out.println("Line Numbers: " + lineNumberValue);


    }

    @And("memorize the parts order reference")
    public void getPartsReference() {
        partsOrderNumber = new PartsOrder().getPartsOrderNumber();
        System.out.println("Parts Order Numbers: " + partsOrderNumber);
        lineNumberValue = new PartsOrder().getLineNumbers();
        System.out.println("Line Numbers: " + lineNumberValue);
        partsReferenceValue = new PartsOrder().getPartsReferenceValue();
        System.out.println("Parts Reference value is " + partsReferenceValue);

    }


    @When("the user updates the Line Details")
    public void modifyLineDetails(DataTable table) {
        List<Map<String, String>> orders = table.asMaps(String.class, String.class);


//        List<String> lineNumberValue = new ArrayList<>(); //todo delete
//        lineNumberValue.add("LN-04908106"); //todo delete
//        lineNumberValue.add("LN-04908107");  //todo delete


        if (lineNumberValue.isEmpty()) {
            throw new RuntimeException("No Line Numbers found.");
        }

        for (Map<String, String> order : orders) {
            // Process line items once per unique Product Name
            Set<String> processedItems = new HashSet<>();

            for (String orderNumber : lineNumberValue) {
                if (!processedItems.contains(orderNumber)) {
                    // Select Line Details only if not processed
                    lineItemNumbers = new PartsOrder().processLineNumbers(
                            orderNumber,
                            "Line Status", order.get("Line Status"),
                            "Shipped Qty", order.get("Shipped Qty"),
                            "Expected Arrival Date", "Actual Arrival Date",
                            "dd/MM/yyyy"
                    );
                    processedItems.add(orderNumber);

                    System.out.println("Processed line items for Order: " + orderNumber + " -> " + lineItemNumbers);
                }
            }
        }
    }

    @And("the user update the {string} and enters the {string} as {string} in Planned Parts")
    public void updateLineItemQuantity(String arg0, String labelText, String quantity) {
//    workDetailTitles = new ArrayList<>();
//        workDetailTitles.add("WL-46694151"); //todo delete
//        workDetailTitles.add("WL-46694152"); //todo delete

        for (String workLineItem : workDetailTitles) {
            new WorkDetails().clickDetailsButton(workLineItem).clickEditLink();
            new WorkDetails().enterInstalledQuantity(labelText, quantity);
            new WorkDetails().clickUpdatePlannedParts();

        }
    }

    @And("the user selects the {string} as {string}, {string} and {string} in New Parts Order")
    public void selectNewPartsOrderBasicDetails(String partyOrderTypeText, String partsOrderType, String requestedDate, String plantValue) {
        new PartsOrder().selectPartsOrderType(partyOrderTypeText, partsOrderType, requestedDate, "dd MMM yyyy", "Ship From Plant", plantValue).clickNextButton();
    }

    @And("the user add {string} as {string}")
    public void addAdditionalProducts(String arg0, String productName) {

        new PartsOrder().clickAddLine().enterProductName(productName);
        additionalProductName = new PartsOrder().clickGo().selectAdditionalProduct(productName);
    }


    @And("the user adds a Non Reference Part with details:")
    public void addNonReferenceAdditionalProducts(DataTable table) {
        additionalProductNames= new PartsOrder().clickAddLine_NonReferenceSparePart().addNonreferenceProduct(table);
    }

    @And("the user adds multiple Non Reference Part Lines with details")
    public void addNonReferenceAdditionalProductLines(DataTable table) {
        additionalProductNames= new PartsOrder().addNonreferenceProduct(table);
    }
    @And("the user selects Save and Release Parts Order")
    public void saveReleasePartsOrder() {
        new PartsOrder().clickAdd().selectPartsOrderLineItems(additionalProductName).clickAtpCheck().clickSaveReleasePartsOrder();
    }

    @And("the user clicks on Save and Release Parts Order")
    public void clickSaveAndRelease() {
        new PartsOrder().clickSaveReleasePartsOrder();
    }


//    @Then("the parts order status should be {string}")
//    public void verifyPartsOrderStatus(String status) {
//        new PartsOrder().checkPartsOrderStatus(selectedMenu, status);
//    }

    @And("the Part Reference value should be displayed on expanding Parts Order Lines")
    public void verifyPartReferenceOnExpandingPartsOrderLines() {
        new PartsOrder().verifyPartReferenceInPartsOrderLine(additionalProductNames);
    }

    @And("the Part Reference value should be displayed on expanding Added Parts Order Lines")
    public void verifyAddedParts_PartReferenceValue_OnExpandingPartsOrderLines() {
        new PartsOrder().verifyPartReferenceInPartsOrderLine(availablePartsAdded);
    }

    @When("the user expands the {string}")
    public void expandPartsOrderNumber(String arg0) {
        new PartsOrder().clickAllPartsOrderButtons();
    }


//    @And("the user selects {string} as {string}, {string} as {string}, {string} and {string} from Line Details")
//    public void enterLineDetails(String lineStatusText, String lineStatusValue, String shippedQtyText, String shippedQtyValue, String expectedArrivalDate, String actualArrivalDate) {
    ////        new ApplicationCommonMethods().navigateToTab("Details");
//        lineItemNumbers = new PartsOrder().processLineNumbers(additionalProductName, lineStatusText, lineStatusValue, shippedQtyText, shippedQtyValue, expectedArrivalDate, actualArrivalDate, "dd/MM/yyyy");
//        System.out.println("Line Item Numbers: " + lineItemNumbers);
//    }

    @And("the user selects {string} for Line Numbers, {string} as {string}, {string} as {string}, {string} and {string} from Line Details")
    public void enterLineDetails(String productName, String lineStatusText, String lineStatusValue, String shippedQtyText, String shippedQtyValue, String expectedArrivalDate, String actualArrivalDate) {
        lineItemNumbers = new PartsOrder().processLineNumbers(productName, lineStatusText, lineStatusValue, shippedQtyText, shippedQtyValue, expectedArrivalDate, actualArrivalDate, "dd/MM/yyyy");
        System.out.println("Line Item Numbers: " + lineItemNumbers);
    }

    @And("the work detail line number should be displayed and memorize work detail")
    public void getWorkDetailLineNumber() {
//        lineNumber = new WorkDetails().getWorkDetailTitle();
        workDetailTitles = new WorkDetails().getWorkDetailTitles();
        System.out.println("Line Item Number" + workDetailTitles);
    }

    @And("the user selects the {string} tab in {string}")
    public void clickPlannedParts(String labelText, String arg1) {
        new WorkDetails().clickPlannedPartsLink(labelText);
    }

    @And("the user edit the {string}")
    public void editLineNumber(String arg0) {
        new WorkDetails().clickDetailsButton(lineNumber).clickEditLink();
    }

    @And("the user enters the {string} as {string} in Planned Parts")
    public void enterInstalledQuantity(String labelText, String value) {
        new WorkDetails().enterInstalledQuantity(labelText, value);
    }

    @And("the user selects update Planned Parts")
    public void clickUpdatePlannedParts() {
        new WorkDetails().clickUpdatePlannedParts();
    }

    @And("the user selects Save Work Order Line")
    public void clickSavePlannedParts() {
        new WorkDetails().clickSavePlannedParts();

    }

    @And("the user selects Save Parts Order")
    public void savePartsOrder() {
        new PartsOrder().clickAdd().selectPartsOrderLineItems(additionalProductName).clickAtpCheck().clickSavePartsOrder();
    }

    @Then("the work order released successfully to back office")
    public void verifyReleasedBackOffice() {
        new PartsOrder().verifyReleasedBo();

    }

    @And("the user create and save multiple Parts Orders")
    public void savePartOrder(DataTable table) {
        List<Map<String, String>> orders = table.asMaps(String.class, String.class);

        for (int i = 0; i < orders.size(); i++) {
            Map<String, String> order = orders.get(i);

            // Navigate to the tab in each iteration
            System.out.println("Navigating to tab: " + order.get("Tab"));
            new ApplicationCommonMethods().navigateToTab(order.get("Tab"));

            // Click "New Parts Order"
            new PartsOrder().clickNewPartsOrders();

            // Select Parts Order Details
            new PartsOrder().selectPartsOrderType(
                    "Parts Order Type",
                    order.get("Parts Order Type"),
                    "Requested Ship Date",
                    order.get("Requested Ship Date"),
                    "Ship From Plant",
                    order.get("Ship From Plant")
            ).clickNextButton();

            // Add Additional Products
            new PartsOrder().clickAddLine().enterProductName(order.get("Product Name"));
            String additionalProductName = new PartsOrder().clickGo().selectAdditionalProduct(order.get("Product Name"));

            // Store additional product name in the global list
            additionalProductNames.add(additionalProductName);

            // Save and Release Parts Order
            new PartsOrder().clickAdd().selectPartsOrderLineItems(additionalProductName)
                    .clickAtpCheck()
                    .clickSavePartsOrder();
        }

        // Optional: Print collected product names
        System.out.println("Collected Additional Product Names: " + additionalProductNames);
    }

    public String fetchWorkOrderNumber(){
        return workOrderNumber;
    }
@And("memorize the contact in service lines and compare")
public void memorizeTheServiceLines() {
    String[] contracts = WorkOrders.getContractNames();

    String firstContract = contracts.length > 0 ? contracts[0] : "";
    System.out.println("First service Line Numbers : " + firstContract);
    String secondContract = contracts.length > 1 ? contracts[1] : "";
    System.out.println("Second service Line Numbers : " + secondContract);

    String firstPaddedContract = "0000" + firstMaterialItem;
    System.out.println("First item number from SAP: " + firstPaddedContract);
    String secondPaddedContract = "0000" + secondMaterialItem;
    System.out.println("Second item number from SAP: " + secondPaddedContract);

    LandingPage.compareText(firstPaddedContract, firstContract);
    LandingPage.compareText(secondPaddedContract, secondContract);
}
    @And("memorize sku's in the service lines and compare")
    public void memorizeTheServiceLinesSku() {
        String[] contracts = WorkOrders.getContractsku();

        String firstContractSkuBfs = contracts.length > 0 ? contracts[0] : "";
        System.out.println("First service Line Numbers : " + firstContractSkuBfs);
        String secondContractSkuBfs = contracts.length > 1 ? contracts[1] : "";
        System.out.println("Second service Line Numbers : " + secondContractSkuBfs);

        LandingPage.compareText(firstMaterial, firstContractSkuBfs);
        LandingPage.compareText(secondMaterial, firstContractSkuBfs);
    }

    @And("I search BFO Work Order")
    public void iSearchBFOWorkorder() {
        new ApplicationCommonMethods().globalSearch(sapWorkOrderNumber);
        new ApplicationCommonMethods().navigateToSearchValue(sapWorkOrderNumber);
    }

    @And("bfs work order and sap work order should match")
    public void bfsWorkOrderAndSapWorkOrderShouldMatch() {
        LandingPage.compareText(sapWorkOrderNumber, mainWorkOrderNumber);
    }

    @And("the user selects the Original Work Order from search results {string}")
    public void searchWO(String menuName) {
        ApplicationCommonMethods applicationCommonMethods = new ApplicationCommonMethods();
        applicationCommonMethods.globalSearch(workOrderNumbers.get(0));
        applicationCommonMethods.navigateToSearchValue(workOrderNumbers.get(0));
        waitForGivenTime(8000);
        refresh();
        waitForGivenTime(5000);
    }

    @And("I verify the Total Quoted Hrs for the clone Work Order is {string}")
    public void verifyQuoteHrsInCloneWO(String expectedHrs) {
        BFODurationPageObjects bfoDurationPageObjects = new BFODurationPageObjects();
        String actualQuotedHrs = bfoDurationPageObjects.getTotalQuotedHrs().split(",")[0];
        Assert.assertEquals("Total Quoted Hrs in the clone order (" + actualQuotedHrs + ")is not same as entered while cloning (" + expectedHrs + ")", expectedHrs, actualQuotedHrs);
    }


    @And("i verify the Total Quoted Hrs for the Original Work order is changed to difference of {string} and {string}")
    public void verifyOriginalQuotedHrs(String initialHrs_OrginialWO, String hrs_CloneWO) {
        BFODurationPageObjects bfoDurationPageObjects = new BFODurationPageObjects();
        String actualQuotedHrs = bfoDurationPageObjects.getTotalQuotedHrs().split(",")[0];
        System.out.println("Actual Quoted Hrs of Original WO: " + actualQuotedHrs);
        String expectedQuotedHrs = String.valueOf(Integer.parseInt(initialHrs_OrginialWO) - Integer.parseInt(hrs_CloneWO));
        System.out.println("Expected Quoted Hrs: " + expectedQuotedHrs);
        Assert.assertEquals("Expected Total Quoted Hrs in the Original Wo is " + expectedQuotedHrs + " but Actual quoted Hrs is " + actualQuotedHrs, actualQuotedHrs, expectedQuotedHrs);
    }

    @And("I verify if error message is displayed for entering Quoted Hrs greater than that in the Original Work Order")
    public void verifyErrorMessageDisplayed() {
        BFODurationPageObjects bfoDurationPageObjects = new BFODurationPageObjects();
        Assert.assertTrue(bfoDurationPageObjects.isErrorMessageDisplayed());
        String actualErrorMessage = bfoDurationPageObjects.fetchErrorMessage();
        Assert.assertEquals("Expected Error message is not displayed, the actual message displayed is" + actualErrorMessage, "If Original Total Quoted Hours is not blank, Total Quoted Hours must be more than 0, but less than Original Total Quoted Hours: Original Total Quoted Hrs, Total Quoted Hrs", actualErrorMessage);
    }

    @And("I change the Total Quoted Hrs to less than that in the Original WO {string}")
    public void iChangeTheTotalQuotedHrsToLessThanThatInTheOriginalWO(String totalQuotedHrsInOriginalWO) {
        int totalQuotedHrsforCloneWO = new Random().nextInt(Integer.valueOf(totalQuotedHrsInOriginalWO) - 1) + 1;
        new WorkOrders().setTotalQuotedHrs(String.valueOf(totalQuotedHrsforCloneWO));
    }

}

