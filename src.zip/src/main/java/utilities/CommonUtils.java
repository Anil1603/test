package utilities;

import org.apache.commons.codec.binary.Base64;
import org.openqa.selenium.OutputType;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import static com.codeborne.selenide.Selenide.screenshot;

public class CommonUtils {
    public static String addScreen()
    {  String encodedBase64 = null;
        FileInputStream fileInputStreamReader = null;
        try {
            Toolkit tool = Toolkit.getDefaultToolkit();
            Dimension d = tool.getScreenSize();
            Rectangle rect = new Rectangle(d);
            Robot robot = new Robot();
            Thread.sleep(2000);
            // File f = new File("screenshot.png");
            File f=new File(System.getProperty("user.dir")+"\\Screenshots\\screenshot.png");
            BufferedImage img = robot.createScreenCapture(rect);
            ImageIO.write(img,"png",f);
            fileInputStreamReader = new FileInputStream(f);
            byte[] bytes = new byte[(int)f.length()];
            fileInputStreamReader.read(bytes);
            encodedBase64 = new String(Base64.encodeBase64(bytes));
            tool.beep();
        } catch(Exception e){
            e.printStackTrace();
        }

        return "data:image/png;base64,"+encodedBase64;

    }




    public static void convertBase64ToImage(String base64String, String filePath) {
        try (FileOutputStream fos = new FileOutputStream(filePath)) {
            // Remove the prefix if present
            if (base64String.startsWith("data:image/png;base64,")) {
                base64String = base64String.replace("data:image/png;base64,", "");
            } else if (base64String.startsWith("data:image/jpeg;base64,")) {
                base64String = base64String.replace("data:image/jpeg;base64,", "");
            }
            byte[] imageBytes = Base64.decodeBase64(base64String);
            fos.write(imageBytes);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static String addScreenshot() {
        String encodedBase64 = null;
        try {
            byte[] screenshotBytes = screenshot(OutputType.BYTES);
            encodedBase64 = new String(Base64.encodeBase64(screenshotBytes));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "data:image/png;base64," + encodedBase64;
    }
}
