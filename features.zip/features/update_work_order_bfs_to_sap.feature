Feature: verify work order bfs to sap.
  As a user
  I want to navigate to the application and create Work Order abd memorize work order
  So that I can verify work order in SAP

  Scenario Outline: work order creation in bfs ad verify in sap
  Given I work in application "BFO" and environment "UAT"
  And I login to "BFO" as user "coordinator-1660@bridge-fo.com.uatbfo26"
  When I navigate to "SE - Services Lightning" from app launcher
  And I wait for "10" seconds
  And I navigate to "Work Orders" from app launcher
  And I click on bfo button "New"
  And I fill work order details for creating new work order from Work Order Page:
  |Field Name                            | Field Value                               |
  |Select Record Type                    | Standalone Work Order                     |
  |Installed At Account                  | 0001340233:Ampcontrol (QLD) Pty Ltd       |
  |Location                              | 0045144542:Ampcontrol QLD Pty Ltd         |
  |Work Order Type                       | Repair                                    |
#    |Work Order Sub-Type                   |                                           |
  |Contact                               |   chandra.vamsi kumar                     |
  |Customer Requested Date               | today                                     |
  |Country of Back Office                | Australia                                 |
  | Back Office System                   |SAP Bridge AP                              |
  |Work Order Category                   |Onsite                                     |
  |Services Business Unit                |POWER SYSTEMS                              |
  |Is Billable                           | Yes                                       |
  |Priority                              | Normal-Medium                             |
#    |Non Billing Reason                    |                                           |
  |Service Commercial Ref                |QWPFSRVPLNNSGEN                            |
#    |Skill Category                        |                                           |
  |Work Order Reason                     | Testing                                   |
  |Work Order Name                       | Manual                                   |
  |Sold To Account                       |0001340233:Ampcontrol (QLD) Pty Ltd        |
  Then user should be able to see the work order number and memorize work order number
  And user should be able to get the work order id from the url and memorize
  And I should see the work order status as "New" in work order page
  And I click on "Create/Update Work Order" button from SFM Tab
#    And I click on "Sync" button from Sync page
  And I check the message "SUCCESS : INITIATED SYNC" on sync window
  And I click on "Ok" button on sync window
  Then I should see the work order status as "Unscheduled" in work order page
  And I wait for back Office reference number
  And I check the "First Synchronization date" and "Last Synchronization date" in work order page
  And I check the "Synchronization Log" as "Work Order CREATED in Back Office" in work order page
    And memorize the Work order name and reason
  And memorize the back office reference number
    And I logout from bfo application
#
#    #SAP
  Given I work in application "SAP"
  When I navigate to "(Bridge) ECC 6.0 SSO - QRH - Pre-Production APAC"
  Then  I Search Order and verify updated details

#
#  #FSR Manager
    Given I work in application "BFO" and environment "UAT"
    And I login to "BFO" as user "coordinator-1660@bridge-fo.com.uatbfo26"
    And the user selects "<Menu Item>" from the Search menu
    When the user search and selects the "<Menu Item>"
    When the user modify "Work Order Name" as "<Work Order Name>"
    When the user modify "Work Order Reason" as "<Work Order Reason>"

    #    # we need to add

    And memorize the Work order name and reason
    And I click on "Create/Update Work Order" button from SFM Tab
#    And I click on "Sync" button from Sync page
    And I check the message "SUCCESS : INITIATED SYNC" on sync window
    And I click on "Ok" button on sync window
    And I logout from bfo application
#
#     #SAP
    Given I work in application "SAP"
    When I navigate to "(Bridge) ECC 6.0 SSO - QRH - Pre-Production APAC"
    Then  I Search Order and verify updated details

    Examples:
      | Menu Item      | Work Order       | Tab Name      | Parts Order Type | Ship From Plant | Product Name | Line Status | Shipped Qty | Work Details Tab     | Installed Quantity | Work Order Name | Work Order Reason |
      | Work Orders     | WO-12264768     | Parts Order   | Ship only        | AU10            | 47053       | Received     | 1           |   Work Details       |  1                 | Manual          | 1234              |




