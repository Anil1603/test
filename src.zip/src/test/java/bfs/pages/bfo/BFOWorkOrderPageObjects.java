package bfs.pages.bfo;
import com.codeborne.selenide.ClickOptions;
import com.codeborne.selenide.Selenide;
import org.openqa.selenium.By;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.$;
import static bfs.pages.BasePage.highLightElement;

public class BFOWorkOrderPageObjects {
    private static final By NEW_BUTTON = By.xpath("//a[@title='New']");
    private static final By CONTINUE_BUTTON = By.xpath("//button[text()='Continue']");
    private static final By RECORD_TYPE_DROPDOWN = By.name("selectItem");
    //private static final String recordTypeBoxHeading = "//h2[text()='Please select a record type']";
    private static final String recordcreationboxClose = "//button[@title='Close']";
    private static final String selectRecordType = "//span[text()='Select  Record Type: ']";
    private static final String selectRecordTypeDropDown = "//div[@class='slds-select_container']//select";
    private static final String selectRecordTypeDropDownValues = "//div[@class='slds-select_container']//select//option";
    private static final String Record_creation_Continue_button = "//button[text()='Continue']";
    private static final String Record_creation_Cancel_button = "//button[text()='Cancel']";
    private static final By  WORK_ORDERS_TAB = By.xpath("//span[text()='Work Orders']");



    public BFOWorkOrderPageObjects clickOnNewButton(){
        highLightElement($(NEW_BUTTON).shouldBe(visible,enabled));
        $(NEW_BUTTON).shouldBe(visible,enabled).click();
        return this;
    }

    public BFOWorkOrderPageObjects waitForRecordTypePopUp(){
        highLightElement($(CONTINUE_BUTTON).shouldBe(visible,enabled));
        $(CONTINUE_BUTTON).shouldBe(visible,enabled);
        return this;
    }

    public BFOWorkOrderPageObjects clickOnContinueButton(){
        highLightElement($(CONTINUE_BUTTON).shouldBe(visible,enabled));
        $(CONTINUE_BUTTON).click();
        return this;
    }

    public void selectRecordType(String value) {
        highLightElement($(RECORD_TYPE_DROPDOWN).shouldBe(visible,enabled));
        $(RECORD_TYPE_DROPDOWN).selectOption(value);
    }

    public void WOselectRecordType(String value){
        highLightElement($(RECORD_TYPE_DROPDOWN).shouldBe(visible,enabled));
        $(RECORD_TYPE_DROPDOWN).selectOption(value);
        $(CONTINUE_BUTTON).shouldBe(visible,enabled).click();
        Selenide.sleep(3000);
    }

    public void clickOnWorkOrdersTab(){
        highLightElement($(WORK_ORDERS_TAB).shouldBe(visible,enabled));
        $(WORK_ORDERS_TAB).shouldBe(visible,enabled).click(ClickOptions.usingJavaScript());
    }
}
