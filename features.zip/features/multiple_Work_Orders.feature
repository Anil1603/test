Feature: Work order creation.
  As a user
  I want to navigate to the application and create Multiple Work Orders and store Work Order IDs in Json file

  Scenario: Multiple Work Orders creation
    Given I work in application "BFO" and environment "UAT"
    And I login to "BFO" as user "coordinator-1660@bridge-fo.com.uatbfo26"
    When I navigate to "SE - Services Lightning" from app launcher
    And I wait for "10" seconds
    And I navigate to "Work Orders" from app launcher
    And Work Order input data is loaded from json file
    And I create multiple work orders from json file data and store the Work Orders id in Json:
      | Field Name              | Field Value             |
      | Select Record Type      | <Select Record Type>    |
      | Installed At Account    | <Installed At Account>  |
      | Location                | <Location>              |
      | Work Order Type         | <WorkOrderType>         |
      | Contact                 | <Contact>               |
      | Customer Requested Date | <CustomerRequestedDate> |
      | Country of Back Office  | <CountryOfBackOffice>   |
      | Back Office System      | <BackOfficeSystem>      |
      | Work Order Category     | <WorkOrderCategory>     |
      | Services Business Unit  | <ServicesBusinessUnit>  |
      | Is Billable             | <IsBillable>            |
      | Priority                | <Priority>              |
      | Service Commercial Ref  | <ServiceCommercialRef>  |
      | Work Order Reason       | <WorkOrderReason>       |
      | Work Order Name         | <WorkOrderName>         |
      | Sold To Account         | <SoldToAccount>         |

    And I logout from bfo application