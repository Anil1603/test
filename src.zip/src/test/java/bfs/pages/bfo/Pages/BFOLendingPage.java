package bfs.pages.bfo.Pages;

import bfs.pages.bfo.BFO_Landing_Header_Objects;
import bfs.pages.bfo.PageObjects.BFOLendingPageObjects;

public class BFOLendingPage {
    public void searchForAppAndOpen(String appName) {
        BFOLendingPageObjects lendingPageObjects = new BFOLendingPageObjects();
        lendingPageObjects.clickOnAPPMenuIcon()
                .enterAppsToSearch(appName)
                .waitForListOfMenu()
                .clickOnWorkOrder(appName);
    }

}
