package bfs.pages.bfo;

import bfs.pages.BasePage;
import com.codeborne.selenide.*;
import io.cucumber.datatable.DataTable;
import org.junit.Assert;

import bfs.CONSTANTS;

import java.time.Duration;
import java.util.Locale;
import java.time.LocalDate;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import java.time.format.DateTimeFormatter;

import static bfs.pages.BasePage.*;
import static bfs.pages.bfo.ApplicationCommonMethods.*;
import static com.codeborne.selenide.Condition.enabled;
import static com.codeborne.selenide.Condition.visible;
import static bfs.pages.bfo.ApplicationCommonMethods.handleException;
import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.*;
import org.openqa.selenium.TimeoutException;
import java.util.*;

public class PartsOrder {

    // XPaths for elements
    private static final String NEW_PARTS_ORDER = "(//h2[text()='Parts Orders']/../parent::div/../following-sibling::div/following-sibling::div/div/button[text()='New'])[last()]";
//    private static final String DROPDOWN_PARTS_ORDER = "//label[contains(text(), '%s')]/parent::div/div/lightning-base-combobox/div/div/div/button";
    private static final String DROPDOWN_PARTS_ORDER = "//label[contains(text(), '%s')]/parent::span/parent::div/div/lightning-base-combobox/div/div/div/button";
    private static final String DROPDOWN_PARTS_ORDER_VALUE = "//span[text()='%s']/parent::span/parent::lightning-base-combobox-item";
    private static final String DATE_REQUESTED_SHIP_DATE = "//label[text()='%s']/parent::div/div/input";
    private static final String SHIP_FROM_PLANT = "//label[contains(text(), '%s')]/parent::div/lightning-input-field//input";
    private static final String LINK_SHIP_FROM_PLANT = "//strong[text()='%s']/parent::lightning-base-combobox-formatted-text/parent::span/parent::span/parent::lightning-base-combobox-item/parent::li";
    private static final String NEXT_PARTS_ORDER = "//button[text()='Next']";
    private static final String ADD_LINE = "(//button[text()='Add Line'])[position()=1]";
    private static final String ADD_LINE_NONREFERENCESPAREPART = "(//div[contains(text(),'NON REFERENCE SPARE PARTS')]/following-sibling::div/button[text()='Add Line'])";
    private static final String TEXT_REFERENCE = "(//td[@data-label='FreeTextReference']//input)[%s]";
    private static final String UNIT_OF_MEASURE = "(//td[@data-label='UOM']//select)[%s]";
    private static final String ORDER_TYPE = "(//td[@data-label='Order Type']//select)[%s]";
    private static final String COMMITTED_SHIP_DATE = "(//input[@name='committeddate'])[%s]";
    private static final String EXPAND_ADDEDPART_ALL = "//div[@class='slds-table_header-fixed_container slds-border_right slds-border_left tableScroll']//button[@title='Open']";
    private static final String PART_REFERENCE_VALUE = "(//tr[@class='cLCMP_DataViewTableRow']//div[@class='serv_expand_table']//td[@data-label='Part Reference']//span)";
    private static final String GO_BUTTON = "//button[text()='Go']";
    private static final String ADD_PRODUCTS = "//span[text()='Add']/parent::button";
    private static final String SAVE_RELEASE_PARTS_ORDER = "(//button[text()='Save and Release'])[last()]";
    private static final String SAVE_PARTS_ORDER = "//button[text()='Save and Release']/preceding-sibling::button[text()='Save']";
    private static final String SAVE_LINE_ITEM = "(//button[text()='Save'])[last()]";
    private static final String OK_BUTTON = "//input[@value='OK']";
    private static final String ATP_CHECK = "(//button[text()='ATP Check'])[last()]";
    private static final String LINE_ITEMS_CHECKBOX = "(//td[@data-cell-value='%s'])/preceding-sibling::td[contains(@data-col-key-value, 'SELECTABLE_CHECKBOX')]/lightning-primitive-cell-checkbox";
    private static final String SEARCH_PRODUCT = "//input[contains(@placeholder, '%s')]";
    private static final String PRODUCT_CHECKBOX = "//span[text()='%s']/parent::lightning-formatted-rich-text/parent::div/parent::td/preceding-sibling::td//div/span";
    private static final String ORDER_STATUS = "//td[@data-label='ORDER STATUS']/div/lightning-formatted-rich-text/span";
    private static final String LOADING_PROGRESS = "//c-custom-bar-format-spinner/div[@class='linear-activity']";
    private static final String LOADER_ICON = "//lightning-spinner[@class='slds-spinner_container']/div[@part='spinner']/span";
    private static final String LOADER_ICON_NEW = "//div[@class='forceModalSpinner']//span";
    private static final String PARTS_NUMBERS = "//td[@data-label='PARTS ORDER NUMBER']/preceding-sibling::td/a/button";
    private static final String LINE_NUMBER = "(//span[text()='%s'])[position()=1]/../../../preceding-sibling::td[@data-label='Line Number']/a";
//    private static final String STANDARD_ADDRESS_CHECKBOX = "//span[text()='Standard Address']//preceding-sibling::input";
//    private static final String LINE_STATUS_VALUE = "//span[text()='%s']/parent::span/parent::lightning-base-combobox-item";
//    private static final String SHIP_QTY_VALUE = "//label[contains(text(),'%s')]/parent::div/div/input";

    private static final String PARTS_ORDER_NUMBERS = "//a[@data-label='PARTS ORDER NUMBER']";
    private static final String LINE_NUMBERS = "//a[@data-label='Line Number']";
    private static final String PART_REFERENCE = "//td[@data-label='Part Reference']/div/lightning-formatted-rich-text/span";
    //    private static final String EXPECTED_ACTUAL_DATE = "//legend[text()='%s']/parent::fieldset/div/div/div/lightning-datepicker/div/div/input";
//    private static final String LINE_STATUS = "//label[contains(text(),'Line Status')]/parent::div/div/lightning-base-combobox";
    private static final String LINE_STATUS = "//label[contains(text(),'Line Status')]/parent::span/parent::div/div/lightning-base-combobox";
    private static final String LINE_STATUS_VALUE = "//span[text()='%s']/parent::span/parent::lightning-base-combobox-item";
    private static final String SHIP_QTY_VALUE = "//label[contains(text(),'%s')]/parent::div/div/input";
    private static final String EXPECTED_ACTUAL_DATE = "//legend[text()='%s']/parent::fieldset/div/div/div/lightning-datepicker/div/div/input";
    private static final String AVAILABILITY_FOR_SELECTED_PLANT_TAB = "//a[@data-label='AVAILABILITY FOR SELECTED PLANT']";
    private static final String PARTS_ORDER_LINE_ITEMS_TAB = "//a[@data-label='Parts Order Line Items']";
    private static final String ATP_STATUS_FOR_PART_VALUE = "//c-lightning-data-table-extension[@class='pol-item-table']//td[@data-cell-value='%s']//preceding-sibling::td[@data-label='Status']//c-atp-status-indicator//div";
    private static final String ATP_STOCK_FOR_PART_TEXT  = "//c-lightning-data-table-extension[@class='pol-item-table']//td[@data-cell-value='%s']//preceding-sibling::td[@data-label='Stock']";
    private static final String ATP_MESSAGE_TEXT = "//c-lightning-data-table-extension[@class='pol-atp-table']//td[@data-label='PRODUCT REF' and @data-cell-value='%s']//following-sibling::td[@data-label='MESSAGE']";
    private static final String SCROLL_BAR = "//div[@class='slds-table_header-fixed_container slds-scrollable_x']";
    private static final String PART_CHECKBOX = "//c-lightning-data-table-extension[@class='pol-item-table']//td[@data-label='PRODUCT REF' and @data-cell-value='%s']//preceding-sibling::td[contains(@data-col-key-value,'CHECKBOX')]//span";
    private static final String PART_DROPDOWN = "(//c-lightning-data-table-extension[@class='pol-item-table']//td[contains(@data-col-key-value,'CHECKBOX')]//following-sibling::th//button)[1]";
    private static final String DELETE_SELECTED_ROW_DROPDOWN_OPTION = "//span[text()='Delete Selected Rows']//parent::a";
    private static final String SAVE_ADDED_PARTS = "//div[@class='slds-grid']//button[text()='Save']";
    private static final String SUCCESS_TOAST_MESSAGE = "//div[contains(@class,'toastTitle ') and text()='Success!']";
    private static final String ATP_CHECK_IN_PROGRESS_TOAST_MESSAGE = "//span[text()='ATP Check In Progress.']";
    private static final String LOADING_PROGRESS_SPINNER_PARTS_ADDITION_PAGE = "//div[@class='slds-spinner slds-spinner_brand slds-spinner_large']//span[text()='Loading']";
    private static final String LINE_NUMBER_LINK = "//flexipage-component2[contains(@data-component-id,'PartsOrderLineSmartList')]//a[@data-label='Line Number']";
    private static final String EDIT_BUTTON_LINE_ORDER_DETAILS_TAB = "//button[contains(@title,'%s')]";
    private static final String DROPDOWN_BUTTON = "//button[contains(@aria-label,'%s')]";
    private static final String DROPDOWN_OPTIONS = "//lightning-base-combobox-item[@data-value='%s']";
    private static final String PARTS_ORDER_NUMBER_LINK = "//a[@data-label='PARTS ORDER NUMBER']";
    private static final String SYNC_IN_ERP_LINK = "//span[text()='Sync in ERP']//parent::a";
    private static final String SYNC_IN_ERP_STATUS_MESSAGE = "//div[@class='messageText']";
    private static final String OK_BUTTON_ERP_SYNC_WINDOW = "//input[@type='submit']";
    private static final String STANDARD_ADDRESS_CHECKBOX = "//span[text()='Standard Address']//preceding-sibling::input";

    public PartsOrder clickAvailabilityForSelectedPlantTab() {
        highLightElement($x(AVAILABILITY_FOR_SELECTED_PLANT_TAB).shouldBe(visible, enabled));
        $x(AVAILABILITY_FOR_SELECTED_PLANT_TAB).click();
        return this;
    }

    public PartsOrder clickPartsOrderLineItemsTab() {
        SelenideElement parts_order_line_items_tab = $x(PARTS_ORDER_LINE_ITEMS_TAB);
        highLightElement(parts_order_line_items_tab.shouldBe(visible, enabled));
        parts_order_line_items_tab.click();
        return this;
    }

    public String getATPStatusPostAtpCheck(String product) {
        highLightElement($x(String.format(ATP_STATUS_FOR_PART_VALUE, product)).shouldBe(visible, enabled));
        return $x(String.format(ATP_STATUS_FOR_PART_VALUE, product)).shouldBe(visible, enabled).getAttribute("class");
    }

    public String getAtpStockForPartText(String product) {
        highLightElement($x(String.format(ATP_STOCK_FOR_PART_TEXT, product)).shouldBe(visible, enabled));
        return $x(String.format(ATP_STOCK_FOR_PART_TEXT, product)).shouldBe(visible, enabled).getAttribute("data-cell-value");
    }

    public String getAtpMessageText(String product) {
        SelenideElement atp_message_text = $x(String.format(ATP_MESSAGE_TEXT, product));
        atp_message_text.scrollIntoView("{block: \"center\"}");
        highLightElement(atp_message_text.shouldBe(visible, enabled));
        CONSTANTS.captureScreen = true;
        return atp_message_text.getAttribute("data-cell-value");
    }

    public PartsOrder selectProductCheckBox(String product) {
        highLightElement($x(String.format(PART_CHECKBOX, product)).shouldBe(visible, enabled));
        $x(String.format(PART_CHECKBOX, product)).shouldBe(visible, enabled).click();
        return this;
    }

    public PartsOrder clickFirstProductDropdown() {
        highLightElement($x(PART_DROPDOWN).shouldBe(visible, enabled));
        $x(PART_DROPDOWN).shouldBe(visible, enabled).click();
        return this;
    }

    public PartsOrder clickDeleteSelectedRowOption() {
        highLightElement($x(DELETE_SELECTED_ROW_DROPDOWN_OPTION).shouldBe(visible, enabled));
        $x(DELETE_SELECTED_ROW_DROPDOWN_OPTION).shouldBe(visible, enabled).click();
        return this;
    }

/*    public PartsOrder clickSaveAddedParts() {
        highLightElement($x(SAVE_ADDED_PARTS).shouldBe(visible, enabled));
        $x(SAVE_ADDED_PARTS).shouldBe(visible, enabled).click();
        waitForLoadingToComplete(LOADING_PROGRESS_SPINNER_PARTS_ADDITION_PAGE);
        return this;
    }*/

    public String getSuccessToastMessage() {
        highLightElement($x(SUCCESS_TOAST_MESSAGE).shouldBe(visible, enabled));
        return $x(SUCCESS_TOAST_MESSAGE).shouldBe(visible, enabled).getText();
    }

    public void waitUntilInvisibilityOfATPCheckInProcessToastMessage() {
        waitForLoadingToComplete(ATP_CHECK_IN_PROGRESS_TOAST_MESSAGE);
    }

    public String fetchATPCheckMessage(String product) {
        clickAvailabilityForSelectedPlantTab();
        String msg = getAtpMessageText(product);
        CONSTANTS.captureScreen=true;
        return msg;
    }

    public void clickLinenumberInPartsOrder() {
        highLightElement($x(LINE_NUMBER_LINK).shouldBe(visible, enabled));
        $x(LINE_NUMBER_LINK).shouldBe(visible, enabled).click(ClickOptions.usingJavaScript());
    }

    public PartsOrder validateATPCheckMessages(List<String> products) {
        waitUntilInvisibilityOfATPCheckInProcessToastMessage();
        for (String product : products) {
            String actualStatus = getATPStatusPostAtpCheck(product).replace("circle_", "");
            int actualStock = Integer.parseInt(getAtpStockForPartText(product));
            String actualMessage = fetchATPCheckMessage(product);
            clickPartsOrderLineItemsTab();
            verifyPartsRow(product, actualStatus, actualStock, actualMessage);
        }
        CONSTANTS.captureScreen=true;
        return this;
    }

    public void verifyPartsRow(String product, String actualStatus, int actualStock, String actualMessage) {
        switch (actualStatus.toLowerCase()) {
            case "green":
                Assert.assertTrue("Stock should be greater than 0 for product -\"" + product + "\" since status is green but actual stock is " + actualStock, actualStock > 0);
                Assert.assertEquals("Expected message is not present for Part " + product + " With Status - Green & Stock = " + actualStock, "OK-Requested Quantity should be available.", actualMessage);
                break;
            case "orange":
                Assert.assertEquals("Stock should 0 for product -\"" + product + "\" since status is orange but actual stock is " + actualStock, 0, actualStock);
                Assert.assertEquals("Not enough stock available at requested date", actualMessage);
                break;
            case "red":
                System.out.println("Error message for part - "+product+" is "+actualMessage);
                Assert.assertEquals("Stock should 0 for product -\"" + product + "\" since status is orange but actual stock is " + actualStock, 0, actualStock);
                Assert.assertNotEquals("Unexpected message for Part " + product + " With Status - Red", "OK-Requested Quantity should be available.", actualMessage);
                break;
            default:
                throw new IllegalArgumentException("Unexpected status: " + actualStatus);
        }
    }

    public PartsOrder validateATPErrorAndWarningForAddedPart(List<String> products) {
        waitUntilInvisibilityOfATPCheckInProcessToastMessage();
        for (String product : products) {
            String actualStatus = getATPStatusPostAtpCheck(product).replace("circle_", "");
            int actualStock = Integer.parseInt(getAtpStockForPartText(product));
            String actualMessage = fetchATPCheckMessage(product);
            clickPartsOrderLineItemsTab();
           if(actualStatus.contains("red")) {
                   int maxAttempts = 3;
                   int attempts = 0;
                   boolean statusFound = false;
               while (attempts < maxAttempts && !statusFound) {
                   if (!actualMessage.contains("not maintained in plant")) {
                       statusFound = true;
                   } else {
                       clickAtpCheck().waitUntilInvisibilityOfATPCheckInProcessToastMessage();
                       Selenide.sleep(7000);
                       actualMessage = fetchATPCheckMessage(product);
                       System.out.println(actualMessage+" , attempt - "+attempts);
                       clickPartsOrderLineItemsTab();
                       attempts++;
                   }
               }

               Assert.assertEquals("Stock should 0 for product -\"" + product + "\" since status is red but actual stock is " + actualStock, 0, actualStock);
//               Assert.fail("ATP Check threw error status for the added part with Error message  - \""+actualMessage+"\"");
               System.out.println("ATP Check threw error status for the added part with Error message  - \""+actualMessage+"\"");
           } else if (actualStatus.contains("orange")) {
               Assert.assertEquals("Stock should 0 for product -\"" + product + "\" since status is orange but actual stock is " + actualStock, 0, actualStock);
               Assert.assertEquals("Not enough stock available at requested date", actualMessage);
//               Assert.fail("ATP Check threw Warning status for the added part with Error message  - \""+actualMessage+"\"");
               System.out.println("ATP Check threw Warning status for the added part with Error message  - \""+actualMessage+"\"");
           }

        }
        CONSTANTS.captureScreen=true;
        return this;
    }

    public List<String> deleteOrangesAndReds(List<String> products) {
        List<String> savedParts = new ArrayList<>(products);
        for (String product : products) {
            if (getATPStatusPostAtpCheck(product).contains("orange") || getATPStatusPostAtpCheck(product).contains("red")) {
                new PartsOrder().selectProductCheckBox(product);
                savedParts.remove(product);
            }
        }
        new PartsOrder().clickFirstProductDropdown();
        new PartsOrder().clickDeleteSelectedRowOption();
        new PartsOrder().clickSaveReleasePartsOrder();
        return savedParts;
    }

    public PartsOrder clickNewPartsOrders() {
        try {
            waitForGivenTime(8000);
            SelenideElement newButton = $x(NEW_PARTS_ORDER);

            // Scroll into view before clicking
            newButton.scrollIntoView("{block: \"center\"}");

            // Use JavaScript to click
            executeJavaScript("arguments[0].click();", newButton);
            waitForGivenTime(10000);
            waitForPageLoad();
            return this;
        } catch (Exception e) {
            ApplicationCommonMethods.handleException("Error clicking on Parts Order", e);
            throw e;
        }
    }

    public PartsOrder selectPartsOrderType(String partsOrderText, String orderType, String requestedDateText, String dateFormat, String shipFromPlanText, String shipValue ) {
        try {

            // Click the dropdown
            String dropdownXpath = String.format(DROPDOWN_PARTS_ORDER, partsOrderText);
            SelenideElement dropdown = $x(dropdownXpath);
            dropdown.shouldBe(visible, enabled).click();

            // Select the dynamic value from the dropdown
            String optionXpath = String.format(DROPDOWN_PARTS_ORDER_VALUE, orderType);
            SelenideElement option = $x(optionXpath);
            option.shouldBe(visible, enabled).click();
            waitForGivenTime(8000);

            if (!"Return Only".equalsIgnoreCase(orderType)) {
                requestedShipDate(requestedDateText, dateFormat);  // Adjust format as needed
                selectShipFromPlant(shipFromPlanText, shipValue); // Adjust textToEnter as needed
//                selectStandardAddress();
            }

        } catch (Exception e) {
            ApplicationCommonMethods.handleException("Error clicking on Parts Order", e);
            throw e;
        }
        return this;
    }

    private void requestedShipDate(String labelText, String format) {
        try {
            // Generate dynamic XPath for the input field
            String dynamicXpath = String.format(DATE_REQUESTED_SHIP_DATE, labelText);
            SelenideElement element = $x(dynamicXpath);

            // Scroll into view and click the field
            element.shouldBe(visible, enabled)
                    .scrollIntoView("{block: \"center\"}")
                    .click();

            // Press ESC to close any popups
            new Actions(WebDriverRunner.getWebDriver()).sendKeys(Keys.ESCAPE).perform();

            // Format the date as "15 FEB 2025" (dd MMM yyyy in uppercase)
            String formattedDate = LocalDate.now().plusDays(1)
                    .format(DateTimeFormatter.ofPattern(format, Locale.ENGLISH))
                    .toUpperCase();

            // Set the formatted date in the input field
            element.setValue(formattedDate);
        } catch (Exception e) {
            throw new RuntimeException("Error interacting with the date input field: " + e.getMessage());
        }
    }

    private void enterTextInField(String labelText, String inputXpathTemplate, String textToEnter) {
        try {
            SelenideElement inputField = $x(String.format(inputXpathTemplate, labelText));
            inputField.shouldBe(visible, enabled).scrollIntoView("{block: \"center\"}").click();
            inputField.clear();
            inputField.setValue(textToEnter);
        } catch (Exception e) {
            handleException("Error entering text into field", e);
        }
    }

    private void clickElement(String xpath, String labelText, String errorMessage) {
        try {
            SelenideElement inputField = $x(String.format(xpath, labelText));
            waitForElementToBeVisibleAndClickable(inputField);
            inputField.click();
        } catch (Exception e) {
            handleException(errorMessage, e);
        }
    }

    private void clickDynamicLink(String xpath, String linkText) {
        try {
            waitForGivenTime(4000);
            ElementsCollection links = $$x(String.format(xpath, linkText));

            if (!links.isEmpty()) { // Check if at least one link exists
                for (SelenideElement link : links) {
                    if (link.isDisplayed()) {
                        link.scrollIntoView("{block: \"center\"}"); // Prevent excessive scrolling
                        try {
                            link.click(); // Normal click
                        } catch (Exception e) {
                            executeJavaScript("arguments[0].click();", link); // JavaScript click fallback
                        }
                        return; // Stop after clicking the first visible link
                    }
                }
            }
        } catch (Exception e) {
            handleException("Error clicking dynamic link: " + linkText, e);
        }
    }

    private void selectShipFromPlant(String labelText, String textToEnter) {
        try {
            enterTextInField(labelText, SHIP_FROM_PLANT, textToEnter);
            clickElement(LINK_SHIP_FROM_PLANT,textToEnter, "Error to Select Ship From Plant");
        } catch (Exception e) {
            handleException("Error selecting location", e);
        }
    }
    public void selectStandardAddress(){
        clickElement(STANDARD_ADDRESS_CHECKBOX, "STANDARD ADDRESS CHECKBOX","Failed to select standard address checkbox");
    }

    public PartsOrder clickNextButton() {
        try {
            SelenideElement nextButton = $x(NEXT_PARTS_ORDER);

            // Scroll into view and click using JavaScript
            nextButton.shouldBe(visible);
            executeJavaScript("arguments[0].scrollIntoView({block: 'center'}); arguments[0].click();", nextButton);
            waitForGivenTime(10000);
        } catch (Exception e) {
            throw new RuntimeException("Error clicking the 'Next' button: " + e.getMessage());
        }
        return this;
    }

    public PartsOrder clickAddLine() {
        try {
            SelenideElement nextButton = $x(ADD_LINE);

            // Scroll into view and click using JavaScript
            nextButton.shouldBe(visible);
            executeJavaScript("arguments[0].scrollIntoView({block: 'center'}); arguments[0].click();", nextButton);
            waitForGivenTime(10000);
        } catch (Exception e) {
            throw new RuntimeException("Error clicking the 'Add Line' button: " + e.getMessage());
        }
        return this;
    }

    public PartsOrder clickAddLine_NonReferenceSparePart() {
        try {
            SelenideElement addLineButton = $x(ADD_LINE_NONREFERENCESPAREPART);
            addLineButton.shouldBe(visible);
            executeJavaScript("arguments[0].scrollIntoView({block: 'center'}); arguments[0].click();", addLineButton);
            waitForGivenTime(5000);
        } catch (Exception e) {
            handleException("Error clicking the 'Add Line' button of the NON Reference Spare Parts ", e);
        }
        return this;
    }

    public PartsOrder enterTextReference(String nonReferenceProductName,int i) {
        try {
            String text_Reference = String.format(TEXT_REFERENCE,i);
            highLightElement($x(text_Reference).shouldBe(visible, enabled));
            SelenideElement txtReference = $x(text_Reference);
            executeJavaScript("arguments[0].scrollIntoView({block: 'center'}); arguments[0].click();", txtReference);
            waitForGivenTime(1000);
            $x(text_Reference).setValue(nonReferenceProductName);
        } catch (Exception e) {
            handleException("Error entering value in the 'Text Reference' textbox for NON REFERENCE SPARE PARTS ", e);
        }
        return this;
    }

    public PartsOrder selectUnitOfMeasure(String UOM,int i) {
        try {
            String uom = String.format(UNIT_OF_MEASURE,i);
            highLightElement($x(uom).shouldBe(visible, enabled));
            $x(uom).selectOption(UOM);
        } catch (Exception e) {
            handleException("Error selecting value from 'Unit Of Measure' dropdown " + UOM, e);
        }
        return this;
    }

    public PartsOrder selectOrderType(String orderTypeValue,int i) {
        try {
            String orderType = String.format(ORDER_TYPE,i);
            highLightElement($x(orderType).shouldBe(visible, enabled));
            $x(orderType).selectOption(orderTypeValue);
        } catch (Exception e) {
            handleException("Error selecting value from 'Order Type' dropdown ", e);
        }
        return this;
    }

    public PartsOrder enterCommittedShipDate(String date,int i) {
        try {
            if (date.isEmpty() || date.equalsIgnoreCase("today")) {
                LocalDate today = LocalDate.now();
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd MMM yyyy");
                date = today.format(formatter);
            }
            var committedShipDateTxtBox = $x(String.format(COMMITTED_SHIP_DATE,i));
            committedShipDateTxtBox.shouldBe(visible, enabled);
            highLightElement(committedShipDateTxtBox);
            committedShipDateTxtBox.setValue(date).pressEnter();

            waitForGivenTime(3000);
        } catch (Exception e) {
            handleException("Error entering the 'Committed ship date' ", e);
        }
        return this;
    }

    public List<String> addNonreferenceProduct(DataTable table) {
        List<String> additionalNonReferenceProductName = new ArrayList<>();
        List<Map<String, String>> orders = table.asMaps(String.class, String.class);
        int j=0;
            for (int i = 0; i < orders.size(); i++) {
                j++;
                clickAddLine_NonReferenceSparePart();
                Map<String, String> order = orders.get(i);
                for(Map.Entry<String,String> entry: order.entrySet()) {
                    String key = entry.getKey();
                    String value = entry.getValue();
                    switch (key) {
                        case "Text Reference" -> {
                            new PartsOrder().enterTextReference(value,j);
                            additionalNonReferenceProductName.add(value);
                        }
                        case "Unit Of Measure" -> new PartsOrder().selectUnitOfMeasure(value,j);
                        case "Order Type" -> new PartsOrder().selectOrderType(value,j);
                        case "Committed Ship date" -> new PartsOrder().enterCommittedShipDate(value,j);
                        default -> System.out.println("Not Implemented for " + key);
                    }
                }

        }
        CONSTANTS.captureScreen = true;
        return additionalNonReferenceProductName;
    }

    public ElementsCollection fetchPartsOrderLinesExpandIcons() {
        ElementsCollection expand_line_icons = null;
        try {
            expand_line_icons = $$x(EXPAND_ADDEDPART_ALL);
        } catch (Exception e) {
            handleException("Error fetching Parts Order Lines Expand Icons from the Parts order line in Parts Order tab", e);
        }
        return expand_line_icons;
    }

    public List<String> getPartReferenceTextFromPartsOrderLines() {
        List<String> actualValues = new ArrayList<>();
        try {
            ElementsCollection partRefTxts = $$x(PART_REFERENCE_VALUE);
            for(SelenideElement partRefTxt: partRefTxts) {
                highLightElement(partRefTxt.shouldBe(visible, Duration.ofSeconds(5000)));
                actualValues.add(partRefTxt.getText());
            }
        } catch (Exception e) {
            handleException("Error fetching part Reference text from the Parts order line in Parts Order tab", e);
        }
        return actualValues;
    }

    public void verifyPartReferenceInPartsOrderLine(List<String> expectedValue) {
        System.out.println("Expected values  -> "+expectedValue);
        waitForGivenTime(5000);
        List<String> actual = new ArrayList<>();
        try {
            ElementsCollection expand_line_icons = fetchPartsOrderLinesExpandIcons();
            for (SelenideElement expandLineIcon : expand_line_icons) {
                highLightElement(expandLineIcon.shouldBe(visible, Duration.ofSeconds(3000)));
                executeJavaScript("arguments[0].click();", expandLineIcon);
                waitForGivenTime(5000);
                actual.addAll(getPartReferenceTextFromPartsOrderLines());
                CONSTANTS.captureScreen = true;
            }
        } catch (Exception e) {
            handleException("ERROR Fetching PART REFERENCE Value from Parts order Line ", e);
        }
        System.out.println("Actual values  -> "+actual);
        Collections.sort(actual);
        Collections.sort(expectedValue);
        Assert.assertTrue("Text Reference values entered does not match with that displayed in Parts Order Line, actual-"+actual+" and expected - "+expectedValue, actual.equals(expectedValue));

    }

    public PartsOrder enterProductName(String textToEnter) {
        try {
            waitForGivenTime(5000);
            SelenideElement inputField = $x(String.format(SEARCH_PRODUCT, "product to search"));
            inputField.click();
            inputField.clear();
            inputField.setValue(textToEnter);
        } catch (Exception e) {
            handleException("Error entering text into field", e);
        }
        return this;
    }

    public PartsOrder clickGo() {
        try {
            waitForGivenTime(5000);
            SelenideElement goButton = $x(GO_BUTTON);

            // Scroll into view and click using JavaScript
            goButton.shouldBe(visible);
            goButton.click();
//            executeJavaScript("arguments[0].scrollIntoView({block: 'center'}); arguments[0].click();", goButton);
            waitForGivenTime(10000);
        } catch (Exception e) {
            throw new RuntimeException("Error clicking the 'Add Line' button: " + e.getMessage());
        }
        return this;
    }

    public String selectAdditionalProduct(String dynamicValue) {
        try {
            // Construct the dynamic XPath
            String xpath = String.format(PRODUCT_CHECKBOX, dynamicValue);

            // Locate the element and click
            SelenideElement checkbox = $x(xpath);
            checkbox.shouldBe(visible, enabled).click();

            return dynamicValue; // Return the value for further use

        } catch (Exception e) {
            throw new RuntimeException("Error selecting checkbox for value: " + dynamicValue, e);
        }
    }

    public PartsOrder clickAdd() {
        try {
            SelenideElement addButton = $x(ADD_PRODUCTS);

            // Scroll into view and click using JavaScript
            addButton.shouldBe(visible);
            executeJavaScript("arguments[0].scrollIntoView({block: 'center'}); arguments[0].click();", addButton);
            waitForGivenTime(10000);
        } catch (Exception e) {
            throw new RuntimeException("Error clicking the 'Add' button: " + e.getMessage());
        }
        return this;
    }

    public PartsOrder selectPartsOrderLineItems(String dynamicValue) {
        try {
            // Locate all matching checkboxes
            String xpath = String.format(LINE_ITEMS_CHECKBOX, dynamicValue);
            ElementsCollection checkboxes = $$x(xpath);

            if (checkboxes.isEmpty()) {
                throw new RuntimeException("No checkboxes found for the given dynamic value: " + dynamicValue);
            }

            for (SelenideElement checkbox : checkboxes) {
                if (checkbox.isDisplayed()) {
                    executeJavaScript("arguments[0].scrollIntoView({block: 'center'}); arguments[0].click();", checkbox);
                    waitForGivenTime(1000); // Small delay for stability
                }
            }
        } catch (Exception e) {
            throw new RuntimeException("Error selecting 'Line Items' checkboxes: " + e.getMessage());
        }
        return this;
    }

    public void waitForLoadingToComplete(String locator) {
        int maxAttempts = 20;  // Max attempts (adjustable)
        int attempt = 0;
        int delayBetweenAttempts = 10000; // 1 second delay between checks

        ElementsCollection elements = $$x(locator);  // Use locator dynamically

        while (attempt < maxAttempts) {
            if (elements.size() == 0) {
                return; // Exit when loading completes
            }

            System.out.println("Waiting for loading to complete... Attempt: " + (attempt + 1));
            Selenide.sleep(delayBetweenAttempts);
            attempt++;
        }

        throw new TimeoutException("Loading did not complete within " + (maxAttempts * delayBetweenAttempts / 1000) + " seconds");
    }

    public PartsOrder clickAtpCheck() {
        try {
            SelenideElement atpCheck = $x(ATP_CHECK);
            sleep(2000);

            // Scroll into view and click using JavaScript
            atpCheck.shouldBe(visible);
            executeJavaScript("arguments[0].scrollIntoView({block: 'center'}); arguments[0].click();", atpCheck);
            waitForLoadingToComplete(LOADING_PROGRESS);
        } catch (Exception e) {
            throw new RuntimeException("Error clicking the 'ATP Check' button: " + e.getMessage());
        }
        return this;
    }

    public PartsOrder clickSaveReleasePartsOrder() {
        try {
            SelenideElement saveRelease = $x(SAVE_RELEASE_PARTS_ORDER);

            // Scroll into view and click using JavaScript
            saveRelease.shouldBe(visible);
            executeJavaScript("arguments[0].scrollIntoView({block: 'center'}); arguments[0].click();", saveRelease);
            waitForGivenTime(10000);
            waitForLoadingToComplete(LOADER_ICON);
        } catch (Exception e) {
            throw new RuntimeException("Error clicking the 'Save' button: " + e.getMessage());
        }
        return this;
    }

    public PartsOrder clickSavePartsOrder() {
        try {
            SelenideElement saveRelease = $x(SAVE_PARTS_ORDER);

            // Scroll into view and click using JavaScript
            saveRelease.shouldBe(visible);
            executeJavaScript("arguments[0].scrollIntoView({block: 'center'}); arguments[0].click();", saveRelease);
            waitForGivenTime(10000);
            waitForLoadingToComplete(LOADER_ICON);
        } catch (Exception e) {
            throw new RuntimeException("Error clicking the 'Save' button: " + e.getMessage());
        }
        return this;
    }

    public void clickAllPartsOrderButtons() {
        waitForGivenTime(5000);
        ElementsCollection buttons = $$x(PARTS_NUMBERS);

        if (buttons.isEmpty()) {
            throw new RuntimeException("No buttons found to click.");
        }

        for (SelenideElement button : buttons) {
            if (button.isDisplayed()) {  // Ensure the button is visible before clicking
                executeJavaScript("arguments[0].click();", button);


                System.out.println("Clicked button: " + button.getText());
                Selenide.sleep(500); // Small delay for UI stability
            }
        }
    }


    public boolean expandPartsOrder(String orderNumber) {
        // Construct the dynamic XPath for multiple elements matching the order number
        String dynamicXPath = String.format("(//a[@title='%s'])[last()]", orderNumber);

        // Find all matching elements
        ElementsCollection orderElements = $$x(dynamicXPath);

        if (orderElements.isEmpty()) {
            System.out.println("No elements found for order number: " + orderNumber);
            throw new RuntimeException("No buttons found to click.");
        }

        boolean clicked = false;
        for (SelenideElement orderElement : orderElements) {
            if (orderElement.isDisplayed()) {
                System.out.println("Clicking on Parts Order: " + orderNumber);
                orderElement.shouldBe(Condition.visible, Duration.ofSeconds(120))
                        .click(ClickOptions.usingJavaScript());
                clicked = true;
                break; // Click only one visible element per order number
            }
        }

        if (!clicked) {
            System.out.println("Skipping hidden or missing order number: " + orderNumber);
        }
        return clicked;
    }


    public void clickFirstPartsOrderButton() {
        waitForGivenTime(5000);
        ElementsCollection buttons = $$x(PARTS_NUMBERS);

        if (buttons.isEmpty()) {
            throw new RuntimeException("No buttons found to click.");
        }

        SelenideElement firstButton = buttons.first(); // Always get the first button

        if (firstButton.isDisplayed()) { // Ensure the button is visible before clicking
            executeJavaScript("arguments[0].click();", firstButton);
            System.out.println("Clicked first button: " + firstButton.getText());
            Selenide.sleep(500); // Small delay for UI stability
        }
    }



//    public void checkPartsOrderStatus(String tab, String expectedStatus) {
//        new ApplicationCommonMethods().navigateToTab(tab);
//        int maxAttempts = 20;
//        int delayBetweenAttempts = 10000; // 10 seconds delay between refresh attempts
//
//        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
//            new ApplicationCommonMethods().navigateToTab(tab);
//
//            // Get all visible statuses as a List<String>
//            List<String> visibleStatuses = $$x(ORDER_STATUS)
//                    .filter(Condition.visible)
//                    .texts(); // Extracts text of all visible elements
//
//            // Check if all visible statuses contain the expected text
//            boolean allVisibleMatched = visibleStatuses.stream().allMatch(text -> text.contains(expectedStatus));
//
//            if (allVisibleMatched) {
//                Assert.assertTrue("Expected status found for all visible locators: " + expectedStatus, true);
//                CONSTANTS.captureScreen = true;
//                return;
//            }
//
//            System.out.println("Attempt " + attempt + ": Status not matched for all visible locators. Refreshing...");
//            refresh();
//            Selenide.sleep(delayBetweenAttempts);
//        }
//
//        Assert.fail("Expected status '" + expectedStatus + "' not found for all visible locators after " + maxAttempts + " attempts");
//    }

    public void checkPartsOrderStatus(String tab, String expectedStatus) {
//        new ApplicationCommonMethods().navigateToTab(tab);
        int maxAttempts = 10;
        int delayBetweenAttempts = 10000; // 10 seconds delay

        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            // Get all visible statuses as a List<String>
           new ApplicationCommonMethods().navigateToTab(tab);
           waitForGivenTime(5000);
            List<String> visibleStatuses = $$x(ORDER_STATUS)
                    .filter(Condition.visible)
                    .texts(); // Extracts text of all visible elements

            if (!visibleStatuses.isEmpty()) { // Ensure statuses are loaded before checking
                boolean allVisibleMatched = visibleStatuses.stream().allMatch(text -> text.equals(expectedStatus));

                if (allVisibleMatched) {
                    CONSTANTS.captureScreen = true;
                    System.out.println("Expected status matched exactly for all visible locators: " + expectedStatus);
                    return; // Exit the method immediately when match is found
                }
            }

            // If the expected status is not found, refresh and retry
            if (attempt < maxAttempts) {
                System.out.println("Attempt " + attempt + " of " + maxAttempts + ": Status mismatch. Refreshing...");
                Selenide.refresh();
                Selenide.sleep(delayBetweenAttempts);
            }
        }

        // If loop completes without finding a match, fail the test
        Assert.fail("Expected status '" + expectedStatus + "' not found for all visible locators after " + maxAttempts + " attempts");
    }





    public List<String> getPartsOrderNumber() {
        waitForGivenTime(5000);
        List<String> titles = new ArrayList<>();

        for (SelenideElement element : $$x(PARTS_ORDER_NUMBERS)) {
            if (element.exists() && element.isDisplayed()) { // Ensure element exists and is visible
                element.shouldBe(Condition.visible.because("Parts Order Numbers link should be visible"))
                        .scrollIntoView("{block: \"center\"}");

                String title = element.getAttribute("title");
                if (title == null || title.isEmpty()) {
                    throw new RuntimeException("Title attribute is missing or empty for WORK DETAIL link.");
                }
                titles.add(title);
            }
        }

        System.out.println("Parts Order Numbers Titles: " + titles);
        return titles;
    }


    public List<String> getLineNumbers() {
        waitForGivenTime(5000);
        List<String> titles = new ArrayList<>();

        for (SelenideElement element : $$x(LINE_NUMBERS)) {
            if (element.exists() && element.isDisplayed()) { // Ensure element exists and is visible
                element.shouldBe(Condition.visible.because("Line Numbers link should be visible"))
                        .scrollIntoView("{block: \"center\"}");

                String title = element.getAttribute("title");
                if (title == null || title.isEmpty()) {
                    throw new RuntimeException("Title attribute is missing or empty for Line Number link.");
                }
                titles.add(title);
            }
        }

        System.out.println("Line Numbers Titles: " + titles);
        return titles;
    }

    public String getPartsReferenceValue() {
        // Locate the element PART_REFERENCE
//        SelenideElement referenceElement = $x("//td[@data-label='Part Reference']/div/lightning-formatted-rich-text/span");
        SelenideElement referenceElement = $x(PART_REFERENCE);
        // Scroll to the element before interacting
//        referenceElement.scrollIntoView(true);

        // Get the text from the element
        String part = referenceElement.getText();
        System.out.println("get work order type : " + part);

        return part;
    }


    public List<String> processLineNumbers(String dynamicValue, String lineStatusText, String lineStatusValue,
                                           String shipQtyText, String shipQtyValue, String expDateText,
                                           String actDateText, String format) {
        waitForGivenTime(8000);
        ElementsCollection lineLinks = $$x(String.format("(//a[@title='%s'])[last()]", dynamicValue));

        if (lineLinks.isEmpty()) {
            throw new RuntimeException("No line number links found: " + lineLinks);
        }

        // Store only unique, visible titles
        List<String> linkTitles = new ArrayList<>();
        for (SelenideElement link : lineLinks) {
            if (link.isDisplayed() && !linkTitles.contains(link.getAttribute("title"))) {
                linkTitles.add(link.getAttribute("title"));
            }
        }

        System.out.println("Captured Titles: " + linkTitles);

        String parentWindow = WebDriverRunner.getWebDriver().getWindowHandle();

        for (int i = 0; i < linkTitles.size(); i++) {
            SelenideElement link = lineLinks.get(i);
            String title = linkTitles.get(i);

            if (link.isDisplayed()) {
                System.out.println("Processing link with title: " + title);
                $(link).shouldBe(Condition.visible, Duration.ofSeconds(120)).click(ClickOptions.usingJavaScript());
                Selenide.sleep(5000);

                // Wait for new tab and switch
                Set<String> windowHandles = WebDriverRunner.getWebDriver().getWindowHandles();
                if (windowHandles.size() > 1) {
                    for (String handle : windowHandles) {
                        if (!handle.equals(parentWindow)) {
                            WebDriverRunner.getWebDriver().switchTo().window(handle);
                            break;
                        }
                    }
                }

                new ApplicationCommonMethods().navigateToTab("Details");

                // Perform operations
                selectLineStatus(lineStatusText, lineStatusValue);
                Selenide.sleep(3000);
                enterExpectedActualShipDate(expDateText, format);
                Selenide.sleep(3000);
                enterExpectedActualShipDate(actDateText, format);
                Selenide.sleep(3000);
                enterShippedQuantity(shipQtyText, shipQtyValue);
                Selenide.sleep(3000);



                clickSaveLineItem();

                // Close new tab and switch back to parent
                closeWindow();
                WebDriverRunner.getWebDriver().switchTo().window(parentWindow);
            } else {
                System.out.println("Skipping hidden link: " + title);
            }
        }

        return linkTitles;
    }


    public PartsOrder selectLineStatus(String labelText, String value) {
        try {
            waitForGivenTime(4000);
            String editButtonXpath = "//span[contains(text(),'Edit " + labelText + "')]/parent::button";
            System.out.println("Trying XPath: " + editButtonXpath);

            // Locate and click the dropdown
            SelenideElement dropdown = $x(editButtonXpath)
                    .shouldBe(Condition.visible.because("Dropdown should be visible for: " + labelText))
                    .scrollIntoView("{block: \"center\"}");
//                     .scrollIntoView(true);
            dropdown.click();
            waitForGivenTime(2000);

            // Locate and click the line status field
            String lineStatusXpath = String.format(LINE_STATUS, labelText);
            SelenideElement lineStatus = $x(lineStatusXpath)
                    .shouldBe(Condition.visible.because("Line status should be visible for: " + labelText));
            lineStatus.click();
            waitForGivenTime(1000);

            // Locate and select the dropdown item
            String dropdownItemXpath = String.format(LINE_STATUS_VALUE, value);
            System.out.println("Trying Item XPath: " + dropdownItemXpath);
            screenshot("before_item_click");

            SelenideElement dropdownItem = $x(dropdownItemXpath)
                    .shouldBe(Condition.visible, Condition.enabled)
                    .scrollIntoView("{block: \"center\"}");
            dropdownItem.click();

        } catch (Exception e) {
            throw new RuntimeException("Error: Failed to Select Line Status - " + e.getMessage(), e);
        }
        return this;
    }


    public PartsOrder enterShippedQuantity(String labelText, String value) {
        try {

            // Add small wait to ensure dropdown options are rendered
            sleep(5000);

            String txtShipQty = String.format(SHIP_QTY_VALUE, labelText);
            SelenideElement shipQty = $x(txtShipQty);
            shipQty.scrollIntoView("{block: \"center\"}");
            shipQty.clear();
            shipQty.setValue(value).pressTab();
//            sleep(3000);
            shipQty.pressTab();
//            sleep(3000);

        } catch (Exception e) {
            throw new RuntimeException("Error Failed to Select Line Status: " + e.getMessage());
        }
        return this;
    }

    public PartsOrder enterExpectedActualShipDate(String labelText,String format) {
        try {
            clickAndEnterCurrentDate(labelText, EXPECTED_ACTUAL_DATE, format);
        } catch (Exception e) {
            throw new RuntimeException("Error Failed to Select Dates: " + e.getMessage());
        }
        return this;
    }

    public PartsOrder clickSaveLineItem() {
        try {
            SelenideElement saveRelease = $x(SAVE_LINE_ITEM);

            // Scroll into view and click using JavaScript
            saveRelease.shouldBe(visible);
            executeJavaScript("arguments[0].scrollIntoView({block: 'center'}); arguments[0].click();", saveRelease);
            waitForGivenTime(10000);
            waitForLoadingToComplete(LOADER_ICON_NEW);
        } catch (Exception e) {
            throw new RuntimeException("Error clicking the 'Save' button: " + e.getMessage());
        }
        return this;
    }
    public PartsOrder verifyReleasedBo() {
        waitForGivenTime(8000);



        String parentWindow = WebDriverRunner.getWebDriver().getWindowHandle();
//                new ApplicationCommonMethods().navigateToTab("Details");

        // Wait for new tab and switch
        Set<String> windowHandles = WebDriverRunner.getWebDriver().getWindowHandles();
        for (String handle : windowHandles) {
            if (!handle.equals(parentWindow)) {
                WebDriverRunner.getWebDriver().switchTo().window(handle);
                break;
            }
        }
        clickOkReleasedBo();
        // Close new tab and switch back to parent
//        closeWindow();
        WebDriverRunner.getWebDriver().switchTo().window(parentWindow);
        return this;
    }
    public PartsOrder clickOkReleasedBo() {
        try {
            SelenideElement saveRelease = $x(OK_BUTTON);

            // Scroll into view and click using JavaScript
            saveRelease.shouldBe(visible);
            executeJavaScript("arguments[0].scrollIntoView({block: 'center'}); arguments[0].click();", saveRelease);
            waitForGivenTime(10000);
        } catch (Exception e) {
            throw new RuntimeException("Error clicking the 'OK' button: " + e.getMessage());
        }
        return this;
    }
    public static void clickAndEnterCurrentDate(String labelText, String xpath, String format) {
        try {
            String dynamicXpath = String.format(xpath, labelText);
            SelenideElement element = $x(dynamicXpath);

            element.shouldBe(visible, enabled)
                    .scrollIntoView("{block: \"center\"}")
                    .click();

            new Actions(WebDriverRunner.getWebDriver()).sendKeys(Keys.ESCAPE).perform();

            // Format current date as dd/MM/yyyy
            String formattedDate = LocalDate.now().format(DateTimeFormatter.ofPattern(format));
            element.setValue(formattedDate);
        } catch (Exception e) {
            handleException("Error interacting with the date input field", e);
        }
    }

    public PartsOrder selectLineOrderAndSwitchtoDetailsTab() {
       String parentWindow = WebDriverRunner.getWebDriver().getWindowHandle();
        new PartsOrder().clickLinenumberInPartsOrder();
        // Wait for new tab and switch
        switchToChildWindow(parentWindow);
        new ApplicationCommonMethods().navigateToTab("Details");
        return this;
    }

    public PartsOrder clickEditButtonInLineOrder_DetailsTab(String fieldName) {// "Entitlement Reason"
        highLightElement($x(String.format(EDIT_BUTTON_LINE_ORDER_DETAILS_TAB, fieldName)).scrollIntoView(false).shouldBe(visible, enabled));
        $x(String.format(EDIT_BUTTON_LINE_ORDER_DETAILS_TAB, fieldName)).shouldBe(visible, enabled).click(); // Edit Entitlement Reason
        return this;
    }

    public PartsOrder selectDropdownValue(String fieldName, String dropdownValue) {
        $x(String.format(DROPDOWN_BUTTON, fieldName)).shouldBe(visible).scrollIntoView("{block: \"center\"}").click();
        $x(String.format(DROPDOWN_OPTIONS,dropdownValue)).shouldBe(visible).click(ClickOptions.usingJavaScript()); //dropdown_options check
        return this;
    }

    public PartsOrder clickPartsOrderNumber() {
        highLightElement($x(PARTS_ORDER_NUMBER_LINK).shouldBe(visible, enabled));
        $x(PARTS_ORDER_NUMBER_LINK).shouldBe(visible, enabled).click(ClickOptions.usingJavaScript());
        CONSTANTS.captureScreen = true;
        return this;
    }

    public PartsOrder clickonSyncInERP() {
        highLightElement($x(SYNC_IN_ERP_LINK).shouldBe(visible, enabled).scrollIntoView(false));
        actions().moveToElement($x(SYNC_IN_ERP_LINK).shouldBe(visible, enabled)).click().perform();
        CONSTANTS.captureScreen = true;
        return this;
    }

    public PartsOrder clickOnOKInERPSyncWindow(){
        highLightElement($x(OK_BUTTON_ERP_SYNC_WINDOW).shouldBe(visible,enabled,interactable));
        Selenide.sleep(4000);
        $x(OK_BUTTON_ERP_SYNC_WINDOW).shouldBe(visible,enabled,interactable).click();
        return this;
    }

    // "Entitlement Reason", "Warranty"
    public void selectEntitlementReasonFromLineOrder(String fieldName, String dropdownValue) {
        selectLineOrderAndSwitchtoDetailsTab();
        clickEditButtonInLineOrder_DetailsTab(fieldName).selectDropdownValue(fieldName, dropdownValue);
        CONSTANTS.captureScreen = true;
        clickSaveLineItem();
        closeWindow();
       switchTo().window(0);
        refresh();
    }

    public void verifySyncInERPInPartsOrder(String expectedMessage){
        clickPartsOrderNumber();
        switchTo().window(1);
        clickonSyncInERP();
        switchTo().window(2); // check
        String actualMessage = $x(SYNC_IN_ERP_STATUS_MESSAGE).getText();
        Assert.assertTrue("Actual message - \" "+actualMessage+" \" is not as expected ",actualMessage.contains(expectedMessage));
        CONSTANTS.captureScreen=true;
        clickOnOKInERPSyncWindow();
        switchTo().window(1);
        closeWindow();
       switchTo().window(0);
        refresh();
    }

}