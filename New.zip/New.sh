#!/usr/bin/env bash
set -euo pipefail
 
OUT=${1:-commits_by_file.csv}
 
git log --pretty=format:'@@@|%h|%ad|%an|%s' --date=iso --name-only -- src \
| awk '
  BEGIN { OFS=","; print "file,commit,date,author,message" }
  /^@@@\|/ {
    sub(/^@@@\|/,"");
    split($0,a,"|");
    commit=a[1]; date=a[2]; author=a[3];
    message=a[4];
    for(i=5;i<=length(a);i++) message=message "|" a[i];
    next
  }
  NF==1 && $0 != "" {
    file=$0;
    if (file ~ /^TestSuites\//) sub(/^TestSuites\//,"",file);
    escMsg=message;
    gsub(/"/,"\"\"",escMsg);
    gsub(/\r/,"",escMsg);
    printf("\"%s\",\"%s\",\"%s\",\"%s\",\"%s\"\n", file, commit, date, author, escMsg);
  }
' > "$OUT"
 
echo "Written $OUT"