package rough;

import bfs.pages.bfo.BFONewServiceContractBasicInfoPageObjects;
import bfs.pages.bfo.BFONewServiceContractDetailsPageObjects;
import com.codeborne.selenide.*;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selectors.byText;
import static com.codeborne.selenide.Selenide.*;

public class DebugTest {

    @Test
    public void test() {
        configure();
//

        open("https://test.salesforce.com");
        //open();
        $("#username").should(visible,enabled).setValue("coordinator-1532@bridge-fo.com.uat24");
        $("#password").should(visible,enabled).setValue("Test@#12345679");
        $("#Login").should(visible,enabled).click();
        BFONewServiceContractBasicInfoPageObjects serviceContractBasicInfoPage = new BFONewServiceContractBasicInfoPageObjects();
        BFONewServiceContractDetailsPageObjects serviceContractDetailsPage = new BFONewServiceContractDetailsPageObjects();
        serviceContractBasicInfoPage.clickOnNewButton();
        Selenide.sleep(5000);
        serviceContractBasicInfoPage.setServiceContractName("Test Service Contract")
               .setSoldToAccount("0001614376:Sharma Electric works(1003)")
               .setMainInstalledAtAccount("Sharma Electric works(1003):Sharma Electric works(1003)")
               .setBillToAccount("Sharma Electric works(1003):Sharma Electric works(1003)")
                .setMainInstalledAtContact("AZHARUDDIN KHAN:AZHARUDDIN KHAN")
                 .setRemoteServiceContact("AZHARUDDIN KHAN:AZHARUDDIN KHAN")
                .setStartDate(getTodayDate("dd/MM/yyyy"))
                .setEndDate(getNextYearDate("dd/MM/yyyy", 1))
                .setDescription("Test Service Contract");

        serviceContractDetailsPage
                .selectSalesRep("1532:Coordinator 1532")
                .setPODate(getTodayDate("dd/MM/yyyy"))
                .setPONumber("PO123456")
                .selectBillToContact("AZHARUDDIN KHAN:AZHARUDDIN KHAN")
                .selectSoldToContact("AZHARUDDIN KHAN:AZHARUDDIN KHAN");
       // serviceContractDetailsPage.clickSaveAndNextButton();

        // write code to get today's date in java*/
    }
    public static void configure() {
        Configuration.browser="chrome";
        Configuration.timeout=10000;
        ChromeOptions options = new ChromeOptions();
        options.setExperimentalOption("debuggerAddress", "127.0.0.1:9222");
        ChromeDriver driver = new ChromeDriver(options);
        WebDriverRunner.setWebDriver(driver);
        Configuration.browserCapabilities = options;
    }



    private static final int MIN_CHARCODE = 48;
    private static final int MAX_CHARCODE = 122;

    public static String cpqEncrypt(String sInput, boolean bEncrypt) {
        StringBuilder newTokenValue = new StringBuilder();
        sInput = new StringBuilder(sInput).reverse().toString();

        for (int i = 0; i < sInput.length(); i++) {
            char oldChar = sInput.charAt(i);
            int newCharCode = oldChar + (bEncrypt ? 20 : -20);

            if (newCharCode > MAX_CHARCODE) {
                newCharCode = newCharCode - MAX_CHARCODE + MIN_CHARCODE - 1;
            }
            if (newCharCode < MIN_CHARCODE) {
                newCharCode = newCharCode + MAX_CHARCODE - MIN_CHARCODE + 1;
            }

            char newChar = (char) newCharCode;
            newTokenValue.append(newChar);
        }

        return newTokenValue.toString();
    }

    public static void main(String[] args) {
        String input = "FEDMC9Cx55<x4uyg";
        boolean encrypt = false; // Set to false for decryption
        String result = cpqEncrypt(input, encrypt);
        System.out.println("Result: " + result);
        System.out.println(getTodayDate("dd/MM/yyyy"));
    }


    public static String getTodayDate() {
        LocalDate today = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        return today.format(formatter);
    }
    public static String getTodayDate(String format) {
        LocalDate today = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
        return today.format(formatter);
    }

    public static String getNextYearDate(String format, int years) {
        LocalDate today = LocalDate.now().plusDays(20);
        LocalDate nextYearDate = today.plusYears(1);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        return nextYearDate.format(formatter);
    }
}
