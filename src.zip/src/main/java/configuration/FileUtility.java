package configuration;

import java.io.FileInputStream;
import java.util.Properties;

public class FileUtility {
    private static  Properties applicationConfig (String folderName,String fileName){
    	String root=System.getProperty("user.dir")+"/"+folderName+"/";
        Properties appProperties = new Properties();
        try{
            FileInputStream fis =null;
            fis = new FileInputStream(root+fileName+".properties");
            appProperties.load(fis);

        }catch (Exception ex){
            ex.getStackTrace();
        }
        return appProperties;
    }

    public static Properties loadProperties(String folderName,String filename){
        return applicationConfig(folderName,filename);
    }


}
