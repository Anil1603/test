package bfs.pages.bfo.PageObjects;

import bfs.CONSTANTS;
import bfs.pages.BasePage;
import bfs.pages.bfo.WorkOrders;
import bfs.pages.servicemax.PageObjects.FSRResponseUpdateWorkOrderPageObjects;
import bfs.stepdefinition.CommonLibrary;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.Selenide;
import org.junit.Assert;

import java.time.Duration;
import java.util.HashMap;
import java.util.LinkedHashMap;

import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selectors.byTagAndText;
import static com.codeborne.selenide.Selenide.*;
import static com.codeborne.selenide.Selenide.switchTo;

public class BFO_FSR_WODetailsPageObjects {
    FSRResponseUpdateWorkOrderPageObjects fsrResponseUpdateWorkOrderPageObjects= new FSRResponseUpdateWorkOrderPageObjects();
    private static final String WORK_ORDER_DETAILS_TAB = "li[data-label='Details']>a";
    private static final String ACCEPT_REJECT_PRIMARY_LABEL = "//div[contains(text(),'Accept & Reject Primary')]";
       public void fsrAcceptWorkOrder(String url) throws InterruptedException {
        new CommonLibrary().iNavigateToUrl(url);
           Selenide.sleep(5000);
         new WorkOrders().clickShowMoreButton();

        new BFO_SFMTabObjects().clickOnSFMTabButtons("accept & reject");
        //wait for frame to available for frame wto be avaable in selenide //iframe[@title='Service Delivery']
        $x("//iframe[@title='Service Delivery']").shouldBe(visible, Duration.ofSeconds(60));
        switchTo().frame($x("//iframe[@title='Service Delivery']"));
     //   $x(ACCEPT_REJECT_PRIMARY_LABEL).shouldBe(visible, Duration.ofSeconds(60));
     //   $(byTagAndText("span","Save")).shouldBe(visible).click();
           Selenide.sleep(5000);
        fsrResponseUpdateWorkOrderPageObjects.clickOnSaveButton();
//        actions().moveToElement($x("//div[@data-target-selection-name='sfdc:RecordField.SVMXC__Service_Order__c.SVMXC__Dispatch_Response__c']")).build().perform();
//        $x("//div[@data-target-selection-name='sfdc:RecordField.SVMXC__Service_Order__c.SVMXC__Dispatch_Response__c']").shouldBe(visible, Duration.ofSeconds(180));
        Selenide.sleep(10000);
        switchTo().defaultContent();
    }

    public void checkFSRResponseStatusIsExist(String responseStatus) {
        Selenide.sleep(5000);
        HashMap<String, Integer> responseList = new LinkedHashMap<>();
        int maxAttempts = 10;
        int attempts = 0;
        boolean statusFound = false;
        ElementsCollection collections;
        do {
            collections = $$x("//records-record-layout-item[@field-label='FSR Response']//div");
            for (int i = 0; i < collections.size(); i++) {
                String response = collections.get(i).getText();
                System.out.println(response);
                responseList.put(response, i);
            }

            if (responseList.containsKey(responseStatus)) {
                statusFound = true;
                Assert.assertTrue(responseList.containsKey(responseStatus));
            } else {
                refresh();
                Selenide.sleep(10000); // Wait for 10 seconds before the next attempt
                attempts++;
            }
        } while (attempts < maxAttempts && !statusFound);

        if (!statusFound) {
            Assert.fail("Expected response status not found after " + maxAttempts + " attempts");
        }
        CONSTANTS.captureScreen = true;
    }


}
