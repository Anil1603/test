package bfs.Pojo;

public class WorkOrdersCreatedPOJO {
    public String workOrder;
    public String date;

    public WorkOrdersCreatedPOJO() {
    }

    public WorkOrdersCreatedPOJO(String date, String workOrder) {
        this.date = date;
        this.workOrder = workOrder;
    }

}