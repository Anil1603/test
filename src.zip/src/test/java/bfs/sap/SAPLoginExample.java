package bfs.sap;

import com.jacob.activeX.ActiveXComponent;
import com.jacob.com.ComThread;
import com.jacob.com.Dispatch;
import com.jacob.com.Variant;

import java.io.IOException;


public class SAPLoginExample{
	
	
	public static void main(String[] args) {
	
		//-Variables------------------------------------------------------
	    ActiveXComponent SAPROTWr, GUIApp, Connection, Session, Obj,win;
	    Dispatch ROTEntry;
	    Variant ScriptEngine;
	    Variant[] arg;
	    ComThread.InitSTA();



	    //Opening the SAP Logon
	    String sapLogonPath = "C:\\Program Files (x86)\\SAP\\FrontEnd\\SAPgui\\saplogon.exe";
	    Process p;
	    try {
	        p = Runtime.getRuntime().exec(sapLogonPath);
	        Thread.sleep(7000);
	    } catch (IOException e) {
	        // TODO Auto-generated catch block
	        e.printStackTrace();
	    } catch (InterruptedException e) {
	        // TODO Auto-generated catch block
	        e.printStackTrace();
	    }


	    //-Set SapGuiAuto = GetObject("SAPGUI")---------------------------
	    SAPROTWr = new ActiveXComponent("SapROTWr.SapROTWrapper");
	    try {
	        ROTEntry = SAPROTWr.invoke("GetROTEntry", "SAPGUI").toDispatch();
	        //-Set application = SapGuiAuto.GetScriptingEngine------------
	        ScriptEngine = Dispatch.call(ROTEntry, "GetScriptingEngine");
	        GUIApp = new ActiveXComponent(ScriptEngine.toDispatch());


	        //SAP Connection Name
	        String sapConnectionName = "(Bridge) MDG 7.0 - I7Y - Integration"; //this is the name of the connection in SAP Logon
	        Connection = new ActiveXComponent(
	        GUIApp.invoke("OpenConnection",sapConnectionName).toDispatch());


	        //-Set connection = application.Children(0)-------------------
	        //Connection = new ActiveXComponent(GUIApp.invoke("Children", 0).toDispatch());

	        //-Set session = connection.Children(0)-----------------------
	        Session = new ActiveXComponent(
	        Connection.invoke("Children", 0).toDispatch());

	        win = new ActiveXComponent(Session.invoke("ActiveWindow").toDispatch());
	        
	        
	        //-Set GUITextField Client------------------------------------
	        //-
	        //- session.findById("wnd[0]/usr/txtRSYST-MANDT").text = "000"
	        //-
	        //------------------------------------------------------------
	       // Obj = new ActiveXComponent(Session.invoke("FindById","wnd[0]/usr/txtRSYST-MANDT").toDispatch());
	        //Obj.setProperty("Text", "511");
	        
	        
	        
	        arg = new Variant[2];
	        arg[0] = new Variant("RSYST-MANDT");
	        arg[1] = new Variant("GuiTextField");
	        Obj = new ActiveXComponent(win.invoke("findByName", arg).toDispatch());
	        Obj.setProperty("text", "511");

	        //-Set GUITextField User--------------------------------------
	        //-
	        //- session.findById("wnd[0]/usr/txtRSYST-BNAME").text = _
	        //-   "BCUSER"
	        //-
	        //------------------------------------------------------------
	          Obj = new ActiveXComponent(Session.invoke("FindById",
	            "wnd[0]/usr/txtRSYST-BNAME").toDispatch());
	          Obj.setProperty("Text", "TEST_SPALL");

	        //-Set GUIPasswordField Password------------------------------
	        //-
	        //- session.findById("wnd[0]/usr/pwdRSYST-BCODE").text = _
	        //-   "minisap"
	        //-
	        //------------------------------------------------------------
	          Obj = new ActiveXComponent(Session.invoke("FindById",
	            "wnd[0]/usr/pwdRSYST-BCODE").toDispatch());
	          Obj.setProperty("Text", "Sapjava@2020");


	        //-Set GUITextField Language----------------------------------
	        //-
	        //- session.findById("wnd[0]/usr/txtRSYST-LANGU").text = "DE"
	        //-
	        //------------------------------------------------------------
	          Obj = new ActiveXComponent(Session.invoke("FindById",
	            "wnd[0]/usr/txtRSYST-LANGU").toDispatch());
	          Obj.setProperty("Text", "EN");

	        //-Press enter------------------------------------------------
	        //-
	        //- session.findById("wnd[0]").sendVKey 0
	        //-
	        //------------------------------------------------------------
	          Obj = new ActiveXComponent(Session.invoke("FindById",
	            "wnd[0]").toDispatch());
	          Obj.invoke("sendVKey", 0);
	          
	          Thread.sleep(10000);
	          
	          Obj = new ActiveXComponent(win.invoke("findById","wnd[0]/tbar[0]/okcd").toDispatch());
	          Obj.setProperty("text", "SE16N");
	          Obj = new ActiveXComponent(win.invoke("findById","wnd[0]").toDispatch());
	          Obj.invoke("sendVKey", 0);
	          Thread.sleep(5000);
	         Obj=new ActiveXComponent(Session.invoke("FindById","wnd[0]/usr/ctxtGD-TAB").toDispatch());
	         Obj.setProperty("Text", "MVKE");
	         Obj=new ActiveXComponent(Session.invoke("FindById","wnd[0]/tbar[1]/btn[8]").toDispatch());
	         Obj.invoke("press");
	        
	         Obj = new ActiveXComponent(Session.invoke("FindById",
	 	            "wnd[0]/tbar[0]/btn[12]").toDispatch());
	         Obj.invoke("press");
	         Thread.sleep(5000);
	          
	         Obj=new ActiveXComponent(Session.invoke("FindById","wnd[0]/usr/tblSAPLSE16NSELFIELDS_TC/ctxtGS_SELFIELDS-LOW[2,1]").toDispatch() );
	         Obj.setProperty("Text","APRIL_SQE_ETOCR115");
	         /*Obj=new ActiveXComponent(Session.invoke("FindById","wnd[0]/usr/tblSAPLSE16NSELFIELDS_TC/ctxtGS_SELFIELDS-LOW[2,2]").toDispatch() );
	         Obj.setProperty("Text","DK02");*/
	         
	         Thread.sleep(5000);
	      
	         Obj = new ActiveXComponent(Session.invoke("FindById",
		 	            "wnd[0]/tbar[1]/btn[8]").toDispatch());
		         Obj.invoke("press");
		         Thread.sleep(5000);
		    Obj = new ActiveXComponent(win.invoke("FindById","wnd[0]/usr/cntlRESULT_LIST/shellcont/shell").toDispatch());		
		    arg = new Variant[2];
	        arg[0] = new Variant(1);
	        arg[1] = new Variant("Material");
	        Obj.invoke("doubleClick",arg);
	        System.out.println("Done");  
	        Thread.sleep(5000); 
	        
	        /*Obj = new ActiveXComponent(Session.invoke("FindById","wnd[0]/usr/cntlRESULT_LIST/shellcont/shell").toDispatch());
	        arg = new Variant[2];
	        arg[0] = new Variant(1);
	        arg[1] = new Variant("Material");
	        String materialName = Obj.getPropertyAsString("LVORM");
		    System.out.println(materialName);
	        */
		    
		    
	        Obj = new ActiveXComponent(win.invoke("FindById","wnd[0]/usr/cntlRESULT_LIST/shellcont/shell").toDispatch());		
	        Obj.invoke("pressToolbarButton","DETAIL");
	        System.out.println("Done");
	        //Runtime.getRuntime().exec( "wscript C:/Schneider/ScriptingPath/doubleClickGridviewSelectedCell.vbs"); 
	        Thread.sleep(5000); 
	       
	        
	        
	       Obj = new ActiveXComponent(Session.invoke("FindById","wnd[1]/usr/tblSAPLTSWUSLDETAIL_TAB/txtGT_SELFIELDS-SCRTEXT_L[0,0]").toDispatch());
	       String clientLabel = Obj.getPropertyAsString("Text");
	       System.out.println(clientLabel);
	       
	       Obj = new ActiveXComponent(Session.invoke("FindById","wnd[1]/usr/tblSAPLTSWUSLDETAIL_TAB/txtGT_SELFIELDS-LOW[1,0]").toDispatch());
	       String clientValue = Obj.getPropertyAsString("Text");
	       System.out.println(clientValue);
	          
	       Obj = new ActiveXComponent(Session.invoke("findById","wnd[1]").toDispatch());
	       Obj.invoke("close");
	       Thread.sleep(5000);
	       /*Obj = new ActiveXComponent(win.invoke("FindById","wnd[0]/usr/cntlRESULT_LIST/shellcont/shell").toDispatch());		
	        Obj.invoke("pressToolbarButton","&INFO");
	        Thread.sleep(5000);*/
	        
	        
	        	Obj = new ActiveXComponent(Session.invoke("FindById","wnd[0]/sbar/pane[0]").toDispatch());
		       String status = Obj.getPropertyAsString("Text");
		       System.out.println("Status "+status);
	       
		       
		       /*Obj = new ActiveXComponent(Session.invoke("FindById","wnd[0]/usr/cntlRESULT_LIST/shellcont/shell").toDispatch());		
		        String mat=Obj.invoke("currentCellColumn","VERSG").toString();
		        System.out.println(mat);  
		        Thread.sleep(5000); */
		       
		       
		      /* Obj = new ActiveXComponent(win.invoke("FindById","wnd[0]/usr/cntlRESULT_LIST/shellcont/shell").toDispatch());		
		        Obj.invoke("selectAll");   
		        Thread.sleep(5000);*/
		        
		        
		        /*Obj = new ActiveXComponent(Session.invoke("FindById","wnd[0]/usr/cntlRESULT_LIST/shellcont/shell").toDispatch());		
		        String mat=Obj.invoke("getCellValue",0,2).toString();
		        System.out.println(mat);  
		        Thread.sleep(5000);   */
	       
	     //Logout
	      /* Obj = new ActiveXComponent(Session.invoke("FindById","wnd[0]/mbar/menu[3]/menu[12]").toDispatch());
	       Obj.invoke("select");
	       Obj = new ActiveXComponent(Session.invoke("FindById","wnd[1]/usr/btnSPOP-OPTION1").toDispatch());
	       Obj.invoke("press");*/
	       
	       
	        arg = new Variant[2];
	        arg[0] = new Variant("System");
	        arg[1] = new Variant("GuiMenu");
	        Obj = new ActiveXComponent(win.invoke("findByName", arg).toDispatch());
	        Obj.invoke("select");
	        
	        
	        arg = new Variant[2];
	        arg[0] = new Variant("Log Off");
	        arg[1] = new Variant("GuiMenu");
	        Obj = new ActiveXComponent(win.invoke("findByName", arg).toDispatch());
	        Obj.invoke("select");
	        
	        Thread.sleep(4000);
	        Obj = new ActiveXComponent(Session.invoke("FindById","wnd[1]/usr/btnSPOP-OPTION1").toDispatch());
		    Obj.invoke("press");
		    
		   
	    }

	    catch (Exception e) {
            System.out.println(e.getMessage());
	    }

	    finally {
	      ComThread.Release();
	      System.exit(0);
	    }

	  }
	
	
	
	
	

}
