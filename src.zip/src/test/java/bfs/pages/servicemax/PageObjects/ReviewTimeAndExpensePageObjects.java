package bfs.pages.servicemax.PageObjects;

import bfs.CONSTANTS;
import bfs.pages.BasePage;
import org.junit.Assert;

import java.time.Duration;

import static com.codeborne.selenide.Condition.attribute;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$x;
import static com.codeborne.selenide.Selenide.switchTo;

public class ReviewTimeAndExpensePageObjects {
    private static final String OPPORTUNITY_DETECTED_VALUE = "//label[text()='Opportunity Detected']/..//div[@class='InputWrapper slds-size--block InputWrapper__has-icon slds-input-has-icon slds-input-has-icon--right']";
    private static final String WORK_ORDER_VALUE="//input[@placeholder='Work Order Number *']";
    private static final String WORK_PERFORMED_VALUE="//textarea[@name='SVMXC__Work_Performed__c']";
    private static final String COMPLETED_BY_VALUE="//label[text()='Completed By *']/..//span[@class='Pill__label slds-pill__label']";
    private static final String COMPLETED_ON_VALUE="//label[text()='Completed On *']/..//input";
    private static final String INSTALLED_AT_ACCOUNT_VALUE="//label[text()='Installed At Account *']/..//span[@class='Pill__label slds-pill__label']";


    public ReviewTimeAndExpensePageObjects verifyOpportunityDetectedValue(String value){
        $x("//iframe[@title='Service Delivery']").shouldBe(visible, Duration.ofSeconds(60));
        switchTo().frame($x("//iframe[@title='Service Delivery']"));
     //   $x(OPPORTUNITY_DETECTED_VALUE).shouldHave(attribute("title",value));
        Assert.assertEquals($x(OPPORTUNITY_DETECTED_VALUE).shouldBe(visible).getAttribute("title"),value);
        System.out.println("Opportunity Detected Value is: "+$x(OPPORTUNITY_DETECTED_VALUE).shouldBe(visible).getAttribute("title"));
        CONSTANTS.captureScreen=true;
        return this;
    }
    public ReviewTimeAndExpensePageObjects verifyWorkOrderValue(String value){
//        value="WO-13213412"; // todo delete
        Assert.assertEquals($x(WORK_ORDER_VALUE).shouldBe(visible).getValue(),value);
        System.out.println("Work Order Value is: "+$x(WORK_ORDER_VALUE).shouldBe(visible).getValue());
        CONSTANTS.captureScreen=true;
        return this;
    }
    public ReviewTimeAndExpensePageObjects verifyWorkPerformedValue(String value){
        Assert.assertEquals($x(WORK_PERFORMED_VALUE).shouldBe(visible).getValue(),value);
        System.out.println("Work Performed Value is: "+$x(WORK_PERFORMED_VALUE).shouldBe(visible).getValue());
        CONSTANTS.captureScreen=true;
        return this;
    }
    public ReviewTimeAndExpensePageObjects verifyCompletedByValue(String value){
        Assert.assertEquals($x(COMPLETED_BY_VALUE).shouldBe(visible).getText(),value);
        System.out.println("Completed By Value is: "+$x(COMPLETED_BY_VALUE).shouldBe(visible).getText());
        CONSTANTS.captureScreen=true;
        return this;
    }
    public ReviewTimeAndExpensePageObjects verifyCompletedOnValue(String format){
        String currentDate = BasePage.getTodayDate(format);
        Assert.assertEquals($x(COMPLETED_ON_VALUE).shouldBe(visible).getValue(),currentDate);
    //    Assert.assertEquals($x(COMPLETED_ON_VALUE).shouldBe(visible).getValue(),value);
        System.out.println("Completed On Value is: "+$x(COMPLETED_ON_VALUE).shouldBe(visible).getValue());
        CONSTANTS.captureScreen=true;
        return this;
    }
    public ReviewTimeAndExpensePageObjects verifyInstalledAtAccountValue(String value){
        Assert.assertEquals($x(INSTALLED_AT_ACCOUNT_VALUE).shouldBe(visible).getText(),value);
        System.out.println("Installed At Account Value is: "+$x(INSTALLED_AT_ACCOUNT_VALUE).shouldBe(visible).getText());
        CONSTANTS.captureScreen=true;
        switchTo().defaultContent();
        return this;
    }

    public void verifyAllDetails(String fieldName, String value){
        switch (fieldName.toLowerCase()){
            case "opportunity detected"-> verifyOpportunityDetectedValue(value);
            case "work order" -> verifyWorkOrderValue(BasePage.data.get(value));  //BasePage.data.get(value)
            case "work performed"-> verifyWorkPerformedValue(value);
            case "completed by"-> verifyCompletedByValue(value);
            case "completed on"-> verifyCompletedOnValue("dd/MM/yyyy");
            case "installed at account"-> verifyInstalledAtAccountValue(value);
            default -> throw new RuntimeException("NOt impleted foe " +fieldName);

        }

    }



}
