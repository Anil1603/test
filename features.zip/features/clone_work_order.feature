Feature: Clone Work Order.
  As a user
  I want to navigate to the application and clone Work Order for a specific cloned Work Order
  So that I can manage cloned orders efficiently


  Scenario Outline: Clone a Work Order for a specific Work Order
    Given I work in application "BFO" and environment "UAT"
    When I login to "bfo" as user "coordinator-1660@bridge-fo.com.uatbfo26"
    And the user selects "<Menu Item>" from the Search menu
    And the user enters "<Work Order>" in Global Search
    And the user selects the "<Work Order>" from search results
    And the user selects the "Clone WO"
#    And the user verifies the "Case" as "<Case ID>"
    And the user selects "Clone Reason" as "<Clone Reason>"
    And the user selects date from "Customer Requested Date" Date Picker
    And the user selects Save Work Order
#    When the user update "Service Commercial Ref" as "<Service Commercial Ref>"

    Examples:
      | Menu Item 	  | Work Order 	  |	Case ID 	| Clone Reason		| Service Commercial Ref	|
      | Work Orders     | WO-12264968   | 110949736 	| Project Duration	|	59600-001				|