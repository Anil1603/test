Feature: Create Work order and clone Work Order which is in New Stage.
  As a user
  I want to navigate to the application and create Work Order
  So that I can clone Work order successfully

  Scenario Outline: clone Work Order which is in New Stage
    Given I work in application "BFO" and environment "UAT"
    And I login to "BFO" as user "coordinator-1550@bridge-fo.com.uatbfo26"
    When I navigate to "SE - Services Lightning" from app launcher
    And I wait for "10" seconds
    And I navigate to "Work Orders" from app launcher
    And I click on bfo button "New"
    And I fill work order details for creating new work order from Work Order Page:
      | Field Name                | Field Value                         |
      | Select Record Type        | Standalone Work Order               |
      | Installed At Account      | 0001340233:Ampcontrol (QLD) Pty Ltd |
      | Location                  | 0045144542:Ampcontrol QLD Pty Ltd   |
      | Work Order Type           | Repair                              |
#    |Work Order Sub-Type                   |                                           |
      | Contact                   | chandra.vamsi kumar                 |
      | Customer Requested Date   | today                               |
      | Country of Back Office    | Australia                           |
      | Back Office System        | SAP Bridge AP                       |
      | Work Order Category       | Onsite                              |
      | Services Business Unit    | POWER SYSTEMS                       |
      | Is Billable               | Yes                                 |
      | Customer Reference Number | 1234                                |
      | Priority                  | Normal-Medium                       |
#    |Non Billing Reason                    |                                           |
      | Service Commercial Ref    | QWPFSRVPLNNSGEN                     |
#    |Skill Category                        |                                           |
      | Work Order Reason         | Testing                             |
      | Work Order Name           | Testing                             |
      | Sold To Account           | 0001340233:Ampcontrol (QLD) Pty Ltd |
    Then user should be able to see the work order number and memorize work order number
    And I should see the work order status as "New" in work order page

    And the user selects the "Clone WO"
    And the user selects "Clone Reason" as "<Clone Reason>"
    And the user selects date from "Customer Requested Date" Date Picker
    And the user selects Save Work Order
    Then switch to Work order page
    Then user should be able to see the work order number and memorize work order number
    And I should see the work order status as "New" in work order page

    Examples:
      | Clone Reason     |
      | Project Duration |