package bfs.pages.bfo;
import com.codeborne.selenide.Condition;
import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;
import com.codeborne.selenide.WebDriverRunner;
import com.codeborne.selenide.ex.ElementNotFound;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;

import java.time.Duration;

import static com.codeborne.selenide.Condition.*;
import static bfs.pages.BasePage.highLightElement;
import static com.codeborne.selenide.Selenide.*;

public class BFOLoginPageObjects {

    private static final By BFO_USERNAME_TEXTBOX = By.id("username");
    private static final By BFO_PASSWORD_TEXTBOX = By.id("password");
    private static final By BFO_LOGIN_BUTTON = By.cssSelector("input[type='submit'][id='Login'],#Login");


    public BFOLoginPageObjects setUsername(String username){
        highLightElement($(BFO_USERNAME_TEXTBOX).shouldBe(visible,enabled));
        $(BFO_USERNAME_TEXTBOX).shouldBe(visible,enabled).setValue(username);
        return this;
    }
    public BFOLoginPageObjects setPassword(String username){
        highLightElement($(BFO_PASSWORD_TEXTBOX).shouldBe(visible,enabled));
        $(BFO_PASSWORD_TEXTBOX).shouldBe(visible,enabled).setValue(username);
        return this;
    }

    public BFOLoginPageObjects clickLoginButton() {
        highLightElement($(BFO_LOGIN_BUTTON).shouldBe(visible, enabled));
        $(BFO_LOGIN_BUTTON).shouldBe(visible, enabled).click();
        Selenide.sleep(9000);
        try {
            if ($$x("//h1[text()='Sorry to interrupt']").size() != 0) {
                refresh();
            }

        } catch (Exception e) {
            System.out.println("Sorry to interrupt pop up not found");

        }
        return this;
    }


}
