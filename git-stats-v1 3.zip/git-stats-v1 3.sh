#!/usr/bin/env bash
set -euo pipefail

tmp_file="$(mktemp)"

git log --pretty=format:'%an <%ae>|%ad' --date=format:'%Y|%m' --numstat | \
awk 'BEGIN { OFS=","; print "Author,Period,Added,Deleted,Total" }
{
    # Capture commit header (author|YYYY|MM)
    if ($0 ~ /\|[0-9]{4}\|[0-9]{2}$/) {
        split($0,parts,"|");
        author=parts[1]; year=parts[2]; month=parts[3];
        key=author "|" year "|" month;
        seen[key]=1; next;
    }
    # Numstat line
    if ($0 ~ /^[0-9-]+\t[0-9-]+\t/) {
        add_field = substr($0,1,index($0,"\t")-1);
        rest = substr($0,index($0,"\t")+1);
        del_field = substr(rest,1,index(rest,"\t")-1);
        add = (add_field=="-"?0:add_field)+0;
        del = (del_field=="-"?0:del_field)+0;
        if (key!="") { added[key]+=add; deleted[key]+=del }
        next;
    }
}
END {
    # Aggregate into periods: 2024_H1 (Jan-Jun 2024), 2025_H1 (Jan-Jun 2025), 2025_H2 (Jul-Dec 2025)
    for (k in seen) {
        split(k,p,"|"); a=p[1]; y=p[2]; m=p[3]+0;
        period="";
        if (y==2024 && m>=1 && m<=6) period="2024_H1";
        else if (y==2025 && m>=1 && m<=6) period="2025_H1";
        else if (y==2025 && m>=7 && m<=12) period="2025_H2";
        else continue;
        pk=a SUBSEP period;
        a_sum=(k in added?added[k]:0); d_sum=(k in deleted?deleted[k]:0);
        pad[pk]+=a_sum; pdel[pk]+=d_sum;
    }
    for (pk in pad) {
        split(pk,s,SUBSEP); a=s[1]; per=s[2];
        A=pad[pk]; D=pdel[pk];
        print a,per,A,D,A+D;
    }
}' > "$tmp_file"

{ head -n1 "$tmp_file"; tail -n +2 "$tmp_file" | sort -t, -k2,2 -k1,1; } > git_stats-v1.csv
rm -f "$tmp_file"