package bfs.pages.bfo.PageObjects;

import bfs.CONSTANTS;
import org.junit.Assert;
import org.openqa.selenium.By;

import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.*;

public class BFOVerifyServiceContractBasicInfoPageObjects {
    private static final String STATUS_TEXT = "//span[text()='Status']/../../following-sibling::*//span//lightning-formatted-text";
   public void checkContractStatus(String status){
       switchTo().defaultContent();
       Assert.assertTrue($x(STATUS_TEXT).shouldBe(visible).getText().contains(status));
       CONSTANTS.captureScreen=true;
   }
}
