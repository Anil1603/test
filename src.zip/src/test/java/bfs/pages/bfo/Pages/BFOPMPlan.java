package bfs.pages.bfo.Pages;

import bfs.pages.bfo.PageObjects.BFOCreatePmPlanObjects;
import com.codeborne.selenide.Selenide;

public class BFOPMPlan {
    public void clickOnRelatedTab(String contractName) {
        BFOCreatePmPlanObjects bfoCreatePmPlanObjects = new BFOCreatePmPlanObjects();
        bfoCreatePmPlanObjects.clickOnRelatedTab()
                .clickOnServiceLinesButton()
                .clickOnContractName(contractName)
                .clickOnCreatePmPlanButton()
                .clickOnCreatePmPlanButtonOnPopUp();
    }
}
