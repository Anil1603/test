package bfs.pages.bfo.PageObjects;

import static com.codeborne.selenide.Condition.enabled;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$x;

public class BFODurationPageObjects {

    private static final String TOTAL_QUOTED_HRS_EDIT_BUTTON = "//span[text()='Total Quoted Hrs']//parent::div//following-sibling::div//button";
    private static final String TOTAL_QUOTED_HRS_INPUT = "//label[text()='Total Quoted Hrs']//following-sibling::div//input";
    private static final String SAVE_BUTTON_IN_DURATION_PAGE_EDIT = "//button[text()='Save']";
    private static final String TOTAL_QUOTED_HRS_VALUE = "//span[text()='Total Quoted Hrs']//parent::div//following-sibling::div//lightning-formatted-number";
    private static final String ERROR_MESSAGE_TOTAL_QUOTED_HRS = "//div[@class='svmx-sfmd-error-cmp-error-detail']";


    public void clickTotalQuotedHrsEditButton() {
        $x(TOTAL_QUOTED_HRS_EDIT_BUTTON).shouldBe(visible, enabled);
        $x(TOTAL_QUOTED_HRS_EDIT_BUTTON).shouldBe(visible, enabled).click();
    }

    public void setTotalQuotedHrs(String value) {
        $x(TOTAL_QUOTED_HRS_INPUT).shouldBe(visible, enabled);
        $x(TOTAL_QUOTED_HRS_INPUT).shouldBe(visible, enabled).setValue(value);
    }

    public String getTotalQuotedHrs() {
        $x(TOTAL_QUOTED_HRS_VALUE).shouldBe(visible, enabled);
        return $x(TOTAL_QUOTED_HRS_VALUE).getText();
    }

    public void clickSaveButton() {
        $x(SAVE_BUTTON_IN_DURATION_PAGE_EDIT).shouldBe(visible, enabled);
        $x(SAVE_BUTTON_IN_DURATION_PAGE_EDIT).shouldBe(visible, enabled).click();
    }

    public boolean isErrorMessageDisplayed() {
        return $x(ERROR_MESSAGE_TOTAL_QUOTED_HRS).isDisplayed();
    }

    public String fetchErrorMessage() {
        return $x(ERROR_MESSAGE_TOTAL_QUOTED_HRS).getText();
    }

}
