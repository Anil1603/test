package bfs.pages.bfo.PageObjects;

import org.openqa.selenium.By;
import com.codeborne.selenide.*;
import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.*;

public class BFOWorkOrderPageObject {
    private static final By NEW_BUTTON = By.xpath("//a[@title='New']");
    private static final By CONTINUE_BUTTON = By.xpath("//button[text()='Continue']");
    private static final By RECORD_TYPE_DROPDOWN = By.name("selectItem");

    public BFOWorkOrderPageObject clickOnNewButton(){
        $(NEW_BUTTON).shouldBe(visible,enabled);
        $(NEW_BUTTON).shouldBe(visible,enabled).click();
        return this;
    }
   public BFOWorkOrderPageObject waitForRecordTypePopUp(){
        $(CONTINUE_BUTTON).shouldBe(visible,enabled);
        return this;
    }
    public BFOWorkOrderPageObject clickOnContinueButton(){
        $(CONTINUE_BUTTON).shouldBe(visible,enabled);
        $(CONTINUE_BUTTON).click();
        return this;
    }
    public BFOWorkOrderPageObject selectRecordType(String value) {
        $(RECORD_TYPE_DROPDOWN).shouldBe(visible,enabled);
        $(RECORD_TYPE_DROPDOWN).selectOption(value);
        return this;
    }

}
