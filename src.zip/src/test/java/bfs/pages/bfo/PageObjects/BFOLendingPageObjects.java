package bfs.pages.bfo.PageObjects;



import bfs.CONSTANTS;
import com.codeborne.selenide.*;
import org.openqa.selenium.By;

import java.time.Duration;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.*;


public class BFOLendingPageObjects {

    private static final By APP_MENU_ICON =By.xpath("//div[@role='navigation'][@aria-label='App']");
    private static final By APP_SEARCH_TEXTBOX =By.xpath("//input[@part='input'][@type='search'][contains(@placeholder,'Search apps')]");
    private static final By LIST_OF_MENU = By.xpath("//div[@class='al-menu-dropdown-list']/*/a/div/*/span/p/b");

    private static final String MY_TEAM_ASSIGNED_FSR_LINK = "//a[text()='My Team Assigned FSR']";

    public BFOLendingPageObjects clickOnAPPMenuIcon(){
        $(APP_MENU_ICON).shouldBe(visible,enabled);
        $((APP_MENU_ICON)).shouldBe(visible,enabled).click();
        return this;
    }

    public BFOLendingPageObjects enterAppsToSearch(String appname){
        $(APP_SEARCH_TEXTBOX).shouldBe(visible,enabled);
        $(APP_SEARCH_TEXTBOX).shouldBe(visible,enabled).setValue(appname);
        return this;
    }
    public BFOLendingPageObjects waitForListOfMenu(){
        $$(LIST_OF_MENU).shouldHave(CollectionCondition.sizeGreaterThan(0));
        return this;
    }
    public void clickOnWorkOrder(String appName) {
        ElementsCollection menuItems = $$(LIST_OF_MENU);
        for (SelenideElement menuItem : menuItems) {
            System.out.println(menuItem.getText());
            if(menuItem.getText().equalsIgnoreCase(appName)){
                menuItem.click();
                break;
            }
        }
    }
    /*
   public BFOLendingPageObjects clickOnMyTeamAssignedFSR(){
        $x(MY_TEAM_ASSIGNED_FSR_LINK).shouldBe(visible,enabled);
     //  $x(MY_TEAM_ASSIGNED_FSR_LINK).shouldBe(visible,enabled,interactable).click();
         executeJavaScript("arguments[0].click();", $x(MY_TEAM_ASSIGNED_FSR_LINK));
     //    actions().moveToElement($x(MY_TEAM_ASSIGNED_FSR_LINK).shouldBe(visible, enabled,interactable)).clickAndHold().click().perform();
        return this;
   }
*/
    public BFOLendingPageObjects clickOnMyTeamAssignedFSR() {
        SelenideElement element = $x(MY_TEAM_ASSIGNED_FSR_LINK).shouldBe(visible, Duration.ofSeconds(60));
        element.scrollIntoView(true).click();
        CONSTANTS.captureScreen = true;
        return this;
    }


}
