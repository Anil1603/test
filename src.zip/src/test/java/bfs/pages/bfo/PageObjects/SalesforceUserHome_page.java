package bfs.pages.bfo.PageObjects;

import org.openqa.selenium.By;

import static com.codeborne.selenide.Selenide.open;

public class SalesforceUserHome_page {

    private static final By setup_Gear_icon = By.xpath("//a[contains(@class, 'menuTriggerLink')]/div[contains(@class, 'headerTrigger')]");


    public void navigateToPage(String pageName) {

        String url = "";
        switch (pageName.toLowerCase()) {
            case "setup":
                url = "https://se--uat24.sandbox.my.salesforce-setup.com/lightning/setup/SetupOneHome/home";
                break;
            case "home":
                url = "https://se--uat24.sandbox.lightning.force.com/lightning/page/home";
                break;
            case "developer console":
                url = "https://se--uat24.sandbox.my.salesforce.com/_ui/common/apex/debug/ApexCSIPage";
                break;
            default:
                throw new IllegalArgumentException("Invalid page name: " + pageName);
        }
        open(url);
    }
}
