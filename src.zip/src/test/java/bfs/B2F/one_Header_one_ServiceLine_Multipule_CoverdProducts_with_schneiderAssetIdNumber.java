package bfs.B2F;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.testng.annotations.Test;

import com.google.common.collect.Table.Cell;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class one_Header_one_ServiceLine_Multipule_CoverdProducts_with_schneiderAssetIdNumber extends getAccessToken{
	
	int boReferenceHeaderNumber=3791002;
	int boReferenceCoveredProductnumber=11650902;
	String serviceLines="";
	String CoverdProducts1="";

		@Test
		public void CreatingServiceLinesforFindErrors() throws IOException {
		String SID=accessToken;
			int z=0;
			FileInputStream fi=new FileInputStream(new File(System.getProperty("user.dir")+"/TestDataFilesFolder/serviceContracts/"+"ServiceContract_shippedSN.xlsx"));
			XSSFWorkbook xf=new XSSFWorkbook(fi);
			XSSFSheet sh=xf.getSheet("Sheet7");
			
			String assetIdNumber="a1aA0000007h0k6IAA";
			String schneiderAssetIdNumber="0029596139";
			
			DataFormatter formatter = new DataFormatter();
			
			
			XWPFDocument document = new XWPFDocument(); 
			 FileOutputStream out = new FileOutputStream(new File(System.getProperty("user.dir")+"/TestDataFilesFolder/serviceContracts/output/"+"one_Header_one_ServiceLine_Multipule_CoverdProducts_with_schneiderAssetIdNumber_output.docx"));
			
			 XWPFDocument document1 = new XWPFDocument(); 
			 FileOutputStream out1 = new FileOutputStream(new File(System.getProperty("user.dir")+"/TestDataFilesFolder/serviceContracts/payload/"+"one_Header_one_ServiceLine_Multipule_CoverdProducts_with_schneiderAssetIdNumber_payload.docx"));

			RestAssured.baseURI="https://se--uat24.sandbox.my.salesforce.com/services/apexrest/field-services/service-contracts";
				
			String CoverdProducts="{"
			      	  +"\"product\": {"
			          +"\"productId\": \"01tA0000004OaqZIAS\""
			            +"},"
			        +"\"asset\": {"
			        +"\"schneiderAssetId\": \""+schneiderAssetIdNumber+"\""
			            +"},"
			    +"\"boReferenceLine\": \"48188619786004983455606191212265764336\","
			          +"\"installedProductStartDate\": \"2023-09-01\","
			          +"\"installedProductEndDate\": \"2024-08-31\","
			          +"\"boReferenceCoveredProduct\": \"481886197860219084170807960207"+boReferenceCoveredProductnumber+"\","
			          +"\"pduIpBfoId\": \"\""
			          +"}";	
			String aa="";
			for(int y=1;y<=100;y++) {
				String val = formatter.formatCellValue(sh.getRow(y).getCell(2));
				assetIdNumber=sh.getRow(y).getCell(1).getStringCellValue().toString();
				XSSFCell cell=sh.getRow(y).getCell(2);
				schneiderAssetIdNumber=val.toString();
				aa="{"
				      	  +"\"product\": {"
				          +"\"productId\": \"01tA0000004OaqZIAS\""
				            +"},"
				        +"\"asset\": {"
				        +"\"schneiderAssetId\": \""+schneiderAssetIdNumber+"\""
				            +"},"
				    +"\"boReferenceLine\": \"48188619786004983455606191212265764336\","
				          +"\"installedProductStartDate\": \"2023-09-01\","
				          +"\"installedProductEndDate\": \"2024-08-31\","
				          +"\"boReferenceCoveredProduct\": \"481886197860219084170807960207"+boReferenceCoveredProductnumber+"\","
				          +"\"pduIpBfoId\": \"\""
				          +"}"+","+aa;
				boReferenceCoveredProductnumber++;
				z=y;
				
			}
            aa=aa.substring(0, aa.length()-1);
			CoverdProducts=aa;
			
			for(int x=0; x<=1;x++) {
				
				String payloadevalue="{"+
						"\"serviceContracts\": ["
						  +"{"
						+"\"contractNumber\": \"IT-1012762\","
						      +"\"boReferenceHeader\": 50537"+boReferenceHeaderNumber+","
						      +"\"status\": \"PCV\","
						      +"\"soldToAccount\": {"
						      +"\"bfoId\": \"001A000000jyEflIAE\","
						        +"\"name\": \"CISCO-SJC-MTV5\""
						        +"},"
						    +"\"poNumber\": 101972,"
						      +"\"startDate\": \"2023-09-01\","
						      +"\"endDate\": \"2024-08-31\","
						      +"\"serviceLines\": ["
						      +"{"
						    	  +"\"name\": 1,"
						          +"\"description\": \"APC Symmetra PX 100kW Power Frame 208V\","
						          +"\"previousContractLineId\": \"\","
						          +"\"startDate\": \"2023-09-01\","
						          +"\"endDate\": \"2024-08-31\","
						          +"\"coveredProducts\": ["
						          +CoverdProducts
								+"],"
				+"\"installedAtAccount\": {"
						          +"\"bfoId\": \"0011200001FplKFAAZ\""
						            +"},"
						+"\"skuComRef\": \"01tA0000004zVyQIAU\","
						          +"\"entitlement\": \"\","
						          +"\"price\": 6013.64,"
						          +"\"currencyCode\": \"USD\","
						          +"\"quantity\": 1,"
						          +"\"lineComment\": \"\","
						          +"\"boReferenceLine\": \"48188619786004983455606191212265764336\","
						          +"\"unitPrice\": 6013.64,"
						          +"\"volumeDiscount\": 0,"
						          +"\"additionalDiscount\": 22.4,"
						          +"\"cpqQuoteNumber\": \"2023-1850605-1\","
						          +"\"partsDiscount\": 100,"
						          +"\"laborDiscount\": 100,"
						          +"\"yearlyUnitPriceBeforeDiscount\": 6013.64,"
						          +"\"requestedPrice\": 6013.64,"
						          +"\"requestedPriceFlag\": true,"
						          +"\"quantityOfYear\": 1,"
						          +"\"proRateApplied\": true,"
						          +"\"upLift\": 6,"
						          +"\"discountValue\": 6013.64,"
						          +"\"discountType\": \"Net\","
						          +"\"initialDiscount\": 22.4,"
						          +"\"cumulativeDiscount\": 22.4,"
						          +"\"parentContractBoRef\": 50537379,"
						          +"\"boLastUpdateTimeStamp\": \"2023-09-13 01:44:46\","
						          +"\"schedulingUpgradeLineBoRef\": \"\","
						          +"\"slaUpgradeLineBoRef\": \"\""
						          +"}"
							  +"],"
							  +"\"description\": \"CISCO - SJC + MTV5 - 1 Year Addition\","
						      +"\"soldToContact\": {"
						      +"\"firstName\": \"DEBBIE\","
						        +"\"lastName\": \"POLLOCK\""
						        		+"},"
							  +"\"price\": 413820.14,"
						      +"\"currencyCode\": \"USD\","
						      +"\"leadingBu\": \"IT\","
						      +"\"evergreen\": false,"
						      +"\"sendCustomerRenewalNotification\": false,"
						      +"\"billToAccount\": {"
						      +"\"bfoId\": \"001A000000v58mnIAA\","
						        +"\"name\": \"CBRE – CISCO FM US\""
						        		+"},"
							  +"\"billToContact\": {"
						      +"\"firstName\": \"JOHN\","
						        +"\"lastName\": \"ALM\""
						        		+"},"
							  +"\"salesRepSesaId\": \"SESA519410\","
						      +"\"mainInstalledAtAccount\": {"
						      +"\"bfoId\": \"001A000000jyEflIAE\""
						        		+"},"
						      +"\"mainInstalledAtContact\": {"
						      +"\"firstName\": \"DEBBIE\","
						        +"\"lastName\": \"POLLOCK\""
						        		+"},"
							  +"\"cpqQuoteNumber\": \"2023-1850605-1\","
						      +"\"renewalNotes\": \"\","
						      +"\"renewedFrom\": \"a281H000001zsROQAY\","
						      +"\"countryOfBo\": \"Global\","
						      +"\"boSystem\": \"ITB_ORA\","
						      +"\"billingSchedule\": \"Quarterly\","
						      +"\"invoiceSchedule\": \"1st of Month\","
						      +"\"invoiceOption\": \"Not Applicable\","
						      +"\"renewalOpportunityReference\": \"OP-210503-10816016\","
						      +"\"amendmentOpportunityReference\": \"\","
						      +"\"ownerSesaId\": \"SESA367580\","
						      +"\"createdByBoUser\": \"\","
						      +"\"lastModifiedByBoUser\": \"\","+
						      "\"boLastUpdateTimeStamp\": \"2023-09-25 08:58:46\","+
						      "\"boBillToRecordId\": 3736908"+
						    "}"+
						  "]"+
						"}";
					
	RequestSpecification httpReqest1=RestAssured.given().auth().oauth2(SID).and().body(payloadevalue); 
	Response response1=httpReqest1.request(Method.POST); 
	String responsebody1=response1.getBody().asString();
	System.out.println(responsebody1);
	XWPFParagraph paragraph1 = document1.createParagraph();
	XWPFRun run1 = paragraph1.createRun();
	run1.setText("Payload  "+x+payloadevalue);
	
	XWPFParagraph paragraph = document.createParagraph();
	XWPFRun run = paragraph.createRun();
	run.setText(responsebody1);
	assetIdNumber=sh.getRow(z).getCell(1).getStringCellValue().toString();
	String val1 = formatter.formatCellValue(sh.getRow(z).getCell(2));
	schneiderAssetIdNumber=val1.toString();
				//CoverdProducts1=CoverdProducts+",";
				boReferenceHeaderNumber++;
				boReferenceCoveredProductnumber++;
				CoverdProducts=CoverdProducts+","+"{"
				      	  +"\"product\": {"
				          +"\"productId\": \"01tA0000004OaqZIAS\""
				            +"},"
				        +"\"asset\": {"
				        +"\"schneiderAssetId\": \""+schneiderAssetIdNumber+"\""
				            +"},"
				    +"\"boReferenceLine\": \"48188619786004983455606191212265764336\","
				          +"\"installedProductStartDate\": \"2023-09-01\","
				          +"\"installedProductEndDate\": \"2024-08-31\","
				          +"\"boReferenceCoveredProduct\": \"481886197860219084170807960207"+boReferenceCoveredProductnumber+"\","
				          +"\"pduIpBfoId\": \"\""
				          +"}";
				z++;
				}
			document1.write(out1);
			out1.close();
	document.write(out);
	out.close();
	
	System.out.println("createparagraph.docx written successfully");
		}
}
